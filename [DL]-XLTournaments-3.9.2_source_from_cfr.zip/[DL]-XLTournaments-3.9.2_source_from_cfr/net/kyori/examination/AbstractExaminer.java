/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.kyori.examination;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.function.IntFunction;
import java.util.stream.BaseStream;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import net.kyori.examination.Examinable;
import net.kyori.examination.ExaminableProperty;
import net.kyori.examination.Examiner;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractExaminer<R>
implements Examiner<R> {
    @Override
    @NotNull
    public R examine(@Nullable Object object) {
        if (object == null) {
            return this.nil();
        }
        if (object instanceof String) {
            return this.examine((String)object);
        }
        if (object instanceof Examinable) {
            return this.examine((Examinable)object);
        }
        if (object instanceof Collection) {
            return this.collection((Collection)object);
        }
        if (object instanceof Map) {
            return this.map((Map)object);
        }
        if (object.getClass().isArray()) {
            Class<?> class_ = object.getClass().getComponentType();
            if (class_.isPrimitive()) {
                if (class_ == Boolean.TYPE) {
                    return this.examine((boolean[])object);
                }
                if (class_ == Byte.TYPE) {
                    return this.examine((byte[])object);
                }
                if (class_ == Character.TYPE) {
                    return this.examine((char[])object);
                }
                if (class_ == Double.TYPE) {
                    return this.examine((double[])object);
                }
                if (class_ == Float.TYPE) {
                    return this.examine((float[])object);
                }
                if (class_ == Integer.TYPE) {
                    return this.examine((int[])object);
                }
                if (class_ == Long.TYPE) {
                    return this.examine((long[])object);
                }
                if (class_ == Short.TYPE) {
                    return this.examine((short[])object);
                }
            }
            return this.array((Object[])object);
        }
        if (object instanceof Boolean) {
            return this.examine((Boolean)object);
        }
        if (object instanceof Character) {
            return this.examine(((Character)object).charValue());
        }
        if (object instanceof Number) {
            if (object instanceof Byte) {
                return this.examine((Byte)object);
            }
            if (object instanceof Double) {
                return this.examine((Double)object);
            }
            if (object instanceof Float) {
                return this.examine(((Float)object).floatValue());
            }
            if (object instanceof Integer) {
                return this.examine((Integer)object);
            }
            if (object instanceof Long) {
                return this.examine((Long)object);
            }
            if (object instanceof Short) {
                return this.examine((Short)object);
            }
        } else if (object instanceof BaseStream) {
            if (object instanceof Stream) {
                return this.stream((Stream)object);
            }
            if (object instanceof DoubleStream) {
                return this.stream((DoubleStream)object);
            }
            if (object instanceof IntStream) {
                return this.stream((IntStream)object);
            }
            if (object instanceof LongStream) {
                return this.stream((LongStream)object);
            }
        }
        return this.scalar(object);
    }

    @NotNull
    private <E> R array(E @NotNull [] arrE) {
        return (R)this.array(arrE, Arrays.stream(arrE).map(this::examine));
    }

    @NotNull
    protected abstract <E> R array(E @NotNull [] var1, @NotNull Stream<R> var2);

    @NotNull
    private <E> R collection(@NotNull Collection<E> collection) {
        return (R)this.collection(collection, collection.stream().map(this::examine));
    }

    @NotNull
    protected abstract <E> R collection(@NotNull Collection<E> var1, @NotNull Stream<R> var2);

    @Override
    @NotNull
    public R examine(@NotNull String string, @NotNull Stream<? extends ExaminableProperty> stream) {
        return this.examinable(string, stream.map((? super T examinableProperty) -> new AbstractMap.SimpleImmutableEntry(examinableProperty.name(), examinableProperty.examine(this))));
    }

    @NotNull
    protected abstract R examinable(@NotNull String var1, @NotNull Stream<Map.Entry<String, R>> var2);

    @NotNull
    private <K, V> R map(@NotNull Map<K, V> map) {
        return this.map(map, map.entrySet().stream().map((? super T entry) -> new AbstractMap.SimpleImmutableEntry<R, R>(this.examine(entry.getKey()), this.examine(entry.getValue()))));
    }

    @NotNull
    protected abstract <K, V> R map(@NotNull Map<K, V> var1, @NotNull Stream<Map.Entry<R, R>> var2);

    @NotNull
    protected abstract R nil();

    @NotNull
    protected abstract R scalar(@NotNull Object var1);

    @NotNull
    protected abstract <T> R stream(@NotNull Stream<T> var1);

    @NotNull
    protected abstract R stream(@NotNull DoubleStream var1);

    @NotNull
    protected abstract R stream(@NotNull IntStream var1);

    @NotNull
    protected abstract R stream(@NotNull LongStream var1);

    @Override
    @NotNull
    public R examine(boolean @Nullable [] arrbl) {
        if (arrbl == null) {
            return this.nil();
        }
        return (R)this.array(arrbl.length, (int n) -> this.examine(arrbl[n]));
    }

    @Override
    @NotNull
    public R examine(byte @Nullable [] arrby) {
        if (arrby == null) {
            return this.nil();
        }
        return (R)this.array(arrby.length, (int n) -> this.examine(arrby[n]));
    }

    @Override
    @NotNull
    public R examine(char @Nullable [] arrc) {
        if (arrc == null) {
            return this.nil();
        }
        return (R)this.array(arrc.length, (int n) -> this.examine(arrc[n]));
    }

    @Override
    @NotNull
    public R examine(double @Nullable [] arrd) {
        if (arrd == null) {
            return this.nil();
        }
        return (R)this.array(arrd.length, (int n) -> this.examine(arrd[n]));
    }

    @Override
    @NotNull
    public R examine(float @Nullable [] arrf) {
        if (arrf == null) {
            return this.nil();
        }
        return (R)this.array(arrf.length, (int n) -> this.examine(arrf[n]));
    }

    @Override
    @NotNull
    public R examine(int @Nullable [] arrn) {
        if (arrn == null) {
            return this.nil();
        }
        return (R)this.array(arrn.length, (int n) -> this.examine(arrn[n]));
    }

    @Override
    @NotNull
    public R examine(long @Nullable [] arrl) {
        if (arrl == null) {
            return this.nil();
        }
        return (R)this.array(arrl.length, (int n) -> this.examine(arrl[n]));
    }

    @Override
    @NotNull
    public R examine(short @Nullable [] arrs) {
        if (arrs == null) {
            return this.nil();
        }
        return (R)this.array(arrs.length, (int n) -> this.examine(arrs[n]));
    }

    @NotNull
    protected abstract R array(int var1, IntFunction<R> var2);
}

