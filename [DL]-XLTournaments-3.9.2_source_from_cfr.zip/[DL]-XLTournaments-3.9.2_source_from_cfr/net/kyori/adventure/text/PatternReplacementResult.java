/*
 * Decompiled with CFR 0.150.
 */
package net.kyori.adventure.text;

public enum PatternReplacementResult {
    REPLACE,
    CONTINUE,
    STOP;

}

