/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$NonExtendable
 */
package net.kyori.adventure.text;

import org.jetbrains.annotations.ApiStatus;

@ApiStatus.NonExtendable
public enum ComponentIteratorFlag {
    INCLUDE_HOVER_SHOW_ENTITY_NAME,
    INCLUDE_HOVER_SHOW_TEXT_COMPONENT,
    INCLUDE_TRANSLATABLE_COMPONENT_ARGUMENTS;

}

