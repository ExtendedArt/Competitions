/*
 * Decompiled with CFR 0.150.
 */
package net.kyori.adventure.text.format;

public interface TextFormat {
}

