/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.kyori.adventure.text.format;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.Merger;
import net.kyori.adventure.text.format.StyleImpl;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

final class IfAbsentOnTargetMerger
implements Merger {
    static final IfAbsentOnTargetMerger INSTANCE = new IfAbsentOnTargetMerger();

    private IfAbsentOnTargetMerger() {
    }

    @Override
    public void mergeColor(StyleImpl.BuilderImpl builderImpl, @Nullable TextColor textColor) {
        if (builderImpl.color == null) {
            builderImpl.color(textColor);
        }
    }

    @Override
    public void mergeDecoration(StyleImpl.BuilderImpl builderImpl, @NotNull TextDecoration textDecoration, @NotNull TextDecoration.State state) {
        builderImpl.decorationIfAbsent(textDecoration, state);
    }

    @Override
    public void mergeClickEvent(StyleImpl.BuilderImpl builderImpl, @Nullable ClickEvent clickEvent) {
        if (builderImpl.clickEvent == null) {
            builderImpl.clickEvent(clickEvent);
        }
    }

    @Override
    public void mergeHoverEvent(StyleImpl.BuilderImpl builderImpl, @Nullable HoverEvent<?> hoverEvent) {
        if (builderImpl.hoverEvent == null) {
            builderImpl.hoverEvent(hoverEvent);
        }
    }

    @Override
    public void mergeInsertion(StyleImpl.BuilderImpl builderImpl, @Nullable String string) {
        if (builderImpl.insertion == null) {
            builderImpl.insertion(string);
        }
    }

    @Override
    public void mergeFont(StyleImpl.BuilderImpl builderImpl, @Nullable Key key) {
        if (builderImpl.font == null) {
            builderImpl.font(key);
        }
    }
}

