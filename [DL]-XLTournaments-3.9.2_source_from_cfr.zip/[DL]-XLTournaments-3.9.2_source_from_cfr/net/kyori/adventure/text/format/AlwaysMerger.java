/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.kyori.adventure.text.format;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.Merger;
import net.kyori.adventure.text.format.StyleImpl;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

final class AlwaysMerger
implements Merger {
    static final AlwaysMerger INSTANCE = new AlwaysMerger();

    private AlwaysMerger() {
    }

    @Override
    public void mergeColor(StyleImpl.BuilderImpl builderImpl, @Nullable TextColor textColor) {
        builderImpl.color(textColor);
    }

    @Override
    public void mergeDecoration(StyleImpl.BuilderImpl builderImpl, @NotNull TextDecoration textDecoration, @NotNull TextDecoration.State state) {
        builderImpl.decoration(textDecoration, state);
    }

    @Override
    public void mergeClickEvent(StyleImpl.BuilderImpl builderImpl, @Nullable ClickEvent clickEvent) {
        builderImpl.clickEvent(clickEvent);
    }

    @Override
    public void mergeHoverEvent(StyleImpl.BuilderImpl builderImpl, @Nullable HoverEvent<?> hoverEvent) {
        builderImpl.hoverEvent(hoverEvent);
    }

    @Override
    public void mergeInsertion(StyleImpl.BuilderImpl builderImpl, @Nullable String string) {
        builderImpl.insertion(string);
    }

    @Override
    public void mergeFont(StyleImpl.BuilderImpl builderImpl, @Nullable Key key) {
        builderImpl.font(key);
    }
}

