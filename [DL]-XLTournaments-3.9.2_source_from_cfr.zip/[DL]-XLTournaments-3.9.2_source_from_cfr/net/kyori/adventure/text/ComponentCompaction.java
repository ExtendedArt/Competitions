/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.kyori.adventure.text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.TextComponentImpl;
import net.kyori.adventure.text.event.HoverEventSource;
import net.kyori.adventure.text.format.Style;
import net.kyori.adventure.text.format.StyleSetter;
import net.kyori.adventure.text.format.TextDecoration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

final class ComponentCompaction {
    private static final TextDecoration[] DECORATIONS = TextDecoration.values();

    private ComponentCompaction() {
    }

    static Component compact(@NotNull Component component, @Nullable Style style) {
        Component component2;
        StyleSetter<Component> styleSetter;
        int n;
        StyleSetter<Style> styleSetter2;
        int n2;
        List<Component> list = component.children();
        Component component3 = component.children(Collections.emptyList());
        if (style != null) {
            component3 = component3.style(ComponentCompaction.simplifyStyle(component.style(), style));
        }
        if ((n2 = list.size()) == 0) {
            if (ComponentCompaction.isBlank(component3)) {
                component3 = component3.style(ComponentCompaction.simplifyStyleForBlank(component3.style()));
            }
            return component3;
        }
        if (n2 == 1 && component3 instanceof TextComponent && (styleSetter2 = (TextComponent)component3).content().isEmpty()) {
            Component component4 = list.get(0);
            return component4.style(component4.style().merge(component3.style(), Style.Merge.Strategy.IF_ABSENT_ON_TARGET)).compact();
        }
        styleSetter2 = component3.style();
        if (style != null) {
            styleSetter2 = styleSetter2.merge(style, Style.Merge.Strategy.IF_ABSENT_ON_TARGET);
        }
        ArrayList<Component> arrayList = new ArrayList<Component>(list.size());
        for (n = 0; n < list.size(); ++n) {
            styleSetter = list.get(n);
            if ((styleSetter = ComponentCompaction.compact((Component)styleSetter, styleSetter2)).children().isEmpty() && styleSetter instanceof TextComponent && (component2 = (TextComponent)styleSetter).content().isEmpty()) continue;
            arrayList.add((Component)styleSetter);
        }
        if (component3 instanceof TextComponent) {
            while (!arrayList.isEmpty()) {
                Component component5 = (Component)arrayList.get(0);
                styleSetter = component5.style().merge((Style)styleSetter2, Style.Merge.Strategy.IF_ABSENT_ON_TARGET);
                if (!(component5 instanceof TextComponent) || !Objects.equals(styleSetter, styleSetter2)) break;
                component3 = ComponentCompaction.joinText((TextComponent)component3, (TextComponent)component5);
                arrayList.remove(0);
                arrayList.addAll(0, component5.children());
            }
        }
        n = 0;
        while (n + 1 < arrayList.size()) {
            Style style2;
            Style style3;
            styleSetter = (Component)arrayList.get(n);
            component2 = (Component)arrayList.get(n + 1);
            if (styleSetter.children().isEmpty() && styleSetter instanceof TextComponent && component2 instanceof TextComponent && (style3 = styleSetter.style().merge((Style)styleSetter2, Style.Merge.Strategy.IF_ABSENT_ON_TARGET)).equals(style2 = component2.style().merge((Style)styleSetter2, Style.Merge.Strategy.IF_ABSENT_ON_TARGET))) {
                TextComponent textComponent = ComponentCompaction.joinText((TextComponent)styleSetter, (TextComponent)component2);
                arrayList.set(n, textComponent);
                arrayList.remove(n + 1);
                continue;
            }
            ++n;
        }
        if (arrayList.isEmpty() && ComponentCompaction.isBlank(component3)) {
            component3 = component3.style(ComponentCompaction.simplifyStyleForBlank(component3.style()));
        }
        return component3.children(arrayList);
    }

    @NotNull
    private static Style simplifyStyle(@NotNull Style style, @NotNull Style style2) {
        if (style.isEmpty()) {
            return style;
        }
        Style.Builder builder = style.toBuilder();
        if (Objects.equals(style.font(), style2.font())) {
            builder.font(null);
        }
        if (Objects.equals(style.color(), style2.color())) {
            builder.color(null);
        }
        for (TextDecoration textDecoration : DECORATIONS) {
            if (style.decoration(textDecoration) != style2.decoration(textDecoration)) continue;
            builder.decoration(textDecoration, TextDecoration.State.NOT_SET);
        }
        if (Objects.equals(style.clickEvent(), style2.clickEvent())) {
            builder.clickEvent(null);
        }
        if (Objects.equals(style.hoverEvent(), style2.hoverEvent())) {
            builder.hoverEvent((HoverEventSource)null);
        }
        if (Objects.equals(style.insertion(), style2.insertion())) {
            builder.insertion(null);
        }
        return builder.build();
    }

    private static boolean isBlank(Component component) {
        if (component instanceof TextComponent) {
            TextComponent textComponent = (TextComponent)component;
            String string = textComponent.content();
            for (int i = 0; i < string.length(); ++i) {
                char c = string.charAt(i);
                if (c == ' ') continue;
                return false;
            }
            return true;
        }
        return false;
    }

    @NotNull
    private static Style simplifyStyleForBlank(@NotNull Style style) {
        Style.Builder builder = style.toBuilder();
        builder.color(null);
        builder.decoration(TextDecoration.ITALIC, TextDecoration.State.NOT_SET);
        builder.decoration(TextDecoration.OBFUSCATED, TextDecoration.State.NOT_SET);
        return builder.build();
    }

    private static TextComponent joinText(TextComponent textComponent, TextComponent textComponent2) {
        return TextComponentImpl.create(textComponent2.children(), textComponent.style(), textComponent.content() + textComponent2.content());
    }
}

