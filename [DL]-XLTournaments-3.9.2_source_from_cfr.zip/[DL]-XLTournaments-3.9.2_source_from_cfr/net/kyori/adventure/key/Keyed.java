/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.kyori.adventure.key;

import net.kyori.adventure.key.Key;
import org.jetbrains.annotations.NotNull;

public interface Keyed {
    @NotNull
    public Key key();
}

