/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.ApiStatus$ScheduledForRemoval
 *  org.jetbrains.annotations.NotNull
 */
package net.kyori.adventure.util;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

public interface Codec<D, E, DX extends Throwable, EX extends Throwable> {
    @NotNull
    public static <D, E, DX extends Throwable, EX extends Throwable> Codec<D, E, DX, EX> codec(final @NotNull Decoder<D, E, DX> decoder, final @NotNull Encoder<D, E, EX> encoder) {
        return new Codec<D, E, DX, EX>(){

            @Override
            @NotNull
            public D decode(@NotNull E e) {
                return decoder.decode(e);
            }

            @Override
            @NotNull
            public E encode(@NotNull D d) {
                return encoder.encode(d);
            }
        };
    }

    @Deprecated
    @ApiStatus.ScheduledForRemoval(inVersion="5.0.0")
    @NotNull
    public static <D, E, DX extends Throwable, EX extends Throwable> Codec<D, E, DX, EX> of(final @NotNull Decoder<D, E, DX> decoder, final @NotNull Encoder<D, E, EX> encoder) {
        return new Codec<D, E, DX, EX>(){

            @Override
            @NotNull
            public D decode(@NotNull E e) {
                return decoder.decode(e);
            }

            @Override
            @NotNull
            public E encode(@NotNull D d) {
                return encoder.encode(d);
            }
        };
    }

    @NotNull
    public D decode(@NotNull E var1) throws DX;

    @NotNull
    public E encode(@NotNull D var1) throws EX;

    public static interface Encoder<D, E, X extends Throwable> {
        @NotNull
        public E encode(@NotNull D var1) throws X;
    }

    public static interface Decoder<D, E, X extends Throwable> {
        @NotNull
        public D decode(@NotNull E var1) throws X;
    }
}

