/*
 * Decompiled with CFR 0.150.
 */
package net.kyori.adventure.util;

@FunctionalInterface
public interface IntFunction2<R> {
    public R apply(int var1, int var2);
}

