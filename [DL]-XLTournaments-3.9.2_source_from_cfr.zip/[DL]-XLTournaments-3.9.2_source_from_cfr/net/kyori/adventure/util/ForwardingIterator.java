/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.kyori.adventure.util;

import java.util.Iterator;
import java.util.Objects;
import java.util.Spliterator;
import java.util.function.Supplier;
import org.jetbrains.annotations.NotNull;

public final class ForwardingIterator<T>
implements Iterable<T> {
    private final Supplier<Iterator<T>> iterator;
    private final Supplier<Spliterator<T>> spliterator;

    public ForwardingIterator(@NotNull Supplier<Iterator<T>> supplier, @NotNull Supplier<Spliterator<T>> supplier2) {
        this.iterator = Objects.requireNonNull(supplier, "iterator");
        this.spliterator = Objects.requireNonNull(supplier2, "spliterator");
    }

    @Override
    @NotNull
    public Iterator<T> iterator() {
        return this.iterator.get();
    }

    @Override
    @NotNull
    public Spliterator<T> spliterator() {
        return this.spliterator.get();
    }
}

