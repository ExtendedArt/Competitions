/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.kyori.adventure.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

public final class MonkeyBars {
    private MonkeyBars() {
    }

    @SafeVarargs
    @NotNull
    public static <E extends Enum<E>> Set<E> enumSet(Class<E> class_, E ... arrE) {
        EnumSet<E> enumSet = EnumSet.noneOf(class_);
        Collections.addAll(enumSet, arrE);
        return Collections.unmodifiableSet(enumSet);
    }

    @NotNull
    public static <T> List<T> addOne(@NotNull List<T> list, T t) {
        if (list.isEmpty()) {
            return Collections.singletonList(t);
        }
        ArrayList<T> arrayList = new ArrayList<T>(list.size() + 1);
        arrayList.addAll(list);
        arrayList.add(t);
        return Collections.unmodifiableList(arrayList);
    }
}

