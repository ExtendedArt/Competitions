/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.kyori.adventure.translation;

import org.jetbrains.annotations.NotNull;

public interface Translatable {
    @NotNull
    public String translationKey();
}

