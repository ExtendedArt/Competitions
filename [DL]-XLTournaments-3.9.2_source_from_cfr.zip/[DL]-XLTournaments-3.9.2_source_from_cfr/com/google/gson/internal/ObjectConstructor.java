/*
 * Decompiled with CFR 0.150.
 */
package com.google.gson.internal;

public interface ObjectConstructor<T> {
    public T construct();
}

