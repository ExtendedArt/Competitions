/*
 * Decompiled with CFR 0.150.
 */
package org.slf4j.helpers;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.Util;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public final class MessageFormatter {
    static final char DELIM_START = '{';
    static final char DELIM_STOP = '}';
    static final String DELIM_STR = "{}";
    private static final char ESCAPE_CHAR = '\\';

    public static final FormattingTuple format(String string, Object object) {
        return MessageFormatter.arrayFormat(string, new Object[]{object});
    }

    public static final FormattingTuple format(String string, Object object, Object object2) {
        return MessageFormatter.arrayFormat(string, new Object[]{object, object2});
    }

    public static final FormattingTuple arrayFormat(String string, Object[] arrobject) {
        Throwable throwable = MessageFormatter.getThrowableCandidate(arrobject);
        Object[] arrobject2 = arrobject;
        if (throwable != null) {
            arrobject2 = MessageFormatter.trimmedCopy(arrobject);
        }
        return MessageFormatter.arrayFormat(string, arrobject2, throwable);
    }

    public static final FormattingTuple arrayFormat(String string, Object[] arrobject, Throwable throwable) {
        if (string == null) {
            return new FormattingTuple(null, arrobject, throwable);
        }
        if (arrobject == null) {
            return new FormattingTuple(string);
        }
        int n = 0;
        StringBuilder stringBuilder = new StringBuilder(string.length() + 50);
        for (int i = 0; i < arrobject.length; ++i) {
            int n2 = string.indexOf(DELIM_STR, n);
            if (n2 == -1) {
                if (n == 0) {
                    return new FormattingTuple(string, arrobject, throwable);
                }
                stringBuilder.append(string, n, string.length());
                return new FormattingTuple(stringBuilder.toString(), arrobject, throwable);
            }
            if (MessageFormatter.isEscapedDelimeter(string, n2)) {
                if (!MessageFormatter.isDoubleEscaped(string, n2)) {
                    --i;
                    stringBuilder.append(string, n, n2 - 1);
                    stringBuilder.append('{');
                    n = n2 + 1;
                    continue;
                }
                stringBuilder.append(string, n, n2 - 1);
                MessageFormatter.deeplyAppendParameter(stringBuilder, arrobject[i], new HashMap<Object[], Object>());
                n = n2 + 2;
                continue;
            }
            stringBuilder.append(string, n, n2);
            MessageFormatter.deeplyAppendParameter(stringBuilder, arrobject[i], new HashMap<Object[], Object>());
            n = n2 + 2;
        }
        stringBuilder.append(string, n, string.length());
        return new FormattingTuple(stringBuilder.toString(), arrobject, throwable);
    }

    static final boolean isEscapedDelimeter(String string, int n) {
        if (n == 0) {
            return false;
        }
        char c = string.charAt(n - 1);
        return c == '\\';
    }

    static final boolean isDoubleEscaped(String string, int n) {
        return n >= 2 && string.charAt(n - 2) == '\\';
    }

    private static void deeplyAppendParameter(StringBuilder stringBuilder, Object object, Map<Object[], Object> map) {
        if (object == null) {
            stringBuilder.append("null");
            return;
        }
        if (!object.getClass().isArray()) {
            MessageFormatter.safeObjectAppend(stringBuilder, object);
        } else if (object instanceof boolean[]) {
            MessageFormatter.booleanArrayAppend(stringBuilder, (boolean[])object);
        } else if (object instanceof byte[]) {
            MessageFormatter.byteArrayAppend(stringBuilder, (byte[])object);
        } else if (object instanceof char[]) {
            MessageFormatter.charArrayAppend(stringBuilder, (char[])object);
        } else if (object instanceof short[]) {
            MessageFormatter.shortArrayAppend(stringBuilder, (short[])object);
        } else if (object instanceof int[]) {
            MessageFormatter.intArrayAppend(stringBuilder, (int[])object);
        } else if (object instanceof long[]) {
            MessageFormatter.longArrayAppend(stringBuilder, (long[])object);
        } else if (object instanceof float[]) {
            MessageFormatter.floatArrayAppend(stringBuilder, (float[])object);
        } else if (object instanceof double[]) {
            MessageFormatter.doubleArrayAppend(stringBuilder, (double[])object);
        } else {
            MessageFormatter.objectArrayAppend(stringBuilder, (Object[])object, map);
        }
    }

    private static void safeObjectAppend(StringBuilder stringBuilder, Object object) {
        try {
            String string = object.toString();
            stringBuilder.append(string);
        }
        catch (Throwable throwable) {
            Util.report("SLF4J: Failed toString() invocation on an object of type [" + object.getClass().getName() + "]", throwable);
            stringBuilder.append("[FAILED toString()]");
        }
    }

    private static void objectArrayAppend(StringBuilder stringBuilder, Object[] arrobject, Map<Object[], Object> map) {
        stringBuilder.append('[');
        if (!map.containsKey(arrobject)) {
            map.put(arrobject, null);
            int n = arrobject.length;
            for (int i = 0; i < n; ++i) {
                MessageFormatter.deeplyAppendParameter(stringBuilder, arrobject[i], map);
                if (i == n - 1) continue;
                stringBuilder.append(", ");
            }
            map.remove(arrobject);
        } else {
            stringBuilder.append("...");
        }
        stringBuilder.append(']');
    }

    private static void booleanArrayAppend(StringBuilder stringBuilder, boolean[] arrbl) {
        stringBuilder.append('[');
        int n = arrbl.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrbl[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void byteArrayAppend(StringBuilder stringBuilder, byte[] arrby) {
        stringBuilder.append('[');
        int n = arrby.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrby[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void charArrayAppend(StringBuilder stringBuilder, char[] arrc) {
        stringBuilder.append('[');
        int n = arrc.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrc[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void shortArrayAppend(StringBuilder stringBuilder, short[] arrs) {
        stringBuilder.append('[');
        int n = arrs.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrs[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void intArrayAppend(StringBuilder stringBuilder, int[] arrn) {
        stringBuilder.append('[');
        int n = arrn.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrn[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void longArrayAppend(StringBuilder stringBuilder, long[] arrl) {
        stringBuilder.append('[');
        int n = arrl.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrl[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void floatArrayAppend(StringBuilder stringBuilder, float[] arrf) {
        stringBuilder.append('[');
        int n = arrf.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrf[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    private static void doubleArrayAppend(StringBuilder stringBuilder, double[] arrd) {
        stringBuilder.append('[');
        int n = arrd.length;
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(arrd[i]);
            if (i == n - 1) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append(']');
    }

    public static Throwable getThrowableCandidate(Object[] arrobject) {
        if (arrobject == null || arrobject.length == 0) {
            return null;
        }
        Object object = arrobject[arrobject.length - 1];
        if (object instanceof Throwable) {
            return (Throwable)object;
        }
        return null;
    }

    public static Object[] trimmedCopy(Object[] arrobject) {
        if (arrobject == null || arrobject.length == 0) {
            throw new IllegalStateException("non-sensical empty or null argument array");
        }
        int n = arrobject.length - 1;
        Object[] arrobject2 = new Object[n];
        if (n > 0) {
            System.arraycopy(arrobject, 0, arrobject2, 0, n);
        }
        return arrobject2;
    }
}

