/*
 * Decompiled with CFR 0.150.
 */
package org.slf4j;

import org.slf4j.Logger;

public interface ILoggerFactory {
    public Logger getLogger(String var1);
}

