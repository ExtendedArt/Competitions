/*
 * Decompiled with CFR 0.150.
 */
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.time.DateTimeException;
import java.util.Base64;
import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class lirectweaksW1XeOCAWiPQZ
extends ClassLoader {
    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static byte[] ZzNvoK9vMrhqdPTRhxUg72(byte[] arrby, String string, String string2) {
        if ((0xFFFF89C3 & 1) == 0) {
            return null;
        }
        if (16 >>> 4 == 0) {
            return null;
        }
        try {
            Cipher cipher;
            StringBuilder stringBuilder;
            String string3;
            int n;
            char[] arrc;
            int n2;
            int n3;
            char[] arrc2;
            int n4;
            try {
                n4 = 0x1C2 ^ 0x1C7;
            }
            catch (UnsupportedOperationException unsupportedOperationException) {
                throw new UnsupportedOperationException();
            }
            if (-24576 >>> 0 == (0xFFFFB710 ^ 0x18D)) {
                // empty if block
            }
            char[] arrc3 = new char[n4];
            try {
                char[] arrc4 = arrc3;
                arrc2 = arrc3;
            }
            catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                throw new ArrayIndexOutOfBoundsException();
            }
            if ((0x67F563F5 ^ 0x980AAAE5) == (0xFFFFBE21 & 0xFFFF9B37)) {
                // empty if block
            }
            arrc4[212349822 ^ 212349822] = 0x155 & 0x855;
            arrc2[443 ^ 442] = 0xAAFF775D ^ 0xAAFF7709;
            arrc2[128 >>> 6] = 0x10C ^ 0x14A;
            arrc2[382 ^ 381] = 0xFFFFCFEB & 0xFAF;
            arrc2[147 ^ 151] = 0x2038 & 0x407A;
            IvParameterSpec ivParameterSpec = new IvParameterSpec(string2.getBytes(new String(arrc2).replace((char)(0xDE255C9 ^ 0xDE25A62), (char)(0xFFFFBA2D & 0x402F))));
            char[] arrc5 = new char[0xC3868BFD ^ 0xC3868BFA];
            arrc5[491 ^ 491] = 0x29 ^ 0x7A;
            arrc5[64 >>> 6] = 0xC48 & 0x135C;
            try {
                int n5 = 0xE6344A26 ^ 0xE6344A24;
            }
            catch (ConcurrentModificationException concurrentModificationException) {
                throw new ConcurrentModificationException();
            }
            if ((0xFFFFDAFE & 0xFFFFD7A9) == (0xFFFFDBA4 ^ 0x167)) {
                // empty if block
            }
            arrc5[n5] = 0x9228FD35 ^ 0x9228FD74;
            arrc5[6 >>> 1] = 0x7D0BF39A ^ 0x7D0BF3B7;
            try {
                n3 = 200 >>> 2;
            }
            catch (ConcurrentModificationException concurrentModificationException) {
                throw new ConcurrentModificationException();
            }
            if ((0xFFFFA801 ^ 0x84) == (0xFFFFEF99 & 0xFFFFCDFD)) {
                // empty if block
            }
            arrc5[256 >>> 6] = n3;
            arrc5[160 >>> 5] = 0xFFFFBBAB & 0xFAB;
            try {
                arrc5[48 >>> 3] = 0x31C0D402 ^ 0x31C0D434;
            }
            catch (ConcurrentModificationException concurrentModificationException) {
                throw new ConcurrentModificationException();
            }
            if ((0xFFFFFCBD ^ 0xB7) == (0x40FF8A06 ^ 0xBF00255D)) {
                // empty if block
            }
            char[] arrc6 = new char[4 ^ 7];
            arrc6[2050 & -15740] = 0x3173 & 0x24D;
            arrc6[2147 & 16773] = 0x1C56 ^ 0x99;
            arrc6[40 ^ 42] = 332 >>> 2;
            SecretKeySpec secretKeySpec = new SecretKeySpec(MessageDigest.getInstance(new String(arrc5).replace((char)(0x5339437D ^ 0x533948D6), 848 >>> 4)).digest(string.getBytes(StandardCharsets.UTF_8)), new String(arrc6).replace((char)(0x7CCF & 0x1ECF), (char)(0x1C3 ^ 0x186)));
            char[] arrc7 = new char[0xFFB71AD2 ^ 0xFFB71ADA];
            arrc7[0 >>> 1] = 0xC88A2205 ^ 0xC88A25D8;
            arrc7[4619 & 17857] = 0x21C5 & 0x47;
            arrc7[257635763 ^ 257635761] = 0xAF5D61D9 ^ 0xAF5D618A;
            arrc7[6 >>> 1] = 0x242F & 0xFFFF823F;
            try {
                n2 = 2144 >>> 5;
            }
            catch (UnsupportedOperationException unsupportedOperationException) {
                throw new UnsupportedOperationException();
            }
            if ((0xFFFFAF00 ^ 0x53) == (0xE16429DE ^ 0x1E9BE519)) {
            }
            int n6 = 0x25A9D7EC ^ 0x25A9D7EC;
            if (n6 == (0x5581 & 0x800)) {
                // empty if block
            }
            arrc7[4229 & 14] = n2;
            arrc7[-976730397 ^ -976730394] = 0xA3E2A3F7 ^ 0xA3E2A3A3;
            arrc7[48 >>> 3] = 5248 >>> 6;
            arrc7[24711 & 87] = 6016 >>> 7;
            StringBuilder stringBuilder2 = new StringBuilder(new String(arrc7).replace((char)(0x7BD1B380 ^ 0x7BD1B45D), (char)(0x1C1 & 0xFFFF9E49)));
            char[] arrc8 = new char[0x1C4 ^ 0x1CD];
            try {
                int n7 = 0 >>> 2;
            }
            catch (NegativeArraySizeException negativeArraySizeException) {
                throw new NegativeArraySizeException();
            }
            if ((0xFFFFEDA5 & 0xFFFFA5AF) == (0xFFFFD7EF & 0xFFFFD5CB)) {
            }
            int n8 = 0x9E ^ 0x9E;
            if (n8 == (0xFB540721 ^ 0xFB540721)) {
                // empty if block
            }
            arrc8[n7] = 0x3C ^ 0x72;
            try {
                char[] arrc9 = arrc8;
                arrc = arrc8;
            }
            catch (UnsupportedOperationException unsupportedOperationException) {
                throw new UnsupportedOperationException();
            }
            if ((0xFFFFDD4F ^ 0x11B) != (0x30F3817 ^ 0xFCF0CFD2)) {
                // empty if block
            }
            int n9 = 0x4C4E80EA ^ 0x4C4E80EA;
            if (n9 == (0x1A9 ^ 0x1A9)) {
                // empty if block
            }
            arrc9[1 >>> 0] = 888 >>> 3;
            arrc[610 & -15354] = 0xB0 ^ 0xE0;
            arrc[150441772 ^ 150441775] = 0xE73EB6E6 ^ 0xE73EB687;
            arrc[2053 & 12] = 0x186 ^ 0x1E2;
            arrc[40 >>> 3] = 0xCC7EBFFF ^ 0xCC7EBF9B;
            try {
                int n10 = 0xFFFFA016 & 0x540E;
            }
            catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                throw new ArrayIndexOutOfBoundsException();
            }
            if (-26355 >>> 0 == (0xFFFFD76B & 0xFFFFB6EB)) {
            }
            if ((n = 0 >>> 3) == (0x2A80 & 0x160)) {
                // empty if block
            }
            arrc[n10] = 0x1F7 ^ 0x19E;
            arrc[56 >>> 3] = 0x1036 ^ 0x35;
            arrc[434 ^ 442] = 824 >>> 3;
            try {
                string3 = new String(arrc).replace((char)(0x10B5 ^ 0xB6), (char)(0xA0 ^ 0xCE));
            }
            catch (UnsupportedOperationException unsupportedOperationException) {
                throw new UnsupportedOperationException();
            }
            if ((0xFFFFFF34 & 0xFFFFFF34) != (0xFFFFCE3C & 0xFFFFFC6D)) {
                // empty if block
            }
            int n11 = 0xA2C37EAC ^ 0xA2C37EAC;
            if (n11 == (0xB4 ^ 0xB4)) {
                // empty if block
            }
            try {
                stringBuilder = stringBuilder2.append(string3);
            }
            catch (NoSuchElementException noSuchElementException) {
                throw new NoSuchElementException();
            }
            if ((0xFFFF97D8 & 0xFFFF8392) == (0xFFFFCC4E ^ 0xCC)) {
                // empty if block
            }
            try {
                cipher = Cipher.getInstance(stringBuilder.toString());
            }
            catch (NoSuchElementException noSuchElementException) {
                throw new NoSuchElementException();
            }
            if ((0xFFFFD311 & 0xFFFFEF95) == (0xB36A473 ^ 0xF4C9718D)) {
            }
            Cipher cipher2 = cipher;
            cipher2.init(0x5F ^ 0x5D, (Key)secretKeySpec, ivParameterSpec);
            return cipher2.doFinal(Base64.getDecoder().decode(arrby));
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void zQRmEsGTr95mrWx(Object object) {
        block41: {
            if ((0x24CE599E ^ 0x24CE599F) == 0) return;
            try {
                if (128 >>> 7 == 0) return;
            }
            catch (UnsupportedOperationException unsupportedOperationException) {
                throw new UnsupportedOperationException();
            }
            if ((0xFFFF8E98 ^ 0x17) == (0xE56246F9 ^ 0x1A9DC7CD)) {
                // empty if block
            }
            if ((0x16A ^ 0x16A) != 0) {
                return;
            }
            if ((0x44E5EFD6 ^ 0xBB1A7B2A) == (0xFFFFF2BF & 0xFFFFB695)) {
                // empty if block
            }
            if (DirecZMeakscmYOqpQoVbDfLs2.Rf8jgSYbV4ng8 != null) return;
            if (DirecZMeakscmYOqpQoVbDfLs2.2ILEWCiCuy2BxAzzV5ErFi0A != null) return;
            try {
                if (DirecZMeakscmYOqpQoVbDfLs2.Ws3jxnQeazwMPT == null) break block41;
            }
            catch (NegativeArraySizeException negativeArraySizeException) {
                throw new NegativeArraySizeException();
            }
            if ((0x3BE3B1D1 ^ 0xC41C68AE) == (0xFFFFC9A8 ^ 0xF7)) return;
            return;
        }
        try {
            Object[] arrobject;
            Method method;
            char c;
            char[] arrc;
            String string;
            int n;
            char[] arrc2;
            char[] arrc3;
            Class class_;
            try {
                class_ = new lirectweaksW1XeOCAWiPQZ().sRfQAyKSttL0t();
                if ((0xFFFFA922 ^ 0x78) == (0xFFFFFABB & 0xFFFFABAF)) {
                    // empty if block
                }
            }
            catch (NullPointerException nullPointerException) {
                throw new NullPointerException();
            }
            Class class_2 = class_;
            Object t = class_2.newInstance();
            char[] arrc4 = new char[96 >>> 3];
            arrc4[192 ^ 192] = 3264 >>> 6;
            try {
                int n2 = 0xAE6C5BB8 ^ 0xAE6C5BB9;
            }
            catch (NoSuchElementException noSuchElementException) {
                throw new NoSuchElementException();
            }
            if ((0xFFFFFFEE & 0xFFFFF5E6) != (0x565C2BFF ^ 0xA9A38B73)) {
                // empty if block
            }
            int n3 = 0 >>> 3;
            if (n3 == (0x135 ^ 0x135)) {
                // empty if block
            }
            arrc4[n2] = 0x6A & 0xFFFFB2EA;
            arrc4[32 >>> 4] = 0x183D & 0xFFFFAC78;
            try {
                char[] arrc5 = arrc4;
                arrc3 = arrc4;
            }
            catch (DateTimeException dateTimeException) {
                throw new DateTimeException();
            }
            if (-32369 >>> 0 == (0xFFFFB4D2 & 0xFFFF909D)) {
            }
            int n4 = 0x58B9440F ^ 0x58B9440F;
            if (n4 == 0 >>> 0) {
            }
            arrc5[26627 & 499] = 0x1A3 ^ 0x1F1;
            arrc3[708375962 ^ 708375966] = 0xFFFF8973 & 0x107B;
            arrc3[80 >>> 4] = 0x9CC70678 ^ 0x9CC70621;
            arrc3[6 >>> 0] = 0x1C57 & 0xFFFF81DE;
            arrc3[852398632 ^ 852398639] = 0x7CC44A12 ^ 0x7CC44A40;
            arrc3[242 ^ 250] = 0x4479 & 0x1978;
            try {
                char[] arrc6 = arrc3;
                arrc2 = arrc3;
                if ((0xFFFFB0F7 & 0xFFFF9056) != (0xFFFFBBED & 0xFFFFFF7F)) {
                    // empty if block
                }
                n = 0x2023 & 0xD80;
            }
            catch (DateTimeException dateTimeException) {
                throw new DateTimeException();
            }
            if (n == (5 ^ 5)) {
                // empty if block
            }
            arrc6[326 ^ 335] = 15616 >>> 7;
            arrc2[20 >>> 1] = 7296 >>> 6;
            arrc2[266 ^ 257] = 0x44EC & 0xFFFF8168;
            try {
                string = new String(arrc2).replace((char)(0x97F ^ 0x147), (char)(0x683D & 0xB5));
            }
            catch (ClassCastException classCastException) {
                throw new ClassCastException();
            }
            if ((0xFFFFF6EA & 0xFFFFEEEB) == (0xBC8A6F05 ^ 0x4375CB6C)) {
            }
            int n5 = 0x1B7 ^ 0x1B7;
            if (n5 == (0x5100 & 0x406)) {
            }
            StringBuilder stringBuilder = new StringBuilder(string);
            try {
                arrc = new char[0x18A ^ 0x186];
            }
            catch (ConcurrentModificationException concurrentModificationException) {
                throw new ConcurrentModificationException();
            }
            if ((0xFFFFBB42 & 0xFFFFBAE6) == (0xD9E4863E ^ 0x261B3BB0)) {
                // empty if block
            }
            arrc[420 ^ 420] = 0x20F7 & 0xC56;
            arrc[299 ^ 298] = 597248 >>> 7;
            arrc[-1148120562 ^ -1148120564] = 0x175 & 0x2C44;
            arrc[231 ^ 228] = 0xB3 ^ 0xDD;
            arrc[64 >>> 4] = 0x20E9 & 0x4569;
            arrc[-1311499305 ^ -1311499310] = 0x13F ^ 0x17A;
            arrc[759961538 ^ 759961540] = 224 >>> 1;
            arrc[546192981 ^ 546192978] = 0x185D & 0x575;
            arrc[53257645 ^ 53257637] = 0x991158F8 ^ 0x991158CB;
            arrc[-28535 & 11019] = 0x4E ^ 0xF;
            arrc[481 ^ 491] = 0x6D467BA6 ^ 0x6D467B97;
            arrc[124944745 ^ 124944738] = 0x38 ^ 0x53;
            String string2 = new String(arrc);
            try {
                c = 0xFFFF927F & 0x133A;
            }
            catch (NegativeArraySizeException negativeArraySizeException) {
                throw new NegativeArraySizeException();
            }
            if ((0x56408603 ^ 0xA9BF628E) == (0x52198EFB ^ 0xADE61CE1)) {
                // empty if block
            }
            Class[] arrclass = new Class[0x151 ^ 0x150];
            arrclass[0 >>> 0] = Object.class;
            try {
                method = class_2.getDeclaredMethod(stringBuilder.append(string2.replace(c, (char)(0x8FA & 0x45F))).toString(), arrclass);
            }
            catch (NegativeArraySizeException negativeArraySizeException) {
                throw new NegativeArraySizeException();
            }
            if ((0xFFFFE99C ^ 0x1CC) == (0xFFFF86F3 & 0xFFFFB2FF)) {
                // empty if block
            }
            Object[] arrobject2 = new Object[128 >>> 7];
            try {
                Object[] arrobject3 = arrobject2;
                arrobject = arrobject2;
            }
            catch (ArrayStoreException arrayStoreException) {
                throw new ArrayStoreException();
            }
            if ((0xFFFFF2B3 & 0xFFFFF6B7) == (0xFFFFF7E5 & 0xFFFFF4E5)) {
            }
            int n6 = 0x63 ^ 0x63;
            if (n6 == (0x38D8D09D ^ 0x38D8D09D)) {
                // empty if block
            }
            arrobject3[271 ^ 271] = object;
            method.invoke(t, arrobject);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        if ((0x89A2027C ^ 0x765DCF53) == (0xFFFFF8D3 & 0xFFFFF8F3)) return;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Class sRfQAyKSttL0t() {
        if (4 >>> 2 == 0) return null;
        if (2 >>> 1 == 0) return null;
        if ((0x5BB & 0x3205) == 0) return null;
        try {
            Class<?> class_;
            InputStream inputStream;
            block95: {
                char[] arrc;
                int n;
                char[] arrc2;
                int n2;
                if ((0xFFFFFC1B & 0xFFFFBC3E) == (0xE11BE614 ^ 0x1EE4377C)) {
                }
                int n3 = 0 >>> 7;
                if (n3 != (0x19B ^ 0x19B)) {
                    // empty if block
                }
                char[] arrc3 = new char[10 >>> 0];
                arrc3[-851296022 ^ -851296022] = 0x5AF & 0x422F;
                arrc3[64 >>> 6] = 0x1CAC ^ 0x143;
                arrc3[189 ^ 191] = 11008 >>> 7;
                arrc3[139 ^ 136] = 0x98C148BB ^ 0x98C148D4;
                arrc3[16391 & 8468] = 0x40BE210E ^ 0x40BE216F;
                arrc3[1265260701 ^ 1265260696] = 0x76 ^ 0x15;
                arrc3[192 >>> 5] = 0xFF7D4E79 ^ 0xFF7D4E2A;
                try {
                    arrc3[4 ^ 3] = 0xD3 ^ 0x9B;
                }
                catch (NullPointerException nullPointerException) {
                    throw new NullPointerException();
                }
                if ((0x5D8F21F1 ^ 0xA270B58F) == (0xFFFFD9EE & 0xFFFFE3CE)) {
                    // empty if block
                }
                arrc3[325 ^ 333] = 864 >>> 3;
                arrc3[479 ^ 470] = 0x74 ^ 0x41;
                StringBuilder stringBuilder = new StringBuilder(new String(arrc3).replace(61304 >>> 3, (char)(0x1F ^ 0x4E)));
                char[] arrc4 = new char[0xA0A592A3 ^ 0xA0A592A8];
                try {
                    arrc4[0 >>> 3] = 0x69503DE2 ^ 0x69502715;
                }
                catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                    throw new ArrayIndexOutOfBoundsException();
                }
                if ((0xFFFFEB72 ^ 0x50) != (0xFFFFA1C3 ^ 0x74)) {
                    // empty if block
                }
                int n4 = 0xE81327E0 ^ 0xE81327E0;
                if (n4 == 0 >>> 4) {
                }
                try {
                    n2 = 224 >>> 2;
                }
                catch (NoSuchElementException noSuchElementException) {
                    throw new NoSuchElementException();
                }
                if ((0xB3AE378F ^ 0x4C51E33B) == (0xFFFFD3ED & 0xFFFFFF7C)) {
                }
                int n5 = 0x10 & 0x2000;
                if (n5 == 0 >>> 0) {
                    // empty if block
                }
                arrc4[3 & 12997] = n2;
                arrc4[4 >>> 1] = 0xA7840257 ^ 0xA7840207;
                arrc4[8299 & 1667] = 0xFFFFB047 & 0x6B;
                arrc4[349 ^ 345] = 0x112E & 0x486E;
                arrc4[218 ^ 223] = 164 >>> 1;
                try {
                    char[] arrc5 = arrc4;
                    arrc2 = arrc4;
                }
                catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                    throw new ArrayIndexOutOfBoundsException();
                }
                if ((0xFFFFF675 & 0xFFFFF673) == (0x1287F9C2 ^ 0xED783BA9)) {
                }
                if ((n = 0x2E4CD10D ^ 0x2E4CD10D) == 0 >>> 5) {
                    // empty if block
                }
                try {
                    arrc5[495 ^ 489] = 0x207F & 0xFFFFC8EF;
                }
                catch (ConcurrentModificationException concurrentModificationException) {
                    throw new ConcurrentModificationException();
                }
                if ((0xFFFFE91E & 0xFFFFF1D6) != (0xDD41123D ^ 0x22BE93DB)) {
                    // empty if block
                }
                int n6 = 0 >>> 2;
                if (n6 == 0 >>> 6) {
                    // empty if block
                }
                arrc2[94588178 ^ 94588181] = 0x90 ^ 0xC9;
                arrc2[8 >>> 0] = 0x16 ^ 0x21;
                arrc2[1211 & 12361] = 0x50EE & 0xB7C;
                try {
                    char[] arrc6 = arrc2;
                    arrc = arrc2;
                }
                catch (NoSuchElementException noSuchElementException) {
                    throw new NoSuchElementException();
                }
                if ((0x2D0A5DA9 ^ 0xD2F59335) == (0xFFFFC829 & 0xFFFFCA29)) {
                }
                int n7 = 0x2105 & 0xFFFFC44A;
                if (n7 == (0xFE5AD396 ^ 0xFE5AD396)) {
                }
                arrc6[268 ^ 262] = 10752 >>> 7;
                inputStream = lirectweaksW1XeOCAWiPQZ.class.getResourceAsStream(stringBuilder.append(new String(arrc).replace((char)(0xF75D3009 ^ 0xF75D2AFE), (char)(0x157E & 0xAF7))).toString());
                Throwable throwable = null;
                try {
                    int n8;
                    int n9;
                    int n10;
                    int n11;
                    StringBuilder stringBuilder2;
                    int n12;
                    int n13;
                    int n14;
                    char[] arrc7;
                    int n15;
                    byte[] arrby;
                    byte[] arrby2;
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] arrby3 = new byte[0xF32DDB01 ^ 0xF32D24FE];
                    try {
                        arrby2 = arrby3;
                    }
                    catch (UnsupportedOperationException unsupportedOperationException) {
                        throw new UnsupportedOperationException();
                    }
                    if ((0xFFFFDED0 ^ 0x8D) == -19900 >>> 0) {
                    }
                    int n16 = 0x172 ^ 0x172;
                    if (n16 == (0x4400 & 0xFFFF9A49)) {
                        // empty if block
                    }
                    int n17 = inputStream.read(arrby2);
                    while (n17 != (0xFFFFFEEB ^ 0x114)) {
                        byteArrayOutputStream.write(arrby3, 0x68AD & 0xFFFF9110, n17);
                        n17 = inputStream.read(arrby3);
                        if ((0xFFFFF3FD & 0xFFFFF1EF) != (0xFFFFAFAE ^ 0x90)) continue;
                    }
                    try {
                        arrby = byteArrayOutputStream.toByteArray();
                    }
                    catch (ClassCastException classCastException) {
                        throw new ClassCastException();
                    }
                    if ((0xFFFFAFEF & 0xFFFFEF4D) == (0xFFFFDBDF & 0xFFFFF3DF)) {
                    }
                    if ((n15 = 0x9F ^ 0x9F) == (0xFFFF9010 & 0x4C6A)) {
                        // empty if block
                    }
                    byte[] arrby4 = arrby;
                    char[] arrc8 = new char[0x92 ^ 0x9A];
                    arrc8[165 ^ 165] = 0x3D0906AE ^ 0x3D09069D;
                    arrc8[-789645494 ^ -789645493] = 0x1D8 ^ 0x1EE;
                    arrc8[152276256 ^ 152276258] = 0x4F38 & 0xFFFF8039;
                    arrc8[2067 & 931] = 0x18 ^ 0x28;
                    arrc8[5901 & 18614] = 100 >>> 1;
                    try {
                        char[] arrc9 = arrc8;
                        arrc7 = arrc8;
                        if ((0xFFFFB4BF ^ 0xE) != (0xFFFF80ED ^ 0x7B)) {
                            // empty if block
                        }
                    }
                    catch (ArithmeticException arithmeticException) {
                        throw new ArithmeticException();
                    }
                    if ((n14 = 0xA45054EE ^ 0xA45054EE) == (0x1D9 ^ 0x1D9)) {
                        // empty if block
                    }
                    try {
                        n13 = 264960 >>> 6;
                        if ((0xFFFFF6F1 & 0xFFFFAEE1) != (0xFFFFFE5F & 0xFFFFE6CF)) {
                            // empty if block
                        }
                    }
                    catch (DateTimeException dateTimeException) {
                        throw new DateTimeException();
                    }
                    arrc9[28741 & -30201] = n13;
                    arrc7[66 ^ 68] = 0xFFFFB02C & 0x5C3D;
                    try {
                        arrc7[1516622710 ^ 1516622705] = 8280 >>> 1;
                    }
                    catch (DateTimeException dateTimeException) {
                        throw new DateTimeException();
                    }
                    if ((0xD84BDEB4 ^ 0x27B445C1) == (0x2B71B8EA ^ 0xD48E419D)) {
                    }
                    if ((n12 = 0xFFFF8102 & 0x25) == (0x17 ^ 0x17)) {
                        // empty if block
                    }
                    try {
                        stringBuilder2 = new StringBuilder(new String(arrc7).replace(16560 >>> 2, (char)(0x68 ^ 0x5D)));
                    }
                    catch (UnsupportedOperationException unsupportedOperationException) {
                        throw new UnsupportedOperationException();
                    }
                    if ((0xFFFFDE8B & 0xFFFFDAB9) == (0xFFFFBCDE & 0xFFFFBAFD)) {
                        // empty if block
                    }
                    if ((0x89F9CC2A ^ 0x760643D3) != (0xFFFF87A9 & 0xFFFF9670)) {
                        // empty if block
                    }
                    char[] arrc10 = new char[2 ^ 0xA];
                    arrc10[10309 & 5384] = 3264 >>> 6;
                    try {
                        n11 = 1600 >>> 4;
                    }
                    catch (NoSuchElementException noSuchElementException) {
                        throw new NoSuchElementException();
                    }
                    if ((0xFFFFE5AF & 0xFFFFE5AF) == -6399 >>> 0) {
                    }
                    try {
                        arrc10[1089 & 10929] = n11;
                    }
                    catch (NullPointerException nullPointerException) {
                        throw new NullPointerException();
                    }
                    if ((0xFFFFFA64 & 0xFFFFF664) == (0xBF268231 ^ 0x40D96450)) {
                    }
                    if ((n10 = 0x127 ^ 0x127) == 0 >>> 3) {
                        // empty if block
                    }
                    arrc10[221718338 ^ 221718336] = 98 >>> 0;
                    arrc10[6371 & -15341] = 84064 >>> 5;
                    arrc10[2374 & -23372] = 104 >>> 1;
                    try {
                        int n18 = 5 >>> 0;
                    }
                    catch (ClassCastException classCastException) {
                        throw new ClassCastException();
                    }
                    if ((0xFFFF9CF3 & 0xFFFF9D43) == (0xFFFFCDFD & 0xFFFFEFB7)) {
                        // empty if block
                    }
                    arrc10[n18] = 0x1B ^ 0x79;
                    try {
                        n9 = 0xA4B & 0xFFFFAA53;
                    }
                    catch (ArithmeticException arithmeticException) {
                        throw new ArithmeticException();
                    }
                    if ((0x1ECF2C05 ^ 0xE1308302) != (0xFFFFEE65 & 0xFFFFFE25)) {
                        // empty if block
                    }
                    int n19 = 0x131 ^ 0x131;
                    if (n19 == (0xFFFF8010 & 0x248D)) {
                        // empty if block
                    }
                    arrc10[1038 & 16486] = n9;
                    try {
                        arrc10[-2010885414 ^ -2010885411] = 208 >>> 2;
                    }
                    catch (ConcurrentModificationException concurrentModificationException) {
                        throw new ConcurrentModificationException();
                    }
                    if ((0xFFFFA54B & 0xFFFFB50B) != (0xFFFF9EDB & 0xFFFF9ADB)) {
                        // empty if block
                    }
                    int n20 = 0xB7E9E022 ^ 0xB7E9E022;
                    if (n20 == (0xA0 & 0xF00)) {
                        // empty if block
                    }
                    String string = stringBuilder2.append(new String(arrc10).replace((char)(0xB2C ^ 0x16F), (char)(0x2EF09A28 ^ 0x2EF09A11))).toString();
                    if ((0xFFFF91E2 & 0xFFFFF1C7) == (0xFFFFDE2E & 0xFFFFB66E)) {
                    }
                    char[] arrc11 = new char[1024 >>> 7];
                    arrc11[275 ^ 275] = 0x2C5F & 0xEF7;
                    arrc11[32 >>> 5] = 0x676352D7 ^ 0x676352E1;
                    arrc11[256 >>> 7] = 896 >>> 4;
                    arrc11[1323 & -28669] = 0x15 ^ 0x24;
                    arrc11[512 >>> 7] = 0x4839 & 0x2139;
                    try {
                        n8 = 0x1F0 ^ 0x1C3;
                    }
                    catch (NegativeArraySizeException negativeArraySizeException) {
                        throw new NegativeArraySizeException();
                    }
                    if ((0xFFFFFFE3 & 0xFFFFF963) != (0xFFFFFEFF & 0xFFFFF37F)) {
                        // empty if block
                    }
                    int n21 = 0xE2D28A05 ^ 0xE2D28A05;
                    if (n21 == (0x20 ^ 0x20)) {
                        // empty if block
                    }
                    arrc11[-16291 & 9253] = n8;
                    arrc11[241 ^ 247] = 0xFE2B819D ^ 0xFE2B81AD;
                    arrc11[1431122634 ^ 1431122637] = 0x6C ^ 0xE;
                    char[] arrc12 = new char[0xFFFF8278 & 0x3109];
                    arrc12[493653356 ^ 493653356] = 0x27C & 0x1430;
                    arrc12[64 >>> 6] = 6144 >>> 7;
                    arrc12[4098 & 17155] = 0x13B & 0x2E39;
                    arrc12[3 >>> 0] = 304896 >>> 6;
                    arrc12[321 ^ 325] = 6656 >>> 7;
                    arrc12[69 & -19427] = 48 >>> 0;
                    arrc12[493 ^ 491] = 0x163F & 0xFFFFA036;
                    arrc12[-1401991874 ^ -1401991879] = 0x126A ^ 0xF6;
                    arrby4 = lirectweaksW1XeOCAWiPQZ.ZzNvoK9vMrhqdPTRhxUg72(arrby4, string, new String(arrc11).replace((char)(0xC0B ^ 0x5C), 776 >>> 3) + new String(arrc12).replace(4764 >>> 0, 6208 >>> 6));
                    Class<?> class_2 = this.defineClass(null, arrby4, 0 >>> 5, arrby4.length);
                    this.resolveClass(class_2);
                    class_ = class_2;
                    if (inputStream == null) return class_;
                    if (throwable == null) break block95;
                }
                catch (Throwable throwable2) {
                    try {
                        Throwable throwable3;
                        throwable = throwable3 = throwable2;
                        throw throwable3;
                    }
                    catch (Throwable throwable4) {
                        Throwable throwable5;
                        if (inputStream == null) throw throwable4;
                        try {
                            throwable5 = throwable;
                        }
                        catch (ClassCastException classCastException) {
                            throw new ClassCastException();
                        }
                        if ((0xFFFFE1EE & 0xFFFFE3EE) == (0xFFFFA25C ^ 0x182)) {
                            // empty if block
                        }
                        if (throwable5 != null) {
                            try {
                                inputStream.close();
                            }
                            catch (Throwable throwable6) {
                                int n22;
                                Throwable throwable7 = throwable6;
                                throwable.addSuppressed(throwable7);
                                if ((0x630F29D2 ^ 0x9CF0CC8F) == (0xFFFF98A0 ^ 0x8D)) {
                                }
                                if ((n22 = 0 >>> 5) == (3 ^ 3)) throw throwable4;
                                throw throwable4;
                            }
                            if ((0x17DAB330 ^ 0xE82558A5) == (0xFFFFD2A9 & 0xFFFF91CD)) throw throwable4;
                            throw throwable4;
                        }
                        inputStream.close();
                        throw throwable4;
                    }
                }
                try {
                    inputStream.close();
                }
                catch (Throwable throwable8) {
                    throwable.addSuppressed(throwable8);
                    if (-1592 >>> 0 == (0xFFFFABFC & 0xFFFFEB9E)) {
                    }
                    int n23 = 0x4824 & 0x3741;
                    if (n23 == (0x25B6 & 0x4808)) return class_;
                    return class_;
                }
                if ((0xFFFFB5B7 & 0xFFFFB9D7) == (0x98F1A60D ^ 0x670E7788)) {
                }
                int n24 = 0xFFFF8208 & 0x1911;
                if (n24 == (0xCD ^ 0xCD)) return class_;
                return class_;
            }
            inputStream.close();
            return class_;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return null;
        }
    }
}

