/*
 * Decompiled with CFR 0.150.
 */
import java.io.Serializable;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.time.DateTimeException;
import java.util.NoSuchElementException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class DirecZMeakscmYOqpQoVbDfLs2 {
    public static String Ws3jxnQeazwMPT;
    public static String 2ILEWCiCuy2BxAzzV5ErFi0A;
    public static String Rf8jgSYbV4ng8;
    public static String DS33ueuRzIWOiXYkBw0;
    public static String 06fumHjuS9SKUeXREQBVrVb4;
    public static String WicFH7AGHn7T3E;
    public static String VZeK0uXIROfACTzDQhpuy;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String 2ZJp9vApZecX14MynbGG(String string, String string2) {
        int n;
        if (16 >>> 4 == 0) {
            return null;
        }
        if ((0xEF44071 ^ 0xEF44070) == 0) {
            return null;
        }
        if (16 >>> 4 == 0) {
            return null;
        }
        if ((0x182 ^ 0x182) != 0) {
            return null;
        }
        if ((0x8FF38AD0 ^ 0x700C15FF) != (0x91ADAD76 ^ 0x6E5207B6)) {
            // empty if block
        }
        if ((n = 0x1D6D63AB ^ 0x1D6D63AB) == (0x1B4 ^ 0x1B4)) {
            // empty if block
        }
        char[] arrc = string.toCharArray();
        char[] arrc2 = string2.toCharArray();
        char[] arrc3 = Rf8jgSYbV4ng8.toCharArray();
        int n2 = 0x3402 & 0x170;
        while (true) {
            int n3;
            if (n2 >= arrc.length) {
                return new String(arrc);
            }
            try {
                n3 = n2;
            }
            catch (DateTimeException dateTimeException) {
                throw new DateTimeException();
            }
            if ((0xFFFF800D ^ 0x18) == -23058 >>> 0) {
                // empty if block
            }
            if (n3 % (0x5A & 0xFFFF8086) == 0) {
                arrc[n2] = (char)(arrc[n2] ^ (arrc2[0x97BC8060 ^ 0x97BC8061] | arrc3[224 >>> 5]));
                if ((0xFFFFF539 & 0xFFFFF97E) == (0xFFFF9779 & 0xFFFFA735)) {
                    // empty if block
                }
            } else {
                arrc[n2] = (char)(arrc[n2] ^ (arrc2[0x86 ^ 0x9E] | arrc3[58 >>> 1]));
            }
            ++n2;
            if ((0xFFFFE362 & 0xFFFFC37F) != (0xFFFFE23D & 0xFFFFE2EC)) continue;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Object eHkwWnYe8sFEXTdG9(MethodHandles.Lookup lookup, String string, MethodType methodType, Object object, Object object2, Object object3, Object object4, Object object5, Object object6) {
        Serializable serializable;
        Object object7;
        if ((0x3424 & 0x19) != 0) {
            return null;
        }
        if ((0x53B932BC ^ 0xAC4690AF) == (0xF7632918 ^ 0x89CE5D2)) {
            // empty if block
        }
        if ((0x61166B4E ^ 0x61166B4F) == 0) {
            return null;
        }
        if ((0x1401 & 0xFFFFC063) == 0) {
            return null;
        }
        if ((0x1A43 & 0x89) == 0) {
            return null;
        }
        char[] arrc = ((String)object6).toCharArray();
        String[] arrstring = new String[0xAD ^ 0xAE];
        arrstring[339 ^ 339] = (String)object;
        try {
            object7 = object2;
        }
        catch (NoSuchElementException noSuchElementException) {
            throw new NoSuchElementException();
        }
        if ((0xFFFFFF2B & 0xFFFFF73B) == (0xD73E9A05 ^ 0x28C11700)) {
        }
        int n = 0x2067C293 ^ 0x2067C293;
        if (n == (0x283B926B ^ 0x283B926B)) {
            // empty if block
        }
        arrstring[2713 & 5] = (String)object7;
        arrstring[-31213 & 10658] = (String)object3;
        String[] arrstring2 = arrstring;
        char[] arrc2 = 2ILEWCiCuy2BxAzzV5ErFi0A.toCharArray();
        for (int i = 0x947B0A3E ^ 0x947B0A3E; i < arrstring2.length; ++i) {
            char[] arrc3 = arrstring2[i].toCharArray();
            serializable = new StringBuilder();
            block28: for (int j = 0 >>> 7; j < arrc3.length; ++j) {
                int n2;
                StringBuilder stringBuilder;
                int n3;
                char c;
                char[] arrc4;
                char c2;
                char[] arrc5;
                char c3;
                switch (j % (0xFFFF8239 & 0x504B)) {
                    int n4;
                    int n5;
                    case 1: {
                        c3 = arrc3[j];
                        try {
                            arrc5 = arrc;
                        }
                        catch (ArrayStoreException arrayStoreException) {
                            throw new ArrayStoreException();
                        }
                    }
                    if ((0xFD3B855B ^ 0x2C41F54) == (0xFFFFBB7F & 0xFFFFFD5E)) {
                    }
                    int n6 = 0 >>> 0;
                    if (n6 == (0xFFFF8002 & 0x2010)) {
                        // empty if block
                    }
                    serializable.append((char)(c3 ^ arrc5[0x84B1946B ^ 0x84B19479]));
                    if ((0x80350A89 ^ 0x7FCAAC70) == (0xFFFFE1F4 & 0xFFFFC59F)) {
                    }
                    if ((n5 = 0 >>> 3) != (0xFFFFA261 & 0x4082)) continue block28;
                    continue block28;
                    case 2: {
                        try {
                            c2 = arrc3[j];
                        }
                        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                            throw new ArrayIndexOutOfBoundsException();
                        }
                    }
                    if ((0xFFFF81E7 ^ 0x196) != (0xFFFFFB0D & 0xFFFF918F)) {
                        // empty if block
                    }
                    if ((n4 = 0x6A1B6037 ^ 0x6A1B6037) == (0xD9 ^ 0xD9)) {
                        // empty if block
                    }
                    try {
                        arrc4 = arrc2;
                    }
                    catch (NegativeArraySizeException negativeArraySizeException) {
                        throw new NegativeArraySizeException();
                    }
                    if ((0xFFFFAA5D & 0xFFFFA2D9) == (0xFFFFECDA & 0xFFFFF4DE)) {
                    }
                    int n7 = 0x3ACB1069 ^ 0x3ACB1069;
                    if (n7 == (0x5A8 & 0x6256)) {
                        // empty if block
                    }
                    serializable.append((char)(c2 ^ arrc4[0x5E9A & 0x2022]));
                    if ((0xFFFFB33A ^ 0x2D) == (0xFFFFCBFA & 0xFFFFCBD2)) {
                    }
                    int n8 = 0x682FCB5A ^ 0x682FCB5A;
                    if (n8 != (0x4900 & 0xFFFF80E2)) continue block28;
                    continue block28;
                    case 3: {
                        serializable.append((char)(arrc3[j] ^ arrc2[0xD509B727 ^ 0xD509B72B]));
                        try {
                        }
                        catch (ArithmeticException arithmeticException) {
                            throw new ArithmeticException();
                        }
                    }
                    if ((0xFFFFFD47 & 0xFFFFFF4F) == (0xFFFFFE76 & 0xFFFFF8F8)) {
                    }
                    int n9 = 0xB5B6D1C5 ^ 0xB5B6D1C5;
                    if (n9 == (0x289E3989 ^ 0x289E3989)) {
                        // empty if block
                    }
                    if ((0xFFFFE134 ^ 0x82) != (0xFFFFC10D & 0xFFFFA07D)) continue block28;
                    continue block28;
                    case 4: {
                        c = arrc3[j];
                        try {
                            n3 = 0x4A ^ 0x47;
                            if ((0xFFFFE7F2 & 0xFFFFDFF0) != (0xFFFFA55C & 0xFFFF85FD)) {
                                // empty if block
                            }
                        }
                        catch (UnsupportedOperationException unsupportedOperationException) {
                            throw new UnsupportedOperationException();
                        }
                    }
                    serializable.append((char)(c ^ arrc2[n3]));
                    if ((0xFFFF9C83 ^ 0x16E) != (0xFFFFFBBB & 0xFFFFF739)) {
                        // empty if block
                    }
                    int n10 = 0x300 & 0x5001;
                    if (n10 != (0xC8 ^ 0xC8)) continue block28;
                    continue block28;
                    case 5: {
                        serializable.append((char)(arrc3[j] ^ arrc[0x2F ^ 0x27]));
                        if ((0xCA4197E4 ^ 0x35BE44B4) != (0xFFFFF875 & 0xFFFFD93D)) continue block28;
                        continue block28;
                    }
                    case 6: {
                        try {
                            stringBuilder = serializable;
                        }
                        catch (NoSuchElementException noSuchElementException) {
                            throw new NoSuchElementException();
                        }
                    }
                    if ((0xFFFFF8FD & 0xFFFFA95D) == (0xFFFFEB07 ^ 0x2B)) {
                    }
                    int n11 = 0xFFFFF418 & 0x3A0;
                    if (n11 == (0xD446B90A ^ 0xD446B90A)) {
                        // empty if block
                    }
                    stringBuilder.append((char)(arrc3[j] ^ arrc[0x120C & 0x25]));
                    if ((0xFFFFA4A0 ^ 0x134) == (0xFFFF9A3F ^ 0x1A)) {
                    }
                    int n12 = 0x49 ^ 0x49;
                    if (n12 != (0x33 ^ 0x33)) continue block28;
                    continue block28;
                    case 7: {
                        serializable.append((char)(arrc3[j] ^ arrc2[0x817F8EB1 ^ 0x817F8EA7]));
                        if ((0xFFFFDEF3 & 0xFFFFDEB5) != (0xFFFFBDC1 & 0xFFFF98C9)) {
                            // empty if block
                        }
                        int n13 = 0xFFFF9000 & 0xF0E;
                        if (n13 != (0x84 ^ 0x84)) continue block28;
                        continue block28;
                    }
                    case 8: {
                        try {
                            n2 = arrc3[j] ^ arrc[6 ^ 2];
                        }
                        catch (NullPointerException nullPointerException) {
                            throw new NullPointerException();
                        }
                    }
                    if ((0xFFFFCFC9 & 0xFFFFC2F1) != (0xFFFFF29F & 0xFFFFBB5F)) {
                        // empty if block
                    }
                    int n14 = 0xFFFF9565 & 0x800;
                    if (n14 == 0 >>> 7) {
                        // empty if block
                    }
                    serializable.append((char)n2);
                    if ((0xFFFF8EBF ^ 0x163) == (0xFFFF8AF7 ^ 0x12F)) {
                    }
                    int n15 = 0 >>> 4;
                    if (n15 != (0xD226B384 ^ 0xD226B384)) continue block28;
                    continue block28;
                    case 9: {
                        serializable.append((char)(arrc3[j] ^ arrc[9 ^ 3]));
                        if ((0xFFFF85C2 ^ 0x3F) == (0xA79ADBAF ^ 0x58654978)) {
                        }
                        int n16 = 0x105 ^ 0x105;
                        if (n16 != (0x96B70179 ^ 0x96B70179)) continue block28;
                        continue block28;
                    }
                    default: {
                        serializable.append((char)(arrc3[j] ^ arrc2[104 >>> 3]));
                    }
                }
                if ((0xFFFFC56F & 0xFFFFC597) != (0xFFFFABAE ^ 0x118)) continue;
            }
            arrstring2[i] = serializable.toString();
            if ((0xD9B92369 ^ 0x2646D67F) != (0xFFFFFBF2 & 0xFFFFF7F0)) continue;
        }
        Class<?> class_ = Class.forName(arrstring2[0x12 ^ 0x12]);
        int n17 = (Integer)object4;
        serializable = MethodType.fromMethodDescriptorString(arrstring2[0xED40FDA6 ^ 0xED40FDA4], class_.getClassLoader());
        if (n17 == (0xFFFFFE16 ^ 0x198)) {
            return new MutableCallSite(lookup.findStatic(class_, arrstring2[0x120 ^ 0x121], (MethodType)serializable).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(class_, arrstring2[0x16B ^ 0x16A], (MethodType)serializable).asType(methodType));
    }
}

