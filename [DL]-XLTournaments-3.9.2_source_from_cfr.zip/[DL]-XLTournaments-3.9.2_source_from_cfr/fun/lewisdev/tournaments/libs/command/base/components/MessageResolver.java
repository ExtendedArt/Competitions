/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package fun.lewisdev.tournaments.libs.command.base.components;

import org.bukkit.command.CommandSender;

@FunctionalInterface
public interface MessageResolver {
    public void resolve(CommandSender var1);
}

