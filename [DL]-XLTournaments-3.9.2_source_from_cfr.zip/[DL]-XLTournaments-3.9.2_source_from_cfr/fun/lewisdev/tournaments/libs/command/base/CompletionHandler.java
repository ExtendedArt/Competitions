/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.libs.command.base;

import fun.lewisdev.tournaments.libs.command.base.components.CompletionResolver;
import fun.lewisdev.tournaments.libs.command.base.components.MfUtil;
import fun.lewisdev.tournaments.libs.command.exceptions.MfException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class CompletionHandler {
    private final Map<String, CompletionResolver> registeredCompletions = new HashMap<String, CompletionResolver>();

    CompletionHandler() {
        this.register("#players", object -> {
            ArrayList<String> arrayList = new ArrayList<String>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                arrayList.add(player.getName());
            }
            arrayList.sort(String.CASE_INSENSITIVE_ORDER);
            return arrayList;
        });
        this.register("#empty", object -> Collections.singletonList(""));
        this.register("#range", object -> {
            String string = String.valueOf(object);
            if (string.contains("class")) {
                return IntStream.rangeClosed(1, 10).mapToObj(Integer::toString).collect(Collectors.toList());
            }
            if (!string.contains("-")) {
                return IntStream.rangeClosed(1, Integer.parseInt(string)).mapToObj(Integer::toString).collect(Collectors.toList());
            }
            String[] arrstring = string.split("-");
            int[] arrn = IntStream.rangeClosed(Integer.parseInt(arrstring[0]), Integer.parseInt(arrstring[1])).toArray();
            ArrayList<String> arrayList = new ArrayList<String>();
            for (int n : arrn) {
                arrayList.add(String.valueOf(n));
            }
            return arrayList;
        });
        this.register("#enum", object -> {
            Class class_ = (Class)object;
            ArrayList<String> arrayList = new ArrayList<String>();
            for (Enum enum_ : (Enum[])class_.getEnumConstants()) {
                arrayList.add(enum_.name());
            }
            arrayList.sort(String.CASE_INSENSITIVE_ORDER);
            return arrayList;
        });
        this.register("#boolean", object -> Arrays.asList("false", "true"));
    }

    public void register(String string, CompletionResolver completionResolver) {
        if (!string.startsWith("#")) {
            throw new MfException("Could not register completion, id - " + string + " does not start with #.");
        }
        this.registeredCompletions.put(string, completionResolver);
    }

    List<String> getTypeResult(String string, Object object) {
        return MfUtil.color(this.registeredCompletions.get(string).resolve(object));
    }

    boolean isNotRegistered(String string) {
        String string2 = string;
        if (string.contains(":")) {
            string2 = string2.split(":")[0];
        }
        return this.registeredCompletions.get(string2) == null;
    }
}

