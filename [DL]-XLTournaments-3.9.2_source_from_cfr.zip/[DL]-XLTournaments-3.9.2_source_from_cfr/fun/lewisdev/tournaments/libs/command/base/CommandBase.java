/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package fun.lewisdev.tournaments.libs.command.base;

import fun.lewisdev.tournaments.libs.command.base.MessageHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandSender;

public abstract class CommandBase {
    private final Map<String, String> arguments = new HashMap<String, String>();
    private final List<String> aliases = new ArrayList<String>();
    private MessageHandler messageHandler;
    private String command;

    public CommandBase() {
    }

    public CommandBase(String string, List<String> list) {
        this.command = string;
        this.aliases.addAll(list);
    }

    public String getArgument(String string) {
        return this.arguments.getOrDefault(string, null);
    }

    public void sendMessage(String string, CommandSender commandSender) {
        this.messageHandler.sendMessage(string, commandSender);
    }

    void setMessageHandler(MessageHandler messageHandler) {
        this.messageHandler = messageHandler;
    }

    void clearArgs() {
        this.arguments.clear();
    }

    void addArgument(String string, String string2) {
        this.arguments.put(string, string2);
    }

    List<String> getAliases() {
        return this.aliases;
    }

    String getCommand() {
        return this.command;
    }

    public void setAliases(List<String> list) {
        this.aliases.addAll(list);
    }
}

