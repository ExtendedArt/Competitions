/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.command.base.components;

import fun.lewisdev.tournaments.libs.command.base.CommandBase;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class CommandData {
    private final CommandBase commandBase;
    private final List<Class<?>> params = new ArrayList();
    private final List<String> parameterNames = new ArrayList<String>();
    private final List<String> permissions = new ArrayList<String>();
    private final List<Integer> valuesArgs = new ArrayList<Integer>();
    private final Map<Integer, String> completions = new HashMap<Integer, String>();
    private Method method;
    private String name;
    private boolean defaultCmd;
    private Class<?> senderClass;
    private Method completionMethod;
    private boolean optional;
    private String wrongUsage;
    private String noPermission;

    public CommandData(CommandBase commandBase) {
        this.commandBase = commandBase;
    }

    public void addPermission(String string) {
        this.permissions.add(string);
    }

    public void setOptional(boolean bl) {
        this.optional = bl;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String string) {
        this.name = string;
    }

    public Method getMethod() {
        return this.method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }

    public Class<?> getSenderClass() {
        return this.senderClass;
    }

    public void setSenderClass(Class<?> class_) {
        this.senderClass = class_;
    }

    public List<Class<?>> getParams() {
        return this.params;
    }

    public Map<Integer, String> getCompletions() {
        return this.completions;
    }

    public List<String> getPermissions() {
        return this.permissions;
    }

    public String getWrongUsage() {
        return this.wrongUsage;
    }

    public void setWrongUsage(String string) {
        this.wrongUsage = string;
    }

    public String getNoPermission() {
        return this.noPermission;
    }

    public void setNoPermission(String string) {
        this.noPermission = string;
    }

    public List<String> getParameterNames() {
        return this.parameterNames;
    }

    public CommandBase getCommandBase() {
        return this.commandBase;
    }

    public Method getCompletionMethod() {
        return this.completionMethod;
    }

    public void setCompletionMethod(Method method) {
        this.completionMethod = method;
    }

    public List<Integer> getArgValue() {
        return this.valuesArgs;
    }

    public boolean isDefault() {
        return this.defaultCmd;
    }

    public void setDefault(boolean bl) {
        this.defaultCmd = bl;
    }

    public boolean hasOptional() {
        return this.optional;
    }

    public boolean hasPermissions() {
        return !this.permissions.isEmpty();
    }
}

