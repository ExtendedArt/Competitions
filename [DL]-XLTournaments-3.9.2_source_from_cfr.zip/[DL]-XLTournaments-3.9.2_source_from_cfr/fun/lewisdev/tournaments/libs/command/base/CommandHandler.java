/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.libs.command.base;

import fun.lewisdev.tournaments.libs.command.annotations.Alias;
import fun.lewisdev.tournaments.libs.command.annotations.CompleteFor;
import fun.lewisdev.tournaments.libs.command.annotations.Completion;
import fun.lewisdev.tournaments.libs.command.annotations.Default;
import fun.lewisdev.tournaments.libs.command.annotations.NoPermission;
import fun.lewisdev.tournaments.libs.command.annotations.Optional;
import fun.lewisdev.tournaments.libs.command.annotations.Permission;
import fun.lewisdev.tournaments.libs.command.annotations.SubCommand;
import fun.lewisdev.tournaments.libs.command.annotations.Values;
import fun.lewisdev.tournaments.libs.command.annotations.WrongUsage;
import fun.lewisdev.tournaments.libs.command.base.CommandBase;
import fun.lewisdev.tournaments.libs.command.base.CompletionHandler;
import fun.lewisdev.tournaments.libs.command.base.MessageHandler;
import fun.lewisdev.tournaments.libs.command.base.ParameterHandler;
import fun.lewisdev.tournaments.libs.command.base.components.CommandData;
import fun.lewisdev.tournaments.libs.command.base.components.MfUtil;
import fun.lewisdev.tournaments.libs.command.exceptions.MfException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public final class CommandHandler
extends Command {
    private final Map<String, CommandData> commands = new HashMap<String, CommandData>();
    private final ParameterHandler parameterHandler;
    private final CompletionHandler completionHandler;
    private final MessageHandler messageHandler;
    private boolean hideTab;
    private boolean completePlayers;

    CommandHandler(ParameterHandler parameterHandler, CompletionHandler completionHandler, MessageHandler messageHandler, CommandBase commandBase, String string, List<String> list, boolean bl, boolean bl2) {
        super(string);
        this.parameterHandler = parameterHandler;
        this.completionHandler = completionHandler;
        this.messageHandler = messageHandler;
        this.hideTab = bl;
        this.completePlayers = bl2;
        this.setAliases(list);
        this.addSubCommands(commandBase);
    }

    void addSubCommands(CommandBase commandBase) {
        for (Method method : commandBase.getClass().getDeclaredMethods()) {
            CommandData commandData = new CommandData(commandBase);
            if (!method.isAnnotationPresent(Default.class) && !method.isAnnotationPresent(SubCommand.class) || !Modifier.isPublic(method.getModifiers())) continue;
            if (method.getParameterCount() == 0) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - needs to have Parameters!");
            }
            if (!CommandSender.class.isAssignableFrom(method.getParameterTypes()[0])) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - first parameter needs to be a CommandSender, Player, or ConsoleCommandSender!");
            }
            commandData.setMethod(method);
            commandData.setSenderClass(method.getParameterTypes()[0]);
            this.checkRegisteredParams(method, commandBase, commandData);
            this.checkDefault(method, commandData);
            this.checkPermission(method, commandData);
            this.checkWrongUsage(method, commandData);
            this.checkOptionalParam(method, commandBase, commandData);
            this.checkMethodCompletion(method, commandBase, commandData);
            this.checkParamCompletion(method, commandBase, commandData);
            this.checkAlias(method, commandData);
            if (!commandData.isDefault() && method.isAnnotationPresent(SubCommand.class)) {
                String string = method.getAnnotation(SubCommand.class).value().toLowerCase();
                commandData.setName(string);
                this.commands.put(string, commandData);
            }
            if (commandData.isDefault()) {
                commandData.setName("mf-default");
                this.commands.put("mf-default", commandData);
            }
            this.checkCompletionMethod(commandBase, commandData);
        }
    }

    public boolean execute(CommandSender commandSender, String string, String[] arrstring) {
        CommandData commandData = this.getDefaultSubCommand();
        if (arrstring.length == 0 || arrstring[0].isEmpty()) {
            if (commandData == null) {
                return this.unknownCommand(commandSender);
            }
            if (commandData.hasPermissions() && !this.hasPermissions(commandSender, commandData)) {
                return this.noPermission(commandSender, commandData);
            }
            if (!(CommandSender.class.equals(commandData.getSenderClass()) || ConsoleCommandSender.class.equals(commandData.getSenderClass()) || commandSender instanceof Player)) {
                return this.noConsole(commandSender);
            }
            if (ConsoleCommandSender.class.equals(commandData.getSenderClass()) && commandSender instanceof Player) {
                return this.noPlayer(commandSender);
            }
            return this.executeCommand(commandData, commandSender, arrstring);
        }
        String string2 = arrstring[0].toLowerCase();
        if (commandData != null && commandData.getParams().size() == 0 && (!this.commands.containsKey(string2) || this.getName().equalsIgnoreCase(string2))) {
            return this.unknownCommand(commandSender);
        }
        if (commandData == null && !this.commands.containsKey(string2)) {
            return this.unknownCommand(commandSender);
        }
        if (this.commands.containsKey(string2)) {
            commandData = this.commands.get(string2);
        }
        assert (commandData != null);
        if (commandData.hasPermissions() && !this.hasPermissions(commandSender, commandData)) {
            return this.noPermission(commandSender, commandData);
        }
        if (!(CommandSender.class.equals(commandData.getSenderClass()) || ConsoleCommandSender.class.equals(commandData.getSenderClass()) || commandSender instanceof Player)) {
            return this.noConsole(commandSender);
        }
        if (ConsoleCommandSender.class.equals(commandData.getSenderClass()) && commandSender instanceof Player) {
            return this.noPlayer(commandSender);
        }
        return this.executeCommand(commandData, commandSender, arrstring);
    }

    private boolean executeCommand(CommandData commandData, CommandSender commandSender, String[] arrstring) {
        try {
            Method method = commandData.getMethod();
            LinkedList<String> linkedList = new LinkedList<String>(Arrays.asList(arrstring));
            if (!commandData.isDefault() && linkedList.size() > 0) {
                linkedList.remove(0);
            }
            if (commandData.getParams().size() == 0 && linkedList.size() == 0) {
                method.invoke(commandData.getCommandBase(), new Object[]{commandSender});
                return true;
            }
            if (commandData.getParams().size() == 1 && String[].class.isAssignableFrom(commandData.getParams().get(0))) {
                method.invoke(commandData.getCommandBase(), new Object[]{commandSender, arrstring});
                return true;
            }
            if (commandData.getParams().size() != linkedList.size() && !commandData.hasOptional()) {
                if (!commandData.isDefault() && commandData.getParams().size() == 0) {
                    return this.wrongUsage(commandSender, commandData);
                }
                if (!String[].class.isAssignableFrom(commandData.getParams().get(commandData.getParams().size() - 1))) {
                    return this.wrongUsage(commandSender, commandData);
                }
            }
            ArrayList<Object> arrayList = new ArrayList<Object>();
            arrayList.add((Object)commandSender);
            for (int i = 0; i < commandData.getParams().size(); ++i) {
                Object object;
                Class<?> class_ = commandData.getParams().get(i);
                if (commandData.hasOptional()) {
                    if (linkedList.size() > commandData.getParams().size()) {
                        return this.wrongUsage(commandSender, commandData);
                    }
                    if (linkedList.size() < commandData.getParams().size() - 1) {
                        return this.wrongUsage(commandSender, commandData);
                    }
                    if (linkedList.size() < commandData.getParams().size()) {
                        linkedList.add(null);
                    }
                }
                if (commandData.getParams().size() > linkedList.size()) {
                    return this.wrongUsage(commandSender, commandData);
                }
                Object object2 = linkedList.get(i);
                if (commandData.getArgValue().contains(i + 1) && !this.completionHandler.getTypeResult((String)(object = commandData.getCompletions().get(i + 1)), object).contains(object2)) {
                    object2 = null;
                }
                if (class_.equals(String[].class)) {
                    object = new String[linkedList.size() - i];
                    for (int j = 0; j < ((String[])object).length; ++j) {
                        object[j] = (String)linkedList.get(i + j);
                    }
                    object2 = object;
                }
                object = this.parameterHandler.getTypeResult(class_, object2, commandData, commandData.getParameterNames().get(i));
                arrayList.add(object);
            }
            method.invoke(commandData.getCommandBase(), arrayList.toArray());
            commandData.getCommandBase().clearArgs();
            return true;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            return true;
        }
    }

    /*
     * WARNING - void declaration
     */
    public List<String> tabComplete(CommandSender commandSender, String string, String[] arrstring) {
        void var8_25;
        Object object;
        if (arrstring.length == 1) {
            Object object2;
            String[] arrstring2;
            Object object4;
            Object object5 = new ArrayList();
            CommandData commandData = this.getDefaultSubCommand();
            if (commandData != null && (object4 = commandData.getCompletionMethod()) != null) {
                try {
                    LinkedList<String> linkedList = new LinkedList<String>(Arrays.asList(arrstring));
                    linkedList.remove("mf-default");
                    return (List)((Method)object4).invoke(commandData.getCommandBase(), new Object[]{linkedList, commandSender});
                }
                catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
                    reflectiveOperationException.printStackTrace();
                }
            }
            object4 = new ArrayList<String>(this.commands.keySet());
            object4.remove("mf-default");
            for (String object32 : this.commands.keySet()) {
                arrstring2 = this.commands.get(object32);
                if (!this.hideTab || !arrstring2.hasPermissions() || this.hasPermissions(commandSender, (CommandData)arrstring2)) continue;
                object4.remove(object32);
            }
            if (commandData != null && commandData.getCompletions().size() != 0) {
                void var8_19;
                object2 = commandData.getCompletions().get(1);
                Class<?> arrayList = commandData.getParams().get(0);
                if (((String)object2).contains(":")) {
                    arrstring2 = ((String)object2).split(":");
                    object2 = arrstring2[0];
                    String string2 = arrstring2[1];
                }
                object4.addAll(this.completionHandler.getTypeResult((String)object2, var8_19));
            }
            if (!"".equals(arrstring[0])) {
                object2 = object4.iterator();
                while (object2.hasNext()) {
                    String string3 = (String)object2.next();
                    if (!string3.toLowerCase().startsWith(arrstring[0].toLowerCase())) continue;
                    object5.add(string3);
                }
            } else {
                object5 = object4;
            }
            Collections.sort(object5);
            if (object5.isEmpty()) {
                if (this.completePlayers) {
                    return super.tabComplete(commandSender, string, arrstring);
                }
                return Collections.singletonList("");
            }
            return object5;
        }
        String string2 = arrstring[0];
        if (!this.commands.containsKey(string2)) {
            if (this.completePlayers) {
                return super.tabComplete(commandSender, string, arrstring);
            }
            return Collections.singletonList("");
        }
        CommandData commandData = this.commands.get(string2);
        if (this.hideTab && commandData.hasPermissions() && !this.hasPermissions(commandSender, commandData)) {
            if (this.completePlayers) {
                return super.tabComplete(commandSender, string, arrstring);
            }
            return Collections.singletonList("");
        }
        Method method = commandData.getCompletionMethod();
        if (method != null) {
            try {
                LinkedList<String> linkedList = new LinkedList<String>(Arrays.asList(arrstring));
                linkedList.remove(string2);
                return (List)method.invoke(commandData.getCommandBase(), new Object[]{linkedList, commandSender});
            }
            catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
                reflectiveOperationException.printStackTrace();
            }
        }
        if (!commandData.getCompletions().containsKey(arrstring.length - 1)) {
            if (this.completePlayers) {
                return super.tabComplete(commandSender, string, arrstring);
            }
            return Collections.singletonList("");
        }
        String string3 = commandData.getCompletions().get(arrstring.length - 1);
        ArrayList<String> arrayList = new ArrayList<String>();
        Object object2 = commandData.getParams().get(arrstring.length - 2);
        if (string3.contains(":")) {
            object = string3.split(":");
            string3 = object[0];
            object2 = object[1];
        }
        if (!"".equals(object = arrstring[arrstring.length - 1])) {
            for (String string4 : this.completionHandler.getTypeResult(string3, object2)) {
                if (!string4.toLowerCase().contains(((String)object).toLowerCase())) continue;
                arrayList.add(string4);
            }
        } else {
            ArrayList<String> arrayList2 = new ArrayList<String>(this.completionHandler.getTypeResult(string3, object2));
        }
        Collections.sort(var8_25);
        return var8_25;
    }

    public void setHideTab(boolean bl) {
        this.hideTab = bl;
    }

    public void setCompletePlayers(boolean bl) {
        this.completePlayers = bl;
    }

    private CommandData getDefaultSubCommand() {
        return this.commands.getOrDefault("mf-default", null);
    }

    private void checkDefault(Method method, CommandData commandData) {
        if (!method.isAnnotationPresent(Default.class)) {
            return;
        }
        commandData.setDefault(true);
    }

    private void checkRegisteredParams(Method method, CommandBase commandBase, CommandData commandData) {
        for (int i = 1; i < method.getParameterTypes().length; ++i) {
            Class<?> class_ = method.getParameterTypes()[i];
            if (class_.equals(String[].class) && i != method.getParameterTypes().length - 1) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " 'String[] args' have to be the last parameter if wants to be used!");
            }
            if (!this.parameterHandler.isRegisteredType(class_)) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " contains unregistered parameter types!");
            }
            commandData.getParams().add(class_);
            commandData.getParameterNames().add(method.getParameters()[i].getName());
        }
    }

    private void checkPermission(Method method, CommandData commandData) {
        if (!method.isAnnotationPresent(Permission.class)) {
            return;
        }
        for (String string : method.getAnnotation(Permission.class).value()) {
            commandData.addPermission(string);
        }
        if (!method.isAnnotationPresent(NoPermission.class)) {
            return;
        }
        commandData.setNoPermission(method.getAnnotation(NoPermission.class).value());
    }

    private void checkWrongUsage(Method method, CommandData commandData) {
        if (!method.isAnnotationPresent(WrongUsage.class)) {
            return;
        }
        commandData.setWrongUsage(method.getAnnotation(WrongUsage.class).value());
    }

    private void checkParamCompletion(Method method, CommandBase commandBase, CommandData commandData) {
        for (int i = 0; i < method.getParameters().length; ++i) {
            String[] arrstring;
            Parameter parameter = method.getParameters()[i];
            if (i == 0 && parameter.isAnnotationPresent(Completion.class)) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - First parameter of a command method cannot have Completion/Values annotation!");
            }
            if (parameter.isAnnotationPresent(Completion.class)) {
                arrstring = parameter.getAnnotation(Completion.class).value();
            } else {
                if (!parameter.isAnnotationPresent(Values.class)) continue;
                arrstring = new String[]{parameter.getAnnotation(Values.class).value()};
            }
            if (arrstring.length != 1) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - Parameter completion can only have one value!");
            }
            if (!arrstring[0].startsWith("#")) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - The completion ID must start with #!");
            }
            if (this.completionHandler.isNotRegistered(arrstring[0])) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - Unregistered completion ID '" + arrstring[0] + "'!");
            }
            commandData.getCompletions().put(i, arrstring[0]);
            if (!parameter.isAnnotationPresent(Values.class)) continue;
            commandData.getArgValue().add(i);
        }
    }

    private void checkMethodCompletion(Method method, CommandBase commandBase, CommandData commandData) {
        if (!method.isAnnotationPresent(Completion.class)) {
            return;
        }
        String[] arrstring = method.getAnnotation(Completion.class).value();
        for (int i = 0; i < arrstring.length; ++i) {
            String string = arrstring[i];
            if (!string.startsWith("#")) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - The completion ID must start with #!");
            }
            if (this.completionHandler.isNotRegistered(string)) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - Unregistered completion ID'" + string + "'!");
            }
            commandData.getCompletions().put(i + 1, string);
        }
    }

    private void checkCompletionMethod(CommandBase commandBase, CommandData commandData) {
        for (Method method : commandBase.getClass().getDeclaredMethods()) {
            String string;
            if (!method.isAnnotationPresent(CompleteFor.class) || !(method.getGenericReturnType() instanceof ParameterizedType)) continue;
            ParameterizedType parameterizedType = (ParameterizedType)method.getGenericReturnType();
            if (method.getParameterTypes().length != 2) {
                throw new MfException("The complete for method has now changed to require 2 parameters, args and sender.");
            }
            if (parameterizedType.getRawType() != List.class || parameterizedType.getActualTypeArguments().length != 1 || parameterizedType.getActualTypeArguments()[0] != String.class || !CommandSender.class.isAssignableFrom(method.getParameterTypes()[1]) || !(string = method.getAnnotation(CompleteFor.class).value()).equalsIgnoreCase(commandData.getName())) continue;
            commandData.setCompletionMethod(method);
        }
    }

    private void checkAlias(Method method, CommandData commandData) {
        if (!method.isAnnotationPresent(Alias.class)) {
            return;
        }
        for (String string : method.getAnnotation(Alias.class).value()) {
            CommandData commandData2 = commandData;
            commandData.setName(string.toLowerCase());
            if (commandData2.isDefault()) {
                commandData2.setDefault(false);
            }
            this.commands.put(string.toLowerCase(), commandData);
        }
    }

    private void checkOptionalParam(Method method, CommandBase commandBase, CommandData commandData) {
        for (int i = 0; i < method.getParameters().length; ++i) {
            Parameter parameter = method.getParameters()[i];
            if (i != method.getParameters().length - 1 && parameter.isAnnotationPresent(Optional.class)) {
                throw new MfException("Method " + method.getName() + " in class " + commandBase.getClass().getName() + " - Optional parameters can only be used as the last parameter of a method!");
            }
            if (!parameter.isAnnotationPresent(Optional.class)) continue;
            commandData.setOptional(true);
        }
    }

    private boolean hasPermissions(CommandSender commandSender, CommandData commandData) {
        for (String string : commandData.getPermissions()) {
            if (!commandSender.hasPermission(string)) continue;
            return true;
        }
        return false;
    }

    private boolean wrongUsage(CommandSender commandSender, CommandData commandData) {
        String string = commandData.getWrongUsage();
        if (string == null) {
            this.messageHandler.sendMessage("cmd.wrong.usage", commandSender);
            return true;
        }
        if (!string.startsWith("#") || !this.messageHandler.hasId(string)) {
            this.messageHandler.sendMessage("cmd.wrong.usage", commandSender);
            commandSender.sendMessage(MfUtil.color(commandData.getWrongUsage()));
            return true;
        }
        this.messageHandler.sendMessage(string, commandSender);
        return true;
    }

    private boolean unknownCommand(CommandSender commandSender) {
        this.messageHandler.sendMessage("cmd.no.exists", commandSender);
        return true;
    }

    private boolean noPermission(CommandSender commandSender, CommandData commandData) {
        String string = commandData.getNoPermission();
        if (string == null) {
            this.messageHandler.sendMessage("cmd.no.permission", commandSender);
            return true;
        }
        if (!string.startsWith("#") || !this.messageHandler.hasId(string)) {
            this.messageHandler.sendMessage("cmd.no.permission", commandSender);
            commandSender.sendMessage(MfUtil.color(commandData.getNoPermission()));
            return true;
        }
        this.messageHandler.sendMessage(string, commandSender);
        return true;
    }

    private boolean noConsole(CommandSender commandSender) {
        this.messageHandler.sendMessage("cmd.no.console", commandSender);
        return true;
    }

    private boolean noPlayer(CommandSender commandSender) {
        this.messageHandler.sendMessage("cmd.no.player", commandSender);
        return true;
    }
}

