/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package fun.lewisdev.tournaments.libs.command.base.components;

import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.ChatColor;

public final class MfUtil {
    public static String color(String string) {
        return ChatColor.translateAlternateColorCodes((char)'&', (String)string);
    }

    public static List<String> color(List<String> list) {
        return list.parallelStream().map(string -> ChatColor.translateAlternateColorCodes((char)'&', (String)string)).collect(Collectors.toList());
    }
}

