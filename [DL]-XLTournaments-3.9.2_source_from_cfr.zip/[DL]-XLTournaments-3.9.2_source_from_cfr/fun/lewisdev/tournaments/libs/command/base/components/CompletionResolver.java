/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.command.base.components;

import java.util.List;

@FunctionalInterface
public interface CompletionResolver {
    public List<String> resolve(Object var1);
}

