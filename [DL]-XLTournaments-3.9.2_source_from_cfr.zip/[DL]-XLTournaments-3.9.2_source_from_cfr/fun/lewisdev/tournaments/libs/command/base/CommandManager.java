/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Server
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandMap
 *  org.bukkit.command.PluginIdentifiableCommand
 *  org.bukkit.command.SimpleCommandMap
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.server.PluginDisableEvent
 *  org.bukkit.plugin.Plugin
 */
package fun.lewisdev.tournaments.libs.command.base;

import fun.lewisdev.tournaments.libs.command.annotations.Alias;
import fun.lewisdev.tournaments.libs.command.base.CommandBase;
import fun.lewisdev.tournaments.libs.command.base.CommandHandler;
import fun.lewisdev.tournaments.libs.command.base.CompletionHandler;
import fun.lewisdev.tournaments.libs.command.base.MessageHandler;
import fun.lewisdev.tournaments.libs.command.base.ParameterHandler;
import fun.lewisdev.tournaments.libs.command.exceptions.MfException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.PluginIdentifiableCommand;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.plugin.Plugin;

public final class CommandManager
implements Listener {
    private final Plugin plugin;
    private final CommandMap commandMap;
    private final Map<String, CommandHandler> commands = new HashMap<String, CommandHandler>();
    private Map<String, Command> bukkitCommands = new HashMap<String, Command>();
    private final ParameterHandler parameterHandler = new ParameterHandler();
    private final CompletionHandler completionHandler = new CompletionHandler();
    private final MessageHandler messageHandler = new MessageHandler();
    private boolean hideTab;
    private boolean completePlayers = false;

    public CommandManager(Plugin plugin) {
        this(plugin, false);
    }

    public CommandManager(Plugin plugin, boolean bl) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents((Listener)this, plugin);
        this.hideTab = bl;
        this.commandMap = this.getCommandMap();
    }

    public ParameterHandler getParameterHandler() {
        return this.parameterHandler;
    }

    public CompletionHandler getCompletionHandler() {
        return this.completionHandler;
    }

    public MessageHandler getMessageHandler() {
        return this.messageHandler;
    }

    public void register(CommandBase ... arrcommandBase) {
        for (CommandBase commandBase : arrcommandBase) {
            this.register(commandBase);
        }
    }

    public void register(CommandBase commandBase) {
        Command command;
        String string;
        Class<?> class_ = commandBase.getClass();
        if (!class_.isAnnotationPresent(fun.lewisdev.tournaments.libs.command.annotations.Command.class)) {
            string = commandBase.getCommand();
            if (string == null) {
                throw new MfException("Class " + commandBase.getClass().getName() + " needs to have @Command!");
            }
        } else {
            string = class_.getAnnotation(fun.lewisdev.tournaments.libs.command.annotations.Command.class).value();
        }
        List<String> list = commandBase.getAliases();
        if (class_.isAnnotationPresent(Alias.class)) {
            list.addAll(Arrays.asList(class_.getAnnotation(Alias.class).value()));
        }
        if ((command = this.commandMap.getCommand(string)) instanceof PluginIdentifiableCommand && ((PluginIdentifiableCommand)command).getPlugin() == this.plugin) {
            this.bukkitCommands.remove(string);
            command.unregister(this.commandMap);
        }
        try {
            if (this.commands.containsKey(string)) {
                this.commands.get(string).addSubCommands(commandBase);
                return;
            }
            commandBase.setMessageHandler(this.messageHandler);
            CommandHandler commandHandler = new CommandHandler(this.parameterHandler, this.completionHandler, this.messageHandler, commandBase, string, list, this.hideTab, this.completePlayers);
            this.commandMap.register(string, this.plugin.getName(), (Command)commandHandler);
            this.commands.put(string, commandHandler);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void hideTabComplete(boolean bl) {
        this.hideTab = bl;
        for (String string : this.commands.keySet()) {
            this.commands.get(string).setHideTab(bl);
        }
    }

    public void setCompletePlayers(boolean bl) {
        this.completePlayers = bl;
        for (String string : this.commands.keySet()) {
            this.commands.get(string).setCompletePlayers(bl);
        }
    }

    @EventHandler
    public void onPluginDisable(PluginDisableEvent pluginDisableEvent) {
        if (pluginDisableEvent.getPlugin() != this.plugin) {
            return;
        }
        this.unregisterAll();
    }

    private void unregisterAll() {
        this.commands.values().forEach(commandHandler -> commandHandler.unregister(this.commandMap));
    }

    private CommandMap getCommandMap() {
        CommandMap commandMap = null;
        try {
            Server server = Bukkit.getServer();
            Method method = server.getClass().getDeclaredMethod("getCommandMap", new Class[0]);
            method.setAccessible(true);
            commandMap = (CommandMap)method.invoke((Object)server, new Object[0]);
            Field field = SimpleCommandMap.class.getDeclaredField("knownCommands");
            field.setAccessible(true);
            this.bukkitCommands = (Map)field.get((Object)commandMap);
        }
        catch (Exception exception) {
            this.plugin.getLogger().log(Level.SEVERE, "Could not get Command Map, Commands won't be registered!");
        }
        return commandMap;
    }
}

