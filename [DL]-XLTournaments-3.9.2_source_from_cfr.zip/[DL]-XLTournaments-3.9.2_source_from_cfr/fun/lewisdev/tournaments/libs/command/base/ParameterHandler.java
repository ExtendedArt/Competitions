/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.primitives.Doubles
 *  com.google.common.primitives.Floats
 *  com.google.common.primitives.Ints
 *  com.google.common.primitives.Longs
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.libs.command.base;

import com.google.common.primitives.Doubles;
import com.google.common.primitives.Floats;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import fun.lewisdev.tournaments.libs.command.base.components.CommandData;
import fun.lewisdev.tournaments.libs.command.base.components.ParameterResolver;
import fun.lewisdev.tournaments.libs.command.base.components.TypeResult;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

public final class ParameterHandler {
    private final Map<Class<?>, ParameterResolver> registeredTypes = new HashMap();

    ParameterHandler() {
        this.register(Short.class, object -> {
            Integer n = Ints.tryParse((String)String.valueOf(object));
            return n == null ? new TypeResult(object) : new TypeResult(n.shortValue(), object);
        });
        this.register(Integer.class, object -> new TypeResult(Ints.tryParse((String)String.valueOf(object)), object));
        this.register(Long.class, object -> new TypeResult(Longs.tryParse((String)String.valueOf(object)), object));
        this.register(Float.class, object -> new TypeResult(Floats.tryParse((String)String.valueOf(object)), object));
        this.register(Double.class, object -> new TypeResult(Doubles.tryParse((String)String.valueOf(object)), object));
        this.register(String.class, object -> object instanceof String ? new TypeResult(object, object) : new TypeResult(object));
        this.register(String[].class, object -> {
            if (object instanceof String[]) {
                return new TypeResult(object, object);
            }
            return new TypeResult(object);
        });
        this.register(Boolean.class, object -> new TypeResult(Boolean.valueOf(String.valueOf(object)), object));
        this.register(Boolean.TYPE, object -> new TypeResult(Boolean.valueOf(String.valueOf(object)), object));
        this.register(Player.class, object -> new TypeResult((Object)Bukkit.getPlayer((String)String.valueOf(object)), object));
        this.register(Material.class, object -> new TypeResult((Object)Material.matchMaterial((String)String.valueOf(object)), object));
        this.register(Sound.class, object -> {
            String string2 = Arrays.stream(Sound.values()).map(Enum::name).filter(string -> string.equalsIgnoreCase(String.valueOf(object))).findFirst().orElse(null);
            return string2 == null ? new TypeResult(null, object) : new TypeResult((Object)Sound.valueOf((String)string2), object);
        });
        this.register(World.class, object -> new TypeResult((Object)Bukkit.getWorld((String)String.valueOf(object)), object));
    }

    public void register(Class<?> class_, ParameterResolver parameterResolver) {
        this.registeredTypes.put(class_, parameterResolver);
    }

    Object getTypeResult(Class<?> class_, Object object, CommandData commandData, String string) {
        TypeResult typeResult = this.registeredTypes.get(class_).resolve(object);
        commandData.getCommandBase().addArgument(string, typeResult.getArgumentName());
        return typeResult.getResolvedValue();
    }

    boolean isRegisteredType(Class<?> class_) {
        return this.registeredTypes.get(class_) != null;
    }
}

