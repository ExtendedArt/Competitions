/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.command.base.components;

public final class TypeResult {
    private Object resolvedValue;
    private String argumentName;

    public TypeResult(Object object, Object object2) {
        this.resolvedValue = object;
        this.argumentName = String.valueOf(object2);
    }

    public TypeResult(Object object) {
        this(null, object);
    }

    public Object getResolvedValue() {
        return this.resolvedValue;
    }

    public String getArgumentName() {
        return this.argumentName;
    }
}

