/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package fun.lewisdev.tournaments.libs.command.base;

import fun.lewisdev.tournaments.libs.command.base.components.MessageResolver;
import fun.lewisdev.tournaments.libs.command.base.components.MfUtil;
import fun.lewisdev.tournaments.libs.command.exceptions.MfException;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.command.CommandSender;

public final class MessageHandler {
    private final Map<String, MessageResolver> messages = new HashMap<String, MessageResolver>();

    MessageHandler() {
        this.register("cmd.no.permission", commandSender -> commandSender.sendMessage(MfUtil.color("&cYou don't have permission to execute this command!")));
        this.register("cmd.no.console", commandSender -> commandSender.sendMessage(MfUtil.color("&cCommand can't be executed through the console!")));
        this.register("cmd.no.player", commandSender -> commandSender.sendMessage(MfUtil.color("&cCommand can only be executed through the console!")));
        this.register("cmd.no.exists", commandSender -> commandSender.sendMessage(MfUtil.color("&cThe command you're trying to use doesn't exist!")));
        this.register("cmd.wrong.usage", commandSender -> commandSender.sendMessage(MfUtil.color("&cWrong usage for the command!")));
    }

    public void register(String string, MessageResolver messageResolver) {
        this.messages.put(string, messageResolver);
    }

    boolean hasId(String string) {
        return this.messages.get(string) != null;
    }

    void sendMessage(String string, CommandSender commandSender) {
        MessageResolver messageResolver = this.messages.get(string);
        if (messageResolver == null) {
            throw new MfException("The message ID \"" + string + "\" does not exist!");
        }
        messageResolver.resolve(commandSender);
    }
}

