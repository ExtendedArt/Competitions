/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.command.base.components;

import fun.lewisdev.tournaments.libs.command.base.components.TypeResult;

@FunctionalInterface
public interface ParameterResolver {
    public TypeResult resolve(Object var1);
}

