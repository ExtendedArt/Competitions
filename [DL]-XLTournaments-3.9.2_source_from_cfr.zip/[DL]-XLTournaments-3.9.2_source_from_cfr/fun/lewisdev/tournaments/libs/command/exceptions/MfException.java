/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.command.exceptions;

public final class MfException
extends RuntimeException {
    public MfException(String string) {
        super(string);
    }
}

