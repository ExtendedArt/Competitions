/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package fun.lewisdev.tournaments.libs.gui.guis;

import fun.lewisdev.tournaments.libs.gui.builder.gui.PaginatedBuilder;
import fun.lewisdev.tournaments.libs.gui.builder.gui.ScrollingBuilder;
import fun.lewisdev.tournaments.libs.gui.builder.gui.SimpleBuilder;
import fun.lewisdev.tournaments.libs.gui.builder.gui.StorageBuilder;
import fun.lewisdev.tournaments.libs.gui.components.GuiType;
import fun.lewisdev.tournaments.libs.gui.components.InteractionModifier;
import fun.lewisdev.tournaments.libs.gui.components.ScrollType;
import fun.lewisdev.tournaments.libs.gui.guis.BaseGui;
import java.util.Set;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class Gui
extends BaseGui {
    public Gui(int n, @NotNull String string, @NotNull Set<InteractionModifier> set) {
        super(n, string, set);
    }

    public Gui(@NotNull GuiType guiType, @NotNull String string, @NotNull Set<InteractionModifier> set) {
        super(guiType, string, set);
    }

    @Deprecated
    public Gui(int n, @NotNull String string) {
        super(n, string);
    }

    @Deprecated
    public Gui(@NotNull String string) {
        super(1, string);
    }

    @Deprecated
    public Gui(@NotNull GuiType guiType, @NotNull String string) {
        super(guiType, string);
    }

    @NotNull
    @Contract(value="_ -> new")
    public static SimpleBuilder gui(@NotNull GuiType guiType) {
        return new SimpleBuilder(guiType);
    }

    @NotNull
    @Contract(value=" -> new")
    public static SimpleBuilder gui() {
        return Gui.gui(GuiType.CHEST);
    }

    @NotNull
    @Contract(value=" -> new")
    public static StorageBuilder storage() {
        return new StorageBuilder();
    }

    @NotNull
    @Contract(value=" -> new")
    public static PaginatedBuilder paginated() {
        return new PaginatedBuilder();
    }

    @NotNull
    @Contract(value="_ -> new")
    public static ScrollingBuilder scrolling(@NotNull ScrollType scrollType) {
        return new ScrollingBuilder(scrollType);
    }

    @NotNull
    @Contract(value=" -> new")
    public static ScrollingBuilder scrolling() {
        return Gui.scrolling(ScrollType.VERTICAL);
    }
}

