/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.gui.components;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

public final class InteractionModifier
extends Enum<InteractionModifier> {
    public static final /* enum */ InteractionModifier PREVENT_ITEM_PLACE = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_ITEM_TAKE = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_ITEM_SWAP = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_ITEM_DROP = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_OTHER_ACTIONS = new InteractionModifier();
    public static final Set<InteractionModifier> VALUES;
    private static final /* synthetic */ InteractionModifier[] $VALUES;

    public static InteractionModifier[] values() {
        return (InteractionModifier[])$VALUES.clone();
    }

    public static InteractionModifier valueOf(String string) {
        return Enum.valueOf(InteractionModifier.class, string);
    }

    private static /* synthetic */ InteractionModifier[] $values() {
        return new InteractionModifier[]{PREVENT_ITEM_PLACE, PREVENT_ITEM_TAKE, PREVENT_ITEM_SWAP, PREVENT_ITEM_DROP, PREVENT_OTHER_ACTIONS};
    }

    static {
        $VALUES = InteractionModifier.$values();
        VALUES = Collections.unmodifiableSet(EnumSet.allOf(InteractionModifier.class));
    }
}

