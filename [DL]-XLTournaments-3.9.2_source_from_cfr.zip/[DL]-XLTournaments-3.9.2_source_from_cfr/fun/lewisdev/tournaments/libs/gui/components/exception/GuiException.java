/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.gui.components.exception;

public final class GuiException
extends RuntimeException {
    public GuiException(String string) {
        super(string);
    }
}

