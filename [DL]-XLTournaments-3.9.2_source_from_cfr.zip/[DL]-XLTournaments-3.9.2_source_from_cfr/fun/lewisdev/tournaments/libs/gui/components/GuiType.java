/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.inventory.InventoryType
 *  org.jetbrains.annotations.NotNull
 */
package fun.lewisdev.tournaments.libs.gui.components;

import org.bukkit.event.inventory.InventoryType;
import org.jetbrains.annotations.NotNull;

public final class GuiType
extends Enum<GuiType> {
    public static final /* enum */ GuiType CHEST = new GuiType(InventoryType.CHEST, 9);
    public static final /* enum */ GuiType WORKBENCH = new GuiType(InventoryType.WORKBENCH, 9);
    public static final /* enum */ GuiType HOPPER = new GuiType(InventoryType.HOPPER, 5);
    public static final /* enum */ GuiType DISPENSER = new GuiType(InventoryType.DISPENSER, 8);
    public static final /* enum */ GuiType BREWING = new GuiType(InventoryType.BREWING, 4);
    @NotNull
    private final InventoryType inventoryType;
    private final int limit;
    private static final /* synthetic */ GuiType[] $VALUES;

    public static GuiType[] values() {
        return (GuiType[])$VALUES.clone();
    }

    public static GuiType valueOf(String string) {
        return Enum.valueOf(GuiType.class, string);
    }

    private GuiType(InventoryType inventoryType, int n2) {
        this.inventoryType = inventoryType;
        this.limit = n2;
    }

    @NotNull
    public InventoryType getInventoryType() {
        return this.inventoryType;
    }

    public int getLimit() {
        return this.limit;
    }

    private static /* synthetic */ GuiType[] $values() {
        return new GuiType[]{CHEST, WORKBENCH, HOPPER, DISPENSER, BREWING};
    }

    static {
        $VALUES = GuiType.$values();
    }
}

