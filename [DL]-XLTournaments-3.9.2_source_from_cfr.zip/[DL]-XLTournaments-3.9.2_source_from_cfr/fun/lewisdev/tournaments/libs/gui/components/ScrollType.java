/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.gui.components;

public final class ScrollType
extends Enum<ScrollType> {
    public static final /* enum */ ScrollType HORIZONTAL = new ScrollType();
    public static final /* enum */ ScrollType VERTICAL = new ScrollType();
    private static final /* synthetic */ ScrollType[] $VALUES;

    public static ScrollType[] values() {
        return (ScrollType[])$VALUES.clone();
    }

    public static ScrollType valueOf(String string) {
        return Enum.valueOf(ScrollType.class, string);
    }

    private static /* synthetic */ ScrollType[] $values() {
        return new ScrollType[]{HORIZONTAL, VERTICAL};
    }

    static {
        $VALUES = ScrollType.$values();
    }
}

