/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.util;

import fun.lewisdev.tournaments.libs.hikari.util.ClockSource;
import fun.lewisdev.tournaments.libs.hikari.util.FastList;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.LockSupport;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConcurrentBag<T extends IConcurrentBagEntry>
implements AutoCloseable {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConcurrentBag.class);
    private final CopyOnWriteArrayList<T> sharedList;
    private final boolean weakThreadLocals;
    private final ThreadLocal<List<Object>> threadList;
    private final IBagStateListener listener;
    private final AtomicInteger waiters;
    private volatile boolean closed;
    private final SynchronousQueue<T> handoffQueue;

    public ConcurrentBag(IBagStateListener iBagStateListener) {
        this.listener = iBagStateListener;
        this.weakThreadLocals = this.useWeakThreadLocals();
        this.handoffQueue = new SynchronousQueue(true);
        this.waiters = new AtomicInteger();
        this.sharedList = new CopyOnWriteArrayList();
        this.threadList = this.weakThreadLocals ? ThreadLocal.withInitial(() -> new ArrayList(16)) : ThreadLocal.withInitial(() -> new FastList(IConcurrentBagEntry.class, 16));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public T borrow(long l, TimeUnit timeUnit) {
        int n;
        List<Object> list = this.threadList.get();
        for (n = list.size() - 1; n >= 0; --n) {
            IConcurrentBagEntry iConcurrentBagEntry;
            Iterator<T> iterator = list.remove(n);
            IConcurrentBagEntry iConcurrentBagEntry2 = iConcurrentBagEntry = this.weakThreadLocals ? (IConcurrentBagEntry)((WeakReference)((Object)iterator)).get() : (IConcurrentBagEntry)((Object)iterator);
            if (iConcurrentBagEntry == null || !iConcurrentBagEntry.compareAndSet(0, 1)) continue;
            return (T)iConcurrentBagEntry;
        }
        n = this.waiters.incrementAndGet();
        try {
            long l2;
            for (IConcurrentBagEntry iConcurrentBagEntry : this.sharedList) {
                if (!iConcurrentBagEntry.compareAndSet(0, 1)) continue;
                if (n > 1) {
                    this.listener.addBagItem(n - 1);
                }
                IConcurrentBagEntry iConcurrentBagEntry3 = iConcurrentBagEntry;
                return (T)iConcurrentBagEntry3;
            }
            this.listener.addBagItem(n);
            l = timeUnit.toNanos(l);
            do {
                l2 = ClockSource.currentTime();
                IConcurrentBagEntry iConcurrentBagEntry = (IConcurrentBagEntry)this.handoffQueue.poll(l, TimeUnit.NANOSECONDS);
                if (iConcurrentBagEntry != null && !iConcurrentBagEntry.compareAndSet(0, 1)) continue;
                IConcurrentBagEntry iConcurrentBagEntry4 = iConcurrentBagEntry;
                return (T)iConcurrentBagEntry4;
            } while ((l -= ClockSource.elapsedNanos(l2)) > 10000L);
            T t = null;
            return t;
        }
        finally {
            this.waiters.decrementAndGet();
        }
    }

    public void requite(T t) {
        t.setState(0);
        int n = 0;
        while (this.waiters.get() > 0) {
            if (t.getState() != 0 || this.handoffQueue.offer(t)) {
                return;
            }
            if ((n & 0xFF) == 255) {
                LockSupport.parkNanos(TimeUnit.MICROSECONDS.toNanos(10L));
            } else {
                Thread.yield();
            }
            ++n;
        }
        List<Object> list = this.threadList.get();
        if (list.size() < 50) {
            list.add(this.weakThreadLocals ? new WeakReference<T>(t) : t);
        }
    }

    public void add(T t) {
        if (this.closed) {
            LOGGER.info("ConcurrentBag has been closed, ignoring add()");
            throw new IllegalStateException("ConcurrentBag has been closed, ignoring add()");
        }
        this.sharedList.add(t);
        while (this.waiters.get() > 0 && t.getState() == 0 && !this.handoffQueue.offer(t)) {
            Thread.yield();
        }
    }

    public boolean remove(T t) {
        if (!(t.compareAndSet(1, -1) || t.compareAndSet(-2, -1) || this.closed)) {
            LOGGER.warn("Attempt to remove an object from the bag that was not borrowed or reserved: {}", (Object)t);
            return false;
        }
        boolean bl = this.sharedList.remove(t);
        if (!bl && !this.closed) {
            LOGGER.warn("Attempt to remove an object from the bag that does not exist: {}", (Object)t);
        }
        this.threadList.get().remove(t);
        return bl;
    }

    @Override
    public void close() {
        this.closed = true;
    }

    public List<T> values(int n) {
        List list = this.sharedList.stream().filter(iConcurrentBagEntry -> iConcurrentBagEntry.getState() == n).collect(Collectors.toList());
        Collections.reverse(list);
        return list;
    }

    public List<T> values() {
        return (List)this.sharedList.clone();
    }

    public boolean reserve(T t) {
        return t.compareAndSet(0, -2);
    }

    public void unreserve(T t) {
        if (t.compareAndSet(-2, 0)) {
            while (this.waiters.get() > 0 && !this.handoffQueue.offer(t)) {
                Thread.yield();
            }
        } else {
            LOGGER.warn("Attempt to relinquish an object to the bag that was not reserved: {}", (Object)t);
        }
    }

    public int getWaitingThreadCount() {
        return this.waiters.get();
    }

    public int getCount(int n) {
        int n2 = 0;
        for (IConcurrentBagEntry iConcurrentBagEntry : this.sharedList) {
            if (iConcurrentBagEntry.getState() != n) continue;
            ++n2;
        }
        return n2;
    }

    public int[] getStateCounts() {
        int[] arrn = new int[6];
        for (IConcurrentBagEntry iConcurrentBagEntry : this.sharedList) {
            int n = iConcurrentBagEntry.getState();
            arrn[n] = arrn[n] + 1;
        }
        arrn[4] = this.sharedList.size();
        arrn[5] = this.waiters.get();
        return arrn;
    }

    public int size() {
        return this.sharedList.size();
    }

    public void dumpState() {
        this.sharedList.forEach(iConcurrentBagEntry -> LOGGER.info(iConcurrentBagEntry.toString()));
    }

    private boolean useWeakThreadLocals() {
        try {
            if (System.getProperty("fun.lewisdev.tournaments.libs.hikari.useWeakReferences") != null) {
                return Boolean.getBoolean("fun.lewisdev.tournaments.libs.hikari.useWeakReferences");
            }
            return this.getClass().getClassLoader() != ClassLoader.getSystemClassLoader();
        }
        catch (SecurityException securityException) {
            return true;
        }
    }

    public static interface IBagStateListener {
        public void addBagItem(int var1);
    }

    public static interface IConcurrentBagEntry {
        public static final int STATE_NOT_IN_USE = 0;
        public static final int STATE_IN_USE = 1;
        public static final int STATE_REMOVED = -1;
        public static final int STATE_RESERVED = -2;

        public boolean compareAndSet(int var1, int var2);

        public void setState(int var1);

        public int getState();
    }
}

