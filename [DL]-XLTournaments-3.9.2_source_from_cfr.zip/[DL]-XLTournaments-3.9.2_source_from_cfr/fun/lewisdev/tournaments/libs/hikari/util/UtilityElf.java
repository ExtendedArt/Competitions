/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.util;

import fun.lewisdev.tournaments.libs.hikari.util.IsolationLevel;
import java.lang.reflect.Constructor;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class UtilityElf {
    private UtilityElf() {
    }

    public static String getNullIfEmpty(String string) {
        return string == null ? null : (string.trim().isEmpty() ? null : string.trim());
    }

    public static void quietlySleep(long l) {
        try {
            Thread.sleep(l);
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }

    public static boolean safeIsAssignableFrom(Object object, String string) {
        try {
            Class<?> class_ = Class.forName(string);
            return class_.isAssignableFrom(object.getClass());
        }
        catch (ClassNotFoundException classNotFoundException) {
            return false;
        }
    }

    public static <T> T createInstance(String string, Class<T> class_, Object ... arrobject) {
        if (string == null) {
            return null;
        }
        try {
            Class<?> class_2 = UtilityElf.class.getClassLoader().loadClass(string);
            if (arrobject.length == 0) {
                return class_.cast(class_2.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
            }
            Class[] arrclass = new Class[arrobject.length];
            for (int i = 0; i < arrobject.length; ++i) {
                arrclass[i] = arrobject[i].getClass();
            }
            Constructor<?> constructor = class_2.getConstructor(arrclass);
            return class_.cast(constructor.newInstance(arrobject));
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static ThreadPoolExecutor createThreadPoolExecutor(int n, String string, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler) {
        if (threadFactory == null) {
            threadFactory = new DefaultThreadFactory(string, true);
        }
        LinkedBlockingQueue<Runnable> linkedBlockingQueue = new LinkedBlockingQueue<Runnable>(n);
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(1, 1, 5L, TimeUnit.SECONDS, linkedBlockingQueue, threadFactory, rejectedExecutionHandler);
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    public static ThreadPoolExecutor createThreadPoolExecutor(BlockingQueue<Runnable> blockingQueue, String string, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler) {
        if (threadFactory == null) {
            threadFactory = new DefaultThreadFactory(string, true);
        }
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(1, 1, 5L, TimeUnit.SECONDS, blockingQueue, threadFactory, rejectedExecutionHandler);
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    public static int getTransactionIsolation(String string) {
        if (string != null) {
            try {
                String string2 = string.toUpperCase(Locale.ENGLISH);
                return IsolationLevel.valueOf(string2).getLevelId();
            }
            catch (IllegalArgumentException illegalArgumentException) {
                try {
                    int n = Integer.parseInt(string);
                    for (IsolationLevel isolationLevel : IsolationLevel.values()) {
                        if (isolationLevel.getLevelId() != n) continue;
                        return isolationLevel.getLevelId();
                    }
                    throw new IllegalArgumentException("Invalid transaction isolation value: " + string);
                }
                catch (NumberFormatException numberFormatException) {
                    throw new IllegalArgumentException("Invalid transaction isolation value: " + string, numberFormatException);
                }
            }
        }
        return -1;
    }

    public static final class DefaultThreadFactory
    implements ThreadFactory {
        private final String threadName;
        private final boolean daemon;

        public DefaultThreadFactory(String string, boolean bl) {
            this.threadName = string;
            this.daemon = bl;
        }

        @Override
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, this.threadName);
            thread.setDaemon(this.daemon);
            return thread;
        }
    }
}

