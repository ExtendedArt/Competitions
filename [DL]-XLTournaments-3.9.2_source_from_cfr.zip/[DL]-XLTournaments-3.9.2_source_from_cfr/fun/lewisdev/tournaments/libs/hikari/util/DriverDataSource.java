/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.util;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Map;
import java.util.Properties;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DriverDataSource
implements DataSource {
    private static final Logger LOGGER = LoggerFactory.getLogger(DriverDataSource.class);
    private static final String PASSWORD = "password";
    private static final String USER = "user";
    private final String jdbcUrl;
    private final Properties driverProperties;
    private Driver driver;

    /*
     * WARNING - void declaration
     */
    public DriverDataSource(String string, String string2, Properties properties, String string3, String string4) {
        Object object;
        this.jdbcUrl = string;
        this.driverProperties = new Properties();
        for (Map.Entry<Object, Object> object2 : properties.entrySet()) {
            this.driverProperties.setProperty(object2.getKey().toString(), object2.getValue().toString());
        }
        if (string3 != null) {
            this.driverProperties.put(USER, this.driverProperties.getProperty(USER, string3));
        }
        if (string4 != null) {
            this.driverProperties.put(PASSWORD, this.driverProperties.getProperty(PASSWORD, string4));
        }
        if (string2 != null) {
            object = DriverManager.getDrivers();
            while (object.hasMoreElements()) {
                Driver driver = (Driver)object.nextElement();
                if (!driver.getClass().getName().equals(string2)) continue;
                this.driver = driver;
                break;
            }
            if (this.driver == null) {
                void var7_14;
                LOGGER.warn("Registered driver with driverClassName={} was not found, trying direct instantiation.", (Object)string2);
                Object var7_10 = null;
                ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
                try {
                    void var7_12;
                    if (classLoader != null) {
                        try {
                            Class<?> class_ = classLoader.loadClass(string2);
                            LOGGER.debug("Driver class {} found in Thread context class loader {}", (Object)string2, (Object)classLoader);
                        }
                        catch (ClassNotFoundException classNotFoundException) {
                            LOGGER.debug("Driver class {} not found in Thread context class loader {}, trying classloader {}", string2, classLoader, this.getClass().getClassLoader());
                        }
                    }
                    if (var7_12 == null) {
                        Class<?> class_ = this.getClass().getClassLoader().loadClass(string2);
                        LOGGER.debug("Driver class {} found in the HikariConfig class classloader {}", (Object)string2, (Object)this.getClass().getClassLoader());
                    }
                }
                catch (ClassNotFoundException classNotFoundException) {
                    LOGGER.debug("Failed to load driver class {} from HikariConfig class classloader {}", (Object)string2, (Object)this.getClass().getClassLoader());
                }
                if (var7_14 != null) {
                    try {
                        this.driver = (Driver)var7_14.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                    }
                    catch (Exception exception) {
                        LOGGER.warn("Failed to create instance of driver class {}, trying jdbcUrl resolution", (Object)string2, (Object)exception);
                    }
                }
            }
        }
        object = string.replaceAll("([?&;]password=)[^&#;]*(.*)", "$1<masked>$2");
        try {
            if (this.driver == null) {
                this.driver = DriverManager.getDriver(string);
                LOGGER.debug("Loaded driver with class name {} for jdbcUrl={}", (Object)this.driver.getClass().getName(), object);
            } else if (!this.driver.acceptsURL(string)) {
                throw new RuntimeException("Driver " + string2 + " claims to not accept jdbcUrl, " + (String)object);
            }
        }
        catch (SQLException sQLException) {
            throw new RuntimeException("Failed to get driver instance for jdbcUrl=" + (String)object, sQLException);
        }
    }

    @Override
    public Connection getConnection() {
        return this.driver.connect(this.jdbcUrl, this.driverProperties);
    }

    @Override
    public Connection getConnection(String string, String string2) {
        Properties properties = (Properties)this.driverProperties.clone();
        if (string != null) {
            properties.put(USER, string);
            if (properties.containsKey("username")) {
                properties.put("username", string);
            }
        }
        if (string2 != null) {
            properties.put(PASSWORD, string2);
        }
        return this.driver.connect(this.jdbcUrl, properties);
    }

    @Override
    public PrintWriter getLogWriter() {
        throw new SQLFeatureNotSupportedException();
    }

    @Override
    public void setLogWriter(PrintWriter printWriter) {
        throw new SQLFeatureNotSupportedException();
    }

    @Override
    public void setLoginTimeout(int n) {
        DriverManager.setLoginTimeout(n);
    }

    @Override
    public int getLoginTimeout() {
        return DriverManager.getLoginTimeout();
    }

    @Override
    public java.util.logging.Logger getParentLogger() {
        return this.driver.getParentLogger();
    }

    @Override
    public <T> T unwrap(Class<T> class_) {
        throw new SQLFeatureNotSupportedException();
    }

    @Override
    public boolean isWrapperFor(Class<?> class_) {
        return false;
    }
}

