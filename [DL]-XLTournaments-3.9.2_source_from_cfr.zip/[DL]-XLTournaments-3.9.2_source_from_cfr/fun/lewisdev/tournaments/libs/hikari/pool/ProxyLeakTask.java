/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.pool;

import fun.lewisdev.tournaments.libs.hikari.pool.PoolEntry;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ProxyLeakTask
implements Runnable {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyLeakTask.class);
    static final ProxyLeakTask NO_LEAK = new ProxyLeakTask(){

        @Override
        void schedule(ScheduledExecutorService scheduledExecutorService, long l) {
        }

        @Override
        public void run() {
        }

        @Override
        public void cancel() {
        }
    };
    private ScheduledFuture<?> scheduledFuture;
    private String connectionName;
    private Exception exception;
    private String threadName;
    private boolean isLeaked;

    ProxyLeakTask(PoolEntry poolEntry) {
        this.exception = new Exception("Apparent connection leak detected");
        this.threadName = Thread.currentThread().getName();
        this.connectionName = poolEntry.connection.toString();
    }

    private ProxyLeakTask() {
    }

    void schedule(ScheduledExecutorService scheduledExecutorService, long l) {
        this.scheduledFuture = scheduledExecutorService.schedule(this, l, TimeUnit.MILLISECONDS);
    }

    @Override
    public void run() {
        this.isLeaked = true;
        StackTraceElement[] arrstackTraceElement = this.exception.getStackTrace();
        StackTraceElement[] arrstackTraceElement2 = new StackTraceElement[arrstackTraceElement.length - 5];
        System.arraycopy(arrstackTraceElement, 5, arrstackTraceElement2, 0, arrstackTraceElement2.length);
        this.exception.setStackTrace(arrstackTraceElement2);
        LOGGER.warn("Connection leak detection triggered for {} on thread {}, stack trace follows", this.connectionName, this.threadName, this.exception);
    }

    void cancel() {
        this.scheduledFuture.cancel(false);
        if (this.isLeaked) {
            LOGGER.info("Previously reported leaked connection {} on thread {} was returned to the pool (unleaked)", (Object)this.connectionName, (Object)this.threadName);
        }
    }
}

