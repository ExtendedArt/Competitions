/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.pool;

import fun.lewisdev.tournaments.libs.hikari.SQLExceptionOverride;
import fun.lewisdev.tournaments.libs.hikari.pool.PoolEntry;
import fun.lewisdev.tournaments.libs.hikari.pool.ProxyFactory;
import fun.lewisdev.tournaments.libs.hikari.pool.ProxyLeakTask;
import fun.lewisdev.tournaments.libs.hikari.util.FastList;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class ProxyConnection
implements Connection {
    static final int DIRTY_BIT_READONLY = 1;
    static final int DIRTY_BIT_AUTOCOMMIT = 2;
    static final int DIRTY_BIT_ISOLATION = 4;
    static final int DIRTY_BIT_CATALOG = 8;
    static final int DIRTY_BIT_NETTIMEOUT = 16;
    static final int DIRTY_BIT_SCHEMA = 32;
    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyConnection.class);
    private static final Set<String> ERROR_STATES = new HashSet<String>();
    private static final Set<Integer> ERROR_CODES;
    protected Connection delegate;
    private final PoolEntry poolEntry;
    private final ProxyLeakTask leakTask;
    private final FastList<Statement> openStatements;
    private int dirtyBits;
    private boolean isCommitStateDirty;
    private boolean isReadOnly;
    private boolean isAutoCommit;
    private int networkTimeout;
    private int transactionIsolation;
    private String dbcatalog;
    private String dbschema;

    protected ProxyConnection(PoolEntry poolEntry, Connection connection, FastList<Statement> fastList, ProxyLeakTask proxyLeakTask, boolean bl, boolean bl2) {
        this.poolEntry = poolEntry;
        this.delegate = connection;
        this.openStatements = fastList;
        this.leakTask = proxyLeakTask;
        this.isReadOnly = bl;
        this.isAutoCommit = bl2;
    }

    public final String toString() {
        return this.getClass().getSimpleName() + "@" + System.identityHashCode(this) + " wrapping " + this.delegate;
    }

    final boolean getAutoCommitState() {
        return this.isAutoCommit;
    }

    final String getCatalogState() {
        return this.dbcatalog;
    }

    final String getSchemaState() {
        return this.dbschema;
    }

    final int getTransactionIsolationState() {
        return this.transactionIsolation;
    }

    final boolean getReadOnlyState() {
        return this.isReadOnly;
    }

    final int getNetworkTimeoutState() {
        return this.networkTimeout;
    }

    final PoolEntry getPoolEntry() {
        return this.poolEntry;
    }

    final SQLException checkException(SQLException sQLException) {
        boolean bl = false;
        SQLException sQLException2 = sQLException;
        SQLExceptionOverride sQLExceptionOverride = this.poolEntry.getPoolBase().exceptionOverride;
        for (int n = 0; this.delegate != ClosedConnection.CLOSED_CONNECTION && sQLException2 != null && n < 10; sQLException2 = sQLException2.getNextException(), ++n) {
            String string = sQLException2.getSQLState();
            if ((string == null || !string.startsWith("08")) && !(sQLException2 instanceof SQLTimeoutException) && !ERROR_STATES.contains(string) && !ERROR_CODES.contains(sQLException2.getErrorCode())) continue;
            if (sQLExceptionOverride != null && sQLExceptionOverride.adjudicate(sQLException2) == SQLExceptionOverride.Override.DO_NOT_EVICT) break;
            bl = true;
            break;
        }
        if (bl) {
            SQLException sQLException3 = sQLException2 != null ? sQLException2 : sQLException;
            LOGGER.warn("{} - Connection {} marked as broken because of SQLSTATE({}), ErrorCode({})", this.poolEntry.getPoolName(), this.delegate, sQLException3.getSQLState(), sQLException3.getErrorCode(), sQLException3);
            this.leakTask.cancel();
            this.poolEntry.evict("(connection is broken)");
            this.delegate = ClosedConnection.CLOSED_CONNECTION;
        }
        return sQLException;
    }

    final synchronized void untrackStatement(Statement statement) {
        this.openStatements.remove(statement);
    }

    final void markCommitStateDirty() {
        if (!this.isAutoCommit) {
            this.isCommitStateDirty = true;
        }
    }

    void cancelLeakTask() {
        this.leakTask.cancel();
    }

    private synchronized <T extends Statement> T trackStatement(T t) {
        this.openStatements.add(t);
        return t;
    }

    private synchronized void closeStatements() {
        int n = this.openStatements.size();
        if (n > 0) {
            for (int i = 0; i < n && this.delegate != ClosedConnection.CLOSED_CONNECTION; ++i) {
                try {
                    Statement statement = this.openStatements.get(i);
                    if (statement == null) continue;
                    statement.close();
                    continue;
                }
                catch (SQLException sQLException) {
                    LOGGER.warn("{} - Connection {} marked as broken because of an exception closing open statements during Connection.close()", (Object)this.poolEntry.getPoolName(), (Object)this.delegate);
                    this.leakTask.cancel();
                    this.poolEntry.evict("(exception closing Statements during Connection.close())");
                    this.delegate = ClosedConnection.CLOSED_CONNECTION;
                }
            }
            this.openStatements.clear();
        }
    }

    @Override
    public final void close() {
        this.closeStatements();
        if (this.delegate != ClosedConnection.CLOSED_CONNECTION) {
            this.leakTask.cancel();
            try {
                if (this.isCommitStateDirty && !this.isAutoCommit) {
                    this.delegate.rollback();
                    LOGGER.debug("{} - Executed rollback on connection {} due to dirty commit state on close().", (Object)this.poolEntry.getPoolName(), (Object)this.delegate);
                }
                if (this.dirtyBits != 0) {
                    this.poolEntry.resetConnectionState(this, this.dirtyBits);
                }
                this.delegate.clearWarnings();
            }
            catch (SQLException sQLException) {
                if (!this.poolEntry.isMarkedEvicted()) {
                    throw this.checkException(sQLException);
                }
            }
            finally {
                this.delegate = ClosedConnection.CLOSED_CONNECTION;
                this.poolEntry.recycle();
            }
        }
    }

    @Override
    public boolean isClosed() {
        return this.delegate == ClosedConnection.CLOSED_CONNECTION;
    }

    @Override
    public Statement createStatement() {
        return ProxyFactory.getProxyStatement(this, this.trackStatement(this.delegate.createStatement()));
    }

    @Override
    public Statement createStatement(int n, int n2) {
        return ProxyFactory.getProxyStatement(this, this.trackStatement(this.delegate.createStatement(n, n2)));
    }

    @Override
    public Statement createStatement(int n, int n2, int n3) {
        return ProxyFactory.getProxyStatement(this, this.trackStatement(this.delegate.createStatement(n, n2, n3)));
    }

    @Override
    public CallableStatement prepareCall(String string) {
        return ProxyFactory.getProxyCallableStatement(this, this.trackStatement(this.delegate.prepareCall(string)));
    }

    @Override
    public CallableStatement prepareCall(String string, int n, int n2) {
        return ProxyFactory.getProxyCallableStatement(this, this.trackStatement(this.delegate.prepareCall(string, n, n2)));
    }

    @Override
    public CallableStatement prepareCall(String string, int n, int n2, int n3) {
        return ProxyFactory.getProxyCallableStatement(this, this.trackStatement(this.delegate.prepareCall(string, n, n2, n3)));
    }

    @Override
    public PreparedStatement prepareStatement(String string) {
        return ProxyFactory.getProxyPreparedStatement(this, this.trackStatement(this.delegate.prepareStatement(string)));
    }

    @Override
    public PreparedStatement prepareStatement(String string, int n) {
        return ProxyFactory.getProxyPreparedStatement(this, this.trackStatement(this.delegate.prepareStatement(string, n)));
    }

    @Override
    public PreparedStatement prepareStatement(String string, int n, int n2) {
        return ProxyFactory.getProxyPreparedStatement(this, this.trackStatement(this.delegate.prepareStatement(string, n, n2)));
    }

    @Override
    public PreparedStatement prepareStatement(String string, int n, int n2, int n3) {
        return ProxyFactory.getProxyPreparedStatement(this, this.trackStatement(this.delegate.prepareStatement(string, n, n2, n3)));
    }

    @Override
    public PreparedStatement prepareStatement(String string, int[] arrn) {
        return ProxyFactory.getProxyPreparedStatement(this, this.trackStatement(this.delegate.prepareStatement(string, arrn)));
    }

    @Override
    public PreparedStatement prepareStatement(String string, String[] arrstring) {
        return ProxyFactory.getProxyPreparedStatement(this, this.trackStatement(this.delegate.prepareStatement(string, arrstring)));
    }

    @Override
    public DatabaseMetaData getMetaData() {
        this.markCommitStateDirty();
        return ProxyFactory.getProxyDatabaseMetaData(this, this.delegate.getMetaData());
    }

    @Override
    public void commit() {
        this.delegate.commit();
        this.isCommitStateDirty = false;
    }

    @Override
    public void rollback() {
        this.delegate.rollback();
        this.isCommitStateDirty = false;
    }

    @Override
    public void rollback(Savepoint savepoint) {
        this.delegate.rollback(savepoint);
        this.isCommitStateDirty = false;
    }

    @Override
    public void setAutoCommit(boolean bl) {
        this.delegate.setAutoCommit(bl);
        this.isAutoCommit = bl;
        this.dirtyBits |= 2;
    }

    @Override
    public void setReadOnly(boolean bl) {
        this.delegate.setReadOnly(bl);
        this.isReadOnly = bl;
        this.isCommitStateDirty = false;
        this.dirtyBits |= 1;
    }

    @Override
    public void setTransactionIsolation(int n) {
        this.delegate.setTransactionIsolation(n);
        this.transactionIsolation = n;
        this.dirtyBits |= 4;
    }

    @Override
    public void setCatalog(String string) {
        this.delegate.setCatalog(string);
        this.dbcatalog = string;
        this.dirtyBits |= 8;
    }

    @Override
    public void setNetworkTimeout(Executor executor, int n) {
        this.delegate.setNetworkTimeout(executor, n);
        this.networkTimeout = n;
        this.dirtyBits |= 0x10;
    }

    @Override
    public void setSchema(String string) {
        this.delegate.setSchema(string);
        this.dbschema = string;
        this.dirtyBits |= 0x20;
    }

    @Override
    public final boolean isWrapperFor(Class<?> class_) {
        return class_.isInstance(this.delegate) || this.delegate != null && this.delegate.isWrapperFor(class_);
    }

    @Override
    public final <T> T unwrap(Class<T> class_) {
        if (class_.isInstance(this.delegate)) {
            return (T)this.delegate;
        }
        if (this.delegate != null) {
            return this.delegate.unwrap(class_);
        }
        throw new SQLException("Wrapped connection is not an instance of " + class_);
    }

    static {
        ERROR_STATES.add("0A000");
        ERROR_STATES.add("57P01");
        ERROR_STATES.add("57P02");
        ERROR_STATES.add("57P03");
        ERROR_STATES.add("01002");
        ERROR_STATES.add("JZ0C0");
        ERROR_STATES.add("JZ0C1");
        ERROR_CODES = new HashSet<Integer>();
        ERROR_CODES.add(500150);
        ERROR_CODES.add(2399);
    }

    private static final class ClosedConnection {
        static final Connection CLOSED_CONNECTION = ClosedConnection.getClosedConnection();

        private ClosedConnection() {
        }

        private static Connection getClosedConnection() {
            InvocationHandler invocationHandler = (object, method, arrobject) -> {
                String string = method.getName();
                if ("isClosed".equals(string)) {
                    return Boolean.TRUE;
                }
                if ("isValid".equals(string)) {
                    return Boolean.FALSE;
                }
                if ("abort".equals(string)) {
                    return Void.TYPE;
                }
                if ("close".equals(string)) {
                    return Void.TYPE;
                }
                if ("toString".equals(string)) {
                    return ClosedConnection.class.getCanonicalName();
                }
                throw new SQLException("Connection is closed");
            };
            return (Connection)Proxy.newProxyInstance(Connection.class.getClassLoader(), new Class[]{Connection.class}, invocationHandler);
        }
    }
}

