/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.pool;

import fun.lewisdev.tournaments.libs.hikari.pool.ProxyCallableStatement;
import fun.lewisdev.tournaments.libs.hikari.pool.ProxyConnection;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Wrapper;
import java.util.Calendar;
import java.util.Map;

public final class HikariProxyCallableStatement
extends ProxyCallableStatement
implements Wrapper,
AutoCloseable,
Statement,
PreparedStatement,
CallableStatement {
    public boolean isWrapperFor(Class class_) {
        try {
            return ((CallableStatement)this.delegate).isWrapperFor(class_);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public ResultSet executeQuery(String string) {
        try {
            return super.executeQuery(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int executeUpdate(String string) {
        try {
            return super.executeUpdate(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getMaxFieldSize() {
        try {
            return ((CallableStatement)this.delegate).getMaxFieldSize();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setMaxFieldSize(int n) {
        try {
            ((CallableStatement)this.delegate).setMaxFieldSize(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getMaxRows() {
        try {
            return ((CallableStatement)this.delegate).getMaxRows();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setMaxRows(int n) {
        try {
            ((CallableStatement)this.delegate).setMaxRows(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setEscapeProcessing(boolean bl) {
        try {
            ((CallableStatement)this.delegate).setEscapeProcessing(bl);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getQueryTimeout() {
        try {
            return ((CallableStatement)this.delegate).getQueryTimeout();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setQueryTimeout(int n) {
        try {
            ((CallableStatement)this.delegate).setQueryTimeout(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void cancel() {
        try {
            ((CallableStatement)this.delegate).cancel();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public SQLWarning getWarnings() {
        try {
            return ((CallableStatement)this.delegate).getWarnings();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void clearWarnings() {
        try {
            ((CallableStatement)this.delegate).clearWarnings();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCursorName(String string) {
        try {
            ((CallableStatement)this.delegate).setCursorName(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean execute(String string) {
        try {
            return super.execute(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public ResultSet getResultSet() {
        try {
            return super.getResultSet();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getUpdateCount() {
        try {
            return ((CallableStatement)this.delegate).getUpdateCount();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean getMoreResults() {
        try {
            return ((CallableStatement)this.delegate).getMoreResults();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setFetchDirection(int n) {
        try {
            ((CallableStatement)this.delegate).setFetchDirection(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getFetchDirection() {
        try {
            return ((CallableStatement)this.delegate).getFetchDirection();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setFetchSize(int n) {
        try {
            ((CallableStatement)this.delegate).setFetchSize(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getFetchSize() {
        try {
            return ((CallableStatement)this.delegate).getFetchSize();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getResultSetConcurrency() {
        try {
            return ((CallableStatement)this.delegate).getResultSetConcurrency();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getResultSetType() {
        try {
            return ((CallableStatement)this.delegate).getResultSetType();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void addBatch(String string) {
        try {
            ((CallableStatement)this.delegate).addBatch(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void clearBatch() {
        try {
            ((CallableStatement)this.delegate).clearBatch();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int[] executeBatch() {
        try {
            return super.executeBatch();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Connection getConnection() {
        try {
            return super.getConnection();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean getMoreResults(int n) {
        try {
            return ((CallableStatement)this.delegate).getMoreResults(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public ResultSet getGeneratedKeys() {
        try {
            return super.getGeneratedKeys();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int executeUpdate(String string, int n) {
        try {
            return super.executeUpdate(string, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int executeUpdate(String string, int[] arrn) {
        try {
            return super.executeUpdate(string, arrn);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int executeUpdate(String string, String[] arrstring) {
        try {
            return super.executeUpdate(string, arrstring);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean execute(String string, int n) {
        try {
            return super.execute(string, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean execute(String string, int[] arrn) {
        try {
            return super.execute(string, arrn);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean execute(String string, String[] arrstring) {
        try {
            return super.execute(string, arrstring);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getResultSetHoldability() {
        try {
            return ((CallableStatement)this.delegate).getResultSetHoldability();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean isClosed() {
        try {
            return ((CallableStatement)this.delegate).isClosed();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setPoolable(boolean bl) {
        try {
            ((CallableStatement)this.delegate).setPoolable(bl);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean isPoolable() {
        try {
            return ((CallableStatement)this.delegate).isPoolable();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void closeOnCompletion() {
        try {
            ((CallableStatement)this.delegate).closeOnCompletion();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean isCloseOnCompletion() {
        try {
            return ((CallableStatement)this.delegate).isCloseOnCompletion();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long getLargeUpdateCount() {
        try {
            return ((CallableStatement)this.delegate).getLargeUpdateCount();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setLargeMaxRows(long l) {
        try {
            ((CallableStatement)this.delegate).setLargeMaxRows(l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long getLargeMaxRows() {
        try {
            return ((CallableStatement)this.delegate).getLargeMaxRows();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long[] executeLargeBatch() {
        try {
            return ((CallableStatement)this.delegate).executeLargeBatch();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long executeLargeUpdate(String string) {
        try {
            return ((CallableStatement)this.delegate).executeLargeUpdate(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long executeLargeUpdate(String string, int n) {
        try {
            return ((CallableStatement)this.delegate).executeLargeUpdate(string, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long executeLargeUpdate(String string, int[] arrn) {
        try {
            return ((CallableStatement)this.delegate).executeLargeUpdate(string, arrn);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long executeLargeUpdate(String string, String[] arrstring) {
        try {
            return ((CallableStatement)this.delegate).executeLargeUpdate(string, arrstring);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String enquoteLiteral(String string) {
        try {
            return ((CallableStatement)this.delegate).enquoteLiteral(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String enquoteIdentifier(String string, boolean bl) {
        try {
            return ((CallableStatement)this.delegate).enquoteIdentifier(string, bl);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean isSimpleIdentifier(String string) {
        try {
            return ((CallableStatement)this.delegate).isSimpleIdentifier(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String enquoteNCharLiteral(String string) {
        try {
            return ((CallableStatement)this.delegate).enquoteNCharLiteral(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public ResultSet executeQuery() {
        try {
            return super.executeQuery();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int executeUpdate() {
        try {
            return super.executeUpdate();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNull(int n, int n2) {
        try {
            ((CallableStatement)this.delegate).setNull(n, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBoolean(int n, boolean bl) {
        try {
            ((CallableStatement)this.delegate).setBoolean(n, bl);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setByte(int n, byte by) {
        try {
            ((CallableStatement)this.delegate).setByte(n, by);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setShort(int n, short s) {
        try {
            ((CallableStatement)this.delegate).setShort(n, s);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setInt(int n, int n2) {
        try {
            ((CallableStatement)this.delegate).setInt(n, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setLong(int n, long l) {
        try {
            ((CallableStatement)this.delegate).setLong(n, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setFloat(int n, float f) {
        try {
            ((CallableStatement)this.delegate).setFloat(n, f);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setDouble(int n, double d) {
        try {
            ((CallableStatement)this.delegate).setDouble(n, d);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBigDecimal(int n, BigDecimal bigDecimal) {
        try {
            ((CallableStatement)this.delegate).setBigDecimal(n, bigDecimal);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setString(int n, String string) {
        try {
            ((CallableStatement)this.delegate).setString(n, string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBytes(int n, byte[] arrby) {
        try {
            ((CallableStatement)this.delegate).setBytes(n, arrby);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setDate(int n, Date date) {
        try {
            ((CallableStatement)this.delegate).setDate(n, date);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTime(int n, Time time) {
        try {
            ((CallableStatement)this.delegate).setTime(n, time);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTimestamp(int n, Timestamp timestamp) {
        try {
            ((CallableStatement)this.delegate).setTimestamp(n, timestamp);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setAsciiStream(int n, InputStream inputStream, int n2) {
        try {
            ((CallableStatement)this.delegate).setAsciiStream(n, inputStream, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setUnicodeStream(int n, InputStream inputStream, int n2) {
        try {
            ((CallableStatement)this.delegate).setUnicodeStream(n, inputStream, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBinaryStream(int n, InputStream inputStream, int n2) {
        try {
            ((CallableStatement)this.delegate).setBinaryStream(n, inputStream, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void clearParameters() {
        try {
            ((CallableStatement)this.delegate).clearParameters();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(int n, Object object, int n2) {
        try {
            ((CallableStatement)this.delegate).setObject(n, object, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(int n, Object object) {
        try {
            ((CallableStatement)this.delegate).setObject(n, object);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean execute() {
        try {
            return super.execute();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void addBatch() {
        try {
            ((CallableStatement)this.delegate).addBatch();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCharacterStream(int n, Reader reader, int n2) {
        try {
            ((CallableStatement)this.delegate).setCharacterStream(n, reader, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setRef(int n, Ref ref) {
        try {
            ((CallableStatement)this.delegate).setRef(n, ref);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBlob(int n, Blob blob) {
        try {
            ((CallableStatement)this.delegate).setBlob(n, blob);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setClob(int n, Clob clob) {
        try {
            ((CallableStatement)this.delegate).setClob(n, clob);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setArray(int n, Array array) {
        try {
            ((CallableStatement)this.delegate).setArray(n, array);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public ResultSetMetaData getMetaData() {
        try {
            return ((CallableStatement)this.delegate).getMetaData();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setDate(int n, Date date, Calendar calendar) {
        try {
            ((CallableStatement)this.delegate).setDate(n, date, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTime(int n, Time time, Calendar calendar) {
        try {
            ((CallableStatement)this.delegate).setTime(n, time, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTimestamp(int n, Timestamp timestamp, Calendar calendar) {
        try {
            ((CallableStatement)this.delegate).setTimestamp(n, timestamp, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNull(int n, int n2, String string) {
        try {
            ((CallableStatement)this.delegate).setNull(n, n2, string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setURL(int n, URL uRL) {
        try {
            ((CallableStatement)this.delegate).setURL(n, uRL);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public ParameterMetaData getParameterMetaData() {
        try {
            return ((CallableStatement)this.delegate).getParameterMetaData();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setRowId(int n, RowId rowId) {
        try {
            ((CallableStatement)this.delegate).setRowId(n, rowId);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNString(int n, String string) {
        try {
            ((CallableStatement)this.delegate).setNString(n, string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNCharacterStream(int n, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setNCharacterStream(n, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNClob(int n, NClob nClob) {
        try {
            ((CallableStatement)this.delegate).setNClob(n, nClob);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setClob(int n, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setClob(n, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBlob(int n, InputStream inputStream, long l) {
        try {
            ((CallableStatement)this.delegate).setBlob(n, inputStream, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNClob(int n, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setNClob(n, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setSQLXML(int n, SQLXML sQLXML) {
        try {
            ((CallableStatement)this.delegate).setSQLXML(n, sQLXML);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(int n, Object object, int n2, int n3) {
        try {
            ((CallableStatement)this.delegate).setObject(n, object, n2, n3);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setAsciiStream(int n, InputStream inputStream, long l) {
        try {
            ((CallableStatement)this.delegate).setAsciiStream(n, inputStream, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBinaryStream(int n, InputStream inputStream, long l) {
        try {
            ((CallableStatement)this.delegate).setBinaryStream(n, inputStream, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCharacterStream(int n, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setCharacterStream(n, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setAsciiStream(int n, InputStream inputStream) {
        try {
            ((CallableStatement)this.delegate).setAsciiStream(n, inputStream);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBinaryStream(int n, InputStream inputStream) {
        try {
            ((CallableStatement)this.delegate).setBinaryStream(n, inputStream);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCharacterStream(int n, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setCharacterStream(n, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNCharacterStream(int n, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setNCharacterStream(n, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setClob(int n, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setClob(n, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBlob(int n, InputStream inputStream) {
        try {
            ((CallableStatement)this.delegate).setBlob(n, inputStream);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNClob(int n, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setNClob(n, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(int n, Object object, SQLType sQLType, int n2) {
        try {
            ((CallableStatement)this.delegate).setObject(n, object, sQLType, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(int n, Object object, SQLType sQLType) {
        try {
            ((CallableStatement)this.delegate).setObject(n, object, sQLType);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long executeLargeUpdate() {
        try {
            return ((CallableStatement)this.delegate).executeLargeUpdate();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(int n, int n2) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(n, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(int n, int n2, int n3) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(n, n2, n3);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean wasNull() {
        try {
            return ((CallableStatement)this.delegate).wasNull();
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String getString(int n) {
        try {
            return ((CallableStatement)this.delegate).getString(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean getBoolean(int n) {
        try {
            return ((CallableStatement)this.delegate).getBoolean(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public byte getByte(int n) {
        try {
            return ((CallableStatement)this.delegate).getByte(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public short getShort(int n) {
        try {
            return ((CallableStatement)this.delegate).getShort(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getInt(int n) {
        try {
            return ((CallableStatement)this.delegate).getInt(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long getLong(int n) {
        try {
            return ((CallableStatement)this.delegate).getLong(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public float getFloat(int n) {
        try {
            return ((CallableStatement)this.delegate).getFloat(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public double getDouble(int n) {
        try {
            return ((CallableStatement)this.delegate).getDouble(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public BigDecimal getBigDecimal(int n, int n2) {
        try {
            return ((CallableStatement)this.delegate).getBigDecimal(n, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public byte[] getBytes(int n) {
        try {
            return ((CallableStatement)this.delegate).getBytes(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Date getDate(int n) {
        try {
            return ((CallableStatement)this.delegate).getDate(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Time getTime(int n) {
        try {
            return ((CallableStatement)this.delegate).getTime(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Timestamp getTimestamp(int n) {
        try {
            return ((CallableStatement)this.delegate).getTimestamp(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Object getObject(int n) {
        try {
            return ((CallableStatement)this.delegate).getObject(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public BigDecimal getBigDecimal(int n) {
        try {
            return ((CallableStatement)this.delegate).getBigDecimal(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    public Object getObject(int n, Map map) {
        try {
            return ((CallableStatement)this.delegate).getObject(n, map);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Ref getRef(int n) {
        try {
            return ((CallableStatement)this.delegate).getRef(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Blob getBlob(int n) {
        try {
            return ((CallableStatement)this.delegate).getBlob(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Clob getClob(int n) {
        try {
            return ((CallableStatement)this.delegate).getClob(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Array getArray(int n) {
        try {
            return ((CallableStatement)this.delegate).getArray(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Date getDate(int n, Calendar calendar) {
        try {
            return ((CallableStatement)this.delegate).getDate(n, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Time getTime(int n, Calendar calendar) {
        try {
            return ((CallableStatement)this.delegate).getTime(n, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Timestamp getTimestamp(int n, Calendar calendar) {
        try {
            return ((CallableStatement)this.delegate).getTimestamp(n, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(int n, int n2, String string) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(n, n2, string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(String string, int n) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(string, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(String string, int n, int n2) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(string, n, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(String string, int n, String string2) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(string, n, string2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public URL getURL(int n) {
        try {
            return ((CallableStatement)this.delegate).getURL(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setURL(String string, URL uRL) {
        try {
            ((CallableStatement)this.delegate).setURL(string, uRL);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNull(String string, int n) {
        try {
            ((CallableStatement)this.delegate).setNull(string, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBoolean(String string, boolean bl) {
        try {
            ((CallableStatement)this.delegate).setBoolean(string, bl);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setByte(String string, byte by) {
        try {
            ((CallableStatement)this.delegate).setByte(string, by);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setShort(String string, short s) {
        try {
            ((CallableStatement)this.delegate).setShort(string, s);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setInt(String string, int n) {
        try {
            ((CallableStatement)this.delegate).setInt(string, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setLong(String string, long l) {
        try {
            ((CallableStatement)this.delegate).setLong(string, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setFloat(String string, float f) {
        try {
            ((CallableStatement)this.delegate).setFloat(string, f);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setDouble(String string, double d) {
        try {
            ((CallableStatement)this.delegate).setDouble(string, d);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBigDecimal(String string, BigDecimal bigDecimal) {
        try {
            ((CallableStatement)this.delegate).setBigDecimal(string, bigDecimal);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setString(String string, String string2) {
        try {
            ((CallableStatement)this.delegate).setString(string, string2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBytes(String string, byte[] arrby) {
        try {
            ((CallableStatement)this.delegate).setBytes(string, arrby);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setDate(String string, Date date) {
        try {
            ((CallableStatement)this.delegate).setDate(string, date);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTime(String string, Time time) {
        try {
            ((CallableStatement)this.delegate).setTime(string, time);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTimestamp(String string, Timestamp timestamp) {
        try {
            ((CallableStatement)this.delegate).setTimestamp(string, timestamp);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setAsciiStream(String string, InputStream inputStream, int n) {
        try {
            ((CallableStatement)this.delegate).setAsciiStream(string, inputStream, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBinaryStream(String string, InputStream inputStream, int n) {
        try {
            ((CallableStatement)this.delegate).setBinaryStream(string, inputStream, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(String string, Object object, int n, int n2) {
        try {
            ((CallableStatement)this.delegate).setObject(string, object, n, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(String string, Object object, int n) {
        try {
            ((CallableStatement)this.delegate).setObject(string, object, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(String string, Object object) {
        try {
            ((CallableStatement)this.delegate).setObject(string, object);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCharacterStream(String string, Reader reader, int n) {
        try {
            ((CallableStatement)this.delegate).setCharacterStream(string, reader, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setDate(String string, Date date, Calendar calendar) {
        try {
            ((CallableStatement)this.delegate).setDate(string, date, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTime(String string, Time time, Calendar calendar) {
        try {
            ((CallableStatement)this.delegate).setTime(string, time, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setTimestamp(String string, Timestamp timestamp, Calendar calendar) {
        try {
            ((CallableStatement)this.delegate).setTimestamp(string, timestamp, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNull(String string, int n, String string2) {
        try {
            ((CallableStatement)this.delegate).setNull(string, n, string2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String getString(String string) {
        try {
            return ((CallableStatement)this.delegate).getString(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public boolean getBoolean(String string) {
        try {
            return ((CallableStatement)this.delegate).getBoolean(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public byte getByte(String string) {
        try {
            return ((CallableStatement)this.delegate).getByte(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public short getShort(String string) {
        try {
            return ((CallableStatement)this.delegate).getShort(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public int getInt(String string) {
        try {
            return ((CallableStatement)this.delegate).getInt(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public long getLong(String string) {
        try {
            return ((CallableStatement)this.delegate).getLong(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public float getFloat(String string) {
        try {
            return ((CallableStatement)this.delegate).getFloat(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public double getDouble(String string) {
        try {
            return ((CallableStatement)this.delegate).getDouble(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public byte[] getBytes(String string) {
        try {
            return ((CallableStatement)this.delegate).getBytes(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Date getDate(String string) {
        try {
            return ((CallableStatement)this.delegate).getDate(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Time getTime(String string) {
        try {
            return ((CallableStatement)this.delegate).getTime(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Timestamp getTimestamp(String string) {
        try {
            return ((CallableStatement)this.delegate).getTimestamp(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Object getObject(String string) {
        try {
            return ((CallableStatement)this.delegate).getObject(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public BigDecimal getBigDecimal(String string) {
        try {
            return ((CallableStatement)this.delegate).getBigDecimal(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    public Object getObject(String string, Map map) {
        try {
            return ((CallableStatement)this.delegate).getObject(string, map);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Ref getRef(String string) {
        try {
            return ((CallableStatement)this.delegate).getRef(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Blob getBlob(String string) {
        try {
            return ((CallableStatement)this.delegate).getBlob(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Clob getClob(String string) {
        try {
            return ((CallableStatement)this.delegate).getClob(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Array getArray(String string) {
        try {
            return ((CallableStatement)this.delegate).getArray(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Date getDate(String string, Calendar calendar) {
        try {
            return ((CallableStatement)this.delegate).getDate(string, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Time getTime(String string, Calendar calendar) {
        try {
            return ((CallableStatement)this.delegate).getTime(string, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Timestamp getTimestamp(String string, Calendar calendar) {
        try {
            return ((CallableStatement)this.delegate).getTimestamp(string, calendar);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public URL getURL(String string) {
        try {
            return ((CallableStatement)this.delegate).getURL(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public RowId getRowId(int n) {
        try {
            return ((CallableStatement)this.delegate).getRowId(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public RowId getRowId(String string) {
        try {
            return ((CallableStatement)this.delegate).getRowId(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setRowId(String string, RowId rowId) {
        try {
            ((CallableStatement)this.delegate).setRowId(string, rowId);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNString(String string, String string2) {
        try {
            ((CallableStatement)this.delegate).setNString(string, string2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNCharacterStream(String string, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setNCharacterStream(string, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNClob(String string, NClob nClob) {
        try {
            ((CallableStatement)this.delegate).setNClob(string, nClob);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setClob(String string, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setClob(string, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBlob(String string, InputStream inputStream, long l) {
        try {
            ((CallableStatement)this.delegate).setBlob(string, inputStream, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNClob(String string, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setNClob(string, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public NClob getNClob(int n) {
        try {
            return ((CallableStatement)this.delegate).getNClob(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public NClob getNClob(String string) {
        try {
            return ((CallableStatement)this.delegate).getNClob(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setSQLXML(String string, SQLXML sQLXML) {
        try {
            ((CallableStatement)this.delegate).setSQLXML(string, sQLXML);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public SQLXML getSQLXML(int n) {
        try {
            return ((CallableStatement)this.delegate).getSQLXML(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public SQLXML getSQLXML(String string) {
        try {
            return ((CallableStatement)this.delegate).getSQLXML(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String getNString(int n) {
        try {
            return ((CallableStatement)this.delegate).getNString(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public String getNString(String string) {
        try {
            return ((CallableStatement)this.delegate).getNString(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Reader getNCharacterStream(int n) {
        try {
            return ((CallableStatement)this.delegate).getNCharacterStream(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Reader getNCharacterStream(String string) {
        try {
            return ((CallableStatement)this.delegate).getNCharacterStream(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Reader getCharacterStream(int n) {
        try {
            return ((CallableStatement)this.delegate).getCharacterStream(n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public Reader getCharacterStream(String string) {
        try {
            return ((CallableStatement)this.delegate).getCharacterStream(string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBlob(String string, Blob blob) {
        try {
            ((CallableStatement)this.delegate).setBlob(string, blob);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setClob(String string, Clob clob) {
        try {
            ((CallableStatement)this.delegate).setClob(string, clob);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setAsciiStream(String string, InputStream inputStream, long l) {
        try {
            ((CallableStatement)this.delegate).setAsciiStream(string, inputStream, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBinaryStream(String string, InputStream inputStream, long l) {
        try {
            ((CallableStatement)this.delegate).setBinaryStream(string, inputStream, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCharacterStream(String string, Reader reader, long l) {
        try {
            ((CallableStatement)this.delegate).setCharacterStream(string, reader, l);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setAsciiStream(String string, InputStream inputStream) {
        try {
            ((CallableStatement)this.delegate).setAsciiStream(string, inputStream);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBinaryStream(String string, InputStream inputStream) {
        try {
            ((CallableStatement)this.delegate).setBinaryStream(string, inputStream);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setCharacterStream(String string, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setCharacterStream(string, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNCharacterStream(String string, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setNCharacterStream(string, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setClob(String string, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setClob(string, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setBlob(String string, InputStream inputStream) {
        try {
            ((CallableStatement)this.delegate).setBlob(string, inputStream);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setNClob(String string, Reader reader) {
        try {
            ((CallableStatement)this.delegate).setNClob(string, reader);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    public Object getObject(int n, Class class_) {
        try {
            return ((CallableStatement)this.delegate).getObject(n, class_);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    public Object getObject(String string, Class class_) {
        try {
            return ((CallableStatement)this.delegate).getObject(string, class_);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(String string, Object object, SQLType sQLType, int n) {
        try {
            ((CallableStatement)this.delegate).setObject(string, object, sQLType, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void setObject(String string, Object object, SQLType sQLType) {
        try {
            ((CallableStatement)this.delegate).setObject(string, object, sQLType);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(int n, SQLType sQLType) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(n, sQLType);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(int n, SQLType sQLType, int n2) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(n, sQLType, n2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(int n, SQLType sQLType, String string) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(n, sQLType, string);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(String string, SQLType sQLType) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(string, sQLType);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(String string, SQLType sQLType, int n) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(string, sQLType, n);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    @Override
    public void registerOutParameter(String string, SQLType sQLType, String string2) {
        try {
            ((CallableStatement)this.delegate).registerOutParameter(string, sQLType, string2);
        }
        catch (SQLException sQLException) {
            throw this.checkException(sQLException);
        }
    }

    protected HikariProxyCallableStatement(ProxyConnection proxyConnection, CallableStatement callableStatement) {
        super(proxyConnection, callableStatement);
    }
}

