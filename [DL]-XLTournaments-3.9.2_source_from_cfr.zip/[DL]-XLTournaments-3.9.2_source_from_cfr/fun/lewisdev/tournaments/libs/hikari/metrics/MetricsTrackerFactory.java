/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.libs.hikari.metrics;

import fun.lewisdev.tournaments.libs.hikari.metrics.IMetricsTracker;
import fun.lewisdev.tournaments.libs.hikari.metrics.PoolStats;

public interface MetricsTrackerFactory {
    public IMetricsTracker create(String var1, PoolStats var2);
}

