/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  io.micrometer.core.instrument.MeterRegistry
 */
package fun.lewisdev.tournaments.libs.hikari.metrics.micrometer;

import fun.lewisdev.tournaments.libs.hikari.metrics.IMetricsTracker;
import fun.lewisdev.tournaments.libs.hikari.metrics.MetricsTrackerFactory;
import fun.lewisdev.tournaments.libs.hikari.metrics.PoolStats;
import fun.lewisdev.tournaments.libs.hikari.metrics.micrometer.MicrometerMetricsTracker;
import io.micrometer.core.instrument.MeterRegistry;

public class MicrometerMetricsTrackerFactory
implements MetricsTrackerFactory {
    private final MeterRegistry registry;

    public MicrometerMetricsTrackerFactory(MeterRegistry meterRegistry) {
        this.registry = meterRegistry;
    }

    @Override
    public IMetricsTracker create(String string, PoolStats poolStats) {
        return new MicrometerMetricsTracker(string, poolStats, this.registry);
    }
}

