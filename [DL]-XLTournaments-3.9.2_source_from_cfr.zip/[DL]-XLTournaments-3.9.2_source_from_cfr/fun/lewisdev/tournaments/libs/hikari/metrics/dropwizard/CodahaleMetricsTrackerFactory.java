/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.codahale.metrics.MetricRegistry
 */
package fun.lewisdev.tournaments.libs.hikari.metrics.dropwizard;

import com.codahale.metrics.MetricRegistry;
import fun.lewisdev.tournaments.libs.hikari.metrics.IMetricsTracker;
import fun.lewisdev.tournaments.libs.hikari.metrics.MetricsTrackerFactory;
import fun.lewisdev.tournaments.libs.hikari.metrics.PoolStats;
import fun.lewisdev.tournaments.libs.hikari.metrics.dropwizard.CodaHaleMetricsTracker;

public final class CodahaleMetricsTrackerFactory
implements MetricsTrackerFactory {
    private final MetricRegistry registry;

    public CodahaleMetricsTrackerFactory(MetricRegistry metricRegistry) {
        this.registry = metricRegistry;
    }

    public MetricRegistry getRegistry() {
        return this.registry;
    }

    @Override
    public IMetricsTracker create(String string, PoolStats poolStats) {
        return new CodaHaleMetricsTracker(string, poolStats, this.registry);
    }
}

