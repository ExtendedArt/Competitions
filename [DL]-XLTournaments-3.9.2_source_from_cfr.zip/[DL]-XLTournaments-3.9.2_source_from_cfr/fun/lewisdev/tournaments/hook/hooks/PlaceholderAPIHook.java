/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 *  org.jetbrains.annotations.NotNull
 */
package fun.lewisdev.tournaments.hook.hooks;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentManager;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public class PlaceholderAPIHook
extends PlaceholderExpansion {
    private static final Pattern LEADER_NAME_PATTERN = Pattern.compile("(\\w+)_LEADER_NAME_(\\w+)");
    private static final Pattern LEADER_SCORE_PATTERN = Pattern.compile("(\\w+)_LEADER_SCORE_(\\w+)");
    private static final Pattern PLAYER_SCORE_PATTERN = Pattern.compile("(\\w+)_SCORE");
    private static final Pattern PLAYER_POSITION_PATTERN = Pattern.compile("(\\w+)_POSITION");
    private static final Pattern TIME_REMAINING_PATTERN = Pattern.compile("(\\w+)_TIME_REMAINING");
    private static final Pattern START_MONTH_PATTERN = Pattern.compile("(\\w+)_START_MONTH");
    private static final Pattern START_MONTH_NUMBER_PATTERN = Pattern.compile("(\\w+)_START_MONTH_NUMBER");
    private static final Pattern END_MONTH_PATTERN = Pattern.compile("(\\w+)_END_MONTH");
    private static final Pattern END_MONTH_NUMBER_PATTERN = Pattern.compile("(\\w+)_END_MONTH_NUMBER");
    private static final Pattern START_DAY_PATTERN = Pattern.compile("(\\w+)_START_DAY");
    private static final Pattern END_DAY_PATTERN = Pattern.compile("(\\w+)_END_DAY");
    private final XLTournamentsPlugin plugin;
    private final TournamentManager tournamentManager;

    public PlaceholderAPIHook(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
        this.tournamentManager = xLTournamentsPlugin.getTournamentManager();
    }

    public boolean persist() {
        return true;
    }

    public boolean canRegister() {
        return true;
    }

    @NotNull
    public String getAuthor() {
        return this.plugin.getDescription().getAuthors().toString();
    }

    @NotNull
    public String getIdentifier() {
        return "xltournaments";
    }

    @NotNull
    public String getVersion() {
        return this.plugin.getDescription().getVersion();
    }

    public String onRequest(OfflinePlayer offlinePlayer, String string) {
        Matcher matcher;
        if (offlinePlayer == null) {
            return "";
        }
        UUID uUID = offlinePlayer.getUniqueId();
        try {
            matcher = START_DAY_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getStartDay();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = END_DAY_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getEndDay();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = START_MONTH_NUMBER_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getStartMonthNumber();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = START_MONTH_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getStartMonth();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = END_MONTH_NUMBER_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getEndMonthNumber();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = END_MONTH_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getEndMonth();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = TIME_REMAINING_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                return optional.get().getTimeRemaining();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = LEADER_NAME_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                Tournament tournament2 = optional.get();
                OfflinePlayer offlinePlayer2 = tournament2.getPlayerFromPosition(Integer.parseInt(matcher.group(2)));
                if (offlinePlayer2 == null) {
                    return "N/A";
                }
                return offlinePlayer2.getName();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = LEADER_SCORE_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                return optional.map(tournament -> String.valueOf(tournament.getScoreFromPosition(Integer.parseInt(matcher.group(2))))).orElse("Invalid Tournament ID");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = PLAYER_SCORE_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                Tournament tournament3 = optional.get();
                if (tournament3.isParticipant(uUID)) {
                    return String.valueOf(tournament3.getScore(uUID));
                }
                return "N/A";
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            matcher = PLAYER_POSITION_PATTERN.matcher(string.toUpperCase());
            if (matcher.find()) {
                Optional<Tournament> optional = this.tournamentManager.getTournament(matcher.group(1));
                if (!optional.isPresent()) {
                    return "Invalid Tournament ID";
                }
                Tournament tournament4 = optional.get();
                if (tournament4.isParticipant(uUID)) {
                    return String.valueOf(tournament4.getPosition(uUID));
                }
                return "N/A";
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }
}

