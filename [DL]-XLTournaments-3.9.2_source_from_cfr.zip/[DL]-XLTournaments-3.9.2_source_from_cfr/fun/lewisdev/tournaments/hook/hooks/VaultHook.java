/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.RegisteredServiceProvider
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments.hook.hooks;

import fun.lewisdev.tournaments.hook.PluginHook;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class VaultHook
implements PluginHook {
    private Economy economy;

    public VaultHook() {
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    @Override
    public boolean onEnable(JavaPlugin javaPlugin) {
        RegisteredServiceProvider registeredServiceProvider = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReCtmeaKS", "\u001e\u0000.{\u0013\u001f-\u001f/\u0005\\99\u0004\r/\u001ah\u001b\u0013?4_ '\u0002'!\u001e<2\u0018\u0004", (Object)"\u0016\u0017=\u0006\u0014\u00180\u00114", "Y[\u0005:\u0003\ri\u00163\u001a\u0019 !^9#\u00060\u0014\u0000r", -115, -1339322326, "fo6wFMxjjNpMH5IMAOrDxOg14PAZSw6NNenJYIhQmlcRRz", (Object)javaPlugin).getServicesManager().getRegistration(Economy.class);
        if (registeredServiceProvider == null) {
            return false;
        }
        this.economy = (Economy)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReCtmeaKS", "\u001e\u0001.{\u0013\u001a\u001a\u001f\u0018\u0005]99\u0004\b\u0018\u001a_#\u0016.<\u0002\u001b\u0014\u0006\u0014\u0015 ,'\u0007\u0006\u0012\u0011!\u0003\u001c?<\u0015\n\u0003", (Object)"\u0016\u0016=\u0005\u0003\u0000\u0007\u001d\u0015\u0014\u0001", "YZ\u0005?\u0010\u0019\u0010[\u001d\u0010\u001d.z>\r\u001b\u0011\u0012\u0005H", -115, 0.5603445322819516, "wOSdqla8oYIA8n7ZCGsOAxNqW6QBuQW1eFin6KCUqY", (Object)registeredServiceProvider);
        return true;
    }

    @Override
    public String getIdentifier() {
        return "Vault";
    }

    public double getBalance(Player player) {
        return this.economy.getBalance((OfflinePlayer)player);
    }

    public void withdraw(Player player, double d) {
        this.economy.withdrawPlayer((OfflinePlayer)player, d);
    }
}

