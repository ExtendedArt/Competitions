/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments.hook;

import org.bukkit.plugin.java.JavaPlugin;

public interface PluginHook {
    public boolean onEnable(JavaPlugin var1);

    public String getIdentifier();
}

