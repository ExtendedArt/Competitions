/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.exception;

import fun.lewisdev.tournaments.exception.TournamentLoadException;

public class ObjectiveNotFoundException
extends TournamentLoadException {
    public ObjectiveNotFoundException(String string) {
        super(string);
    }
}

