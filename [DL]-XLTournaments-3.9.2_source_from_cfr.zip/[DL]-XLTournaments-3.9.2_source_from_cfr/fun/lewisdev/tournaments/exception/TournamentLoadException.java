/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.exception;

import fun.lewisdev.tournaments.exception.TournamentException;

public class TournamentLoadException
extends TournamentException {
    public TournamentLoadException(String string) {
        super(string);
    }
}

