/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.exception;

public class TournamentException
extends RuntimeException {
    public TournamentException(String string) {
        super(string);
    }
}

