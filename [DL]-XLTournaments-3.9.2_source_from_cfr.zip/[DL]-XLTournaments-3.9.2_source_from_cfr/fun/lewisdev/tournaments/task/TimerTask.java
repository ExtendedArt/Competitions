/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments.task;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentManager;
import fun.lewisdev.tournaments.tournament.TournamentStatus;
import fun.lewisdev.tournaments.utility.Timeline;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class TimerTask
implements Runnable {
    private static final JavaPlugin JAVA_PLUGIN = JavaPlugin.getProvidingPlugin(XLTournamentsPlugin.class);
    private final TournamentManager tournamentManager;

    public TimerTask(TournamentManager tournamentManager) {
        this.tournamentManager = tournamentManager;
    }

    @Override
    public void run() {
        for (Tournament tournament2 : this.tournamentManager.getTournaments().stream().filter(tournament -> tournament.getStatus() != TournamentStatus.ENDED).collect(Collectors.toList())) {
            if (tournament2.getStatus() == TournamentStatus.WAITING && tournament2.getStartTimeMillis() < System.currentTimeMillis()) {
                tournament2.start(true);
                continue;
            }
            if (tournament2.getEndTimeMillis() >= System.currentTimeMillis()) continue;
            tournament2.stop();
            tournament2.setStatus(TournamentStatus.ENDED);
            if (tournament2.getTimeline() == Timeline.SPECIFIC) continue;
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)JAVA_PLUGIN, tournament2::clearParticipants);
            tournament2.setStatus(TournamentStatus.ENDED);
            Bukkit.getScheduler().runTaskLater((Plugin)JAVA_PLUGIN, () -> {
                tournament2.updateStatus();
                tournament2.start(true);
            }, 100L);
        }
    }
}

