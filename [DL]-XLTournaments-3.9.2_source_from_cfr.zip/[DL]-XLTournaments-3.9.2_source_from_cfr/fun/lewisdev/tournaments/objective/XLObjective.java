/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments.objective;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentStatus;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public abstract class XLObjective
implements Listener {
    private final String identifier;
    private boolean listenerRegistered;
    private final Map<String, Tournament> tournamentsLinked;

    public XLObjective(String string) {
        this.identifier = string;
        this.tournamentsLinked = new HashMap<String, Tournament>();
        this.listenerRegistered = false;
    }

    public abstract boolean loadTournament(Tournament var1, FileConfiguration var2);

    public void addTournament(Tournament tournament) {
        if (!this.listenerRegistered) {
            Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)JavaPlugin.getProvidingPlugin(XLTournamentsPlugin.class));
            this.listenerRegistered = true;
        }
        this.tournamentsLinked.put(tournament.getIdentifier(), tournament);
    }

    public boolean canExecute(Tournament tournament, Player player) {
        UUID uUID = player.getUniqueId();
        return tournament.isParticipant(uUID) && !tournament.hasFinishedChallenge(uUID) && !tournament.getDisabledWorlds().contains(player.getWorld().getName()) && !tournament.getDisabledGamemodes().contains((Object)player.getGameMode());
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public List<Tournament> getTournaments() {
        return Collections.unmodifiableList(this.tournamentsLinked.values().stream().filter(tournament -> tournament.getStatus() == TournamentStatus.ACTIVE).collect(Collectors.toList()));
    }
}

