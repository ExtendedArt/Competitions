/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.badbones69.crazycrates.api.events.PlayerPrizeEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package fun.lewisdev.tournaments.objective.external;

import com.badbones69.crazycrates.api.events.PlayerPrizeEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class CrazyCratesObjective
extends XLObjective {
    public CrazyCratesObjective() {
        super("CRAZYCRATES_OPEN");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerPrize(PlayerPrizeEvent playerPrizeEvent) {
        Player player = playerPrizeEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

