/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.badbones69.crazyenvoys.api.events.EnvoyOpenEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package fun.lewisdev.tournaments.objective.external;

import com.badbones69.crazyenvoys.api.events.EnvoyOpenEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class CrazyEnvoyObjective
extends XLObjective {
    public CrazyEnvoyObjective() {
        super("CRAZYENVOY_OPEN");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEnvoyOpen(EnvoyOpenEvent envoyOpenEvent) {
        Player player = envoyOpenEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

