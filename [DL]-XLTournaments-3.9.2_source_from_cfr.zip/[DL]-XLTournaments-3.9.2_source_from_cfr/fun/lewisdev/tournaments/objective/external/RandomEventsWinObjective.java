/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.adri1711.randomevents.api.events.ReventEndEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 */
package fun.lewisdev.tournaments.objective.external;

import com.adri1711.randomevents.api.events.ReventEndEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

public class RandomEventsWinObjective
extends XLObjective {
    public RandomEventsWinObjective() {
        super("RANDOMEVENTS_WINS");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler
    public void onEventEnd(ReventEndEvent reventEndEvent) {
        for (Tournament tournament : this.getTournaments()) {
            for (Player player : reventEndEvent.getWinners()) {
                if (!this.canExecute(tournament, player)) continue;
                tournament.addScore(player.getUniqueId(), 1);
            }
        }
    }
}

