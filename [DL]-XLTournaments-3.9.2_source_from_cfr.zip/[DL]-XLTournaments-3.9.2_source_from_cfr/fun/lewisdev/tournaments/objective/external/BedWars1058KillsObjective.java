/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.andrei1058.bedwars.api.events.player.PlayerKillEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 */
package fun.lewisdev.tournaments.objective.external;

import com.andrei1058.bedwars.api.events.player.PlayerKillEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

public class BedWars1058KillsObjective
extends XLObjective {
    public BedWars1058KillsObjective() {
        super("BEDWARS1058_KILLS");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler
    public void onPlayerKill(PlayerKillEvent playerKillEvent) {
        Player player = playerKillEvent.getKiller();
        if (player == null) {
            return;
        }
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

