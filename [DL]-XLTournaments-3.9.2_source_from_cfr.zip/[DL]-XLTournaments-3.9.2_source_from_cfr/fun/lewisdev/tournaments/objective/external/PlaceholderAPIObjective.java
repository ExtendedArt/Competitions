/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitTask
 */
package fun.lewisdev.tournaments.objective.external;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import java.util.UUID;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class PlaceholderAPIObjective
extends XLObjective {
    private final JavaPlugin JAVA_PLUGIN = JavaPlugin.getProvidingPlugin(XLTournamentsPlugin.class);
    private BukkitTask task;

    public PlaceholderAPIObjective() {
        super("PLACEHOLDERAPI");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        String string = fileConfiguration.getString("objective");
        if (string.contains(";")) {
            String string2 = string.substring(string.lastIndexOf(";") + 1).replace("%", "");
            tournament.setMeta("PLACEHOLDER", string2);
            if (this.task == null || this.task.isCancelled()) {
                int n = this.JAVA_PLUGIN.getConfig().getInt("placeholderapi_objective_task_update", 100);
                this.task = Bukkit.getScheduler().runTaskTimerAsynchronously((Plugin)this.JAVA_PLUGIN, this::updatePlaceholders, 20L, (long)n);
            }
            return true;
        }
        this.JAVA_PLUGIN.getLogger().warning("The PlaceholderAPI placeholder in tournament " + tournament.getIdentifier() + " is invalid.");
        return true;
    }

    public void updatePlaceholders() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uUID = player.getUniqueId();
            for (Tournament tournament : this.getTournaments()) {
                int n;
                if (!tournament.hasMeta("PLACEHOLDER") || !this.canExecute(tournament, player)) continue;
                try {
                    n = Integer.parseInt(PlaceholderAPI.setPlaceholders((OfflinePlayer)player, (String)("%" + tournament.getMeta("PLACEHOLDER") + "%")));
                }
                catch (Exception exception) {
                    continue;
                }
                tournament.addScore(uUID, n, true);
            }
        }
    }
}

