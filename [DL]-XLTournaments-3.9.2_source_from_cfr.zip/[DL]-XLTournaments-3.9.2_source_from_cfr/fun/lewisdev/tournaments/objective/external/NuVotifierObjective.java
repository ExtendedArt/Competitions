/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.vexsoftware.votifier.model.Vote
 *  com.vexsoftware.votifier.model.VotifierEvent
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package fun.lewisdev.tournaments.objective.external;

import com.vexsoftware.votifier.model.Vote;
import com.vexsoftware.votifier.model.VotifierEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class NuVotifierObjective
extends XLObjective {
    public NuVotifierObjective() {
        super("NUVOTIFIER_VOTES");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerVote(VotifierEvent votifierEvent) {
        Vote vote = votifierEvent.getVote();
        String string = vote.getUsername();
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)string);
        Player player = offlinePlayer.getPlayer();
        if (offlinePlayer.isOnline() && player != null) {
            for (Tournament tournament : this.getTournaments()) {
                if (!this.canExecute(tournament, player)) continue;
                tournament.addScore(player.getUniqueId(), 1);
            }
        }
    }
}

