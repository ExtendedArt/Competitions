/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.andrei1058.bedwars.api.events.gameplay.GameEndEvent
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 */
package fun.lewisdev.tournaments.objective.external;

import com.andrei1058.bedwars.api.events.gameplay.GameEndEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

public class BedWars1058WinObjective
extends XLObjective {
    public BedWars1058WinObjective() {
        super("BEDWARS1058_WINS");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler
    public void onGameEnd(GameEndEvent gameEndEvent) {
        for (Tournament tournament : this.getTournaments()) {
            for (UUID uUID : gameEndEvent.getWinners()) {
                Player player = Bukkit.getPlayer((UUID)uUID);
                if (player == null || !this.canExecute(tournament, player)) continue;
                tournament.addScore(uUID, 1);
            }
        }
    }
}

