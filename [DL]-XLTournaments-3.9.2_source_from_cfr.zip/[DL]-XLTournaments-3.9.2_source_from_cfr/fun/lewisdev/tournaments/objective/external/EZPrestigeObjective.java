/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.clip.ezprestige.events.EZPrestigeEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package fun.lewisdev.tournaments.objective.external;

import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import me.clip.ezprestige.events.EZPrestigeEvent;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class EZPrestigeObjective
extends XLObjective {
    public EZPrestigeObjective() {
        super("EZPRESTIGE_PRESTIGE");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerPrestige(EZPrestigeEvent eZPrestigeEvent) {
        Player player = eZPrestigeEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

