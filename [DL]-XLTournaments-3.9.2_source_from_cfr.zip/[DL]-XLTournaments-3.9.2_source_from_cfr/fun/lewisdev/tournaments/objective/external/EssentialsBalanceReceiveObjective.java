/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.ess3.api.events.UserBalanceUpdateEvent
 *  net.ess3.api.events.UserBalanceUpdateEvent$Cause
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 */
package fun.lewisdev.tournaments.objective.external;

import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import net.ess3.api.events.UserBalanceUpdateEvent;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

public class EssentialsBalanceReceiveObjective
extends XLObjective {
    public EssentialsBalanceReceiveObjective() {
        super("ESSENTIALS_BALANCE_RECEIVE");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler
    public void onBalanceUpdate(UserBalanceUpdateEvent userBalanceUpdateEvent) {
        if (userBalanceUpdateEvent.getCause() == UserBalanceUpdateEvent.Cause.COMMAND_PAY) {
            return;
        }
        long l = userBalanceUpdateEvent.getOldBalance().longValue();
        long l2 = userBalanceUpdateEvent.getNewBalance().longValue();
        if (l2 > l) {
            Player player = userBalanceUpdateEvent.getPlayer();
            for (Tournament tournament : this.getTournaments()) {
                if (!this.canExecute(tournament, player)) continue;
                tournament.addScore(player.getUniqueId(), (int)(l2 - l));
            }
        }
    }
}

