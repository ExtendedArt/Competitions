/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.shampaggon.crackshot.events.WeaponDamageEntityEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package fun.lewisdev.tournaments.objective.external;

import com.shampaggon.crackshot.events.WeaponDamageEntityEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class CrackShotDamageObjective
extends XLObjective {
    public CrackShotDamageObjective() {
        super("CRACKSHOT_DAMAGE");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onWeaponDamage(WeaponDamageEntityEvent weaponDamageEntityEvent) {
        Player player = weaponDamageEntityEvent.getPlayer();
        if (player == null) {
            return;
        }
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), (int)Math.round(weaponDamageEntityEvent.getDamage()));
        }
    }
}

