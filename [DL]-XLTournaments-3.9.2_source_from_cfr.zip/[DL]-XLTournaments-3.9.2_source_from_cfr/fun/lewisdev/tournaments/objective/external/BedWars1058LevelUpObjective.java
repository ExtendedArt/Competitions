/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.andrei1058.bedwars.api.events.player.PlayerLevelUpEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 */
package fun.lewisdev.tournaments.objective.external;

import com.andrei1058.bedwars.api.events.player.PlayerLevelUpEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;

public class BedWars1058LevelUpObjective
extends XLObjective {
    public BedWars1058LevelUpObjective() {
        super("BEDWARS1058_LEVEL_UP");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler
    public void onPlayerLevelUp(PlayerLevelUpEvent playerLevelUpEvent) {
        Player player = playerLevelUpEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

