/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.electro2560.dev.cluescrolls.events.PlayerClueCompletedEvent
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package fun.lewisdev.tournaments.objective.external;

import com.electro2560.dev.cluescrolls.events.PlayerClueCompletedEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class ClueScrollsClueCompleteObjective
extends XLObjective {
    public ClueScrollsClueCompleteObjective() {
        super("CLUESCROLLS_CLUE_COMPLETE");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onClueComplete(PlayerClueCompletedEvent playerClueCompletedEvent) {
        Player player = playerClueCompletedEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

