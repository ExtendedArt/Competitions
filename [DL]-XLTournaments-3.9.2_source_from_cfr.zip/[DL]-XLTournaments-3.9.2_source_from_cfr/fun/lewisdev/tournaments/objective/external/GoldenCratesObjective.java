/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  su.nightexpress.goldencrates.api.event.CrateOpenEvent
 */
package fun.lewisdev.tournaments.objective.external;

import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import su.nightexpress.goldencrates.api.event.CrateOpenEvent;

public class GoldenCratesObjective
extends XLObjective {
    public GoldenCratesObjective() {
        super("GOLDENCRATES_OPEN");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        return true;
    }

    @EventHandler
    public void onCrateOpen(CrateOpenEvent crateOpenEvent) {
        Player player = crateOpenEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

