/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.block.Block
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.metadata.FixedMetadataValue
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.plugin.Plugin
 */
package fun.lewisdev.tournaments.objective.internal;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.objective.hook.TEBlockExplode;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.utility.universal.XBlock;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;

public class BreakObjective
extends XLObjective {
    private final XLTournamentsPlugin plugin;
    private final boolean excludePlaced;

    public BreakObjective(XLTournamentsPlugin xLTournamentsPlugin) {
        super("BLOCK_BREAK");
        FileConfiguration fileConfiguration = xLTournamentsPlugin.getConfig();
        this.excludePlaced = fileConfiguration.getBoolean("exclude_placed_blocks");
        if (xLTournamentsPlugin.getServer().getPluginManager().isPluginEnabled("TokenEnchant") && fileConfiguration.getBoolean("tokenenchant_explode_event")) {
            Bukkit.getServer().getPluginManager().registerEvents((Listener)new TEBlockExplode(this, this.excludePlaced), (Plugin)xLTournamentsPlugin);
        }
        this.plugin = xLTournamentsPlugin;
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        if (fileConfiguration.contains("block_whitelist")) {
            tournament.setMeta("BLOCK_WHITELIST", fileConfiguration.getStringList("block_whitelist"));
        }
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent blockBreakEvent) {
        Player player = blockBreakEvent.getPlayer();
        Block block = blockBreakEvent.getBlock();
        if (XBlock.isCrop(block) && !XBlock.isFullyGrown(block)) {
            return;
        }
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player) || block.hasMetadata("XLTPlacedBlock") || tournament.hasMeta("BLOCK_WHITELIST") && !((List)tournament.getMeta("BLOCK_WHITELIST")).contains(block.getType().toString())) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBlockPlace(BlockPlaceEvent blockPlaceEvent) {
        if (this.excludePlaced) {
            blockPlaceEvent.getBlock().setMetadata("XLTPlacedBlock", (MetadataValue)new FixedMetadataValue((Plugin)this.plugin, (Object)blockPlaceEvent.getPlayer().getName()));
        }
    }
}

