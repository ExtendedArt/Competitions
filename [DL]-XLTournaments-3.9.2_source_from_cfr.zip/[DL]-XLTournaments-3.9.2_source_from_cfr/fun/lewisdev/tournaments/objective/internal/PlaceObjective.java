/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.block.BlockPlaceEvent
 */
package fun.lewisdev.tournaments.objective.internal;

import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockPlaceEvent;

public class PlaceObjective
extends XLObjective {
    public PlaceObjective() {
        super("BLOCK_PLACE");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        if (fileConfiguration.contains("block_whitelist")) {
            tournament.setMeta("BLOCK_WHITELIST", fileConfiguration.getStringList("block_whitelist"));
        }
        return true;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBlockPlace(BlockPlaceEvent blockPlaceEvent) {
        Player player = blockPlaceEvent.getPlayer();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player) || tournament.hasMeta("BLOCK_WHITELIST") && !((List)tournament.getMeta("BLOCK_WHITELIST")).contains(blockPlaceEvent.getBlock().getType().toString())) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

