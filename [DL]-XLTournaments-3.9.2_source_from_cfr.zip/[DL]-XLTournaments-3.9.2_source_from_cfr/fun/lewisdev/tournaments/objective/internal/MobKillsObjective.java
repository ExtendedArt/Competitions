/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityDeathEvent
 */
package fun.lewisdev.tournaments.objective.internal;

import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDeathEvent;

public class MobKillsObjective
extends XLObjective {
    public MobKillsObjective() {
        super("MOB_KILLS");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        if (fileConfiguration.contains("mob_whitelist")) {
            tournament.setMeta("MOB_WHITELIST", fileConfiguration.getStringList("mob_whitelist"));
        }
        return true;
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onEntityDeath(EntityDeathEvent entityDeathEvent) {
        LivingEntity livingEntity = entityDeathEvent.getEntity();
        if (livingEntity instanceof Player || livingEntity.getKiller() == null) {
            return;
        }
        Player player = livingEntity.getKiller();
        for (Tournament tournament : this.getTournaments()) {
            if (!this.canExecute(tournament, player) || tournament.hasMeta("MOB_WHITELIST") && !((List)tournament.getMeta("MOB_WHITELIST")).contains(livingEntity.getType().toString())) continue;
            tournament.addScore(player.getUniqueId(), 1);
        }
    }
}

