/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitTask
 */
package fun.lewisdev.tournaments.objective.internal;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class PlaytimeObjective
extends XLObjective {
    private final JavaPlugin JAVA_PLUGIN = JavaPlugin.getProvidingPlugin(XLTournamentsPlugin.class);
    private BukkitTask task;

    public PlaytimeObjective() {
        super("PLAYTIME");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        if (this.task == null || this.task.isCancelled()) {
            int n = this.JAVA_PLUGIN.getConfig().getInt("playtime_objective_task_update", 200);
            this.task = Bukkit.getScheduler().runTaskTimerAsynchronously((Plugin)this.JAVA_PLUGIN, this::updatePlaytime, 20L, (long)n);
        }
        return true;
    }

    private void updatePlaytime() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            for (Tournament tournament : this.getTournaments()) {
                if (!this.canExecute(tournament, player)) continue;
                tournament.addScore(player.getUniqueId(), 10);
            }
        }
    }
}

