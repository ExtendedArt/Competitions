/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.inventory.CraftItemEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments.objective.internal;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.utility.universal.XMaterial;
import java.util.Optional;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class CraftTournament
extends XLObjective {
    public CraftTournament() {
        super("ITEM_CRAFT");
    }

    @Override
    public boolean loadTournament(Tournament tournament, FileConfiguration fileConfiguration) {
        Optional<XMaterial> optional;
        String string = fileConfiguration.getString("objective");
        if (string.contains(";") && (optional = XMaterial.matchXMaterial(string.split(";")[1])).isPresent()) {
            tournament.setMeta("ITEM_CRAFT", (Object)optional.get().parseMaterial());
            return true;
        }
        JavaPlugin.getProvidingPlugin(XLTournamentsPlugin.class).getLogger().warning("The crafting material in tournament " + tournament.getIdentifier() + " is invalid.");
        return false;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onItemCraft(CraftItemEvent craftItemEvent) {
        ItemStack itemStack = craftItemEvent.getCurrentItem();
        int n = itemStack.getAmount();
        if (craftItemEvent.isShiftClick()) {
            Object object;
            int n2 = craftItemEvent.getInventory().getMaxStackSize();
            for (Object object2 : object = craftItemEvent.getInventory().getMatrix()) {
                int n3;
                if (object2 == null || object2.getType() == Material.AIR || (n3 = object2.getAmount()) >= n2 || n3 <= 0) continue;
                n2 = n3;
            }
            n *= n2;
        }
        Player player = (Player)craftItemEvent.getWhoClicked();
        for (Tournament tournament : this.getTournaments()) {
            if (tournament.getMeta("ITEM_CRAFT") != itemStack.getType() || !this.canExecute(tournament, player)) continue;
            tournament.addScore(player.getUniqueId(), n);
        }
    }
}

