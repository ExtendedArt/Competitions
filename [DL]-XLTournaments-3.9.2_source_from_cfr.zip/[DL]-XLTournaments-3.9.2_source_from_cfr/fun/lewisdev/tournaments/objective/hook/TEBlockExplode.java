/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.vk2gpz.tokenenchant.event.TEBlockExplodeEvent
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 */
package fun.lewisdev.tournaments.objective.hook;

import com.vk2gpz.tokenenchant.event.TEBlockExplodeEvent;
import fun.lewisdev.tournaments.objective.internal.BreakObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import java.util.List;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class TEBlockExplode
implements Listener {
    private final BreakObjective breakObjective;
    private final boolean excludePlaced;

    public TEBlockExplode(BreakObjective breakObjective, boolean bl) {
        this.breakObjective = breakObjective;
        this.excludePlaced = bl;
    }

    @EventHandler
    public void onBlockExplode(TEBlockExplodeEvent tEBlockExplodeEvent) {
        Player player = tEBlockExplodeEvent.getPlayer();
        for (Tournament tournament : this.breakObjective.getTournaments()) {
            if (!this.breakObjective.canExecute(tournament, player)) continue;
            int n = tEBlockExplodeEvent.blockList().size();
            for (Block block : tEBlockExplodeEvent.blockList()) {
                if ((!this.excludePlaced || !block.hasMetadata("XLTPlacedBlock")) && (!tournament.hasMeta("BLOCK_WHITELIST") || ((List)tournament.getMeta("BLOCK_WHITELIST")).contains(tEBlockExplodeEvent.getBlock().getType().toString()))) continue;
                --n;
            }
            if (n <= 0) continue;
            tournament.addScore(player.getUniqueId(), n);
        }
    }
}

