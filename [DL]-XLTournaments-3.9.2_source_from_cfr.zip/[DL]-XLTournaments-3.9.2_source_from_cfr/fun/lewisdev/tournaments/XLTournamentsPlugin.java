/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments;

import fun.lewisdev.tournaments.XLTournamentsAPI;
import fun.lewisdev.tournaments.action.ActionManager;
import fun.lewisdev.tournaments.command.TournamentsCommand;
import fun.lewisdev.tournaments.config.ConfigHandler;
import fun.lewisdev.tournaments.hook.HookManager;
import fun.lewisdev.tournaments.hook.hooks.PlaceholderAPIHook;
import fun.lewisdev.tournaments.libs.command.base.CommandManager;
import fun.lewisdev.tournaments.libs.gui.guis.BaseGui;
import fun.lewisdev.tournaments.menu.MenuManager;
import fun.lewisdev.tournaments.objective.ObjectiveManager;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.storage.StorageManager;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentManager;
import fun.lewisdev.tournaments.utility.Messages;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.entity.HumanEntity;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class XLTournamentsPlugin
extends JavaPlugin
implements XLTournamentsAPI {
    private ConfigHandler menuFile;
    private MenuManager menuManager;
    private ObjectiveManager objectiveManager;
    private ConfigHandler messagesFile;
    private StorageManager storageManager;
    private TournamentManager tournamentManager;
    private int 1318c08555154 = 873365504;
    private ActionManager actionManager;
    private HookManager hookManager;

    public void onEnable() {
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017 '{\u001d=\u0010\u001d\u0014\u00150?{\u00057\u0012\u0006\t\u00108,;\u0005+I,+%:<'\u001f9\n\u0011\t\u0005&\u00199\u0004?\u000e\u001a", (Object)"\u001d:(127\t\u0012\u000e\u0016e", "Y|\u001f", -114, 0.7977370355920099, "lZ1CgYocXNZB3vqUMFU7Sb2i5kyT4kgu3CYvg9e1wg1aw4");
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b\u000b?4_\u0011\"\u001d:_\u0006&2\u0016\r8\u0013x=\u0005.2\u0014\u0016", (Object)"\u0018\u0004/:", "Y&#4\u0007\u0005y\u00187\u001f\rf\u0006\u0005\u0016?\u001a1JC\u001f", -113, 2.4903170905001617, "S29OVh8edQALeqylADj7WBAwxs7Hv2hazaxV7iB0jKiZgvHNjsJZ", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0018'{\u001dU\u0014\u001d\u0010\u0015\b?{\u0005_\u0016\u0006\r\u0010\u0000,;\u0005CM,/%\u0002<'\u001fQ\u000e\u0011\r\u0005\u001e\u00199\u0004W\n\u001a", (Object)"\u0016\b=\u0019\u001eW\u0004\u0011\u0011", "YD\u0005?\u0010F\u0002[\u0016\u0005\u0004%z\u001d_\u0004\u0013\n\u001f\nf\u0019\u001eW\u0004\u0011\u0011J", -113, -897589626, "tsrvcvQH0JZ67tY8RImUDFr5cgwK2FoYNFuoyO6mCJwxjXCbmRhzsLe", this), "");
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b\u0012?4_\u0000'\u001d?_\u001f&2\u0016\u001c=\u0013}=\u001c.2\u0014\u0007", (Object)"\u0018\u001d/:", "Y?#4\u0007\u0014|\u00182\u001f\u0014f\u0006\u0005\u0007:\u001a4JZ\u001f", -115, -0.53527945f, "jMBVSrpcuv6psu4vDcsG1Jrp6fzpQdyjc8BDde", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0001'{\u001d$'\u001d#\u0015\u0011?{\u0005.%\u0006>\u0010\u0019,;\u00052~,\u001c%\u001b<'\u001f =\u0011>\u0005\u0007\u00199\u0004&9\u001a", (Object)"\u0016\u0011=\u0019\u001e&7\u0011\"", "Y]\u0005?\u001071[%\u0005\u001d%z\u001d.7\u00139\u001f\u0013f\u0019\u001e&7\u0011\"J", -113, 0.24616903f, "fwhOPqb9AQGGuvqixGtlVZbNPdX2Uon2eLGI90TSZox7PhPyQ", this), "\\/|      XLTournaments v" + (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001eK.{\u0013\u00111\u001f3\u0005\u001799\u0004\u00033\u001at!U<2\u0018\n\u001e\u0011)\u0012K %\u0005\r5\u001a\u001c\u0018U,", (Object)"\u0016\\=\u0003\u0014\u0016)\u001d5\u001f", "Y\u0010\u0005?\u0010\u0012;[6\u0010W.z\"\u0010(\u001d4\u0016\u0002", -113, -648712942, "grLPZa5WdbFePjW29M9HcV19lZWPoK8rbc3", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017 '{\u001d\u0004\u0011\u001d\u0015\u00150?{\u0005\u000e\u0013\u0006\b\u00108,;\u0005\u0012H,*%:<'\u001f\u0000\u000b\u0011\b\u0005&\u00199\u0004\u0006\u000f\u001a", (Object)"\u00160=\u0011\u0014\u0012\u0005\u0006\u000f\u0001! :\u001f", "Y|\u0005:\u0003\u0006I\u0016\u0013\u001a> !^\u0011\n\u0001\u0001\u0018;f\u0005\u001d\u0014\u0001\u001d\b50:6\u0003\b\u0016\u0000\u000f\u001e;\u000f<\u001d\u0004]", -113, -0.10068624760126829, "OSh6fXtRa3yPoBVqRlUzhfzoYoRT4nnSE6hQLW37X4gXc3xFn", this)));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b'?4_\u0002\u0011\u001d\t_*&2\u0016\u001e\u000b\u0013K=).2\u0014\u0005", (Object)"\u0018(/:", "Y\n#4\u0007\u0016J\u0018\u0004\u001f!f\u0006\u0005\u0005\f\u001a\u0002Jo\u001f", -115, -1954883844, "m8hLeCIcwMRfFlD6XrFeMSm3O8YCJBlUxFN", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017#'{\u001d\r\u0005\u001d\u0001\u00153?{\u0005\u0007\u0007\u0006\u001c\u0010;,;\u0005\u001b\\,>%9<'\u001f\t\u001f\u0011\u001c\u0005%\u00199\u0004\u000f\u001b\u001a", (Object)"\u00163=\u0019\u001e\u000f\u0015\u0011\u0000", "Y\u007f\u0005?\u0010\u001e\u0013[\u0007\u0005?%z\u001d\u0007\u0015\u0013\u001b\u001f1f\u0019\u001e\u000f\u0015\u0011\u0000J", -115, -6068000435367374210L, "TbjHrJ0ahFyVzdJFB7VhhegBrvQWVs7d34SVVFM6oomze0nGp6B", this), "/\\|_     Author: " + (List)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001e(.{\u0013$\u0003\u001f\u0001\u0005t99\u00046\u0001\u001aF!6<2\u0018?,\u0011\u001b\u0012( %\u00058\u0007\u001a.\u00186,", (Object)"\u0016?=\u0014\u0004%\u0000\u001b\u001a\u0002", "Ys\u0005?\u0010'\t[\u001d\u00053%z=8\u001b\u0000S", -115, 218712165, "jBFchHTBQwdxi3tXylZHwsKOHqT6MvmTZTxzIGJjN4wc3TP1fK", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017%'{\u001d\u0013\u0015\u001d\u0011\u00155?{\u0005\u0019\u0017\u0006\f\u0010=,;\u0005\u0005L,.%?<'\u001f\u0017\u000f\u0011\f\u0005#\u00199\u0004\u0011\u000b\u001a", (Object)"\u00165=\u0011\u0014\u0005\u0001\u0006\u000b\u0001$ :\u001f", "Yy\u0005:\u0003\u0011M\u0016\u0017\u001a; !^\u0006\u000e\u0001\u0005\u0018>f\u0005\u001d\u0003\u0005\u001d\f55:6\u0003\u001f\u0012\u0000\u000b\u001e>\u000f<\u001d\u0013Y", -113, 16.79403798644607, "BnDAbJqAvliYSC4xNmPkQv35GFrDFAIgR2MGg5biOD04LI87sYd", this)));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b)?4_'<\u001d$_$&2\u0016;&\u0013f='.2\u0014 ", (Object)"\u0018&/:", "Y\u0004#4\u00073g\u0018)\u001f/f\u0006\u0005 !\u001a/Ja\u001f", -115, 0.9529975f, "RdjiHzbPR4LSjrZ1BMH8cGzi8Rh37LFofT7Tc46X8LCcc", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u000f'{\u001d2@\u001dD\u0015\u001f?{\u00058B\u0006Y\u0010\u0017,;\u0005$\u0019,{%\u0015<'\u001f6Z\u0011Y\u0005\t\u00199\u00040^\u001a", (Object)"\u0016\u001f=\u0019\u001e0P\u0011E", "YS\u0005?\u0010!V[B\u0005\u0013%z\u001d8P\u0013^\u001f\u001df\u0019\u001e0P\u0011EJ", -115, -1755075733, "W4GK7HXMWQn7GJSOuczn2m17iiEjO4DXklptBYerXOoi", this), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "5\u000e;0\u0012\u0002 \u0011\f\u001a\u0014*8(\u0017\u001c\u0004<\u001e1+\u0011\u0017\u0014\u001eF", (Object)"C=\u0003%H.,\u00047\u0014\u0004\u0011dE\u0015\u0014\u001a\u000f6 ", "Y+#4\u00079B\u0018\f\u001f\u0000f\u0006\u0005*\u0004\u001a\nJ+#4\u00079B\u0018\f\u001f\u0000f\u0006\u0005*\u0004\u001a\nJN\u0005?\u0010.\f[\u0001\u0010\t.z\",\u001f\u001d\u0003\u0016\\", -114, -0.4716047208404058, "BIKnmQBCXSJSNDDR0zgvbSid9bmeHvVzqocPpJdqkA4lrhDc5ra", "YnYnYnYnY\r\u0016>\u0000<\u0010)\u0011:Yf\u001agY\u0002\u001c9\u0010=Y\nY|I|HcK~K}Wn8\"\u0015n+'\u001e&\r=Y\u001c\u001c=\u001c<\u000f+\u001d`", "K8p4tIMBh1DTJ4GVnNWHmLurNtYBBse20Pu85ND8OEj2fM"));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b\u0019?4_C5\u001d-_\u0014&2\u0016_/\u0013o=\u0017.2\u0014D", (Object)"\u0018\u0016/:", "Y4#4\u0007Wn\u0018 \u001f\u001ff\u0006\u0005D(\u001a&JQ\u001f", -115, -1536994606, "Pm9WAD9c69Wmnw3vwhxa0CHSlTrQRpZj5nxTe0iaipDcQquBJExBWA", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0012'{\u001dTA\u001dE\u0015\u0002?{\u0005^C\u0006X\u0010\n,;\u0005B\u0018,z%\b<'\u001fP[\u0011X\u0005\u0014\u00199\u0004V_\u001a", (Object)"\u0016\u0002=\u0019\u001eVQ\u0011D", "YN\u0005?\u0010GW[C\u0005\u000e%z\u001d^Q\u0013_\u001f\u0000f\u0019\u001eVQ\u0011DJ", -113, 0.5898f, "hZkM6AGz15kvWeJJMqgDlqydCjklG6yPBh23RL", this), "");
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b\u0014?4_2\u0000\u001d\u0018_\u0019&2\u0016.\u001a\u0013Z=\u001a.2\u00145", (Object)"\u0018\u001b/:", "Y9#4\u0007&[\u0018\u0015\u001f\u0012f\u0006\u00055\u001d\u001a\u0013J\\\u001f", -115, -1634515281, "nHlgtBWZGlF7KZHK1Iu7JaMGPuHAT4F8bVNOZLAt5YwrV", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017:'{\u001d\r\u0014\u001d\u0010\u0015*?{\u0005\u0007\u0016\u0006\r\u0010\",;\u0005\u001bM,/% <'\u001f\t\u000e\u0011\r\u0005<\u00199\u0004\u000f\n\u001a", (Object)"\u0016*=\u0019\u001e\u000f\u0004\u0011\u0011", "Yf\u0005?\u0010\u001e\u0002[\u0016\u0005&%z\u001d\u0007\u0004\u0013\n\u001f(f\u0019\u001e\u000f\u0004\u0011\u0011J", -115, -4.922051369728962, "8rQ9cGZyh69HZO1IXNOI0PiL2B0nIaDqmUPasg0JGqMVeIcGHB", this), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "50;0\u0012\u0018 \u0011\f\u001a**8(\r\u001c\u0004<\u001e\u000f+\u0011\u0017\u000e\u001eF", (Object)"C\u0003\u0003%H4,\u00047\u0014:\u0011dE\u000f\u0014\u001a\u000f6\u001e", "Y\u0015#4\u0007#B\u0018\f\u001f>f\u0006\u00050\u0004\u001a\nJ\u0015#4\u0007#B\u0018\f\u001f>f\u0006\u00050\u0004\u001a\nJp\u0005?\u00104\f[\u0001\u00107.z\"6\u001f\u001d\u0003\u0016b", -114, 1602897054, "l8QgmVQtBRGZS4grLPYsUU6jWcRBuPlATJcoNB7g1w2PnnikE", "\u0017\":)2#<m+!.*2#uc", "OSPypOeFIeyKBZuQijqVXMvtExcabDxhJdSx4"));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0005'{\u001d \u0001\u001d\u0005\u0015\u0015?{\u0005*\u0003\u0006\u0018\u0010\u001d,;\u00056X,:%\u001f<'\u001f$\u001b\u0011\u0018\u0005\u0003\u00199\u0004\"\u001f\u001a", (Object)"\u0002\u0011?05 \u0010\u0015\u0003\u001d\u0004\n:\u001f#\u001f\u0013", "YY\u001f", -115, 0.4767112f, "bHUhvgYxEqijlB3gNCpfyblph7R5AHif9MwYJNaO4izx3r9Pp", this);
        this.messagesFile = new ConfigHandler(this, (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "5?;0\u0012\u0011<\u0011\u0010\u001a%*8(\u0004\u0000\u0004 \u001e\u0000+\u0011\u0017\u0007\u0002F", (Object)"C\f\u0003%H=0\u0004+\u00145\u0011dE\u0006\b\u001a\u00136\u0011", "Y\u001a#4\u0007*^\u0018\u0010\u001f1f\u0006\u00059\u0018\u001a\u0016J\u001a#4\u0007*^\u0018\u0010\u001f1f\u0006\u00059\u0018\u001a\u0016J\u007f\u0005?\u0010=\u0010[\u001d\u00108.z\"?\u0003\u001d\u001f\u0016m", -114, -4542841837637950821L, "jGFjq3uLKWQN6wXLkbVHZlQexA2Bgr1GGQi", "2\u0018,\u000e>\u001a:\u000e", "uVnpoVlqwriBE04KDRwIwPjH9qlbJKkWdycNwpeOBJd"));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017F'{\u001d,\u0012\u001d\u0016\u0015V?{\u0005&\u0010\u0006\u000b\u0010^,;\u0005:K\u0017\n\u001fU 2_\n\n\u001a\u0003\u0018T\u00014\u001f-\t\u0011\u0017", (Object)"\u0002R?05,\u0003\u0015\u0010\u001dG\n:\u001f/\f\u0013", "Y\u001a\u001f", -113, 18.63302019204577, "7KjZe8oeIWEWWcsNZJ3A5XGcSAJaDZSHKp4mPL", this.messagesFile);
        this.menuFile = new ConfigHandler(this, (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "5\u000b;0\u0012\u0000z\u0011V\u001a\u0011*8(\u0015F\u0004f\u001e4+\u0011\u0017\u0016DF", (Object)"C8\u0003%H,v\u0004m\u0014\u0001\u0011dE\u0017N\u001aU6%", "Y.#4\u0007;\u0018\u0018V\u001f\u0005f\u0006\u0005(^\u001aPJ.#4\u0007;\u0018\u0018V\u001f\u0005f\u0006\u0005(^\u001aPJK\u0005?\u0010,V[[\u0010\f.z\".E\u001dY\u0016Y", -114, -9.46375657210951, "8UvO7WekZEG1PfBfJub0QAHJzv1j17yV20wQJ", "\u0010)\u00139", "Gt5LbSSjjbuW2FfqlJib324wDXD76tKu72F7OzYCsCgih3"));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0004'{\u001d\u0000\u001e\u001d\u001a\u0015\u0014?{\u0005\n\u001c\u0006\u0007\u0010\u001c,;\u0005\u0016G\u0017\u0006\u001f\u0017 2_&\u0006\u001a\u000f\u0018\u0016\u00014\u001f\u0001\u0005\u0011\u001b", (Object)"\u0002\u0010?05\u0000\u000f\u0015\u001c\u001d\u0005\n:\u001f\u0003\u0000\u0013", "YX\u001f", -115, -0.42739016f, "pjABiYpFeFLNxeZALtq78YE8xCcJiMQH8X3lmYCVGETiQvlYgsF", this.menuFile);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017A'{\u001d'&\u001d\"\u0015Q?{\u0005-$\u0006?\u0010Y,;\u00051\u007f\u0001%\u0018X !\bl\u001c\u0011\"\u0002U.0\u0002", (Object)"\u0002Q=\u0016\u001e,7\u001d6\u0004F(!\u0018-?", "Yx&'\u0016m3\u0001:\u001a]=z\u0012-?\u00128\u0016A;4\u0005+>\u001a~\u0017]%0^\u00048\u001842['3\u0018%$\u00060\u0005]&;Jk\u0007", -114, 0.38665593f, "qLWiQ1NfBluXjhtv7r4Bmm0x48NPtTG9mmlmq7riGvIG", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017-'{\u001d]\u0007\u001d\u0003\u0015=?{\u0005W\u0005\u0006\u001e\u00105,;\u0005K^\u0017\u001f\u001f> 2_{\u001f\u001a\u0016\u0018?\u00014\u001f\\\u001c\u0011\u0002", (Object)"\u0016==\u0016\u001eV\u0016\u001d\u0017", "Yq\u0005:\u0003__\u0016\u0005\u001a3 !^[\u001f\u001a\u0016\u0018?<'\u0010L\u0019\u001b\u001e^> 9\u0014\u00176\u001d\u001c\u0014\u001b&;\u0017Q\u0017\u0001\u0002\u0010, :\u001f\u0003", -113, 10.942397175931829, "kIRhpK9r8Wkwsa8uWeXjminyy8Afn62nqzC0WYcTlWhf2Sk", this.messagesFile));
        this.hookManager = new HookManager(this);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0012'{\u001d4\u000e\u001d\n\u0015\u0002?{\u0005>\f\u0006\u0017\u0010\n,;\u0005\"W\u001c\u0016\u001e\fg\u001d\u001e>\u00129\u0018\u001f\u0006.0\u0003", (Object)"\u001e\t\f;\u00103\u0015\u0011", "YN\u001f", -113, 1.113595426522238, "GMWlyPciQciCnDyi9qghb4LKWP8Ehpucw9BrKSEylADgBrIh0XkItF1", this.hookManager);
        this.storageManager = new StorageManager(this);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u001b'{\u001d#\u001d\u001d\u0019\u0015\u000b?{\u0005)\u001f\u0006\u0004\u0010\u0003,;\u00055D\u0007\u001e\u001e\u001c(2\u0014h9\u0000\u0005\u0003\u000f.0<'\u0004\u0015\r\u0014\u001c", (Object)"\u001e\u0000\f;\u0010$\u0006\u0011", "YG\u001f", -115, -3299497828547760197L, "st2Vj3KKFWskBgr1U3nXXEvadi23RhTdtCK9hDjp73", this.storageManager);
        this.actionManager = new ActionManager(this);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017D'{\u001d+8\u001d<\u0015T?{\u0005!:\u0006!\u0010\\,;\u0005=a\u0015,\u0005X&;_\u000f,\u0000&\u001e_\u00044\u001f/(\u0011=", (Object)"\u001e_\f;\u0010,#\u0011", "Y\u0018\u001f", -115, 0.87679064f, "qICaO6edNjSmlIFyb21tJaGP6VNOZiVxOa8UIxf3MYdcps5", this.actionManager);
        this.objectiveManager = new ObjectiveManager(this);
        this.tournamentManager = new TournamentManager(this);
        this.menuManager = new MenuManager(this);
        CommandManager commandManager = new CommandManager((Plugin)this, true);
        Object object2 = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0007'{\u001dS\r\u001d\t\u0015\u0017?{\u0005Y\u000f\u0006\u0014\u0010\u001f,;\u0005ET\u0018\u0013\u0013\u0001g6\u001e[\u0017\u0015\u0014\u0015\\+4\u0002ST7\u0015\u001c\u001f(;\u0015{\u001b\u001a\u001b\u0016\u0017;", (Object)"\u0016\u0017=\u0018\u0014E\t\u0015\u001d\u0014:(;\u0015Z\u001f\u0006", "Y[\u00053\u0004XU\u0018\u001f\u0006\u001b:1\u0014@U\u0000\u0015\u0004\u0000'4\u001cS\u0014\u0000\t^\u001e 7\u0002\u0019\u0019\u001b\u0017\u001c\u0013'1^T\u001b\u0007\u001f^?,&\u0002W\u001d\u00112\u0010\u001c-9\u0014DA", -115, -6.187621282252504, "07b3zOfq65Iouf3IZxrPsLTZmrYkYpgfvVgKV1NW", commandManager);
        Object object3 = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "5\n;0\u0012\u0015\u000f\u0011#\u001a\u0010*8(\u00003\u0004\u0013\u001e5+\u0011\u0017\u00031F", (Object)"C9\u0003%H9\u0003\u0004\u0018\u0014\u0000\u0011dE\u0002;\u001a 6$", "Y/#4\u0007.m\u0018#\u001f\u0004f\u0006\u0005=+\u001a%J/#4\u0007.m\u0018#\u001f\u0004f\u0006\u0005=+\u001a%JJ\u0005?\u00109#[.\u0010\r.z\";0\u001d,\u0016X", -114, -1.0899681128895822, "Nrx1B6uyO38ExvjdY7cC4oz1p4xzSJpQxCc0c4OcOWfSEaiL8M", "\u0018\u0010\u001fS\u0015\u0012U\r\u001e\u000f\u0016\u0014\b\u000e\u0012\u0012\u0015", "6cQvV8DxupzwGgnTlCFS2csJ55Di1trPHStwhPb");
        Messages messages = Messages.NO_PERMISSION;
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b,?4_:\u000e\u001d\u0016_\u0002+?\u0014,\u000e\u0007", (Object)"\u0003(8 \u0018=\u001f:\u0015\u001f\u0003<9\u001d", "Y\u0001#4\u0007.U\u0018\u001b\u001f*f\u001a\u0013%\u001f\u0017\u000eJd\u0005?\u00109\u001b[\u0016\u0010#.z>-\u0010\u0011\u0019\u0005v", -114, -6305657808516459336L, "BFWKzeLlOmYVE1Lc6UMey0VuskkZ37CYiVNSFCDE6uZpsX7J8", (Object)messages);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u00176'{\u001d\u0014!\u001d%\u0015&?{\u0005\u001e#\u00068\u0010.,;\u0005\u0002x\u0018?\u00130g6\u001e\u001c;\u00158\u0015m+4\u0002\u0014x93\u00020(2\u001497\u001a2\u001d&;", (Object)"\u0003&.<\u0002\u00053\u0006", "Y\u000f#4\u0007\u0010y\u00187\u001f$f\u0006\u0005\u0003?\u001a1J\u000f/ \u001f^:\u0011!\u00180-0\u0007^\"\u001b#\u0003-(8\u0014\u001f\"\u0007y\u001d*+&^\u00129\u0019;\u0010--z\u0013\u0010%\u0011y\u0012,$%\u001e\u001f3\u001a\"\u0002l\u00040\u0002\u00027\u00133#&::\u001d\u00073\u0006mX\u0015", -115, 12.083274549987468, "0ZQcVjTZqP8BrTRZtkC1uN7EgEJWcco8TsNG48dEaNWQaesH", object2, object3, commandSender -> messages.send(commandSender, new Object[0]));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\"'{\u001d\u0000D\u001d@\u00152?{\u0005\nF\u0006]\u0010:,;\u0005\u0016\u001d\u0018Z\u0013$g6\u001e\b^\u0015]\u0015y+4\u0002\u0000\u001d7\\\u001c'%0\u0005\f\\\u001a{\u00109-9\u0014\u0017", (Object)"\u00032.<\u0002\u0011V\u0006", "Y\u001b#4\u0007\u0004\u001c\u0018R\u001f0f\u0006\u0005\u0017Z\u001aTJ\u001b/ \u001fJ_\u0011D\u0018$-0\u0007JG\u001bF\u00039(8\u0014\u000bG\u0007\u001c\u001d>+&^\u0006\\\u0019^\u00109-z\u0013\u0004@\u0011\u001c\u00128$%\u001e\u000bV\u001aG\u0002x\n:\u001c\u0015_\u0011G\u00188'\u0007\u0014\u0016\\\u0018E\u0014%r|'", -113, 14.726613812857645, "LLan3ocTeqzQ6cqFh5W7wYmLmRtxpYeTBki6SK", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u0002'{\u001d7O\u001dK\u0015\u0012?{\u0005=M\u0006V\u0010\u001a,;\u0005!\u0016\u0018Q\u0013\u0004g6\u001e?U\u0015V\u0015Y+4\u00027\u00167W\u001c\u001a(;\u0015\u001fY\u001aY\u0016\u0012;", (Object)"\u0016\u0012=\u0016\u001e?H\u0018]\u0005\u001e&;93V\u0010T\u0014\u0005", "Y^\u00053\u0004<\u0017\u0018]\u0006\u001e:1\u0014$\u0017\u0000W\u0004\u0005'4\u001c7V\u0000K^\u001b 7\u0002}[\u001bU\u001c\u0016'1^0Y\u0007]^4&8\u0001>]\u0000Q\u001e\u0019\u00014\u001f6T\u0011JJ", -115, -1.1188299980880412, "NWHC8Wq2R9uov4RMyBwKxOfimbWgkSrF720ZboJn4r4iLDNMDfz7ZxH", commandManager), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "5\u001d;0\u0012\u001dx\u0011T\u001a\u0007*8(\bD\u0004d\u001e\"+\u0011\u0017\u000bFF", (Object)"C.\u0003%H1t\u0004o\u0014\u0017\u0011dE\nL\u001aW63", "Y8#4\u0007&\u001a\u0018T\u001f\u0013f\u0006\u00055\\\u001aRJ8#4\u0007&\u001a\u0018T\u001f\u0013f\u0006\u00055\\\u001aRJ]\u0005?\u00101T[Y\u0010\u001a.z\"3G\u001d[\u0016O", -114, 5923461551171030977L, "DP9O5PqmGzvLr9fmLVt3ZCaXaiamlxenPtSE4bAGw", "z\b6\t+\u00128\u0011<\u0012-\u000f", "EXb84IwtjUTfxdpC3qoESx9otxfh7Gi8wuryDGJxRE"), object -> this.tournamentManager.getTournaments().stream().map(Tournament::getIdentifier).collect(Collectors.toList()));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017\u000f'{\u001d(3\u001d7\u0015\u001f?{\u0005\"1\u0006*\u0010\u0017,;\u0005>j\u0018-\u0013\tg6\u001e )\u0015*\u0015T+4\u0002(j7+\u001c\u0017(;\u0015\u0000%\u001a%\u0016\u001f;", (Object)"\u0003\u001f.<\u00029!\u0006", "Y6/ \u001fb(\u00113\u0018\t-0\u0007b0\u001b1\u0003\u0014(8\u0014#0\u0007k\u001d\u0013+&^.+\u0019)\u0010\u0014-z\u0013,7\u0011k2\u0015$8\u0010# 6%\u0002\u001fr|'", -115, -0.3573146569064758, "emGMD5CRMVmCMKioRVzTgjTdHzb7CXMhTD2TPnZ", commandManager, new TournamentsCommand(this));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001b\u0016?4_\u0006'\u001d?_\u001b&2\u0016\u001a=\u0013}=\u0018.2\u0014\u0001", (Object)"\u0018\u0019/:", "Y;#4\u0007\u0012|\u00182\u001f\u0010f\u0006\u0005\u0001:\u001a4J^\u001f", -115, -0.6985479796642345, "9BaJSrcbsIiyl5sr5hwsr8BKna2jEGWcH6TnU3NGkg", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u0017D'{\u001d-\u0001\u001d\u0005\u0015T?{\u0005'\u0003\u0006\u0018\u0010\\,;\u0005;X,:%^<'\u001f)\u001b\u0011\u0018\u0005B\u00199\u0004/\u001f\u001a", (Object)"\u0016T=\u0019\u001e/\u0011\u0011\u0004", "Y\u0018\u0005?\u0010>\u0017[\u0003\u0005X%z\u001d'\u0011\u0013\u001f\u001fVf\u0019\u001e/\u0011\u0011\u0004J", -115, 2079606673, "LQJSvm9pHFOZl1pFAJ1PXlGESU603NwSsPyI1kLwPsH8a1CF2SL2U1", this), "");
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001e+.{\u00137>\u001f<\u0005w\u000b \u001a)<\u0000", (Object)"\u0016<=\u0006\u0012*0\u0010 \u001d<;", "Yp\u0005:\u0003%z\u0016 \u001a2 !^16\u001c0\u0015,%0\u0003m\u0017\u0001>\u001a0=\u0006\u0012*0\u0010 \u001d<;n", -114, -1024421513392038822L, "1RIsU5Z5BEucSXqVlRY42wY3SSNHawB0yk2XDx2aE2smMI6jJiH").scheduleSyncDelayedTask((Plugin)this, () -> {
            this.objectiveManager.onEnable();
            this.tournamentManager.onEnable();
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new PlaceholderAPIHook(this).register();
            }
        });
    }

    public void onDisable() {
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u001e\u0002.{\u0013E2\u001f0\u0005^\u000b \u001a[0\u0000", (Object)"\u0016\u0015=\u001a\u001f\\0\u001a<!\u001c(,\u0014B*", "YY\u0005?\u0010F8[,\u0005\u0019%z2_5\u0018<\u0012\u0004 :\u001f\u000b", -114, 0.009097444836114743, "QDMKYnrF0VknC0MX41pN4SEqbsRxMATDs4hsl9naEHxd7odxiO2").stream().filter(player -> player.getOpenInventory().getTopInventory().getHolder() instanceof BaseGui).forEach(HumanEntity::closeInventory);
        if (this.tournamentManager != null) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("FirEctlEakO", "\u00172'{\u001d6\u0018\u001d\u001c\u0015\"?{\u0005<\u001a\u0006\u0001\u0010*,;\u0005 A\u0000\u0000\u00045'4\u001c6\u0001\u0000A%(<'\u001f2\u0002\u0011\u0001\u0005\n(;\u00104\n\u0006", (Object)"\u001e)\r<\u00022\r\u0018\n", "Y\u001d`\u0003", -115, 4630623485163106259L, "2pWeoz5ESJ2X2grd0DGL65cU2T9gZzOFaTCw2Am5s6sBKGp8Zlmp3s0", this.tournamentManager, false);
        }
    }

    public ConfigHandler getMessagesFile() {
        return this.messagesFile;
    }

    public ConfigHandler getMenuFile() {
        return this.menuFile;
    }

    public TournamentManager getTournamentManager() {
        return this.tournamentManager;
    }

    private static /* bridge */ /* synthetic */ void loadConfig0() {
    }

    @Override
    public void registerObjective(XLObjective xLObjective, String string) {
        this.objectiveManager.registerObjective(xLObjective, string);
    }

    public void reload() {
        this.reloadConfig();
        this.messagesFile.reload();
        this.menuFile.reload();
        Messages.setConfiguration(this.messagesFile.getConfig());
        this.tournamentManager.onDisable(true);
        this.tournamentManager.onEnable();
    }

    public XLTournamentsPlugin() {
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    public MenuManager getMenuManager() {
        return this.menuManager;
    }

    @Override
    public Optional<Tournament> getTournament(String string) {
        return this.tournamentManager.getTournament(string);
    }

    public ObjectiveManager getObjectiveManager() {
        return this.objectiveManager;
    }

    @Override
    public void registerObjective(XLObjective xLObjective) {
        this.objectiveManager.registerObjective(xLObjective);
    }

    public HookManager getHookManager() {
        return this.hookManager;
    }

    public StorageManager getStorageManager() {
        return this.storageManager;
    }

    public ActionManager getActionManager() {
        return this.actionManager;
    }
}

