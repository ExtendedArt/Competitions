/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 */
package fun.lewisdev.tournaments.utility;

import fun.lewisdev.tournaments.utility.TextUtil;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;

public final class Messages
extends Enum<Messages> {
    public static final /* enum */ Messages PREFIX = new Messages("general.prefix");
    public static final /* enum */ Messages RELOAD = new Messages("general.reload");
    public static final /* enum */ Messages NO_PERMISSION = new Messages("general.no_permission");
    public static final /* enum */ Messages FORCE_UPDATED_TOURNAMENTS = new Messages("tournament.force_updated_tournaments");
    public static final /* enum */ Messages ALREADY_PARTICIPATING = new Messages("tournament.already_participating");
    public static final /* enum */ Messages NOT_ENOUGH_FUNDS = new Messages("tournament.not_enough_funds");
    public static final /* enum */ Messages TOURNAMENT_NO_PERMISSION = new Messages("tournament.tournament_no_permission");
    public static final /* enum */ Messages TOURNAMENT_WAITING = new Messages("tournament.waiting");
    public static final /* enum */ Messages TOURNAMENT_ENDED = new Messages("tournament.ended");
    public static final /* enum */ Messages TOURNAMENT_CLEARED = new Messages("tournament.cleared");
    public static final /* enum */ Messages TOURNAMENT_CLEARED_PLAYER = new Messages("tournament.cleared_player");
    public static final /* enum */ Messages LIST_TOURNAMENTS = new Messages("tournament.list");
    private static FileConfiguration config;
    private final String path;
    private static final /* synthetic */ Messages[] $VALUES;

    public static Messages[] values() {
        return (Messages[])$VALUES.clone();
    }

    public static Messages valueOf(String string) {
        return Enum.valueOf(Messages.class, string);
    }

    private Messages(String string2) {
        this.path = string2;
    }

    public static void setConfiguration(FileConfiguration fileConfiguration) {
        config = fileConfiguration;
    }

    public void send(CommandSender commandSender, Object ... arrobject) {
        Object object;
        Object object2 = config.get(this.path);
        if (object2 == null) {
            object = "XLTournaments: message not found (" + this.path + ")";
        } else {
            Object object3 = object = object2 instanceof List ? TextUtil.fromList((List)object2) : object2.toString();
        }
        if (!((String)object).isEmpty()) {
            commandSender.sendMessage(TextUtil.color(this.replace((String)object, arrobject)));
        }
    }

    private String replace(String string, Object ... arrobject) {
        for (int i = 0; i < arrobject.length && i + 1 < arrobject.length; i += 2) {
            string = string.replace(String.valueOf(arrobject[i]), String.valueOf(arrobject[i + 1]));
        }
        String string2 = config.getString(PREFIX.getPath());
        return string.replace("{PREFIX}", string2 != null && !string2.isEmpty() ? string2 : "");
    }

    public String getPath() {
        return this.path;
    }

    private String getConfiguration() {
        return "-1458066355";
    }

    private static /* synthetic */ Messages[] $values() {
        return new Messages[]{PREFIX, RELOAD, NO_PERMISSION, FORCE_UPDATED_TOURNAMENTS, ALREADY_PARTICIPATING, NOT_ENOUGH_FUNDS, TOURNAMENT_NO_PERMISSION, TOURNAMENT_WAITING, TOURNAMENT_ENDED, TOURNAMENT_CLEARED, TOURNAMENT_CLEARED_PLAYER, LIST_TOURNAMENTS};
    }

    static {
        $VALUES = Messages.$values();
    }
}

