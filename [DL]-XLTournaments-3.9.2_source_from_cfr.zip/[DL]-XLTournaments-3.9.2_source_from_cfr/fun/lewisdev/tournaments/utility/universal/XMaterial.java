/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.cache.Cache
 *  com.google.common.cache.CacheBuilder
 *  javax.annotation.Nonnull
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SpawnEggMeta
 *  org.bukkit.potion.Potion
 */
package fun.lewisdev.tournaments.utility.universal;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SpawnEggMeta;
import org.bukkit.potion.Potion;

public final class XMaterial
extends Enum<XMaterial> {
    public static final /* enum */ XMaterial ACACIA_BOAT = new XMaterial("BOAT_ACACIA");
    public static final /* enum */ XMaterial ACACIA_BUTTON = new XMaterial("WOOD_BUTTON");
    public static final /* enum */ XMaterial ACACIA_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ACACIA_DOOR = new XMaterial("ACACIA_DOOR", "ACACIA_DOOR_ITEM");
    public static final /* enum */ XMaterial ACACIA_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ACACIA_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ACACIA_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ACACIA_LEAVES = new XMaterial(0, "LEAVES_2");
    public static final /* enum */ XMaterial ACACIA_LOG = new XMaterial(0, "LOG_2");
    public static final /* enum */ XMaterial ACACIA_PLANKS = new XMaterial(4, "WOOD");
    public static final /* enum */ XMaterial ACACIA_PRESSURE_PLATE = new XMaterial("WOOD_PLATE");
    public static final /* enum */ XMaterial ACACIA_SAPLING = new XMaterial(4, "SAPLING");
    public static final /* enum */ XMaterial ACACIA_SIGN = new XMaterial("SIGN_POST", "SIGN");
    public static final /* enum */ XMaterial ACACIA_SLAB = new XMaterial(4, "WOOD_DOUBLE_STEP", "WOOD_STEP", "WOODEN_SLAB");
    public static final /* enum */ XMaterial ACACIA_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ACACIA_TRAPDOOR = new XMaterial("TRAP_DOOR");
    public static final /* enum */ XMaterial ACACIA_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ACACIA_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial ACACIA_WOOD = new XMaterial(0, "LOG_2");
    public static final /* enum */ XMaterial ACTIVATOR_RAIL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AIR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ALLAY_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ALLIUM = new XMaterial(2, "RED_ROSE");
    public static final /* enum */ XMaterial AMETHYST_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AMETHYST_CLUSTER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AMETHYST_SHARD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ANCIENT_DEBRIS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ANDESITE = new XMaterial(5, "STONE");
    public static final /* enum */ XMaterial ANDESITE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ANDESITE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ANDESITE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ANGLER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ANVIL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial APPLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ARCHER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ARMOR_STAND = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ARMS_UP_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ARROW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ATTACHED_MELON_STEM = new XMaterial(7, "MELON_STEM");
    public static final /* enum */ XMaterial ATTACHED_PUMPKIN_STEM = new XMaterial(7, "PUMPKIN_STEM");
    public static final /* enum */ XMaterial AXOLOTL_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AXOLOTL_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AZALEA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AZALEA_LEAVES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial AZURE_BLUET = new XMaterial(3, "RED_ROSE");
    public static final /* enum */ XMaterial BAKED_POTATO = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_CHEST_RAFT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_DOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_MOSAIC = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_MOSAIC_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_MOSAIC_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_PLANKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_PRESSURE_PLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_RAFT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_SAPLING = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_TRAPDOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAMBOO_WALL_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BARREL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BARRIER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BASALT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BAT_SPAWN_EGG = new XMaterial(65, "MONSTER_EGG");
    public static final /* enum */ XMaterial BEACON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BEDROCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BEEF = new XMaterial("RAW_BEEF");
    public static final /* enum */ XMaterial BEEHIVE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BEETROOT = new XMaterial("BEETROOT_BLOCK");
    public static final /* enum */ XMaterial BEETROOTS = new XMaterial("BEETROOT");
    public static final /* enum */ XMaterial BEETROOT_SEEDS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BEETROOT_SOUP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BEE_NEST = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BEE_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BELL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIG_DRIPLEAF = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIG_DRIPLEAF_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIRCH_BOAT = new XMaterial("BOAT_BIRCH");
    public static final /* enum */ XMaterial BIRCH_BUTTON = new XMaterial("WOOD_BUTTON");
    public static final /* enum */ XMaterial BIRCH_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIRCH_DOOR = new XMaterial("BIRCH_DOOR", "BIRCH_DOOR_ITEM");
    public static final /* enum */ XMaterial BIRCH_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIRCH_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIRCH_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIRCH_LEAVES = new XMaterial(2, "LEAVES");
    public static final /* enum */ XMaterial BIRCH_LOG = new XMaterial(2, "LOG");
    public static final /* enum */ XMaterial BIRCH_PLANKS = new XMaterial(2, "WOOD");
    public static final /* enum */ XMaterial BIRCH_PRESSURE_PLATE = new XMaterial("WOOD_PLATE");
    public static final /* enum */ XMaterial BIRCH_SAPLING = new XMaterial(2, "SAPLING");
    public static final /* enum */ XMaterial BIRCH_SIGN = new XMaterial("SIGN_POST", "SIGN");
    public static final /* enum */ XMaterial BIRCH_SLAB = new XMaterial(2, "WOOD_DOUBLE_STEP", "WOOD_STEP", "WOODEN_SLAB");
    public static final /* enum */ XMaterial BIRCH_STAIRS = new XMaterial("BIRCH_WOOD_STAIRS");
    public static final /* enum */ XMaterial BIRCH_TRAPDOOR = new XMaterial("TRAP_DOOR");
    public static final /* enum */ XMaterial BIRCH_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BIRCH_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial BIRCH_WOOD = new XMaterial(2, "LOG");
    public static final /* enum */ XMaterial BLACKSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACKSTONE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACKSTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACKSTONE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACK_BANNER = new XMaterial("STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial BLACK_BED = new XMaterial(XMaterial.supports(12) ? 15 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial BLACK_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACK_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACK_CARPET = new XMaterial(15, "CARPET");
    public static final /* enum */ XMaterial BLACK_CONCRETE = new XMaterial(15, "CONCRETE");
    public static final /* enum */ XMaterial BLACK_CONCRETE_POWDER = new XMaterial(15, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial BLACK_DYE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACK_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACK_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLACK_STAINED_GLASS = new XMaterial(15, "STAINED_GLASS");
    public static final /* enum */ XMaterial BLACK_STAINED_GLASS_PANE = new XMaterial(15, "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial BLACK_TERRACOTTA = new XMaterial(15, "STAINED_CLAY");
    public static final /* enum */ XMaterial BLACK_WALL_BANNER = new XMaterial("WALL_BANNER");
    public static final /* enum */ XMaterial BLACK_WOOL = new XMaterial(15, "WOOL");
    public static final /* enum */ XMaterial BLADE_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLAST_FURNACE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLAZE_POWDER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLAZE_ROD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLAZE_SPAWN_EGG = new XMaterial(61, "MONSTER_EGG");
    public static final /* enum */ XMaterial BLUE_BANNER = new XMaterial(4, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial BLUE_BED = new XMaterial(XMaterial.supports(12) ? 11 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial BLUE_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLUE_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLUE_CARPET = new XMaterial(11, "CARPET");
    public static final /* enum */ XMaterial BLUE_CONCRETE = new XMaterial(11, "CONCRETE");
    public static final /* enum */ XMaterial BLUE_CONCRETE_POWDER = new XMaterial(11, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial BLUE_DYE = new XMaterial(4, "INK_SACK", "LAPIS_LAZULI");
    public static final /* enum */ XMaterial BLUE_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLUE_ICE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLUE_ORCHID = new XMaterial(1, "RED_ROSE");
    public static final /* enum */ XMaterial BLUE_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BLUE_STAINED_GLASS = new XMaterial(11, "STAINED_GLASS");
    public static final /* enum */ XMaterial BLUE_STAINED_GLASS_PANE = new XMaterial(11, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial BLUE_TERRACOTTA = new XMaterial(11, "STAINED_CLAY");
    public static final /* enum */ XMaterial BLUE_WALL_BANNER = new XMaterial(4, "WALL_BANNER");
    public static final /* enum */ XMaterial BLUE_WOOL = new XMaterial(11, "WOOL");
    public static final /* enum */ XMaterial BONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BONE_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BONE_MEAL = new XMaterial(15, "INK_SACK");
    public static final /* enum */ XMaterial BOOK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BOOKSHELF = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BOW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BOWL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BRAIN_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BRAIN_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BRAIN_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BRAIN_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BREAD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BREWER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BREWING_STAND = new XMaterial("BREWING_STAND", "BREWING_STAND_ITEM");
    public static final /* enum */ XMaterial BRICK = new XMaterial("CLAY_BRICK");
    public static final /* enum */ XMaterial BRICKS = new XMaterial("BRICK");
    public static final /* enum */ XMaterial BRICK_SLAB = new XMaterial(4, "STEP");
    public static final /* enum */ XMaterial BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BROWN_BANNER = new XMaterial(3, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial BROWN_BED = new XMaterial(XMaterial.supports(12) ? 12 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial BROWN_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BROWN_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BROWN_CARPET = new XMaterial(12, "CARPET");
    public static final /* enum */ XMaterial BROWN_CONCRETE = new XMaterial(12, "CONCRETE");
    public static final /* enum */ XMaterial BROWN_CONCRETE_POWDER = new XMaterial(12, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial BROWN_DYE = new XMaterial(3, "INK_SACK", "DYE", "COCOA_BEANS");
    public static final /* enum */ XMaterial BROWN_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BROWN_MUSHROOM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BROWN_MUSHROOM_BLOCK = new XMaterial("BROWN_MUSHROOM", "HUGE_MUSHROOM_1");
    public static final /* enum */ XMaterial BROWN_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BROWN_STAINED_GLASS = new XMaterial(12, "STAINED_GLASS");
    public static final /* enum */ XMaterial BROWN_STAINED_GLASS_PANE = new XMaterial(12, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial BROWN_TERRACOTTA = new XMaterial(12, "STAINED_CLAY");
    public static final /* enum */ XMaterial BROWN_WALL_BANNER = new XMaterial(3, "WALL_BANNER");
    public static final /* enum */ XMaterial BROWN_WOOL = new XMaterial(12, "WOOL");
    public static final /* enum */ XMaterial BRUSH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUBBLE_COLUMN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUBBLE_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUBBLE_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUBBLE_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUBBLE_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUDDING_AMETHYST = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BUNDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial BURN_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CACTUS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CAKE = new XMaterial("CAKE_BLOCK");
    public static final /* enum */ XMaterial CALCITE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CALIBRATED_SCULK_SENSOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CAMEL_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CAMPFIRE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CARROT = new XMaterial("CARROT_ITEM");
    public static final /* enum */ XMaterial CARROTS = new XMaterial("CARROT");
    public static final /* enum */ XMaterial CARROT_ON_A_STICK = new XMaterial("CARROT_STICK");
    public static final /* enum */ XMaterial CARTOGRAPHY_TABLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CARVED_PUMPKIN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CAT_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CAULDRON = new XMaterial("CAULDRON", "CAULDRON_ITEM");
    public static final /* enum */ XMaterial CAVE_AIR = new XMaterial("AIR");
    public static final /* enum */ XMaterial CAVE_SPIDER_SPAWN_EGG = new XMaterial(59, "MONSTER_EGG");
    public static final /* enum */ XMaterial CAVE_VINES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CAVE_VINES_PLANT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHAIN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHAINMAIL_BOOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHAINMAIL_CHESTPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHAINMAIL_HELMET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHAINMAIL_LEGGINGS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHAIN_COMMAND_BLOCK = new XMaterial("COMMAND", "COMMAND_CHAIN");
    public static final /* enum */ XMaterial CHARCOAL = new XMaterial(1, "COAL");
    public static final /* enum */ XMaterial CHERRY_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_DOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_LEAVES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_PLANKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_PRESSURE_PLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_SAPLING = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_TRAPDOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_WALL_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHERRY_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHEST = new XMaterial("LOCKED_CHEST");
    public static final /* enum */ XMaterial CHEST_MINECART = new XMaterial("STORAGE_MINECART");
    public static final /* enum */ XMaterial CHICKEN = new XMaterial("RAW_CHICKEN");
    public static final /* enum */ XMaterial CHICKEN_SPAWN_EGG = new XMaterial(93, "MONSTER_EGG");
    public static final /* enum */ XMaterial CHIPPED_ANVIL = new XMaterial(1, "ANVIL");
    public static final /* enum */ XMaterial CHISELED_BOOKSHELF = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHISELED_DEEPSLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHISELED_NETHER_BRICKS = new XMaterial(1, "NETHER_BRICKS");
    public static final /* enum */ XMaterial CHISELED_POLISHED_BLACKSTONE = new XMaterial("POLISHED_BLACKSTONE");
    public static final /* enum */ XMaterial CHISELED_QUARTZ_BLOCK = new XMaterial(1, "QUARTZ_BLOCK");
    public static final /* enum */ XMaterial CHISELED_RED_SANDSTONE = new XMaterial(1, "RED_SANDSTONE");
    public static final /* enum */ XMaterial CHISELED_SANDSTONE = new XMaterial(1, "SANDSTONE");
    public static final /* enum */ XMaterial CHISELED_STONE_BRICKS = new XMaterial(3, "SMOOTH_BRICK");
    public static final /* enum */ XMaterial CHORUS_FLOWER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHORUS_FRUIT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CHORUS_PLANT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CLAY = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CLAY_BALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CLOCK = new XMaterial("WATCH");
    public static final /* enum */ XMaterial COAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COAL_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COARSE_DIRT = new XMaterial(1, "DIRT");
    public static final /* enum */ XMaterial COAST_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLED_DEEPSLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLED_DEEPSLATE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLED_DEEPSLATE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLED_DEEPSLATE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLESTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLESTONE_SLAB = new XMaterial(3, "STEP");
    public static final /* enum */ XMaterial COBBLESTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COBBLESTONE_WALL = new XMaterial("COBBLE_WALL");
    public static final /* enum */ XMaterial COBWEB = new XMaterial("WEB");
    public static final /* enum */ XMaterial COCOA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COCOA_BEANS = new XMaterial(3, "INK_SACK");
    public static final /* enum */ XMaterial COD = new XMaterial("RAW_FISH");
    public static final /* enum */ XMaterial COD_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COD_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COMMAND_BLOCK = new XMaterial("COMMAND");
    public static final /* enum */ XMaterial COMMAND_BLOCK_MINECART = new XMaterial("COMMAND_MINECART");
    public static final /* enum */ XMaterial COMPARATOR = new XMaterial("REDSTONE_COMPARATOR_OFF", "REDSTONE_COMPARATOR_ON", "REDSTONE_COMPARATOR");
    public static final /* enum */ XMaterial COMPASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COMPOSTER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CONDUIT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COOKED_BEEF = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COOKED_CHICKEN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COOKED_COD = new XMaterial("COOKED_FISH");
    public static final /* enum */ XMaterial COOKED_MUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COOKED_PORKCHOP = new XMaterial("GRILLED_PORK");
    public static final /* enum */ XMaterial COOKED_RABBIT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COOKED_SALMON = new XMaterial(1, "COOKED_FISH");
    public static final /* enum */ XMaterial COOKIE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COPPER_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COPPER_INGOT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COPPER_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CORNFLOWER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial COW_SPAWN_EGG = new XMaterial(92, "MONSTER_EGG");
    public static final /* enum */ XMaterial CRACKED_DEEPSLATE_BRICKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRACKED_DEEPSLATE_TILES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRACKED_NETHER_BRICKS = new XMaterial(2, "NETHER_BRICKS");
    public static final /* enum */ XMaterial CRACKED_POLISHED_BLACKSTONE_BRICKS = new XMaterial("POLISHED_BLACKSTONE_BRICKS");
    public static final /* enum */ XMaterial CRACKED_STONE_BRICKS = new XMaterial(2, "SMOOTH_BRICK");
    public static final /* enum */ XMaterial CRAFTING_TABLE = new XMaterial("WORKBENCH");
    public static final /* enum */ XMaterial CREEPER_BANNER_PATTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CREEPER_HEAD = new XMaterial(4, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial CREEPER_SPAWN_EGG = new XMaterial(50, "MONSTER_EGG");
    public static final /* enum */ XMaterial CREEPER_WALL_HEAD = new XMaterial(4, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial CRIMSON_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_DOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_FUNGUS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_HYPHAE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_NYLIUM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_PLANKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_PRESSURE_PLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_SIGN = new XMaterial("SIGN_POST");
    public static final /* enum */ XMaterial CRIMSON_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_TRAPDOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRIMSON_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial CROSSBOW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CRYING_OBSIDIAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CUT_RED_SANDSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CUT_RED_SANDSTONE_SLAB = new XMaterial("STONE_SLAB2");
    public static final /* enum */ XMaterial CUT_SANDSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CUT_SANDSTONE_SLAB = new XMaterial(1, "STEP");
    public static final /* enum */ XMaterial CYAN_BANNER = new XMaterial(6, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial CYAN_BED = new XMaterial(XMaterial.supports(12) ? 9 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial CYAN_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CYAN_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CYAN_CARPET = new XMaterial(9, "CARPET");
    public static final /* enum */ XMaterial CYAN_CONCRETE = new XMaterial(9, "CONCRETE");
    public static final /* enum */ XMaterial CYAN_CONCRETE_POWDER = new XMaterial(9, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial CYAN_DYE = new XMaterial(6, "INK_SACK");
    public static final /* enum */ XMaterial CYAN_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CYAN_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial CYAN_STAINED_GLASS = new XMaterial(9, "STAINED_GLASS");
    public static final /* enum */ XMaterial CYAN_STAINED_GLASS_PANE = new XMaterial(9, "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial CYAN_TERRACOTTA = new XMaterial(9, "STAINED_CLAY");
    public static final /* enum */ XMaterial CYAN_WALL_BANNER = new XMaterial(6, "WALL_BANNER");
    public static final /* enum */ XMaterial CYAN_WOOL = new XMaterial(9, "WOOL");
    public static final /* enum */ XMaterial DAMAGED_ANVIL = new XMaterial(2, "ANVIL");
    public static final /* enum */ XMaterial DANDELION = new XMaterial("YELLOW_FLOWER");
    public static final /* enum */ XMaterial DANGER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_BOAT = new XMaterial("BOAT_DARK_OAK");
    public static final /* enum */ XMaterial DARK_OAK_BUTTON = new XMaterial("WOOD_BUTTON");
    public static final /* enum */ XMaterial DARK_OAK_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_DOOR = new XMaterial("DARK_OAK_DOOR", "DARK_OAK_DOOR_ITEM");
    public static final /* enum */ XMaterial DARK_OAK_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_LEAVES = new XMaterial(1, "LEAVES_2");
    public static final /* enum */ XMaterial DARK_OAK_LOG = new XMaterial(1, "LOG_2");
    public static final /* enum */ XMaterial DARK_OAK_PLANKS = new XMaterial(5, "WOOD");
    public static final /* enum */ XMaterial DARK_OAK_PRESSURE_PLATE = new XMaterial("WOOD_PLATE");
    public static final /* enum */ XMaterial DARK_OAK_SAPLING = new XMaterial(5, "SAPLING");
    public static final /* enum */ XMaterial DARK_OAK_SIGN = new XMaterial("SIGN_POST", "SIGN");
    public static final /* enum */ XMaterial DARK_OAK_SLAB = new XMaterial(5, "WOOD_DOUBLE_STEP", "WOOD_STEP", "WOODEN_SLAB");
    public static final /* enum */ XMaterial DARK_OAK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_TRAPDOOR = new XMaterial("TRAP_DOOR");
    public static final /* enum */ XMaterial DARK_OAK_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_OAK_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial DARK_OAK_WOOD = new XMaterial(1, "LOG_2");
    public static final /* enum */ XMaterial DARK_PRISMARINE = new XMaterial(2, "PRISMARINE");
    public static final /* enum */ XMaterial DARK_PRISMARINE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DARK_PRISMARINE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DAYLIGHT_DETECTOR = new XMaterial("DAYLIGHT_DETECTOR_INVERTED");
    public static final /* enum */ XMaterial DEAD_BRAIN_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BRAIN_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BRAIN_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BRAIN_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BUBBLE_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BUBBLE_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BUBBLE_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BUBBLE_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_BUSH = new XMaterial("LONG_GRASS");
    public static final /* enum */ XMaterial DEAD_FIRE_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_FIRE_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_FIRE_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_FIRE_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_HORN_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_HORN_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_HORN_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_HORN_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_TUBE_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_TUBE_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_TUBE_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEAD_TUBE_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEBUG_STICK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DECORATED_POT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_BRICKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_COAL_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_COPPER_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_DIAMOND_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_EMERALD_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_GOLD_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_IRON_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_LAPIS_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_REDSTONE_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_TILES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_TILE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_TILE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DEEPSLATE_TILE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DETECTOR_RAIL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_AXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_BOOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_CHESTPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_HELMET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_HOE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_HORSE_ARMOR = new XMaterial("DIAMOND_BARDING");
    public static final /* enum */ XMaterial DIAMOND_LEGGINGS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_PICKAXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIAMOND_SHOVEL = new XMaterial("DIAMOND_SPADE");
    public static final /* enum */ XMaterial DIAMOND_SWORD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIORITE = new XMaterial(3, "STONE");
    public static final /* enum */ XMaterial DIORITE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIORITE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIORITE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIRT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DIRT_PATH = new XMaterial("GRASS_PATH");
    public static final /* enum */ XMaterial DISC_FRAGMENT_5 = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DISPENSER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DOLPHIN_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DONKEY_SPAWN_EGG = new XMaterial(32, "MONSTER_EGG");
    public static final /* enum */ XMaterial DRAGON_BREATH = new XMaterial("DRAGONS_BREATH");
    public static final /* enum */ XMaterial DRAGON_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DRAGON_HEAD = new XMaterial(5, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial DRAGON_WALL_HEAD = new XMaterial(5, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial DRIED_KELP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DRIED_KELP_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DRIPSTONE_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DROPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DROWNED_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial DUNE_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ECHO_SHARD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ELDER_GUARDIAN_SPAWN_EGG = new XMaterial(4, "MONSTER_EGG");
    public static final /* enum */ XMaterial ELYTRA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EMERALD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EMERALD_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EMERALD_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ENCHANTED_BOOK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ENCHANTED_GOLDEN_APPLE = new XMaterial(1, "GOLDEN_APPLE");
    public static final /* enum */ XMaterial ENCHANTING_TABLE = new XMaterial("ENCHANTMENT_TABLE");
    public static final /* enum */ XMaterial ENDERMAN_SPAWN_EGG = new XMaterial(58, "MONSTER_EGG");
    public static final /* enum */ XMaterial ENDERMITE_SPAWN_EGG = new XMaterial(67, "MONSTER_EGG");
    public static final /* enum */ XMaterial ENDER_CHEST = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ENDER_DRAGON_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ENDER_EYE = new XMaterial("EYE_OF_ENDER");
    public static final /* enum */ XMaterial ENDER_PEARL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial END_CRYSTAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial END_GATEWAY = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial END_PORTAL = new XMaterial("ENDER_PORTAL");
    public static final /* enum */ XMaterial END_PORTAL_FRAME = new XMaterial("ENDER_PORTAL_FRAME");
    public static final /* enum */ XMaterial END_ROD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial END_STONE = new XMaterial("ENDER_STONE");
    public static final /* enum */ XMaterial END_STONE_BRICKS = new XMaterial("END_BRICKS");
    public static final /* enum */ XMaterial END_STONE_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial END_STONE_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial END_STONE_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EVOKER_SPAWN_EGG = new XMaterial(34, "MONSTER_EGG");
    public static final /* enum */ XMaterial EXPERIENCE_BOTTLE = new XMaterial("EXP_BOTTLE");
    public static final /* enum */ XMaterial EXPLORER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EXPOSED_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EXPOSED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EXPOSED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EXPOSED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial EYE_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FARMLAND = new XMaterial("SOIL");
    public static final /* enum */ XMaterial FEATHER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FERMENTED_SPIDER_EYE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FERN = new XMaterial(2, "LONG_GRASS");
    public static final /* enum */ XMaterial FILLED_MAP = new XMaterial("MAP");
    public static final /* enum */ XMaterial FIRE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FIREWORK_ROCKET = new XMaterial("FIREWORK");
    public static final /* enum */ XMaterial FIREWORK_STAR = new XMaterial("FIREWORK_CHARGE");
    public static final /* enum */ XMaterial FIRE_CHARGE = new XMaterial("FIREBALL");
    public static final /* enum */ XMaterial FIRE_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FIRE_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FIRE_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FIRE_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FISHING_ROD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLETCHING_TABLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLINT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLINT_AND_STEEL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLOWERING_AZALEA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLOWERING_AZALEA_LEAVES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLOWER_BANNER_PATTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FLOWER_POT = new XMaterial("FLOWER_POT", "FLOWER_POT_ITEM");
    public static final /* enum */ XMaterial FOX_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FRIEND_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FROGSPAWN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FROG_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FROSTED_ICE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial FURNACE = new XMaterial("BURNING_FURNACE");
    public static final /* enum */ XMaterial FURNACE_MINECART = new XMaterial("POWERED_MINECART");
    public static final /* enum */ XMaterial GHAST_SPAWN_EGG = new XMaterial(56, "MONSTER_EGG");
    public static final /* enum */ XMaterial GHAST_TEAR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GILDED_BLACKSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLASS_BOTTLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLASS_PANE = new XMaterial("THIN_GLASS");
    public static final /* enum */ XMaterial GLISTERING_MELON_SLICE = new XMaterial("SPECKLED_MELON");
    public static final /* enum */ XMaterial GLOBE_BANNER_PATTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOWSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOWSTONE_DUST = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOW_BERRIES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOW_INK_SAC = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOW_ITEM_FRAME = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOW_LICHEN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GLOW_SQUID_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOAT_HORN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOAT_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOLDEN_APPLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOLDEN_AXE = new XMaterial("GOLD_AXE");
    public static final /* enum */ XMaterial GOLDEN_BOOTS = new XMaterial("GOLD_BOOTS");
    public static final /* enum */ XMaterial GOLDEN_CARROT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOLDEN_CHESTPLATE = new XMaterial("GOLD_CHESTPLATE");
    public static final /* enum */ XMaterial GOLDEN_HELMET = new XMaterial("GOLD_HELMET");
    public static final /* enum */ XMaterial GOLDEN_HOE = new XMaterial("GOLD_HOE");
    public static final /* enum */ XMaterial GOLDEN_HORSE_ARMOR = new XMaterial("GOLD_BARDING");
    public static final /* enum */ XMaterial GOLDEN_LEGGINGS = new XMaterial("GOLD_LEGGINGS");
    public static final /* enum */ XMaterial GOLDEN_PICKAXE = new XMaterial("GOLD_PICKAXE");
    public static final /* enum */ XMaterial GOLDEN_SHOVEL = new XMaterial("GOLD_SPADE");
    public static final /* enum */ XMaterial GOLDEN_SWORD = new XMaterial("GOLD_SWORD");
    public static final /* enum */ XMaterial GOLD_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOLD_INGOT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOLD_NUGGET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GOLD_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRANITE = new XMaterial(1, "STONE");
    public static final /* enum */ XMaterial GRANITE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRANITE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRANITE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRASS = new XMaterial(1, "LONG_GRASS");
    public static final /* enum */ XMaterial GRASS_BLOCK = new XMaterial("GRASS");
    public static final /* enum */ XMaterial GRAVEL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRAY_BANNER = new XMaterial(8, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial GRAY_BED = new XMaterial(XMaterial.supports(12) ? 7 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial GRAY_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRAY_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRAY_CARPET = new XMaterial(7, "CARPET");
    public static final /* enum */ XMaterial GRAY_CONCRETE = new XMaterial(7, "CONCRETE");
    public static final /* enum */ XMaterial GRAY_CONCRETE_POWDER = new XMaterial(7, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial GRAY_DYE = new XMaterial(8, "INK_SACK");
    public static final /* enum */ XMaterial GRAY_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRAY_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GRAY_STAINED_GLASS = new XMaterial(7, "STAINED_GLASS");
    public static final /* enum */ XMaterial GRAY_STAINED_GLASS_PANE = new XMaterial(7, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial GRAY_TERRACOTTA = new XMaterial(7, "STAINED_CLAY");
    public static final /* enum */ XMaterial GRAY_WALL_BANNER = new XMaterial(8, "WALL_BANNER");
    public static final /* enum */ XMaterial GRAY_WOOL = new XMaterial(7, "WOOL");
    public static final /* enum */ XMaterial GREEN_BANNER = new XMaterial(2, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial GREEN_BED = new XMaterial(XMaterial.supports(12) ? 13 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial GREEN_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GREEN_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GREEN_CARPET = new XMaterial(13, "CARPET");
    public static final /* enum */ XMaterial GREEN_CONCRETE = new XMaterial(13, "CONCRETE");
    public static final /* enum */ XMaterial GREEN_CONCRETE_POWDER = new XMaterial(13, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial GREEN_DYE = new XMaterial(2, "INK_SACK", "CACTUS_GREEN");
    public static final /* enum */ XMaterial GREEN_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GREEN_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GREEN_STAINED_GLASS = new XMaterial(13, "STAINED_GLASS");
    public static final /* enum */ XMaterial GREEN_STAINED_GLASS_PANE = new XMaterial(13, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial GREEN_TERRACOTTA = new XMaterial(13, "STAINED_CLAY");
    public static final /* enum */ XMaterial GREEN_WALL_BANNER = new XMaterial(2, "WALL_BANNER");
    public static final /* enum */ XMaterial GREEN_WOOL = new XMaterial(13, "WOOL");
    public static final /* enum */ XMaterial GRINDSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial GUARDIAN_SPAWN_EGG = new XMaterial(68, "MONSTER_EGG");
    public static final /* enum */ XMaterial GUNPOWDER = new XMaterial("SULPHUR");
    public static final /* enum */ XMaterial HANGING_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HAY_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HEARTBREAK_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HEART_OF_THE_SEA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HEART_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HEAVY_WEIGHTED_PRESSURE_PLATE = new XMaterial("IRON_PLATE");
    public static final /* enum */ XMaterial HOGLIN_SPAWN_EGG = new XMaterial("MONSTER_EGG");
    public static final /* enum */ XMaterial HONEYCOMB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HONEYCOMB_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HONEY_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HONEY_BOTTLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HOPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HOPPER_MINECART = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HORN_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HORN_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HORN_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HORN_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HORSE_SPAWN_EGG = new XMaterial(100, "MONSTER_EGG");
    public static final /* enum */ XMaterial HOST_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HOWL_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial HUSK_SPAWN_EGG = new XMaterial(23, "MONSTER_EGG");
    public static final /* enum */ XMaterial ICE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial INFESTED_CHISELED_STONE_BRICKS = new XMaterial(5, "MONSTER_EGGS");
    public static final /* enum */ XMaterial INFESTED_COBBLESTONE = new XMaterial(1, "MONSTER_EGGS");
    public static final /* enum */ XMaterial INFESTED_CRACKED_STONE_BRICKS = new XMaterial(4, "MONSTER_EGGS");
    public static final /* enum */ XMaterial INFESTED_DEEPSLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial INFESTED_MOSSY_STONE_BRICKS = new XMaterial(3, "MONSTER_EGGS");
    public static final /* enum */ XMaterial INFESTED_STONE = new XMaterial("MONSTER_EGGS");
    public static final /* enum */ XMaterial INFESTED_STONE_BRICKS = new XMaterial(2, "MONSTER_EGGS");
    public static final /* enum */ XMaterial INK_SAC = new XMaterial("INK_SACK");
    public static final /* enum */ XMaterial IRON_AXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_BARS = new XMaterial("IRON_FENCE");
    public static final /* enum */ XMaterial IRON_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_BOOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_CHESTPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_DOOR = new XMaterial("IRON_DOOR_BLOCK");
    public static final /* enum */ XMaterial IRON_GOLEM_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_HELMET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_HOE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_HORSE_ARMOR = new XMaterial("IRON_BARDING");
    public static final /* enum */ XMaterial IRON_INGOT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_LEGGINGS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_NUGGET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_PICKAXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_SHOVEL = new XMaterial("IRON_SPADE");
    public static final /* enum */ XMaterial IRON_SWORD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial IRON_TRAPDOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ITEM_FRAME = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JACK_O_LANTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JIGSAW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUKEBOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUNGLE_BOAT = new XMaterial("BOAT_JUNGLE");
    public static final /* enum */ XMaterial JUNGLE_BUTTON = new XMaterial("WOOD_BUTTON");
    public static final /* enum */ XMaterial JUNGLE_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUNGLE_DOOR = new XMaterial("JUNGLE_DOOR", "JUNGLE_DOOR_ITEM");
    public static final /* enum */ XMaterial JUNGLE_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUNGLE_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUNGLE_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUNGLE_LEAVES = new XMaterial(3, "LEAVES");
    public static final /* enum */ XMaterial JUNGLE_LOG = new XMaterial(3, "LOG");
    public static final /* enum */ XMaterial JUNGLE_PLANKS = new XMaterial(3, "WOOD");
    public static final /* enum */ XMaterial JUNGLE_PRESSURE_PLATE = new XMaterial("WOOD_PLATE");
    public static final /* enum */ XMaterial JUNGLE_SAPLING = new XMaterial(3, "SAPLING");
    public static final /* enum */ XMaterial JUNGLE_SIGN = new XMaterial("SIGN_POST", "SIGN");
    public static final /* enum */ XMaterial JUNGLE_SLAB = new XMaterial(3, "WOOD_DOUBLE_STEP", "WOOD_STEP", "WOODEN_SLAB");
    public static final /* enum */ XMaterial JUNGLE_STAIRS = new XMaterial("JUNGLE_WOOD_STAIRS");
    public static final /* enum */ XMaterial JUNGLE_TRAPDOOR = new XMaterial("TRAP_DOOR");
    public static final /* enum */ XMaterial JUNGLE_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial JUNGLE_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial JUNGLE_WOOD = new XMaterial(3, "LOG");
    public static final /* enum */ XMaterial KELP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial KELP_PLANT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial KNOWLEDGE_BOOK = new XMaterial("BOOK");
    public static final /* enum */ XMaterial LADDER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LANTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LAPIS_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LAPIS_LAZULI = new XMaterial(4, "INK_SACK");
    public static final /* enum */ XMaterial LAPIS_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LARGE_AMETHYST_BUD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LARGE_FERN = new XMaterial(3, "DOUBLE_PLANT");
    public static final /* enum */ XMaterial LAVA = new XMaterial("STATIONARY_LAVA");
    public static final /* enum */ XMaterial LAVA_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LAVA_CAULDRON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LEAD = new XMaterial("LEASH");
    public static final /* enum */ XMaterial LEATHER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LEATHER_BOOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LEATHER_CHESTPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LEATHER_HELMET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LEATHER_HORSE_ARMOR = new XMaterial("IRON_HORSE_ARMOR");
    public static final /* enum */ XMaterial LEATHER_LEGGINGS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LECTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LEVER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHTNING_ROD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_BLUE_BANNER = new XMaterial(12, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial LIGHT_BLUE_BED = new XMaterial(XMaterial.supports(12) ? 3 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial LIGHT_BLUE_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_BLUE_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_BLUE_CARPET = new XMaterial(3, "CARPET");
    public static final /* enum */ XMaterial LIGHT_BLUE_CONCRETE = new XMaterial(3, "CONCRETE");
    public static final /* enum */ XMaterial LIGHT_BLUE_CONCRETE_POWDER = new XMaterial(3, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial LIGHT_BLUE_DYE = new XMaterial(12, "INK_SACK");
    public static final /* enum */ XMaterial LIGHT_BLUE_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_BLUE_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_BLUE_STAINED_GLASS = new XMaterial(3, "STAINED_GLASS");
    public static final /* enum */ XMaterial LIGHT_BLUE_STAINED_GLASS_PANE = new XMaterial(3, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial LIGHT_BLUE_TERRACOTTA = new XMaterial(3, "STAINED_CLAY");
    public static final /* enum */ XMaterial LIGHT_BLUE_WALL_BANNER = new XMaterial(12, "WALL_BANNER", "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial LIGHT_BLUE_WOOL = new XMaterial(3, "WOOL");
    public static final /* enum */ XMaterial LIGHT_GRAY_BANNER = new XMaterial(7, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial LIGHT_GRAY_BED = new XMaterial(XMaterial.supports(12) ? 8 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial LIGHT_GRAY_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_GRAY_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIGHT_GRAY_CARPET = new XMaterial(8, "CARPET");
    public static final /* enum */ XMaterial LIGHT_GRAY_CONCRETE = new XMaterial(8, "CONCRETE");
    public static final /* enum */ XMaterial LIGHT_GRAY_CONCRETE_POWDER = new XMaterial(8, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial LIGHT_GRAY_DYE = new XMaterial(7, "INK_SACK");
    public static final /* enum */ XMaterial LIGHT_GRAY_GLAZED_TERRACOTTA = new XMaterial("SILVER_GLAZED_TERRACOTTA");
    public static final /* enum */ XMaterial LIGHT_GRAY_SHULKER_BOX = new XMaterial("SILVER_SHULKER_BOX");
    public static final /* enum */ XMaterial LIGHT_GRAY_STAINED_GLASS = new XMaterial(8, "STAINED_GLASS");
    public static final /* enum */ XMaterial LIGHT_GRAY_STAINED_GLASS_PANE = new XMaterial(8, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial LIGHT_GRAY_TERRACOTTA = new XMaterial(8, "STAINED_CLAY");
    public static final /* enum */ XMaterial LIGHT_GRAY_WALL_BANNER = new XMaterial(7, "WALL_BANNER");
    public static final /* enum */ XMaterial LIGHT_GRAY_WOOL = new XMaterial(8, "WOOL");
    public static final /* enum */ XMaterial LIGHT_WEIGHTED_PRESSURE_PLATE = new XMaterial("GOLD_PLATE");
    public static final /* enum */ XMaterial LILAC = new XMaterial(1, "DOUBLE_PLANT");
    public static final /* enum */ XMaterial LILY_OF_THE_VALLEY = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LILY_PAD = new XMaterial("WATER_LILY");
    public static final /* enum */ XMaterial LIME_BANNER = new XMaterial(10, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial LIME_BED = new XMaterial(XMaterial.supports(12) ? 5 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial LIME_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIME_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIME_CARPET = new XMaterial(5, "CARPET");
    public static final /* enum */ XMaterial LIME_CONCRETE = new XMaterial(5, "CONCRETE");
    public static final /* enum */ XMaterial LIME_CONCRETE_POWDER = new XMaterial(5, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial LIME_DYE = new XMaterial(10, "INK_SACK");
    public static final /* enum */ XMaterial LIME_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIME_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LIME_STAINED_GLASS = new XMaterial(5, "STAINED_GLASS");
    public static final /* enum */ XMaterial LIME_STAINED_GLASS_PANE = new XMaterial(5, "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial LIME_TERRACOTTA = new XMaterial(5, "STAINED_CLAY");
    public static final /* enum */ XMaterial LIME_WALL_BANNER = new XMaterial(10, "WALL_BANNER");
    public static final /* enum */ XMaterial LIME_WOOL = new XMaterial(5, "WOOL");
    public static final /* enum */ XMaterial LINGERING_POTION = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LLAMA_SPAWN_EGG = new XMaterial(103, "MONSTER_EGG");
    public static final /* enum */ XMaterial LODESTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial LOOM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAGENTA_BANNER = new XMaterial(13, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial MAGENTA_BED = new XMaterial(XMaterial.supports(12) ? 2 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial MAGENTA_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAGENTA_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAGENTA_CARPET = new XMaterial(2, "CARPET");
    public static final /* enum */ XMaterial MAGENTA_CONCRETE = new XMaterial(2, "CONCRETE");
    public static final /* enum */ XMaterial MAGENTA_CONCRETE_POWDER = new XMaterial(2, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial MAGENTA_DYE = new XMaterial(13, "INK_SACK");
    public static final /* enum */ XMaterial MAGENTA_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAGENTA_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAGENTA_STAINED_GLASS = new XMaterial(2, "STAINED_GLASS");
    public static final /* enum */ XMaterial MAGENTA_STAINED_GLASS_PANE = new XMaterial(2, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial MAGENTA_TERRACOTTA = new XMaterial(2, "STAINED_CLAY");
    public static final /* enum */ XMaterial MAGENTA_WALL_BANNER = new XMaterial(13, "WALL_BANNER");
    public static final /* enum */ XMaterial MAGENTA_WOOL = new XMaterial(2, "WOOL");
    public static final /* enum */ XMaterial MAGMA_BLOCK = new XMaterial("MAGMA");
    public static final /* enum */ XMaterial MAGMA_CREAM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAGMA_CUBE_SPAWN_EGG = new XMaterial(62, "MONSTER_EGG");
    public static final /* enum */ XMaterial MANGROVE_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_DOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_LEAVES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_PLANKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_PRESSURE_PLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_PROPAGULE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_TRAPDOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_WALL_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MANGROVE_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MAP = new XMaterial("EMPTY_MAP");
    public static final /* enum */ XMaterial MEDIUM_AMETHYST_BUD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MELON = new XMaterial("MELON_BLOCK");
    public static final /* enum */ XMaterial MELON_SEEDS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MELON_SLICE = new XMaterial("MELON");
    public static final /* enum */ XMaterial MELON_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MILK_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MINECART = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MINER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOJANG_BANNER_PATTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOOSHROOM_SPAWN_EGG = new XMaterial(96, "MONSTER_EGG");
    public static final /* enum */ XMaterial MOSSY_COBBLESTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSSY_COBBLESTONE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSSY_COBBLESTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSSY_COBBLESTONE_WALL = new XMaterial(1, "COBBLE_WALL", "COBBLESTONE_WALL");
    public static final /* enum */ XMaterial MOSSY_STONE_BRICKS = new XMaterial(1, "SMOOTH_BRICK");
    public static final /* enum */ XMaterial MOSSY_STONE_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSSY_STONE_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSSY_STONE_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSS_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOSS_CARPET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOURNER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MOVING_PISTON = new XMaterial("PISTON_MOVING_PIECE");
    public static final /* enum */ XMaterial MUD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUDDY_MANGROVE_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUD_BRICKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUD_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUD_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUD_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MULE_SPAWN_EGG = new XMaterial(32, "MONSTER_EGG");
    public static final /* enum */ XMaterial MUSHROOM_STEM = new XMaterial("BROWN_MUSHROOM");
    public static final /* enum */ XMaterial MUSHROOM_STEW = new XMaterial("MUSHROOM_SOUP");
    public static final /* enum */ XMaterial MUSIC_DISC_11 = new XMaterial("RECORD_11");
    public static final /* enum */ XMaterial MUSIC_DISC_13 = new XMaterial("GOLD_RECORD");
    public static final /* enum */ XMaterial MUSIC_DISC_5 = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUSIC_DISC_BLOCKS = new XMaterial("RECORD_3");
    public static final /* enum */ XMaterial MUSIC_DISC_CAT = new XMaterial("GREEN_RECORD");
    public static final /* enum */ XMaterial MUSIC_DISC_CHIRP = new XMaterial("RECORD_4");
    public static final /* enum */ XMaterial MUSIC_DISC_FAR = new XMaterial("RECORD_5");
    public static final /* enum */ XMaterial MUSIC_DISC_MALL = new XMaterial("RECORD_6");
    public static final /* enum */ XMaterial MUSIC_DISC_MELLOHI = new XMaterial("RECORD_7");
    public static final /* enum */ XMaterial MUSIC_DISC_OTHERSIDE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUSIC_DISC_PIGSTEP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUSIC_DISC_RELIC = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MUSIC_DISC_STAL = new XMaterial("RECORD_8");
    public static final /* enum */ XMaterial MUSIC_DISC_STRAD = new XMaterial("RECORD_9");
    public static final /* enum */ XMaterial MUSIC_DISC_WAIT = new XMaterial("RECORD_12");
    public static final /* enum */ XMaterial MUSIC_DISC_WARD = new XMaterial("RECORD_10");
    public static final /* enum */ XMaterial MUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial MYCELIUM = new XMaterial("MYCEL");
    public static final /* enum */ XMaterial NAME_TAG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NAUTILUS_SHELL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_AXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_BOOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_CHESTPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_HELMET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_HOE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_INGOT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_LEGGINGS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_PICKAXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_SCRAP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_SHOVEL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_SWORD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERITE_UPGRADE_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHERRACK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHER_BRICK = new XMaterial("NETHER_BRICK_ITEM");
    public static final /* enum */ XMaterial NETHER_BRICKS = new XMaterial("NETHER_BRICK");
    public static final /* enum */ XMaterial NETHER_BRICK_FENCE = new XMaterial("NETHER_FENCE");
    public static final /* enum */ XMaterial NETHER_BRICK_SLAB = new XMaterial(6, "STEP");
    public static final /* enum */ XMaterial NETHER_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHER_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHER_GOLD_ORE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHER_PORTAL = new XMaterial("PORTAL");
    public static final /* enum */ XMaterial NETHER_QUARTZ_ORE = new XMaterial("QUARTZ_ORE");
    public static final /* enum */ XMaterial NETHER_SPROUTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHER_STAR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NETHER_WART = new XMaterial("NETHER_WARTS", "NETHER_STALK");
    public static final /* enum */ XMaterial NETHER_WART_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial NOTE_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OAK_BOAT = new XMaterial("BOAT");
    public static final /* enum */ XMaterial OAK_BUTTON = new XMaterial("WOOD_BUTTON");
    public static final /* enum */ XMaterial OAK_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OAK_DOOR = new XMaterial("WOODEN_DOOR", "WOOD_DOOR");
    public static final /* enum */ XMaterial OAK_FENCE = new XMaterial("FENCE");
    public static final /* enum */ XMaterial OAK_FENCE_GATE = new XMaterial("FENCE_GATE");
    public static final /* enum */ XMaterial OAK_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OAK_LEAVES = new XMaterial("LEAVES");
    public static final /* enum */ XMaterial OAK_LOG = new XMaterial("LOG");
    public static final /* enum */ XMaterial OAK_PLANKS = new XMaterial("WOOD");
    public static final /* enum */ XMaterial OAK_PRESSURE_PLATE = new XMaterial("WOOD_PLATE");
    public static final /* enum */ XMaterial OAK_SAPLING = new XMaterial("SAPLING");
    public static final /* enum */ XMaterial OAK_SIGN = new XMaterial("SIGN_POST", "SIGN");
    public static final /* enum */ XMaterial OAK_SLAB = new XMaterial("WOOD_DOUBLE_STEP", "WOOD_STEP", "WOODEN_SLAB");
    public static final /* enum */ XMaterial OAK_STAIRS = new XMaterial("WOOD_STAIRS");
    public static final /* enum */ XMaterial OAK_TRAPDOOR = new XMaterial("TRAP_DOOR");
    public static final /* enum */ XMaterial OAK_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OAK_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial OAK_WOOD = new XMaterial("LOG");
    public static final /* enum */ XMaterial OBSERVER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OBSIDIAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OCELOT_SPAWN_EGG = new XMaterial(98, "MONSTER_EGG");
    public static final /* enum */ XMaterial OCHRE_FROGLIGHT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ORANGE_BANNER = new XMaterial(14, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial ORANGE_BED = new XMaterial(XMaterial.supports(12) ? 1 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial ORANGE_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ORANGE_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ORANGE_CARPET = new XMaterial(1, "CARPET");
    public static final /* enum */ XMaterial ORANGE_CONCRETE = new XMaterial(1, "CONCRETE");
    public static final /* enum */ XMaterial ORANGE_CONCRETE_POWDER = new XMaterial(1, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial ORANGE_DYE = new XMaterial(14, "INK_SACK");
    public static final /* enum */ XMaterial ORANGE_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ORANGE_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ORANGE_STAINED_GLASS = new XMaterial(1, "STAINED_GLASS");
    public static final /* enum */ XMaterial ORANGE_STAINED_GLASS_PANE = new XMaterial(1, "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial ORANGE_TERRACOTTA = new XMaterial(1, "STAINED_CLAY");
    public static final /* enum */ XMaterial ORANGE_TULIP = new XMaterial(5, "RED_ROSE");
    public static final /* enum */ XMaterial ORANGE_WALL_BANNER = new XMaterial(14, "WALL_BANNER");
    public static final /* enum */ XMaterial ORANGE_WOOL = new XMaterial(1, "WOOL");
    public static final /* enum */ XMaterial OXEYE_DAISY = new XMaterial(8, "RED_ROSE");
    public static final /* enum */ XMaterial OXIDIZED_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OXIDIZED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OXIDIZED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial OXIDIZED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PACKED_ICE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PACKED_MUD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PAINTING = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PANDA_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PAPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PARROT_SPAWN_EGG = new XMaterial(105, "MONSTER_EGG");
    public static final /* enum */ XMaterial PEARLESCENT_FROGLIGHT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PEONY = new XMaterial(5, "DOUBLE_PLANT");
    public static final /* enum */ XMaterial PETRIFIED_OAK_SLAB = new XMaterial("WOOD_STEP");
    public static final /* enum */ XMaterial PHANTOM_MEMBRANE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PHANTOM_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PIGLIN_BANNER_PATTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PIGLIN_BRUTE_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PIGLIN_HEAD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PIGLIN_SPAWN_EGG = new XMaterial(57, "MONSTER_EGG");
    public static final /* enum */ XMaterial PIGLIN_WALL_HEAD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PIG_SPAWN_EGG = new XMaterial(90, "MONSTER_EGG");
    public static final /* enum */ XMaterial PILLAGER_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PINK_BANNER = new XMaterial(9, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial PINK_BED = new XMaterial(XMaterial.supports(12) ? 6 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial PINK_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PINK_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PINK_CARPET = new XMaterial(6, "CARPET");
    public static final /* enum */ XMaterial PINK_CONCRETE = new XMaterial(6, "CONCRETE");
    public static final /* enum */ XMaterial PINK_CONCRETE_POWDER = new XMaterial(6, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial PINK_DYE = new XMaterial(9, "INK_SACK");
    public static final /* enum */ XMaterial PINK_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PINK_PETALS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PINK_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PINK_STAINED_GLASS = new XMaterial(6, "STAINED_GLASS");
    public static final /* enum */ XMaterial PINK_STAINED_GLASS_PANE = new XMaterial(6, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial PINK_TERRACOTTA = new XMaterial(6, "STAINED_CLAY");
    public static final /* enum */ XMaterial PINK_TULIP = new XMaterial(7, "RED_ROSE");
    public static final /* enum */ XMaterial PINK_WALL_BANNER = new XMaterial(9, "WALL_BANNER");
    public static final /* enum */ XMaterial PINK_WOOL = new XMaterial(6, "WOOL");
    public static final /* enum */ XMaterial PISTON = new XMaterial("PISTON_BASE");
    public static final /* enum */ XMaterial PISTON_HEAD = new XMaterial("PISTON_EXTENSION");
    public static final /* enum */ XMaterial PITCHER_CROP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PITCHER_PLANT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PITCHER_POD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PLAYER_HEAD = new XMaterial(3, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial PLAYER_WALL_HEAD = new XMaterial(3, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial PLENTY_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PODZOL = new XMaterial(2, "DIRT");
    public static final /* enum */ XMaterial POINTED_DRIPSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POISONOUS_POTATO = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLAR_BEAR_SPAWN_EGG = new XMaterial(102, "MONSTER_EGG");
    public static final /* enum */ XMaterial POLISHED_ANDESITE = new XMaterial(6, "STONE");
    public static final /* enum */ XMaterial POLISHED_ANDESITE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_ANDESITE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BASALT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_BRICKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_PRESSURE_PLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_BLACKSTONE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_DEEPSLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_DEEPSLATE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_DEEPSLATE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_DEEPSLATE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_DIORITE = new XMaterial(4, "STONE");
    public static final /* enum */ XMaterial POLISHED_DIORITE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_DIORITE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_GRANITE = new XMaterial(2, "STONE");
    public static final /* enum */ XMaterial POLISHED_GRANITE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POLISHED_GRANITE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POPPED_CHORUS_FRUIT = new XMaterial("CHORUS_FRUIT_POPPED");
    public static final /* enum */ XMaterial POPPY = new XMaterial("RED_ROSE");
    public static final /* enum */ XMaterial PORKCHOP = new XMaterial("PORK");
    public static final /* enum */ XMaterial POTATO = new XMaterial("POTATO_ITEM");
    public static final /* enum */ XMaterial POTATOES = new XMaterial("POTATO");
    public static final /* enum */ XMaterial POTION = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_ACACIA_SAPLING = new XMaterial(4, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_ALLIUM = new XMaterial(2, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_AZALEA_BUSH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_AZURE_BLUET = new XMaterial(3, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_BAMBOO = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_BIRCH_SAPLING = new XMaterial(2, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_BLUE_ORCHID = new XMaterial(1, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_BROWN_MUSHROOM = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_CACTUS = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_CHERRY_SAPLING = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_CORNFLOWER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_CRIMSON_FUNGUS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_CRIMSON_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_DANDELION = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_DARK_OAK_SAPLING = new XMaterial(5, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_DEAD_BUSH = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_FERN = new XMaterial(2, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_FLOWERING_AZALEA_BUSH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_JUNGLE_SAPLING = new XMaterial(3, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_LILY_OF_THE_VALLEY = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_MANGROVE_PROPAGULE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_OAK_SAPLING = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_ORANGE_TULIP = new XMaterial(5, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_OXEYE_DAISY = new XMaterial(8, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_PINK_TULIP = new XMaterial(7, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_POPPY = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_RED_MUSHROOM = new XMaterial("FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_RED_TULIP = new XMaterial(4, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_SPRUCE_SAPLING = new XMaterial(1, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_TORCHFLOWER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_WARPED_FUNGUS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_WARPED_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTED_WHITE_TULIP = new XMaterial(6, "FLOWER_POT");
    public static final /* enum */ XMaterial POTTED_WITHER_ROSE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTERY_SHARD_ARCHER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTERY_SHARD_ARMS_UP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTERY_SHARD_PRIZE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POTTERY_SHARD_SKULL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POWDER_SNOW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POWDER_SNOW_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POWDER_SNOW_CAULDRON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial POWERED_RAIL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_BRICKS = new XMaterial(1, "PRISMARINE");
    public static final /* enum */ XMaterial PRISMARINE_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_CRYSTALS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_SHARD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRISMARINE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PRIZE_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PUFFERFISH = new XMaterial(3, "RAW_FISH");
    public static final /* enum */ XMaterial PUFFERFISH_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PUFFERFISH_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PUMPKIN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PUMPKIN_PIE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PUMPKIN_SEEDS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PUMPKIN_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPLE_BANNER = new XMaterial(5, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial PURPLE_BED = new XMaterial(XMaterial.supports(12) ? 10 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial PURPLE_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPLE_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPLE_CARPET = new XMaterial(10, "CARPET");
    public static final /* enum */ XMaterial PURPLE_CONCRETE = new XMaterial(10, "CONCRETE");
    public static final /* enum */ XMaterial PURPLE_CONCRETE_POWDER = new XMaterial(10, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial PURPLE_DYE = new XMaterial(5, "INK_SACK");
    public static final /* enum */ XMaterial PURPLE_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPLE_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPLE_STAINED_GLASS = new XMaterial(10, "STAINED_GLASS");
    public static final /* enum */ XMaterial PURPLE_STAINED_GLASS_PANE = new XMaterial(10, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial PURPLE_TERRACOTTA = new XMaterial(10, "STAINED_CLAY");
    public static final /* enum */ XMaterial PURPLE_WALL_BANNER = new XMaterial(5, "WALL_BANNER");
    public static final /* enum */ XMaterial PURPLE_WOOL = new XMaterial(10, "WOOL");
    public static final /* enum */ XMaterial PURPUR_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPUR_PILLAR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial PURPUR_SLAB = new XMaterial("PURPUR_DOUBLE_SLAB");
    public static final /* enum */ XMaterial PURPUR_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial QUARTZ = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial QUARTZ_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial QUARTZ_BRICKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial QUARTZ_PILLAR = new XMaterial(2, "QUARTZ_BLOCK");
    public static final /* enum */ XMaterial QUARTZ_SLAB = new XMaterial(7, "STEP");
    public static final /* enum */ XMaterial QUARTZ_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RABBIT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RABBIT_FOOT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RABBIT_HIDE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RABBIT_SPAWN_EGG = new XMaterial(101, "MONSTER_EGG");
    public static final /* enum */ XMaterial RABBIT_STEW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAIL = new XMaterial("RAILS");
    public static final /* enum */ XMaterial RAISER_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAVAGER_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAW_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAW_COPPER_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAW_GOLD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAW_GOLD_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAW_IRON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RAW_IRON_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RECOVERY_COMPASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial REDSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial REDSTONE_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial REDSTONE_LAMP = new XMaterial("REDSTONE_LAMP_ON", "REDSTONE_LAMP_OFF");
    public static final /* enum */ XMaterial REDSTONE_ORE = new XMaterial("GLOWING_REDSTONE_ORE");
    public static final /* enum */ XMaterial REDSTONE_TORCH = new XMaterial("REDSTONE_TORCH_OFF", "REDSTONE_TORCH_ON");
    public static final /* enum */ XMaterial REDSTONE_WALL_TORCH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial REDSTONE_WIRE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_BANNER = new XMaterial(1, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial RED_BED = new XMaterial(XMaterial.supports(12) ? 14 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial RED_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_CARPET = new XMaterial(14, "CARPET");
    public static final /* enum */ XMaterial RED_CONCRETE = new XMaterial(14, "CONCRETE");
    public static final /* enum */ XMaterial RED_CONCRETE_POWDER = new XMaterial(14, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial RED_DYE = new XMaterial(1, "INK_SACK", "ROSE_RED");
    public static final /* enum */ XMaterial RED_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_MUSHROOM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_MUSHROOM_BLOCK = new XMaterial("RED_MUSHROOM", "HUGE_MUSHROOM_2");
    public static final /* enum */ XMaterial RED_NETHER_BRICKS = new XMaterial("RED_NETHER_BRICK");
    public static final /* enum */ XMaterial RED_NETHER_BRICK_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_NETHER_BRICK_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_NETHER_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_SAND = new XMaterial(1, "SAND");
    public static final /* enum */ XMaterial RED_SANDSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_SANDSTONE_SLAB = new XMaterial("DOUBLE_STONE_SLAB2", "STONE_SLAB2");
    public static final /* enum */ XMaterial RED_SANDSTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_SANDSTONE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RED_STAINED_GLASS = new XMaterial(14, "STAINED_GLASS");
    public static final /* enum */ XMaterial RED_STAINED_GLASS_PANE = new XMaterial(14, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial RED_TERRACOTTA = new XMaterial(14, "STAINED_CLAY");
    public static final /* enum */ XMaterial RED_TULIP = new XMaterial(4, "RED_ROSE");
    public static final /* enum */ XMaterial RED_WALL_BANNER = new XMaterial(1, "WALL_BANNER");
    public static final /* enum */ XMaterial RED_WOOL = new XMaterial(14, "WOOL");
    public static final /* enum */ XMaterial REINFORCED_DEEPSLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial REPEATER = new XMaterial("DIODE_BLOCK_ON", "DIODE_BLOCK_OFF", "DIODE");
    public static final /* enum */ XMaterial REPEATING_COMMAND_BLOCK = new XMaterial("COMMAND", "COMMAND_REPEATING");
    public static final /* enum */ XMaterial RESPAWN_ANCHOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial RIB_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ROOTED_DIRT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ROSE_BUSH = new XMaterial(4, "DOUBLE_PLANT");
    public static final /* enum */ XMaterial ROTTEN_FLESH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SADDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SALMON = new XMaterial(1, "RAW_FISH");
    public static final /* enum */ XMaterial SALMON_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SALMON_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SAND = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SANDSTONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SANDSTONE_SLAB = new XMaterial(1, "DOUBLE_STEP", "STEP", "STONE_SLAB");
    public static final /* enum */ XMaterial SANDSTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SANDSTONE_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCAFFOLDING = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCULK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCULK_CATALYST = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCULK_SENSOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCULK_SHRIEKER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCULK_VEIN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SCUTE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SEAGRASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SEA_LANTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SEA_PICKLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHEAF_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHEARS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHEEP_SPAWN_EGG = new XMaterial(91, "MONSTER_EGG");
    public static final /* enum */ XMaterial SHELTER_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHIELD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHROOMLIGHT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHULKER_BOX = new XMaterial("PURPLE_SHULKER_BOX");
    public static final /* enum */ XMaterial SHULKER_SHELL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SHULKER_SPAWN_EGG = new XMaterial(69, "MONSTER_EGG");
    public static final /* enum */ XMaterial SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SILVERFISH_SPAWN_EGG = new XMaterial(60, "MONSTER_EGG");
    public static final /* enum */ XMaterial SKELETON_HORSE_SPAWN_EGG = new XMaterial(28, "MONSTER_EGG");
    public static final /* enum */ XMaterial SKELETON_SKULL = new XMaterial("SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial SKELETON_SPAWN_EGG = new XMaterial(51, "MONSTER_EGG");
    public static final /* enum */ XMaterial SKELETON_WALL_SKULL = new XMaterial("SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial SKULL_BANNER_PATTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SKULL_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SLIME_BALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SLIME_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SLIME_SPAWN_EGG = new XMaterial(55, "MONSTER_EGG");
    public static final /* enum */ XMaterial SMALL_AMETHYST_BUD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMALL_DRIPLEAF = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMITHING_TABLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOKER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_BASALT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_QUARTZ = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_QUARTZ_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_QUARTZ_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_RED_SANDSTONE = new XMaterial(2, "RED_SANDSTONE");
    public static final /* enum */ XMaterial SMOOTH_RED_SANDSTONE_SLAB = new XMaterial("STONE_SLAB2");
    public static final /* enum */ XMaterial SMOOTH_RED_SANDSTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_SANDSTONE = new XMaterial(2, "SANDSTONE");
    public static final /* enum */ XMaterial SMOOTH_SANDSTONE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_SANDSTONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_STONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SMOOTH_STONE_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNIFFER_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNIFFER_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNORT_POTTERY_SHERD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNOW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNOWBALL = new XMaterial("SNOW_BALL");
    public static final /* enum */ XMaterial SNOW_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SNOW_GOLEM_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_CAMPFIRE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_FIRE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_LANTERN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_SAND = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_SOIL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_TORCH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SOUL_WALL_TORCH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPAWNER = new XMaterial("MOB_SPAWNER");
    public static final /* enum */ XMaterial SPECTRAL_ARROW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPIDER_EYE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPIDER_SPAWN_EGG = new XMaterial(52, "MONSTER_EGG");
    public static final /* enum */ XMaterial SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPLASH_POTION = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPONGE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPORE_BLOSSOM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPRUCE_BOAT = new XMaterial("BOAT_SPRUCE");
    public static final /* enum */ XMaterial SPRUCE_BUTTON = new XMaterial("WOOD_BUTTON");
    public static final /* enum */ XMaterial SPRUCE_CHEST_BOAT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPRUCE_DOOR = new XMaterial("SPRUCE_DOOR", "SPRUCE_DOOR_ITEM");
    public static final /* enum */ XMaterial SPRUCE_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPRUCE_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPRUCE_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPRUCE_LEAVES = new XMaterial(1, "LEAVES");
    public static final /* enum */ XMaterial SPRUCE_LOG = new XMaterial(1, "LOG");
    public static final /* enum */ XMaterial SPRUCE_PLANKS = new XMaterial(1, "WOOD");
    public static final /* enum */ XMaterial SPRUCE_PRESSURE_PLATE = new XMaterial("WOOD_PLATE");
    public static final /* enum */ XMaterial SPRUCE_SAPLING = new XMaterial(1, "SAPLING");
    public static final /* enum */ XMaterial SPRUCE_SIGN = new XMaterial("SIGN_POST", "SIGN");
    public static final /* enum */ XMaterial SPRUCE_SLAB = new XMaterial(1, "WOOD_DOUBLE_STEP", "WOOD_STEP", "WOODEN_SLAB");
    public static final /* enum */ XMaterial SPRUCE_STAIRS = new XMaterial("SPRUCE_WOOD_STAIRS");
    public static final /* enum */ XMaterial SPRUCE_TRAPDOOR = new XMaterial("TRAP_DOOR");
    public static final /* enum */ XMaterial SPRUCE_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SPRUCE_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial SPRUCE_WOOD = new XMaterial(1, "LOG");
    public static final /* enum */ XMaterial SPYGLASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SQUID_SPAWN_EGG = new XMaterial(94, "MONSTER_EGG");
    public static final /* enum */ XMaterial STICK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STICKY_PISTON = new XMaterial("PISTON_BASE", "PISTON_STICKY_BASE");
    public static final /* enum */ XMaterial STONE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONECUTTER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_AXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_BRICKS = new XMaterial("SMOOTH_BRICK");
    public static final /* enum */ XMaterial STONE_BRICK_SLAB = new XMaterial(5, "DOUBLE_STEP", "STEP", "STONE_SLAB");
    public static final /* enum */ XMaterial STONE_BRICK_STAIRS = new XMaterial("SMOOTH_STAIRS");
    public static final /* enum */ XMaterial STONE_BRICK_WALL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_HOE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_PICKAXE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_PRESSURE_PLATE = new XMaterial("STONE_PLATE");
    public static final /* enum */ XMaterial STONE_SHOVEL = new XMaterial("STONE_SPADE");
    public static final /* enum */ XMaterial STONE_SLAB = new XMaterial("DOUBLE_STEP", "STEP");
    public static final /* enum */ XMaterial STONE_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STONE_SWORD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRAY_SPAWN_EGG = new XMaterial(6, "MONSTER_EGG");
    public static final /* enum */ XMaterial STRIDER_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRING = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_ACACIA_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_ACACIA_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_BAMBOO_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_BIRCH_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_BIRCH_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_CHERRY_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_CHERRY_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_CRIMSON_HYPHAE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_CRIMSON_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_DARK_OAK_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_DARK_OAK_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_JUNGLE_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_JUNGLE_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_MANGROVE_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_MANGROVE_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_OAK_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_OAK_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_SPRUCE_LOG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_SPRUCE_WOOD = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_WARPED_HYPHAE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRIPPED_WARPED_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRUCTURE_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial STRUCTURE_VOID = new XMaterial(10, "BARRIER");
    public static final /* enum */ XMaterial SUGAR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SUGAR_CANE = new XMaterial("SUGAR_CANE_BLOCK");
    public static final /* enum */ XMaterial SUNFLOWER = new XMaterial("DOUBLE_PLANT");
    public static final /* enum */ XMaterial SUSPICIOUS_GRAVEL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SUSPICIOUS_SAND = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SUSPICIOUS_STEW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SWEET_BERRIES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial SWEET_BERRY_BUSH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TADPOLE_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TADPOLE_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TALL_GRASS = new XMaterial(2, "DOUBLE_PLANT");
    public static final /* enum */ XMaterial TALL_SEAGRASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TARGET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TERRACOTTA = new XMaterial("HARD_CLAY");
    public static final /* enum */ XMaterial TIDE_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TINTED_GLASS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TIPPED_ARROW = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TNT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TNT_MINECART = new XMaterial("EXPLOSIVE_MINECART");
    public static final /* enum */ XMaterial TORCH = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TORCHFLOWER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TORCHFLOWER_CROP = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TORCHFLOWER_SEEDS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TOTEM_OF_UNDYING = new XMaterial("TOTEM");
    public static final /* enum */ XMaterial TRADER_LLAMA_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TRAPPED_CHEST = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TRIDENT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TRIPWIRE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TRIPWIRE_HOOK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TROPICAL_FISH = new XMaterial(2, "RAW_FISH");
    public static final /* enum */ XMaterial TROPICAL_FISH_BUCKET = new XMaterial("BUCKET", "WATER_BUCKET");
    public static final /* enum */ XMaterial TROPICAL_FISH_SPAWN_EGG = new XMaterial("MONSTER_EGG");
    public static final /* enum */ XMaterial TUBE_CORAL = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TUBE_CORAL_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TUBE_CORAL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TUBE_CORAL_WALL_FAN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TUFF = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TURTLE_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TURTLE_HELMET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TURTLE_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TWISTING_VINES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial TWISTING_VINES_PLANT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial VERDANT_FROGLIGHT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial VEX_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial VEX_SPAWN_EGG = new XMaterial(35, "MONSTER_EGG");
    public static final /* enum */ XMaterial VILLAGER_SPAWN_EGG = new XMaterial(120, "MONSTER_EGG");
    public static final /* enum */ XMaterial VINDICATOR_SPAWN_EGG = new XMaterial(36, "MONSTER_EGG");
    public static final /* enum */ XMaterial VINE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial VOID_AIR = new XMaterial("AIR");
    public static final /* enum */ XMaterial WALL_TORCH = new XMaterial("TORCH");
    public static final /* enum */ XMaterial WANDERING_TRADER_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARDEN_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARD_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_BUTTON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_DOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_FENCE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_FENCE_GATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_FUNGUS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_FUNGUS_ON_A_STICK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_HYPHAE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_NYLIUM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_PLANKS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_PRESSURE_PLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_ROOTS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_SIGN = new XMaterial("SIGN_POST");
    public static final /* enum */ XMaterial WARPED_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_STEM = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_TRAPDOOR = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_WALL_HANGING_SIGN = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WARPED_WALL_SIGN = new XMaterial("WALL_SIGN");
    public static final /* enum */ XMaterial WARPED_WART_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WATER = new XMaterial("STATIONARY_WATER");
    public static final /* enum */ XMaterial WATER_BUCKET = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WATER_CAULDRON = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_COPPER_BLOCK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_EXPOSED_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_EXPOSED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_EXPOSED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_EXPOSED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_OXIDIZED_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_OXIDIZED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_OXIDIZED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_OXIDIZED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_WEATHERED_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_WEATHERED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_WEATHERED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAXED_WEATHERED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WEATHERED_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WEATHERED_CUT_COPPER = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WEATHERED_CUT_COPPER_SLAB = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WEATHERED_CUT_COPPER_STAIRS = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WEEPING_VINES = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WEEPING_VINES_PLANT = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WET_SPONGE = new XMaterial(1, "SPONGE");
    public static final /* enum */ XMaterial WHEAT = new XMaterial("CROPS");
    public static final /* enum */ XMaterial WHEAT_SEEDS = new XMaterial("SEEDS");
    public static final /* enum */ XMaterial WHITE_BANNER = new XMaterial(15, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial WHITE_BED = new XMaterial("BED_BLOCK", "BED");
    public static final /* enum */ XMaterial WHITE_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WHITE_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WHITE_CARPET = new XMaterial("CARPET");
    public static final /* enum */ XMaterial WHITE_CONCRETE = new XMaterial("CONCRETE");
    public static final /* enum */ XMaterial WHITE_CONCRETE_POWDER = new XMaterial("CONCRETE_POWDER");
    public static final /* enum */ XMaterial WHITE_DYE = new XMaterial(15, "INK_SACK", "BONE_MEAL");
    public static final /* enum */ XMaterial WHITE_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WHITE_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WHITE_STAINED_GLASS = new XMaterial("STAINED_GLASS");
    public static final /* enum */ XMaterial WHITE_STAINED_GLASS_PANE = new XMaterial("THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial WHITE_TERRACOTTA = new XMaterial("STAINED_CLAY");
    public static final /* enum */ XMaterial WHITE_TULIP = new XMaterial(6, "RED_ROSE");
    public static final /* enum */ XMaterial WHITE_WALL_BANNER = new XMaterial(15, "WALL_BANNER");
    public static final /* enum */ XMaterial WHITE_WOOL = new XMaterial("WOOL");
    public static final /* enum */ XMaterial WILD_ARMOR_TRIM_SMITHING_TEMPLATE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WITCH_SPAWN_EGG = new XMaterial(66, "MONSTER_EGG");
    public static final /* enum */ XMaterial WITHER_ROSE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WITHER_SKELETON_SKULL = new XMaterial(1, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial WITHER_SKELETON_SPAWN_EGG = new XMaterial(5, "MONSTER_EGG");
    public static final /* enum */ XMaterial WITHER_SKELETON_WALL_SKULL = new XMaterial(1, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial WITHER_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial WOLF_SPAWN_EGG = new XMaterial(95, "MONSTER_EGG");
    public static final /* enum */ XMaterial WOODEN_AXE = new XMaterial("WOOD_AXE");
    public static final /* enum */ XMaterial WOODEN_HOE = new XMaterial("WOOD_HOE");
    public static final /* enum */ XMaterial WOODEN_PICKAXE = new XMaterial("WOOD_PICKAXE");
    public static final /* enum */ XMaterial WOODEN_SHOVEL = new XMaterial("WOOD_SPADE");
    public static final /* enum */ XMaterial WOODEN_SWORD = new XMaterial("WOOD_SWORD");
    public static final /* enum */ XMaterial WRITABLE_BOOK = new XMaterial("BOOK_AND_QUILL");
    public static final /* enum */ XMaterial WRITTEN_BOOK = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial YELLOW_BANNER = new XMaterial(11, "STANDING_BANNER", "BANNER");
    public static final /* enum */ XMaterial YELLOW_BED = new XMaterial(XMaterial.supports(12) ? 4 : 0, "BED_BLOCK", "BED");
    public static final /* enum */ XMaterial YELLOW_CANDLE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial YELLOW_CANDLE_CAKE = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial YELLOW_CARPET = new XMaterial(4, "CARPET");
    public static final /* enum */ XMaterial YELLOW_CONCRETE = new XMaterial(4, "CONCRETE");
    public static final /* enum */ XMaterial YELLOW_CONCRETE_POWDER = new XMaterial(4, "CONCRETE_POWDER");
    public static final /* enum */ XMaterial YELLOW_DYE = new XMaterial(11, "INK_SACK", "DANDELION_YELLOW");
    public static final /* enum */ XMaterial YELLOW_GLAZED_TERRACOTTA = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial YELLOW_SHULKER_BOX = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial YELLOW_STAINED_GLASS = new XMaterial(4, "STAINED_GLASS");
    public static final /* enum */ XMaterial YELLOW_STAINED_GLASS_PANE = new XMaterial(4, "THIN_GLASS", "STAINED_GLASS_PANE");
    public static final /* enum */ XMaterial YELLOW_TERRACOTTA = new XMaterial(4, "STAINED_CLAY");
    public static final /* enum */ XMaterial YELLOW_WALL_BANNER = new XMaterial(11, "WALL_BANNER");
    public static final /* enum */ XMaterial YELLOW_WOOL = new XMaterial(4, "WOOL");
    public static final /* enum */ XMaterial ZOGLIN_SPAWN_EGG = new XMaterial(new String[0]);
    public static final /* enum */ XMaterial ZOMBIE_HEAD = new XMaterial(2, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial ZOMBIE_HORSE_SPAWN_EGG = new XMaterial(29, "MONSTER_EGG");
    public static final /* enum */ XMaterial ZOMBIE_SPAWN_EGG = new XMaterial(54, "MONSTER_EGG");
    public static final /* enum */ XMaterial ZOMBIE_VILLAGER_SPAWN_EGG = new XMaterial(27, "MONSTER_EGG");
    public static final /* enum */ XMaterial ZOMBIE_WALL_HEAD = new XMaterial(2, "SKULL", "SKULL_ITEM");
    public static final /* enum */ XMaterial ZOMBIFIED_PIGLIN_SPAWN_EGG = new XMaterial(57, "MONSTER_EGG", "ZOMBIE_PIGMAN_SPAWN_EGG");
    public static final XMaterial[] VALUES;
    private static final Map<String, XMaterial> NAMES;
    private static final Cache<String, XMaterial> NAME_CACHE;
    private static final Cache<String, Pattern> CACHED_REGEX;
    private static final byte MAX_DATA_VALUE = 120;
    private static final byte UNKNOWN_DATA_VALUE = -1;
    private static final short MAX_ID = 2267;
    private static final Set<String> DUPLICATED;
    private final byte data;
    @Nonnull
    private final String[] legacy;
    @Nullable
    private final Material material;
    private static final /* synthetic */ XMaterial[] $VALUES;

    public static XMaterial[] values() {
        return (XMaterial[])$VALUES.clone();
    }

    public static XMaterial valueOf(String string) {
        return Enum.valueOf(XMaterial.class, string);
    }

    private XMaterial(int n2, String ... arrstring) {
        this.data = (byte)n2;
        this.legacy = arrstring;
        Material material = null;
        if (!Data.ISFLAT && this.isDuplicated() || (material = Material.getMaterial((String)this.name())) == null) {
            for (int i = arrstring.length - 1; i >= 0 && (material = Material.getMaterial((String)arrstring[i])) == null; --i) {
            }
        }
        this.material = material;
    }

    private XMaterial(String ... arrstring) {
        this(0, arrstring);
    }

    @Nonnull
    private static Optional<XMaterial> getIfPresent(@Nonnull String string) {
        return Optional.ofNullable(NAMES.get(string));
    }

    public static int getVersion() {
        return Data.VERSION;
    }

    @Nullable
    private static XMaterial requestOldXMaterial(@Nonnull String string, byte by) {
        String string2 = string + by;
        XMaterial xMaterial = (XMaterial)((Object)NAME_CACHE.getIfPresent((Object)string2));
        if (xMaterial != null) {
            return xMaterial;
        }
        for (XMaterial xMaterial2 : VALUES) {
            if (by != -1 && by != xMaterial2.data || !xMaterial2.anyMatchLegacy(string)) continue;
            NAME_CACHE.put((Object)string2, (Object)xMaterial2);
            return xMaterial2;
        }
        return null;
    }

    @Nonnull
    private static Optional<XMaterial> matchXMaterialWithData(@Nonnull String string) {
        int n = string.indexOf(58);
        if (n != -1) {
            String string2 = XMaterial.format(string.substring(0, n));
            try {
                byte by = (byte)Integer.parseInt(string.substring(n + 1).replace(" ", ""));
                return by >= 0 && by < 120 ? XMaterial.matchDefinedXMaterial(string2, by) : XMaterial.matchDefinedXMaterial(string2, (byte)-1);
            }
            catch (NumberFormatException numberFormatException) {
                return XMaterial.matchDefinedXMaterial(string2, (byte)-1);
            }
        }
        return Optional.empty();
    }

    @Nonnull
    public static Optional<XMaterial> matchXMaterial(@Nonnull String string) {
        if (string == null || string.isEmpty()) {
            throw new IllegalArgumentException("Cannot match a material with null or empty material name");
        }
        Optional<XMaterial> optional = XMaterial.matchXMaterialWithData(string);
        return optional.isPresent() ? optional : XMaterial.matchDefinedXMaterial(XMaterial.format(string), (byte)-1);
    }

    @Nonnull
    public static XMaterial matchXMaterial(@Nonnull Material material) {
        Objects.requireNonNull(material, "Cannot match null material");
        return XMaterial.matchDefinedXMaterial(material.name(), (byte)-1).orElseThrow(() -> new IllegalArgumentException("Unsupported material with no data value: " + material.name()));
    }

    @Nonnull
    public static XMaterial matchXMaterial(@Nonnull ItemStack itemStack) {
        ItemMeta itemMeta;
        Objects.requireNonNull(itemStack, "Cannot match null ItemStack");
        Object object = itemStack.getType().name();
        byte by = (byte)(Data.ISFLAT || ((String)object).equals("MAP") || itemStack.getType().getMaxDurability() > 0 ? (short)0 : itemStack.getDurability());
        if (XMaterial.supports(9) && !XMaterial.supports(13) && itemStack.hasItemMeta() && ((String)object).equals("MONSTER_EGG") && (itemMeta = itemStack.getItemMeta()) instanceof SpawnEggMeta) {
            SpawnEggMeta spawnEggMeta = (SpawnEggMeta)itemMeta;
            object = spawnEggMeta.getSpawnedType().name() + "_SPAWN_EGG";
        }
        if (!XMaterial.supports(9) && ((String)object).endsWith("ION")) {
            return Potion.fromItemStack((ItemStack)itemStack).isSplash() ? SPLASH_POTION : POTION;
        }
        if (XMaterial.supports(13) && !XMaterial.supports(14)) {
            if (((String)object).equals("CACTUS_GREEN")) {
                return GREEN_DYE;
            }
            if (((String)object).equals("ROSE_RED")) {
                return RED_DYE;
            }
            if (((String)object).equals("DANDELION_YELLOW")) {
                return YELLOW_DYE;
            }
        }
        if ((itemMeta = XMaterial.matchDefinedXMaterial((String)object, by)).isPresent()) {
            return (XMaterial)((Object)itemMeta.get());
        }
        throw new IllegalArgumentException("Unsupported material from item: " + (String)object + " (" + by + ")");
    }

    @Nonnull
    @Deprecated
    public static Optional<XMaterial> matchXMaterial(int n, byte by) {
        if (n < 0 || n > 2267 || by < 0) {
            return Optional.empty();
        }
        for (XMaterial xMaterial : VALUES) {
            if (xMaterial.data != by || xMaterial.getId() != n) continue;
            return Optional.of(xMaterial);
        }
        return Optional.empty();
    }

    @Nonnull
    protected static Optional<XMaterial> matchDefinedXMaterial(@Nonnull String string, byte by) {
        boolean bl;
        Object object;
        Boolean bl2 = null;
        boolean bl3 = string.equalsIgnoreCase("MAP");
        if ((Data.ISFLAT || !bl3 && by <= 0 && !(bl2 = Boolean.valueOf(XMaterial.isDuplicated(string))).booleanValue()) && (object = XMaterial.getIfPresent(string)).isPresent()) {
            return object;
        }
        object = XMaterial.requestOldXMaterial(string, by);
        if (object == null) {
            return by >= 0 && bl3 ? Optional.of(FILLED_MAP) : Optional.empty();
        }
        boolean bl4 = bl = object == CARROTS || object == POTATOES || object == BRICKS;
        if (!Data.ISFLAT && bl && (bl2 == null ? XMaterial.isDuplicated(string) : bl2 != false)) {
            return XMaterial.getIfPresent(string);
        }
        return Optional.of(object);
    }

    @Nonnull
    protected static String format(@Nonnull String string) {
        int n = string.length();
        char[] arrc = new char[n];
        int n2 = 0;
        boolean bl = false;
        for (int i = 0; i < n; ++i) {
            char c = string.charAt(i);
            if (!(bl || n2 == 0 || c != '-' && c != ' ' && c != '_' || arrc[n2] == '_')) {
                bl = true;
                continue;
            }
            boolean bl2 = false;
            if (!(c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z') && !(bl2 = c >= '0' && c <= '9')) continue;
            if (bl) {
                arrc[n2++] = 95;
                bl = false;
            }
            arrc[n2++] = bl2 ? c : (char)(c & 0x5F);
        }
        return new String(arrc, 0, n2);
    }

    public static boolean supports(int n) {
        return Data.VERSION >= n;
    }

    public String[] getLegacy() {
        return this.legacy;
    }

    public boolean isOneOf(@Nullable Collection<String> collection) {
        if (collection == null || collection.isEmpty()) {
            return false;
        }
        String string = this.name();
        for (String string2 : collection) {
            Optional<XMaterial> optional;
            String string3 = string2.toUpperCase(Locale.ENGLISH);
            if (string3.startsWith("CONTAINS:")) {
                string2 = XMaterial.format(string3.substring(9));
                if (!string.contains(string2)) continue;
                return true;
            }
            if (string3.startsWith("REGEX:")) {
                optional = (Pattern)CACHED_REGEX.getIfPresent((Object)(string2 = string2.substring(6)));
                if (optional == null) {
                    try {
                        optional = Pattern.compile(string2);
                        CACHED_REGEX.put((Object)string2, (Object)optional);
                    }
                    catch (PatternSyntaxException patternSyntaxException) {
                        patternSyntaxException.printStackTrace();
                    }
                }
                if (optional == null || !((Pattern)((Object)optional)).matcher(string).matches()) continue;
                return true;
            }
            optional = XMaterial.matchXMaterial(string2);
            if (!optional.isPresent() || optional.get() != this) continue;
            return true;
        }
        return false;
    }

    @Nonnull
    public ItemStack setType(@Nonnull ItemStack itemStack) {
        Objects.requireNonNull(itemStack, "Cannot set material for null ItemStack");
        Material material = this.parseMaterial();
        Objects.requireNonNull(material, () -> "Unsupported material: " + this.name());
        itemStack.setType(material);
        if (!Data.ISFLAT && material.getMaxDurability() <= 0) {
            itemStack.setDurability((short)this.data);
        }
        return itemStack;
    }

    private boolean anyMatchLegacy(@Nonnull String string) {
        for (int i = this.legacy.length - 1; i >= 0; --i) {
            if (!string.equals(this.legacy[i])) continue;
            return true;
        }
        return false;
    }

    @Nonnull
    public String toString() {
        return Arrays.stream(this.name().split("_")).map(string -> string.charAt(0) + string.substring(1).toLowerCase()).collect(Collectors.joining(" "));
    }

    public int getId() {
        Material material = this.parseMaterial();
        if (material == null) {
            return -1;
        }
        try {
            return material.getId();
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return -1;
        }
    }

    public byte getData() {
        return this.data;
    }

    @Nullable
    public ItemStack parseItem() {
        Material material = this.parseMaterial();
        if (material == null) {
            return null;
        }
        return Data.ISFLAT ? new ItemStack(material) : new ItemStack(material, 1, (short)this.data);
    }

    @Nullable
    public Material parseMaterial() {
        return this.material;
    }

    public boolean isSimilar(@Nonnull ItemStack itemStack) {
        Objects.requireNonNull(itemStack, "Cannot compare with null ItemStack");
        if (itemStack.getType() != this.parseMaterial()) {
            return false;
        }
        return Data.ISFLAT || itemStack.getDurability() == this.data || itemStack.getType().getMaxDurability() > 0;
    }

    public boolean isSupported() {
        return this.material != null;
    }

    @Nullable
    public XMaterial or(@Nullable XMaterial xMaterial) {
        return this.isSupported() ? this : xMaterial;
    }

    private static boolean isDuplicated(@Nonnull String string) {
        return DUPLICATED.contains(string);
    }

    private boolean isDuplicated() {
        switch (this.name()) {
            case "MELON": 
            case "CARROT": 
            case "POTATO": 
            case "GRASS": 
            case "BRICK": 
            case "NETHER_BRICK": 
            case "DARK_OAK_DOOR": 
            case "ACACIA_DOOR": 
            case "BIRCH_DOOR": 
            case "JUNGLE_DOOR": 
            case "SPRUCE_DOOR": 
            case "MAP": 
            case "CAULDRON": 
            case "BREWING_STAND": 
            case "FLOWER_POT": {
                return true;
            }
        }
        return false;
    }

    private static /* synthetic */ XMaterial[] $values() {
        return new XMaterial[]{ACACIA_BOAT, ACACIA_BUTTON, ACACIA_CHEST_BOAT, ACACIA_DOOR, ACACIA_FENCE, ACACIA_FENCE_GATE, ACACIA_HANGING_SIGN, ACACIA_LEAVES, ACACIA_LOG, ACACIA_PLANKS, ACACIA_PRESSURE_PLATE, ACACIA_SAPLING, ACACIA_SIGN, ACACIA_SLAB, ACACIA_STAIRS, ACACIA_TRAPDOOR, ACACIA_WALL_HANGING_SIGN, ACACIA_WALL_SIGN, ACACIA_WOOD, ACTIVATOR_RAIL, AIR, ALLAY_SPAWN_EGG, ALLIUM, AMETHYST_BLOCK, AMETHYST_CLUSTER, AMETHYST_SHARD, ANCIENT_DEBRIS, ANDESITE, ANDESITE_SLAB, ANDESITE_STAIRS, ANDESITE_WALL, ANGLER_POTTERY_SHERD, ANVIL, APPLE, ARCHER_POTTERY_SHERD, ARMOR_STAND, ARMS_UP_POTTERY_SHERD, ARROW, ATTACHED_MELON_STEM, ATTACHED_PUMPKIN_STEM, AXOLOTL_BUCKET, AXOLOTL_SPAWN_EGG, AZALEA, AZALEA_LEAVES, AZURE_BLUET, BAKED_POTATO, BAMBOO, BAMBOO_BLOCK, BAMBOO_BUTTON, BAMBOO_CHEST_RAFT, BAMBOO_DOOR, BAMBOO_FENCE, BAMBOO_FENCE_GATE, BAMBOO_HANGING_SIGN, BAMBOO_MOSAIC, BAMBOO_MOSAIC_SLAB, BAMBOO_MOSAIC_STAIRS, BAMBOO_PLANKS, BAMBOO_PRESSURE_PLATE, BAMBOO_RAFT, BAMBOO_SAPLING, BAMBOO_SIGN, BAMBOO_SLAB, BAMBOO_STAIRS, BAMBOO_TRAPDOOR, BAMBOO_WALL_HANGING_SIGN, BAMBOO_WALL_SIGN, BARREL, BARRIER, BASALT, BAT_SPAWN_EGG, BEACON, BEDROCK, BEEF, BEEHIVE, BEETROOT, BEETROOTS, BEETROOT_SEEDS, BEETROOT_SOUP, BEE_NEST, BEE_SPAWN_EGG, BELL, BIG_DRIPLEAF, BIG_DRIPLEAF_STEM, BIRCH_BOAT, BIRCH_BUTTON, BIRCH_CHEST_BOAT, BIRCH_DOOR, BIRCH_FENCE, BIRCH_FENCE_GATE, BIRCH_HANGING_SIGN, BIRCH_LEAVES, BIRCH_LOG, BIRCH_PLANKS, BIRCH_PRESSURE_PLATE, BIRCH_SAPLING, BIRCH_SIGN, BIRCH_SLAB, BIRCH_STAIRS, BIRCH_TRAPDOOR, BIRCH_WALL_HANGING_SIGN, BIRCH_WALL_SIGN, BIRCH_WOOD, BLACKSTONE, BLACKSTONE_SLAB, BLACKSTONE_STAIRS, BLACKSTONE_WALL, BLACK_BANNER, BLACK_BED, BLACK_CANDLE, BLACK_CANDLE_CAKE, BLACK_CARPET, BLACK_CONCRETE, BLACK_CONCRETE_POWDER, BLACK_DYE, BLACK_GLAZED_TERRACOTTA, BLACK_SHULKER_BOX, BLACK_STAINED_GLASS, BLACK_STAINED_GLASS_PANE, BLACK_TERRACOTTA, BLACK_WALL_BANNER, BLACK_WOOL, BLADE_POTTERY_SHERD, BLAST_FURNACE, BLAZE_POWDER, BLAZE_ROD, BLAZE_SPAWN_EGG, BLUE_BANNER, BLUE_BED, BLUE_CANDLE, BLUE_CANDLE_CAKE, BLUE_CARPET, BLUE_CONCRETE, BLUE_CONCRETE_POWDER, BLUE_DYE, BLUE_GLAZED_TERRACOTTA, BLUE_ICE, BLUE_ORCHID, BLUE_SHULKER_BOX, BLUE_STAINED_GLASS, BLUE_STAINED_GLASS_PANE, BLUE_TERRACOTTA, BLUE_WALL_BANNER, BLUE_WOOL, BONE, BONE_BLOCK, BONE_MEAL, BOOK, BOOKSHELF, BOW, BOWL, BRAIN_CORAL, BRAIN_CORAL_BLOCK, BRAIN_CORAL_FAN, BRAIN_CORAL_WALL_FAN, BREAD, BREWER_POTTERY_SHERD, BREWING_STAND, BRICK, BRICKS, BRICK_SLAB, BRICK_STAIRS, BRICK_WALL, BROWN_BANNER, BROWN_BED, BROWN_CANDLE, BROWN_CANDLE_CAKE, BROWN_CARPET, BROWN_CONCRETE, BROWN_CONCRETE_POWDER, BROWN_DYE, BROWN_GLAZED_TERRACOTTA, BROWN_MUSHROOM, BROWN_MUSHROOM_BLOCK, BROWN_SHULKER_BOX, BROWN_STAINED_GLASS, BROWN_STAINED_GLASS_PANE, BROWN_TERRACOTTA, BROWN_WALL_BANNER, BROWN_WOOL, BRUSH, BUBBLE_COLUMN, BUBBLE_CORAL, BUBBLE_CORAL_BLOCK, BUBBLE_CORAL_FAN, BUBBLE_CORAL_WALL_FAN, BUCKET, BUDDING_AMETHYST, BUNDLE, BURN_POTTERY_SHERD, CACTUS, CAKE, CALCITE, CALIBRATED_SCULK_SENSOR, CAMEL_SPAWN_EGG, CAMPFIRE, CANDLE, CANDLE_CAKE, CARROT, CARROTS, CARROT_ON_A_STICK, CARTOGRAPHY_TABLE, CARVED_PUMPKIN, CAT_SPAWN_EGG, CAULDRON, CAVE_AIR, CAVE_SPIDER_SPAWN_EGG, CAVE_VINES, CAVE_VINES_PLANT, CHAIN, CHAINMAIL_BOOTS, CHAINMAIL_CHESTPLATE, CHAINMAIL_HELMET, CHAINMAIL_LEGGINGS, CHAIN_COMMAND_BLOCK, CHARCOAL, CHERRY_BOAT, CHERRY_BUTTON, CHERRY_CHEST_BOAT, CHERRY_DOOR, CHERRY_FENCE, CHERRY_FENCE_GATE, CHERRY_HANGING_SIGN, CHERRY_LEAVES, CHERRY_LOG, CHERRY_PLANKS, CHERRY_PRESSURE_PLATE, CHERRY_SAPLING, CHERRY_SIGN, CHERRY_SLAB, CHERRY_STAIRS, CHERRY_TRAPDOOR, CHERRY_WALL_HANGING_SIGN, CHERRY_WALL_SIGN, CHERRY_WOOD, CHEST, CHEST_MINECART, CHICKEN, CHICKEN_SPAWN_EGG, CHIPPED_ANVIL, CHISELED_BOOKSHELF, CHISELED_DEEPSLATE, CHISELED_NETHER_BRICKS, CHISELED_POLISHED_BLACKSTONE, CHISELED_QUARTZ_BLOCK, CHISELED_RED_SANDSTONE, CHISELED_SANDSTONE, CHISELED_STONE_BRICKS, CHORUS_FLOWER, CHORUS_FRUIT, CHORUS_PLANT, CLAY, CLAY_BALL, CLOCK, COAL, COAL_BLOCK, COAL_ORE, COARSE_DIRT, COAST_ARMOR_TRIM_SMITHING_TEMPLATE, COBBLED_DEEPSLATE, COBBLED_DEEPSLATE_SLAB, COBBLED_DEEPSLATE_STAIRS, COBBLED_DEEPSLATE_WALL, COBBLESTONE, COBBLESTONE_SLAB, COBBLESTONE_STAIRS, COBBLESTONE_WALL, COBWEB, COCOA, COCOA_BEANS, COD, COD_BUCKET, COD_SPAWN_EGG, COMMAND_BLOCK, COMMAND_BLOCK_MINECART, COMPARATOR, COMPASS, COMPOSTER, CONDUIT, COOKED_BEEF, COOKED_CHICKEN, COOKED_COD, COOKED_MUTTON, COOKED_PORKCHOP, COOKED_RABBIT, COOKED_SALMON, COOKIE, COPPER_BLOCK, COPPER_INGOT, COPPER_ORE, CORNFLOWER, COW_SPAWN_EGG, CRACKED_DEEPSLATE_BRICKS, CRACKED_DEEPSLATE_TILES, CRACKED_NETHER_BRICKS, CRACKED_POLISHED_BLACKSTONE_BRICKS, CRACKED_STONE_BRICKS, CRAFTING_TABLE, CREEPER_BANNER_PATTERN, CREEPER_HEAD, CREEPER_SPAWN_EGG, CREEPER_WALL_HEAD, CRIMSON_BUTTON, CRIMSON_DOOR, CRIMSON_FENCE, CRIMSON_FENCE_GATE, CRIMSON_FUNGUS, CRIMSON_HANGING_SIGN, CRIMSON_HYPHAE, CRIMSON_NYLIUM, CRIMSON_PLANKS, CRIMSON_PRESSURE_PLATE, CRIMSON_ROOTS, CRIMSON_SIGN, CRIMSON_SLAB, CRIMSON_STAIRS, CRIMSON_STEM, CRIMSON_TRAPDOOR, CRIMSON_WALL_HANGING_SIGN, CRIMSON_WALL_SIGN, CROSSBOW, CRYING_OBSIDIAN, CUT_COPPER, CUT_COPPER_SLAB, CUT_COPPER_STAIRS, CUT_RED_SANDSTONE, CUT_RED_SANDSTONE_SLAB, CUT_SANDSTONE, CUT_SANDSTONE_SLAB, CYAN_BANNER, CYAN_BED, CYAN_CANDLE, CYAN_CANDLE_CAKE, CYAN_CARPET, CYAN_CONCRETE, CYAN_CONCRETE_POWDER, CYAN_DYE, CYAN_GLAZED_TERRACOTTA, CYAN_SHULKER_BOX, CYAN_STAINED_GLASS, CYAN_STAINED_GLASS_PANE, CYAN_TERRACOTTA, CYAN_WALL_BANNER, CYAN_WOOL, DAMAGED_ANVIL, DANDELION, DANGER_POTTERY_SHERD, DARK_OAK_BOAT, DARK_OAK_BUTTON, DARK_OAK_CHEST_BOAT, DARK_OAK_DOOR, DARK_OAK_FENCE, DARK_OAK_FENCE_GATE, DARK_OAK_HANGING_SIGN, DARK_OAK_LEAVES, DARK_OAK_LOG, DARK_OAK_PLANKS, DARK_OAK_PRESSURE_PLATE, DARK_OAK_SAPLING, DARK_OAK_SIGN, DARK_OAK_SLAB, DARK_OAK_STAIRS, DARK_OAK_TRAPDOOR, DARK_OAK_WALL_HANGING_SIGN, DARK_OAK_WALL_SIGN, DARK_OAK_WOOD, DARK_PRISMARINE, DARK_PRISMARINE_SLAB, DARK_PRISMARINE_STAIRS, DAYLIGHT_DETECTOR, DEAD_BRAIN_CORAL, DEAD_BRAIN_CORAL_BLOCK, DEAD_BRAIN_CORAL_FAN, DEAD_BRAIN_CORAL_WALL_FAN, DEAD_BUBBLE_CORAL, DEAD_BUBBLE_CORAL_BLOCK, DEAD_BUBBLE_CORAL_FAN, DEAD_BUBBLE_CORAL_WALL_FAN, DEAD_BUSH, DEAD_FIRE_CORAL, DEAD_FIRE_CORAL_BLOCK, DEAD_FIRE_CORAL_FAN, DEAD_FIRE_CORAL_WALL_FAN, DEAD_HORN_CORAL, DEAD_HORN_CORAL_BLOCK, DEAD_HORN_CORAL_FAN, DEAD_HORN_CORAL_WALL_FAN, DEAD_TUBE_CORAL, DEAD_TUBE_CORAL_BLOCK, DEAD_TUBE_CORAL_FAN, DEAD_TUBE_CORAL_WALL_FAN, DEBUG_STICK, DECORATED_POT, DEEPSLATE, DEEPSLATE_BRICKS, DEEPSLATE_BRICK_SLAB, DEEPSLATE_BRICK_STAIRS, DEEPSLATE_BRICK_WALL, DEEPSLATE_COAL_ORE, DEEPSLATE_COPPER_ORE, DEEPSLATE_DIAMOND_ORE, DEEPSLATE_EMERALD_ORE, DEEPSLATE_GOLD_ORE, DEEPSLATE_IRON_ORE, DEEPSLATE_LAPIS_ORE, DEEPSLATE_REDSTONE_ORE, DEEPSLATE_TILES, DEEPSLATE_TILE_SLAB, DEEPSLATE_TILE_STAIRS, DEEPSLATE_TILE_WALL, DETECTOR_RAIL, DIAMOND, DIAMOND_AXE, DIAMOND_BLOCK, DIAMOND_BOOTS, DIAMOND_CHESTPLATE, DIAMOND_HELMET, DIAMOND_HOE, DIAMOND_HORSE_ARMOR, DIAMOND_LEGGINGS, DIAMOND_ORE, DIAMOND_PICKAXE, DIAMOND_SHOVEL, DIAMOND_SWORD, DIORITE, DIORITE_SLAB, DIORITE_STAIRS, DIORITE_WALL, DIRT, DIRT_PATH, DISC_FRAGMENT_5, DISPENSER, DOLPHIN_SPAWN_EGG, DONKEY_SPAWN_EGG, DRAGON_BREATH, DRAGON_EGG, DRAGON_HEAD, DRAGON_WALL_HEAD, DRIED_KELP, DRIED_KELP_BLOCK, DRIPSTONE_BLOCK, DROPPER, DROWNED_SPAWN_EGG, DUNE_ARMOR_TRIM_SMITHING_TEMPLATE, ECHO_SHARD, EGG, ELDER_GUARDIAN_SPAWN_EGG, ELYTRA, EMERALD, EMERALD_BLOCK, EMERALD_ORE, ENCHANTED_BOOK, ENCHANTED_GOLDEN_APPLE, ENCHANTING_TABLE, ENDERMAN_SPAWN_EGG, ENDERMITE_SPAWN_EGG, ENDER_CHEST, ENDER_DRAGON_SPAWN_EGG, ENDER_EYE, ENDER_PEARL, END_CRYSTAL, END_GATEWAY, END_PORTAL, END_PORTAL_FRAME, END_ROD, END_STONE, END_STONE_BRICKS, END_STONE_BRICK_SLAB, END_STONE_BRICK_STAIRS, END_STONE_BRICK_WALL, EVOKER_SPAWN_EGG, EXPERIENCE_BOTTLE, EXPLORER_POTTERY_SHERD, EXPOSED_COPPER, EXPOSED_CUT_COPPER, EXPOSED_CUT_COPPER_SLAB, EXPOSED_CUT_COPPER_STAIRS, EYE_ARMOR_TRIM_SMITHING_TEMPLATE, FARMLAND, FEATHER, FERMENTED_SPIDER_EYE, FERN, FILLED_MAP, FIRE, FIREWORK_ROCKET, FIREWORK_STAR, FIRE_CHARGE, FIRE_CORAL, FIRE_CORAL_BLOCK, FIRE_CORAL_FAN, FIRE_CORAL_WALL_FAN, FISHING_ROD, FLETCHING_TABLE, FLINT, FLINT_AND_STEEL, FLOWERING_AZALEA, FLOWERING_AZALEA_LEAVES, FLOWER_BANNER_PATTERN, FLOWER_POT, FOX_SPAWN_EGG, FRIEND_POTTERY_SHERD, FROGSPAWN, FROG_SPAWN_EGG, FROSTED_ICE, FURNACE, FURNACE_MINECART, GHAST_SPAWN_EGG, GHAST_TEAR, GILDED_BLACKSTONE, GLASS, GLASS_BOTTLE, GLASS_PANE, GLISTERING_MELON_SLICE, GLOBE_BANNER_PATTERN, GLOWSTONE, GLOWSTONE_DUST, GLOW_BERRIES, GLOW_INK_SAC, GLOW_ITEM_FRAME, GLOW_LICHEN, GLOW_SQUID_SPAWN_EGG, GOAT_HORN, GOAT_SPAWN_EGG, GOLDEN_APPLE, GOLDEN_AXE, GOLDEN_BOOTS, GOLDEN_CARROT, GOLDEN_CHESTPLATE, GOLDEN_HELMET, GOLDEN_HOE, GOLDEN_HORSE_ARMOR, GOLDEN_LEGGINGS, GOLDEN_PICKAXE, GOLDEN_SHOVEL, GOLDEN_SWORD, GOLD_BLOCK, GOLD_INGOT, GOLD_NUGGET, GOLD_ORE, GRANITE, GRANITE_SLAB, GRANITE_STAIRS, GRANITE_WALL, GRASS, GRASS_BLOCK, GRAVEL, GRAY_BANNER, GRAY_BED, GRAY_CANDLE, GRAY_CANDLE_CAKE, GRAY_CARPET, GRAY_CONCRETE, GRAY_CONCRETE_POWDER, GRAY_DYE, GRAY_GLAZED_TERRACOTTA, GRAY_SHULKER_BOX, GRAY_STAINED_GLASS, GRAY_STAINED_GLASS_PANE, GRAY_TERRACOTTA, GRAY_WALL_BANNER, GRAY_WOOL, GREEN_BANNER, GREEN_BED, GREEN_CANDLE, GREEN_CANDLE_CAKE, GREEN_CARPET, GREEN_CONCRETE, GREEN_CONCRETE_POWDER, GREEN_DYE, GREEN_GLAZED_TERRACOTTA, GREEN_SHULKER_BOX, GREEN_STAINED_GLASS, GREEN_STAINED_GLASS_PANE, GREEN_TERRACOTTA, GREEN_WALL_BANNER, GREEN_WOOL, GRINDSTONE, GUARDIAN_SPAWN_EGG, GUNPOWDER, HANGING_ROOTS, HAY_BLOCK, HEARTBREAK_POTTERY_SHERD, HEART_OF_THE_SEA, HEART_POTTERY_SHERD, HEAVY_WEIGHTED_PRESSURE_PLATE, HOGLIN_SPAWN_EGG, HONEYCOMB, HONEYCOMB_BLOCK, HONEY_BLOCK, HONEY_BOTTLE, HOPPER, HOPPER_MINECART, HORN_CORAL, HORN_CORAL_BLOCK, HORN_CORAL_FAN, HORN_CORAL_WALL_FAN, HORSE_SPAWN_EGG, HOST_ARMOR_TRIM_SMITHING_TEMPLATE, HOWL_POTTERY_SHERD, HUSK_SPAWN_EGG, ICE, INFESTED_CHISELED_STONE_BRICKS, INFESTED_COBBLESTONE, INFESTED_CRACKED_STONE_BRICKS, INFESTED_DEEPSLATE, INFESTED_MOSSY_STONE_BRICKS, INFESTED_STONE, INFESTED_STONE_BRICKS, INK_SAC, IRON_AXE, IRON_BARS, IRON_BLOCK, IRON_BOOTS, IRON_CHESTPLATE, IRON_DOOR, IRON_GOLEM_SPAWN_EGG, IRON_HELMET, IRON_HOE, IRON_HORSE_ARMOR, IRON_INGOT, IRON_LEGGINGS, IRON_NUGGET, IRON_ORE, IRON_PICKAXE, IRON_SHOVEL, IRON_SWORD, IRON_TRAPDOOR, ITEM_FRAME, JACK_O_LANTERN, JIGSAW, JUKEBOX, JUNGLE_BOAT, JUNGLE_BUTTON, JUNGLE_CHEST_BOAT, JUNGLE_DOOR, JUNGLE_FENCE, JUNGLE_FENCE_GATE, JUNGLE_HANGING_SIGN, JUNGLE_LEAVES, JUNGLE_LOG, JUNGLE_PLANKS, JUNGLE_PRESSURE_PLATE, JUNGLE_SAPLING, JUNGLE_SIGN, JUNGLE_SLAB, JUNGLE_STAIRS, JUNGLE_TRAPDOOR, JUNGLE_WALL_HANGING_SIGN, JUNGLE_WALL_SIGN, JUNGLE_WOOD, KELP, KELP_PLANT, KNOWLEDGE_BOOK, LADDER, LANTERN, LAPIS_BLOCK, LAPIS_LAZULI, LAPIS_ORE, LARGE_AMETHYST_BUD, LARGE_FERN, LAVA, LAVA_BUCKET, LAVA_CAULDRON, LEAD, LEATHER, LEATHER_BOOTS, LEATHER_CHESTPLATE, LEATHER_HELMET, LEATHER_HORSE_ARMOR, LEATHER_LEGGINGS, LECTERN, LEVER, LIGHT, LIGHTNING_ROD, LIGHT_BLUE_BANNER, LIGHT_BLUE_BED, LIGHT_BLUE_CANDLE, LIGHT_BLUE_CANDLE_CAKE, LIGHT_BLUE_CARPET, LIGHT_BLUE_CONCRETE, LIGHT_BLUE_CONCRETE_POWDER, LIGHT_BLUE_DYE, LIGHT_BLUE_GLAZED_TERRACOTTA, LIGHT_BLUE_SHULKER_BOX, LIGHT_BLUE_STAINED_GLASS, LIGHT_BLUE_STAINED_GLASS_PANE, LIGHT_BLUE_TERRACOTTA, LIGHT_BLUE_WALL_BANNER, LIGHT_BLUE_WOOL, LIGHT_GRAY_BANNER, LIGHT_GRAY_BED, LIGHT_GRAY_CANDLE, LIGHT_GRAY_CANDLE_CAKE, LIGHT_GRAY_CARPET, LIGHT_GRAY_CONCRETE, LIGHT_GRAY_CONCRETE_POWDER, LIGHT_GRAY_DYE, LIGHT_GRAY_GLAZED_TERRACOTTA, LIGHT_GRAY_SHULKER_BOX, LIGHT_GRAY_STAINED_GLASS, LIGHT_GRAY_STAINED_GLASS_PANE, LIGHT_GRAY_TERRACOTTA, LIGHT_GRAY_WALL_BANNER, LIGHT_GRAY_WOOL, LIGHT_WEIGHTED_PRESSURE_PLATE, LILAC, LILY_OF_THE_VALLEY, LILY_PAD, LIME_BANNER, LIME_BED, LIME_CANDLE, LIME_CANDLE_CAKE, LIME_CARPET, LIME_CONCRETE, LIME_CONCRETE_POWDER, LIME_DYE, LIME_GLAZED_TERRACOTTA, LIME_SHULKER_BOX, LIME_STAINED_GLASS, LIME_STAINED_GLASS_PANE, LIME_TERRACOTTA, LIME_WALL_BANNER, LIME_WOOL, LINGERING_POTION, LLAMA_SPAWN_EGG, LODESTONE, LOOM, MAGENTA_BANNER, MAGENTA_BED, MAGENTA_CANDLE, MAGENTA_CANDLE_CAKE, MAGENTA_CARPET, MAGENTA_CONCRETE, MAGENTA_CONCRETE_POWDER, MAGENTA_DYE, MAGENTA_GLAZED_TERRACOTTA, MAGENTA_SHULKER_BOX, MAGENTA_STAINED_GLASS, MAGENTA_STAINED_GLASS_PANE, MAGENTA_TERRACOTTA, MAGENTA_WALL_BANNER, MAGENTA_WOOL, MAGMA_BLOCK, MAGMA_CREAM, MAGMA_CUBE_SPAWN_EGG, MANGROVE_BOAT, MANGROVE_BUTTON, MANGROVE_CHEST_BOAT, MANGROVE_DOOR, MANGROVE_FENCE, MANGROVE_FENCE_GATE, MANGROVE_HANGING_SIGN, MANGROVE_LEAVES, MANGROVE_LOG, MANGROVE_PLANKS, MANGROVE_PRESSURE_PLATE, MANGROVE_PROPAGULE, MANGROVE_ROOTS, MANGROVE_SIGN, MANGROVE_SLAB, MANGROVE_STAIRS, MANGROVE_TRAPDOOR, MANGROVE_WALL_HANGING_SIGN, MANGROVE_WALL_SIGN, MANGROVE_WOOD, MAP, MEDIUM_AMETHYST_BUD, MELON, MELON_SEEDS, MELON_SLICE, MELON_STEM, MILK_BUCKET, MINECART, MINER_POTTERY_SHERD, MOJANG_BANNER_PATTERN, MOOSHROOM_SPAWN_EGG, MOSSY_COBBLESTONE, MOSSY_COBBLESTONE_SLAB, MOSSY_COBBLESTONE_STAIRS, MOSSY_COBBLESTONE_WALL, MOSSY_STONE_BRICKS, MOSSY_STONE_BRICK_SLAB, MOSSY_STONE_BRICK_STAIRS, MOSSY_STONE_BRICK_WALL, MOSS_BLOCK, MOSS_CARPET, MOURNER_POTTERY_SHERD, MOVING_PISTON, MUD, MUDDY_MANGROVE_ROOTS, MUD_BRICKS, MUD_BRICK_SLAB, MUD_BRICK_STAIRS, MUD_BRICK_WALL, MULE_SPAWN_EGG, MUSHROOM_STEM, MUSHROOM_STEW, MUSIC_DISC_11, MUSIC_DISC_13, MUSIC_DISC_5, MUSIC_DISC_BLOCKS, MUSIC_DISC_CAT, MUSIC_DISC_CHIRP, MUSIC_DISC_FAR, MUSIC_DISC_MALL, MUSIC_DISC_MELLOHI, MUSIC_DISC_OTHERSIDE, MUSIC_DISC_PIGSTEP, MUSIC_DISC_RELIC, MUSIC_DISC_STAL, MUSIC_DISC_STRAD, MUSIC_DISC_WAIT, MUSIC_DISC_WARD, MUTTON, MYCELIUM, NAME_TAG, NAUTILUS_SHELL, NETHERITE_AXE, NETHERITE_BLOCK, NETHERITE_BOOTS, NETHERITE_CHESTPLATE, NETHERITE_HELMET, NETHERITE_HOE, NETHERITE_INGOT, NETHERITE_LEGGINGS, NETHERITE_PICKAXE, NETHERITE_SCRAP, NETHERITE_SHOVEL, NETHERITE_SWORD, NETHERITE_UPGRADE_SMITHING_TEMPLATE, NETHERRACK, NETHER_BRICK, NETHER_BRICKS, NETHER_BRICK_FENCE, NETHER_BRICK_SLAB, NETHER_BRICK_STAIRS, NETHER_BRICK_WALL, NETHER_GOLD_ORE, NETHER_PORTAL, NETHER_QUARTZ_ORE, NETHER_SPROUTS, NETHER_STAR, NETHER_WART, NETHER_WART_BLOCK, NOTE_BLOCK, OAK_BOAT, OAK_BUTTON, OAK_CHEST_BOAT, OAK_DOOR, OAK_FENCE, OAK_FENCE_GATE, OAK_HANGING_SIGN, OAK_LEAVES, OAK_LOG, OAK_PLANKS, OAK_PRESSURE_PLATE, OAK_SAPLING, OAK_SIGN, OAK_SLAB, OAK_STAIRS, OAK_TRAPDOOR, OAK_WALL_HANGING_SIGN, OAK_WALL_SIGN, OAK_WOOD, OBSERVER, OBSIDIAN, OCELOT_SPAWN_EGG, OCHRE_FROGLIGHT, ORANGE_BANNER, ORANGE_BED, ORANGE_CANDLE, ORANGE_CANDLE_CAKE, ORANGE_CARPET, ORANGE_CONCRETE, ORANGE_CONCRETE_POWDER, ORANGE_DYE, ORANGE_GLAZED_TERRACOTTA, ORANGE_SHULKER_BOX, ORANGE_STAINED_GLASS, ORANGE_STAINED_GLASS_PANE, ORANGE_TERRACOTTA, ORANGE_TULIP, ORANGE_WALL_BANNER, ORANGE_WOOL, OXEYE_DAISY, OXIDIZED_COPPER, OXIDIZED_CUT_COPPER, OXIDIZED_CUT_COPPER_SLAB, OXIDIZED_CUT_COPPER_STAIRS, PACKED_ICE, PACKED_MUD, PAINTING, PANDA_SPAWN_EGG, PAPER, PARROT_SPAWN_EGG, PEARLESCENT_FROGLIGHT, PEONY, PETRIFIED_OAK_SLAB, PHANTOM_MEMBRANE, PHANTOM_SPAWN_EGG, PIGLIN_BANNER_PATTERN, PIGLIN_BRUTE_SPAWN_EGG, PIGLIN_HEAD, PIGLIN_SPAWN_EGG, PIGLIN_WALL_HEAD, PIG_SPAWN_EGG, PILLAGER_SPAWN_EGG, PINK_BANNER, PINK_BED, PINK_CANDLE, PINK_CANDLE_CAKE, PINK_CARPET, PINK_CONCRETE, PINK_CONCRETE_POWDER, PINK_DYE, PINK_GLAZED_TERRACOTTA, PINK_PETALS, PINK_SHULKER_BOX, PINK_STAINED_GLASS, PINK_STAINED_GLASS_PANE, PINK_TERRACOTTA, PINK_TULIP, PINK_WALL_BANNER, PINK_WOOL, PISTON, PISTON_HEAD, PITCHER_CROP, PITCHER_PLANT, PITCHER_POD, PLAYER_HEAD, PLAYER_WALL_HEAD, PLENTY_POTTERY_SHERD, PODZOL, POINTED_DRIPSTONE, POISONOUS_POTATO, POLAR_BEAR_SPAWN_EGG, POLISHED_ANDESITE, POLISHED_ANDESITE_SLAB, POLISHED_ANDESITE_STAIRS, POLISHED_BASALT, POLISHED_BLACKSTONE, POLISHED_BLACKSTONE_BRICKS, POLISHED_BLACKSTONE_BRICK_SLAB, POLISHED_BLACKSTONE_BRICK_STAIRS, POLISHED_BLACKSTONE_BRICK_WALL, POLISHED_BLACKSTONE_BUTTON, POLISHED_BLACKSTONE_PRESSURE_PLATE, POLISHED_BLACKSTONE_SLAB, POLISHED_BLACKSTONE_STAIRS, POLISHED_BLACKSTONE_WALL, POLISHED_DEEPSLATE, POLISHED_DEEPSLATE_SLAB, POLISHED_DEEPSLATE_STAIRS, POLISHED_DEEPSLATE_WALL, POLISHED_DIORITE, POLISHED_DIORITE_SLAB, POLISHED_DIORITE_STAIRS, POLISHED_GRANITE, POLISHED_GRANITE_SLAB, POLISHED_GRANITE_STAIRS, POPPED_CHORUS_FRUIT, POPPY, PORKCHOP, POTATO, POTATOES, POTION, POTTED_ACACIA_SAPLING, POTTED_ALLIUM, POTTED_AZALEA_BUSH, POTTED_AZURE_BLUET, POTTED_BAMBOO, POTTED_BIRCH_SAPLING, POTTED_BLUE_ORCHID, POTTED_BROWN_MUSHROOM, POTTED_CACTUS, POTTED_CHERRY_SAPLING, POTTED_CORNFLOWER, POTTED_CRIMSON_FUNGUS, POTTED_CRIMSON_ROOTS, POTTED_DANDELION, POTTED_DARK_OAK_SAPLING, POTTED_DEAD_BUSH, POTTED_FERN, POTTED_FLOWERING_AZALEA_BUSH, POTTED_JUNGLE_SAPLING, POTTED_LILY_OF_THE_VALLEY, POTTED_MANGROVE_PROPAGULE, POTTED_OAK_SAPLING, POTTED_ORANGE_TULIP, POTTED_OXEYE_DAISY, POTTED_PINK_TULIP, POTTED_POPPY, POTTED_RED_MUSHROOM, POTTED_RED_TULIP, POTTED_SPRUCE_SAPLING, POTTED_TORCHFLOWER, POTTED_WARPED_FUNGUS, POTTED_WARPED_ROOTS, POTTED_WHITE_TULIP, POTTED_WITHER_ROSE, POTTERY_SHARD_ARCHER, POTTERY_SHARD_ARMS_UP, POTTERY_SHARD_PRIZE, POTTERY_SHARD_SKULL, POWDER_SNOW, POWDER_SNOW_BUCKET, POWDER_SNOW_CAULDRON, POWERED_RAIL, PRISMARINE, PRISMARINE_BRICKS, PRISMARINE_BRICK_SLAB, PRISMARINE_BRICK_STAIRS, PRISMARINE_CRYSTALS, PRISMARINE_SHARD, PRISMARINE_SLAB, PRISMARINE_STAIRS, PRISMARINE_WALL, PRIZE_POTTERY_SHERD, PUFFERFISH, PUFFERFISH_BUCKET, PUFFERFISH_SPAWN_EGG, PUMPKIN, PUMPKIN_PIE, PUMPKIN_SEEDS, PUMPKIN_STEM, PURPLE_BANNER, PURPLE_BED, PURPLE_CANDLE, PURPLE_CANDLE_CAKE, PURPLE_CARPET, PURPLE_CONCRETE, PURPLE_CONCRETE_POWDER, PURPLE_DYE, PURPLE_GLAZED_TERRACOTTA, PURPLE_SHULKER_BOX, PURPLE_STAINED_GLASS, PURPLE_STAINED_GLASS_PANE, PURPLE_TERRACOTTA, PURPLE_WALL_BANNER, PURPLE_WOOL, PURPUR_BLOCK, PURPUR_PILLAR, PURPUR_SLAB, PURPUR_STAIRS, QUARTZ, QUARTZ_BLOCK, QUARTZ_BRICKS, QUARTZ_PILLAR, QUARTZ_SLAB, QUARTZ_STAIRS, RABBIT, RABBIT_FOOT, RABBIT_HIDE, RABBIT_SPAWN_EGG, RABBIT_STEW, RAIL, RAISER_ARMOR_TRIM_SMITHING_TEMPLATE, RAVAGER_SPAWN_EGG, RAW_COPPER, RAW_COPPER_BLOCK, RAW_GOLD, RAW_GOLD_BLOCK, RAW_IRON, RAW_IRON_BLOCK, RECOVERY_COMPASS, REDSTONE, REDSTONE_BLOCK, REDSTONE_LAMP, REDSTONE_ORE, REDSTONE_TORCH, REDSTONE_WALL_TORCH, REDSTONE_WIRE, RED_BANNER, RED_BED, RED_CANDLE, RED_CANDLE_CAKE, RED_CARPET, RED_CONCRETE, RED_CONCRETE_POWDER, RED_DYE, RED_GLAZED_TERRACOTTA, RED_MUSHROOM, RED_MUSHROOM_BLOCK, RED_NETHER_BRICKS, RED_NETHER_BRICK_SLAB, RED_NETHER_BRICK_STAIRS, RED_NETHER_BRICK_WALL, RED_SAND, RED_SANDSTONE, RED_SANDSTONE_SLAB, RED_SANDSTONE_STAIRS, RED_SANDSTONE_WALL, RED_SHULKER_BOX, RED_STAINED_GLASS, RED_STAINED_GLASS_PANE, RED_TERRACOTTA, RED_TULIP, RED_WALL_BANNER, RED_WOOL, REINFORCED_DEEPSLATE, REPEATER, REPEATING_COMMAND_BLOCK, RESPAWN_ANCHOR, RIB_ARMOR_TRIM_SMITHING_TEMPLATE, ROOTED_DIRT, ROSE_BUSH, ROTTEN_FLESH, SADDLE, SALMON, SALMON_BUCKET, SALMON_SPAWN_EGG, SAND, SANDSTONE, SANDSTONE_SLAB, SANDSTONE_STAIRS, SANDSTONE_WALL, SCAFFOLDING, SCULK, SCULK_CATALYST, SCULK_SENSOR, SCULK_SHRIEKER, SCULK_VEIN, SCUTE, SEAGRASS, SEA_LANTERN, SEA_PICKLE, SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE, SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE, SHEAF_POTTERY_SHERD, SHEARS, SHEEP_SPAWN_EGG, SHELTER_POTTERY_SHERD, SHIELD, SHROOMLIGHT, SHULKER_BOX, SHULKER_SHELL, SHULKER_SPAWN_EGG, SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE, SILVERFISH_SPAWN_EGG, SKELETON_HORSE_SPAWN_EGG, SKELETON_SKULL, SKELETON_SPAWN_EGG, SKELETON_WALL_SKULL, SKULL_BANNER_PATTERN, SKULL_POTTERY_SHERD, SLIME_BALL, SLIME_BLOCK, SLIME_SPAWN_EGG, SMALL_AMETHYST_BUD, SMALL_DRIPLEAF, SMITHING_TABLE, SMOKER, SMOOTH_BASALT, SMOOTH_QUARTZ, SMOOTH_QUARTZ_SLAB, SMOOTH_QUARTZ_STAIRS, SMOOTH_RED_SANDSTONE, SMOOTH_RED_SANDSTONE_SLAB, SMOOTH_RED_SANDSTONE_STAIRS, SMOOTH_SANDSTONE, SMOOTH_SANDSTONE_SLAB, SMOOTH_SANDSTONE_STAIRS, SMOOTH_STONE, SMOOTH_STONE_SLAB, SNIFFER_EGG, SNIFFER_SPAWN_EGG, SNORT_POTTERY_SHERD, SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE, SNOW, SNOWBALL, SNOW_BLOCK, SNOW_GOLEM_SPAWN_EGG, SOUL_CAMPFIRE, SOUL_FIRE, SOUL_LANTERN, SOUL_SAND, SOUL_SOIL, SOUL_TORCH, SOUL_WALL_TORCH, SPAWNER, SPECTRAL_ARROW, SPIDER_EYE, SPIDER_SPAWN_EGG, SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE, SPLASH_POTION, SPONGE, SPORE_BLOSSOM, SPRUCE_BOAT, SPRUCE_BUTTON, SPRUCE_CHEST_BOAT, SPRUCE_DOOR, SPRUCE_FENCE, SPRUCE_FENCE_GATE, SPRUCE_HANGING_SIGN, SPRUCE_LEAVES, SPRUCE_LOG, SPRUCE_PLANKS, SPRUCE_PRESSURE_PLATE, SPRUCE_SAPLING, SPRUCE_SIGN, SPRUCE_SLAB, SPRUCE_STAIRS, SPRUCE_TRAPDOOR, SPRUCE_WALL_HANGING_SIGN, SPRUCE_WALL_SIGN, SPRUCE_WOOD, SPYGLASS, SQUID_SPAWN_EGG, STICK, STICKY_PISTON, STONE, STONECUTTER, STONE_AXE, STONE_BRICKS, STONE_BRICK_SLAB, STONE_BRICK_STAIRS, STONE_BRICK_WALL, STONE_BUTTON, STONE_HOE, STONE_PICKAXE, STONE_PRESSURE_PLATE, STONE_SHOVEL, STONE_SLAB, STONE_STAIRS, STONE_SWORD, STRAY_SPAWN_EGG, STRIDER_SPAWN_EGG, STRING, STRIPPED_ACACIA_LOG, STRIPPED_ACACIA_WOOD, STRIPPED_BAMBOO_BLOCK, STRIPPED_BIRCH_LOG, STRIPPED_BIRCH_WOOD, STRIPPED_CHERRY_LOG, STRIPPED_CHERRY_WOOD, STRIPPED_CRIMSON_HYPHAE, STRIPPED_CRIMSON_STEM, STRIPPED_DARK_OAK_LOG, STRIPPED_DARK_OAK_WOOD, STRIPPED_JUNGLE_LOG, STRIPPED_JUNGLE_WOOD, STRIPPED_MANGROVE_LOG, STRIPPED_MANGROVE_WOOD, STRIPPED_OAK_LOG, STRIPPED_OAK_WOOD, STRIPPED_SPRUCE_LOG, STRIPPED_SPRUCE_WOOD, STRIPPED_WARPED_HYPHAE, STRIPPED_WARPED_STEM, STRUCTURE_BLOCK, STRUCTURE_VOID, SUGAR, SUGAR_CANE, SUNFLOWER, SUSPICIOUS_GRAVEL, SUSPICIOUS_SAND, SUSPICIOUS_STEW, SWEET_BERRIES, SWEET_BERRY_BUSH, TADPOLE_BUCKET, TADPOLE_SPAWN_EGG, TALL_GRASS, TALL_SEAGRASS, TARGET, TERRACOTTA, TIDE_ARMOR_TRIM_SMITHING_TEMPLATE, TINTED_GLASS, TIPPED_ARROW, TNT, TNT_MINECART, TORCH, TORCHFLOWER, TORCHFLOWER_CROP, TORCHFLOWER_SEEDS, TOTEM_OF_UNDYING, TRADER_LLAMA_SPAWN_EGG, TRAPPED_CHEST, TRIDENT, TRIPWIRE, TRIPWIRE_HOOK, TROPICAL_FISH, TROPICAL_FISH_BUCKET, TROPICAL_FISH_SPAWN_EGG, TUBE_CORAL, TUBE_CORAL_BLOCK, TUBE_CORAL_FAN, TUBE_CORAL_WALL_FAN, TUFF, TURTLE_EGG, TURTLE_HELMET, TURTLE_SPAWN_EGG, TWISTING_VINES, TWISTING_VINES_PLANT, VERDANT_FROGLIGHT, VEX_ARMOR_TRIM_SMITHING_TEMPLATE, VEX_SPAWN_EGG, VILLAGER_SPAWN_EGG, VINDICATOR_SPAWN_EGG, VINE, VOID_AIR, WALL_TORCH, WANDERING_TRADER_SPAWN_EGG, WARDEN_SPAWN_EGG, WARD_ARMOR_TRIM_SMITHING_TEMPLATE, WARPED_BUTTON, WARPED_DOOR, WARPED_FENCE, WARPED_FENCE_GATE, WARPED_FUNGUS, WARPED_FUNGUS_ON_A_STICK, WARPED_HANGING_SIGN, WARPED_HYPHAE, WARPED_NYLIUM, WARPED_PLANKS, WARPED_PRESSURE_PLATE, WARPED_ROOTS, WARPED_SIGN, WARPED_SLAB, WARPED_STAIRS, WARPED_STEM, WARPED_TRAPDOOR, WARPED_WALL_HANGING_SIGN, WARPED_WALL_SIGN, WARPED_WART_BLOCK, WATER, WATER_BUCKET, WATER_CAULDRON, WAXED_COPPER_BLOCK, WAXED_CUT_COPPER, WAXED_CUT_COPPER_SLAB, WAXED_CUT_COPPER_STAIRS, WAXED_EXPOSED_COPPER, WAXED_EXPOSED_CUT_COPPER, WAXED_EXPOSED_CUT_COPPER_SLAB, WAXED_EXPOSED_CUT_COPPER_STAIRS, WAXED_OXIDIZED_COPPER, WAXED_OXIDIZED_CUT_COPPER, WAXED_OXIDIZED_CUT_COPPER_SLAB, WAXED_OXIDIZED_CUT_COPPER_STAIRS, WAXED_WEATHERED_COPPER, WAXED_WEATHERED_CUT_COPPER, WAXED_WEATHERED_CUT_COPPER_SLAB, WAXED_WEATHERED_CUT_COPPER_STAIRS, WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE, WEATHERED_COPPER, WEATHERED_CUT_COPPER, WEATHERED_CUT_COPPER_SLAB, WEATHERED_CUT_COPPER_STAIRS, WEEPING_VINES, WEEPING_VINES_PLANT, WET_SPONGE, WHEAT, WHEAT_SEEDS, WHITE_BANNER, WHITE_BED, WHITE_CANDLE, WHITE_CANDLE_CAKE, WHITE_CARPET, WHITE_CONCRETE, WHITE_CONCRETE_POWDER, WHITE_DYE, WHITE_GLAZED_TERRACOTTA, WHITE_SHULKER_BOX, WHITE_STAINED_GLASS, WHITE_STAINED_GLASS_PANE, WHITE_TERRACOTTA, WHITE_TULIP, WHITE_WALL_BANNER, WHITE_WOOL, WILD_ARMOR_TRIM_SMITHING_TEMPLATE, WITCH_SPAWN_EGG, WITHER_ROSE, WITHER_SKELETON_SKULL, WITHER_SKELETON_SPAWN_EGG, WITHER_SKELETON_WALL_SKULL, WITHER_SPAWN_EGG, WOLF_SPAWN_EGG, WOODEN_AXE, WOODEN_HOE, WOODEN_PICKAXE, WOODEN_SHOVEL, WOODEN_SWORD, WRITABLE_BOOK, WRITTEN_BOOK, YELLOW_BANNER, YELLOW_BED, YELLOW_CANDLE, YELLOW_CANDLE_CAKE, YELLOW_CARPET, YELLOW_CONCRETE, YELLOW_CONCRETE_POWDER, YELLOW_DYE, YELLOW_GLAZED_TERRACOTTA, YELLOW_SHULKER_BOX, YELLOW_STAINED_GLASS, YELLOW_STAINED_GLASS_PANE, YELLOW_TERRACOTTA, YELLOW_WALL_BANNER, YELLOW_WOOL, ZOGLIN_SPAWN_EGG, ZOMBIE_HEAD, ZOMBIE_HORSE_SPAWN_EGG, ZOMBIE_SPAWN_EGG, ZOMBIE_VILLAGER_SPAWN_EGG, ZOMBIE_WALL_HEAD, ZOMBIFIED_PIGLIN_SPAWN_EGG};
    }

    static {
        $VALUES = XMaterial.$values();
        VALUES = XMaterial.values();
        NAMES = new HashMap<String, XMaterial>();
        NAME_CACHE = CacheBuilder.newBuilder().expireAfterAccess(1L, TimeUnit.HOURS).build();
        CACHED_REGEX = CacheBuilder.newBuilder().expireAfterAccess(3L, TimeUnit.HOURS).build();
        for (XMaterial xMaterial : VALUES) {
            NAMES.put(xMaterial.name(), xMaterial);
        }
        if (Data.ISFLAT) {
            DUPLICATED = null;
        } else {
            DUPLICATED = new HashSet<String>(4);
            DUPLICATED.add(GRASS.name());
            DUPLICATED.add(MELON.name());
            DUPLICATED.add(BRICK.name());
            DUPLICATED.add(NETHER_BRICK.name());
        }
    }

    private static final class Data {
        private static final int VERSION;
        private static final boolean ISFLAT;

        private Data() {
        }

        static {
            String string = Bukkit.getVersion();
            Matcher matcher = Pattern.compile("MC: \\d\\.(\\d+)").matcher(string);
            if (!matcher.find()) {
                throw new IllegalArgumentException("Failed to parse server version from: " + string);
            }
            VERSION = Integer.parseInt(matcher.group(1));
            ISFLAT = XMaterial.supports(13);
        }
    }
}

