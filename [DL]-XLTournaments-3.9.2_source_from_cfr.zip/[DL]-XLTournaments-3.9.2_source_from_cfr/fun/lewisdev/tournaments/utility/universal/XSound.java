/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  javax.annotation.Nonnull
 *  javax.annotation.Nullable
 *  org.bukkit.Instrument
 *  org.bukkit.Location
 *  org.bukkit.Note
 *  org.bukkit.Note$Tone
 *  org.bukkit.Sound
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package fun.lewisdev.tournaments.utility.universal;

import com.google.common.base.Strings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.WeakHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.Instrument;
import org.bukkit.Location;
import org.bukkit.Note;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class XSound
extends Enum<XSound> {
    public static final /* enum */ XSound AMBIENT_BASALT_DELTAS_ADDITIONS = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_BASALT_DELTAS_LOOP = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_BASALT_DELTAS_MOOD = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_CAVE = new XSound("AMBIENCE_CAVE");
    public static final /* enum */ XSound AMBIENT_CRIMSON_FOREST_ADDITIONS = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_CRIMSON_FOREST_LOOP = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_CRIMSON_FOREST_MOOD = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_NETHER_WASTES_ADDITIONS = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_NETHER_WASTES_LOOP = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_NETHER_WASTES_MOOD = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_SOUL_SAND_VALLEY_ADDITIONS = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_SOUL_SAND_VALLEY_LOOP = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_SOUL_SAND_VALLEY_MOOD = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_UNDERWATER_ENTER = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_UNDERWATER_EXIT = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_UNDERWATER_LOOP = new XSound("AMBIENT_UNDERWATER_EXIT");
    public static final /* enum */ XSound AMBIENT_UNDERWATER_LOOP_ADDITIONS = new XSound("AMBIENT_UNDERWATER_EXIT");
    public static final /* enum */ XSound AMBIENT_UNDERWATER_LOOP_ADDITIONS_RARE = new XSound("AMBIENT_UNDERWATER_EXIT");
    public static final /* enum */ XSound AMBIENT_UNDERWATER_LOOP_ADDITIONS_ULTRA_RARE = new XSound("AMBIENT_UNDERWATER_EXIT");
    public static final /* enum */ XSound AMBIENT_WARPED_FOREST_ADDITIONS = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_WARPED_FOREST_LOOP = new XSound(new String[0]);
    public static final /* enum */ XSound AMBIENT_WARPED_FOREST_MOOD = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_CHIME = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_RESONATE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_CLUSTER_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_CLUSTER_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_CLUSTER_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_CLUSTER_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AMETHYST_CLUSTER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANCIENT_DEBRIS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANCIENT_DEBRIS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANCIENT_DEBRIS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANCIENT_DEBRIS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANCIENT_DEBRIS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANVIL_BREAK = new XSound("ANVIL_BREAK");
    public static final /* enum */ XSound BLOCK_ANVIL_DESTROY = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANVIL_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ANVIL_HIT = new XSound("BLOCK_ANVIL_FALL");
    public static final /* enum */ XSound BLOCK_ANVIL_LAND = new XSound("ANVIL_LAND");
    public static final /* enum */ XSound BLOCK_ANVIL_PLACE = new XSound("BLOCK_ANVIL_FALL");
    public static final /* enum */ XSound BLOCK_ANVIL_STEP = new XSound("BLOCK_ANVIL_FALL");
    public static final /* enum */ XSound BLOCK_ANVIL_USE = new XSound("ANVIL_USE");
    public static final /* enum */ XSound BLOCK_AZALEA_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_LEAVES_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_LEAVES_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_LEAVES_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_LEAVES_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_LEAVES_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_AZALEA_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_SAPLING_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_SAPLING_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_SAPLING_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_BUTTON_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_BUTTON_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_DOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_DOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_FENCE_GATE_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_FENCE_GATE_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_HANGING_SIGN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_HANGING_SIGN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_HANGING_SIGN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_HANGING_SIGN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_HANGING_SIGN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_PRESSURE_PLATE_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_PRESSURE_PLATE_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_TRAPDOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BAMBOO_WOOD_TRAPDOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BARREL_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BARREL_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BASALT_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BASALT_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BASALT_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BASALT_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BASALT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEACON_ACTIVATE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEACON_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEACON_DEACTIVATE = new XSound("BLOCK_BEACON_AMBIENT");
    public static final /* enum */ XSound BLOCK_BEACON_POWER_SELECT = new XSound("BLOCK_BEACON_AMBIENT");
    public static final /* enum */ XSound BLOCK_BEEHIVE_DRIP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEEHIVE_ENTER = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEEHIVE_EXIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEEHIVE_SHEAR = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BEEHIVE_WORK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BELL_RESONATE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BELL_USE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_TILT_DOWN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BIG_DRIPLEAF_TILT_UP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BLASTFURNACE_FIRE_CRACKLE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BONE_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BONE_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BONE_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BONE_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BONE_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BREWING_STAND_BREW = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BUBBLE_COLUMN_BUBBLE_POP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BUBBLE_COLUMN_UPWARDS_INSIDE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BUBBLE_COLUMN_WHIRLPOOL_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_BUBBLE_COLUMN_WHIRLPOOL_INSIDE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAKE_ADD_CANDLE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CALCITE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CALCITE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CALCITE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CALCITE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CALCITE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAMPFIRE_CRACKLE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_EXTINGUISH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CANDLE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAVE_VINES_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAVE_VINES_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAVE_VINES_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAVE_VINES_PICK_BERRIES = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAVE_VINES_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CAVE_VINES_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHAIN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHAIN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHAIN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHAIN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHAIN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_LEAVES_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_LEAVES_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_LEAVES_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_LEAVES_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_LEAVES_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_SAPLING_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_SAPLING_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_SAPLING_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_SAPLING_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_SAPLING_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_BUTTON_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_BUTTON_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_DOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_DOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_FENCE_GATE_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_FENCE_GATE_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_HANGING_SIGN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_HANGING_SIGN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_HANGING_SIGN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_HANGING_SIGN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_HANGING_SIGN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_PRESSURE_PLATE_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_PRESSURE_PLATE_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_TRAPDOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHERRY_WOOD_TRAPDOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHEST_CLOSE = new XSound("CHEST_CLOSE", "ENTITY_CHEST_CLOSE");
    public static final /* enum */ XSound BLOCK_CHEST_LOCKED = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHEST_OPEN = new XSound("CHEST_OPEN", "ENTITY_CHEST_OPEN");
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_INSERT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_INSERT_ENCHANTED = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_PICKUP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_PICKUP_ENCHANTED = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHISELED_BOOKSHELF_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHORUS_FLOWER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CHORUS_FLOWER_GROW = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COMPARATOR_CLICK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COMPOSTER_EMPTY = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COMPOSTER_FILL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COMPOSTER_FILL_SUCCESS = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COMPOSTER_READY = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CONDUIT_ACTIVATE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CONDUIT_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CONDUIT_AMBIENT_SHORT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CONDUIT_ATTACK_TARGET = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CONDUIT_DEACTIVATE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COPPER_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COPPER_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COPPER_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COPPER_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_COPPER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CORAL_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CORAL_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CORAL_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CORAL_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CORAL_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_CROP_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DECORATED_POT_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DECORATED_POT_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DECORATED_POT_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DECORATED_POT_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DECORATED_POT_SHATTER = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DECORATED_POT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_BRICKS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_BRICKS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_BRICKS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_BRICKS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_BRICKS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_TILES_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_TILES_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_TILES_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_TILES_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DEEPSLATE_TILES_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DISPENSER_DISPENSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DISPENSER_FAIL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DISPENSER_LAUNCH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DRIPSTONE_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DRIPSTONE_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DRIPSTONE_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DRIPSTONE_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_DRIPSTONE_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ENCHANTMENT_TABLE_USE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ENDER_CHEST_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ENDER_CHEST_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_END_GATEWAY_SPAWN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_END_PORTAL_FRAME_FILL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_END_PORTAL_SPAWN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FENCE_GATE_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FENCE_GATE_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FIRE_AMBIENT = new XSound("FIRE");
    public static final /* enum */ XSound BLOCK_FIRE_EXTINGUISH = new XSound("FIZZ");
    public static final /* enum */ XSound BLOCK_FLOWERING_AZALEA_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FLOWERING_AZALEA_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FLOWERING_AZALEA_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FLOWERING_AZALEA_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FLOWERING_AZALEA_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGLIGHT_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGLIGHT_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGLIGHT_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGLIGHT_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGLIGHT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGSPAWN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGSPAWN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGSPAWN_HATCH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGSPAWN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGSPAWN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FROGSPAWN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FUNGUS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FUNGUS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FUNGUS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FUNGUS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FUNGUS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_FURNACE_FIRE_CRACKLE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GILDED_BLACKSTONE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GILDED_BLACKSTONE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GILDED_BLACKSTONE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GILDED_BLACKSTONE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GILDED_BLACKSTONE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GLASS_BREAK = new XSound("GLASS");
    public static final /* enum */ XSound BLOCK_GLASS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GLASS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GLASS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GLASS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRASS_BREAK = new XSound("DIG_GRASS");
    public static final /* enum */ XSound BLOCK_GRASS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRASS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRASS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRASS_STEP = new XSound("STEP_GRASS");
    public static final /* enum */ XSound BLOCK_GRAVEL_BREAK = new XSound("DIG_GRAVEL");
    public static final /* enum */ XSound BLOCK_GRAVEL_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRAVEL_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRAVEL_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GRAVEL_STEP = new XSound("STEP_GRAVEL");
    public static final /* enum */ XSound BLOCK_GRINDSTONE_USE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_GROWING_PLANT_CROP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_ROOTS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_ROOTS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_ROOTS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_ROOTS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_ROOTS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_SIGN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_SIGN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_SIGN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_SIGN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HANGING_SIGN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HONEY_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HONEY_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HONEY_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HONEY_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HONEY_BLOCK_SLIDE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_HONEY_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_IRON_DOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_IRON_DOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_IRON_TRAPDOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_IRON_TRAPDOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LADDER_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LADDER_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LADDER_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LADDER_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LADDER_STEP = new XSound("STEP_LADDER");
    public static final /* enum */ XSound BLOCK_LANTERN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LANTERN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LANTERN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LANTERN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LANTERN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LARGE_AMETHYST_BUD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LARGE_AMETHYST_BUD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LAVA_AMBIENT = new XSound("LAVA");
    public static final /* enum */ XSound BLOCK_LAVA_EXTINGUISH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LAVA_POP = new XSound("LAVA_POP");
    public static final /* enum */ XSound BLOCK_LEVER_CLICK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LILY_PAD_PLACE = new XSound("BLOCK_WATERLILY_PLACE");
    public static final /* enum */ XSound BLOCK_LODESTONE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LODESTONE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LODESTONE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LODESTONE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_LODESTONE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MANGROVE_ROOTS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MANGROVE_ROOTS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MANGROVE_ROOTS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MANGROVE_ROOTS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MANGROVE_ROOTS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MEDIUM_AMETHYST_BUD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MEDIUM_AMETHYST_BUD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_METAL_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_METAL_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_METAL_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_METAL_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_METAL_PRESSURE_PLATE_CLICK_OFF = new XSound("BLOCK_METAL_PRESSUREPLATE_CLICK_OFF");
    public static final /* enum */ XSound BLOCK_METAL_PRESSURE_PLATE_CLICK_ON = new XSound("BLOCK_METAL_PRESSUREPLATE_CLICK_ON");
    public static final /* enum */ XSound BLOCK_METAL_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_CARPET_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_CARPET_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_CARPET_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_CARPET_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_CARPET_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MOSS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUDDY_MANGROVE_ROOTS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUDDY_MANGROVE_ROOTS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUDDY_MANGROVE_ROOTS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUDDY_MANGROVE_ROOTS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUDDY_MANGROVE_ROOTS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_BRICKS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_BRICKS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_BRICKS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_BRICKS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_BRICKS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_MUD_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERITE_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERITE_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERITE_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERITE_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERITE_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERRACK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERRACK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERRACK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERRACK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHERRACK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_BRICKS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_BRICKS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_BRICKS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_BRICKS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_BRICKS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_GOLD_ORE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_GOLD_ORE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_GOLD_ORE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_GOLD_ORE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_GOLD_ORE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_ORE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_ORE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_ORE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_ORE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_ORE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_SPROUTS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_SPROUTS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_SPROUTS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_SPROUTS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_SPROUTS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WART_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_BUTTON_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_BUTTON_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_DOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_DOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_FENCE_GATE_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_FENCE_GATE_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_HANGING_SIGN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_HANGING_SIGN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_HANGING_SIGN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_HANGING_SIGN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_HANGING_SIGN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_PRESSURE_PLATE_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_PRESSURE_PLATE_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_TRAPDOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NETHER_WOOD_TRAPDOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_BANJO = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_BASEDRUM = new XSound("NOTE_BASS_DRUM", "BLOCK_NOTE_BASEDRUM");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_BASS = new XSound("NOTE_BASS", "BLOCK_NOTE_BASS");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_BELL = new XSound("BLOCK_NOTE_BELL");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_BIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_CHIME = new XSound("BLOCK_NOTE_CHIME");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_COW_BELL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_DIDGERIDOO = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_FLUTE = new XSound("BLOCK_NOTE_FLUTE");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_GUITAR = new XSound("NOTE_BASS_GUITAR", "BLOCK_NOTE_GUITAR");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_HARP = new XSound("NOTE_PIANO", "BLOCK_NOTE_HARP");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_HAT = new XSound("NOTE_STICKS", "BLOCK_NOTE_HAT");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IMITATE_CREEPER = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IMITATE_ENDER_DRAGON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IMITATE_PIGLIN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IMITATE_SKELETON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IMITATE_WITHER_SKELETON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IMITATE_ZOMBIE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_IRON_XYLOPHONE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_PLING = new XSound("NOTE_PLING", "BLOCK_NOTE_PLING");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_SNARE = new XSound("NOTE_SNARE_DRUM", "BLOCK_NOTE_SNARE");
    public static final /* enum */ XSound BLOCK_NOTE_BLOCK_XYLOPHONE = new XSound("BLOCK_NOTE_XYLOPHONE");
    public static final /* enum */ XSound BLOCK_NYLIUM_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NYLIUM_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NYLIUM_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NYLIUM_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_NYLIUM_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PACKED_MUD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PACKED_MUD_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PACKED_MUD_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PACKED_MUD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PACKED_MUD_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PINK_PETALS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PINK_PETALS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PINK_PETALS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PINK_PETALS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PINK_PETALS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PISTON_CONTRACT = new XSound("PISTON_RETRACT");
    public static final /* enum */ XSound BLOCK_PISTON_EXTEND = new XSound("PISTON_EXTEND");
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_DRIP_LAVA = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_DRIP_LAVA_INTO_CAULDRON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_DRIP_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_DRIP_WATER_INTO_CAULDRON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POINTED_DRIPSTONE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POLISHED_DEEPSLATE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POLISHED_DEEPSLATE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POLISHED_DEEPSLATE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POLISHED_DEEPSLATE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POLISHED_DEEPSLATE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PORTAL_AMBIENT = new XSound("PORTAL");
    public static final /* enum */ XSound BLOCK_PORTAL_TRAVEL = new XSound("PORTAL_TRAVEL");
    public static final /* enum */ XSound BLOCK_PORTAL_TRIGGER = new XSound("PORTAL_TRIGGER");
    public static final /* enum */ XSound BLOCK_POWDER_SNOW_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POWDER_SNOW_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POWDER_SNOW_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POWDER_SNOW_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_POWDER_SNOW_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_PUMPKIN_CARVE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_REDSTONE_TORCH_BURNOUT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_RESPAWN_ANCHOR_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_RESPAWN_ANCHOR_CHARGE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_RESPAWN_ANCHOR_DEPLETE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_RESPAWN_ANCHOR_SET_SPAWN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTED_DIRT_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTED_DIRT_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTED_DIRT_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTED_DIRT_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTED_DIRT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTS_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_ROOTS_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SAND_BREAK = new XSound("DIG_SAND");
    public static final /* enum */ XSound BLOCK_SAND_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SAND_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SAND_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SAND_STEP = new XSound("STEP_SAND");
    public static final /* enum */ XSound BLOCK_SCAFFOLDING_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCAFFOLDING_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCAFFOLDING_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCAFFOLDING_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCAFFOLDING_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CATALYST_BLOOM = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CATALYST_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CATALYST_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CATALYST_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CATALYST_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CATALYST_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_CHARGE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_CLICKING = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_CLICKING_STOP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SENSOR_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SHRIEKER_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SHRIEKER_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SHRIEKER_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SHRIEKER_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SHRIEKER_SHRIEK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SHRIEKER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_SPREAD = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_VEIN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_VEIN_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_VEIN_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_VEIN_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SCULK_VEIN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHROOMLIGHT_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHROOMLIGHT_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHROOMLIGHT_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHROOMLIGHT_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHROOMLIGHT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHULKER_BOX_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SHULKER_BOX_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SIGN_WAXED_INTERACT_FAIL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SLIME_BLOCK_BREAK = new XSound("BLOCK_SLIME_BREAK");
    public static final /* enum */ XSound BLOCK_SLIME_BLOCK_FALL = new XSound("BLOCK_SLIME_FALL");
    public static final /* enum */ XSound BLOCK_SLIME_BLOCK_HIT = new XSound("BLOCK_SLIME_HIT");
    public static final /* enum */ XSound BLOCK_SLIME_BLOCK_PLACE = new XSound("BLOCK_SLIME_PLACE");
    public static final /* enum */ XSound BLOCK_SLIME_BLOCK_STEP = new XSound("BLOCK_SLIME_STEP");
    public static final /* enum */ XSound BLOCK_SMALL_AMETHYST_BUD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMALL_AMETHYST_BUD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMALL_DRIPLEAF_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMALL_DRIPLEAF_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMALL_DRIPLEAF_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMALL_DRIPLEAF_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMALL_DRIPLEAF_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMITHING_TABLE_USE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SMOKER_SMOKE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNIFFER_EGG_CRACK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNIFFER_EGG_HATCH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNIFFER_EGG_PLOP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNOW_BREAK = new XSound("DIG_SNOW");
    public static final /* enum */ XSound BLOCK_SNOW_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNOW_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNOW_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SNOW_STEP = new XSound("STEP_SNOW");
    public static final /* enum */ XSound BLOCK_SOUL_SAND_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SAND_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SAND_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SAND_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SAND_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SOIL_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SOIL_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SOIL_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SOIL_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SOUL_SOIL_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SPORE_BLOSSOM_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SPORE_BLOSSOM_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SPORE_BLOSSOM_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SPORE_BLOSSOM_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SPORE_BLOSSOM_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STEM_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STEM_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STEM_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STEM_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STEM_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STONE_BREAK = new XSound("DIG_STONE");
    public static final /* enum */ XSound BLOCK_STONE_BUTTON_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STONE_BUTTON_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STONE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STONE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STONE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_STONE_PRESSURE_PLATE_CLICK_OFF = new XSound("BLOCK_STONE_PRESSUREPLATE_CLICK_OFF");
    public static final /* enum */ XSound BLOCK_STONE_PRESSURE_PLATE_CLICK_ON = new XSound("BLOCK_STONE_PRESSUREPLATE_CLICK_ON");
    public static final /* enum */ XSound BLOCK_STONE_STEP = new XSound("STEP_STONE");
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_GRAVEL_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_GRAVEL_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_GRAVEL_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_GRAVEL_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_GRAVEL_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_SAND_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_SAND_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_SAND_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_SAND_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SUSPICIOUS_SAND_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SWEET_BERRY_BUSH_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES = new XSound("ITEM_SWEET_BERRIES_PICK_FROM_BUSH");
    public static final /* enum */ XSound BLOCK_SWEET_BERRY_BUSH_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TRIPWIRE_ATTACH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TRIPWIRE_CLICK_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TRIPWIRE_CLICK_ON = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TRIPWIRE_DETACH = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TUFF_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TUFF_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TUFF_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TUFF_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_TUFF_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_VINE_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_VINE_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_VINE_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_VINE_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_VINE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WART_BLOCK_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WART_BLOCK_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WART_BLOCK_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WART_BLOCK_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WART_BLOCK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WATER_AMBIENT = new XSound("WATER");
    public static final /* enum */ XSound BLOCK_WEEPING_VINES_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WEEPING_VINES_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WEEPING_VINES_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WEEPING_VINES_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WEEPING_VINES_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WET_GRASS_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WET_GRASS_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WET_GRASS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WET_GRASS_PLACE = new XSound("BLOCK_WET_GRASS_HIT");
    public static final /* enum */ XSound BLOCK_WET_GRASS_STEP = new XSound("BLOCK_WET_GRASS_HIT");
    public static final /* enum */ XSound BLOCK_WOODEN_BUTTON_CLICK_OFF = new XSound("WOOD_CLICK", "BLOCK_WOOD_BUTTON_CLICK_OFF");
    public static final /* enum */ XSound BLOCK_WOODEN_BUTTON_CLICK_ON = new XSound("WOOD_CLICK", "BLOCK_WOOD_BUTTON_CLICK_ON");
    public static final /* enum */ XSound BLOCK_WOODEN_DOOR_CLOSE = new XSound("DOOR_CLOSE");
    public static final /* enum */ XSound BLOCK_WOODEN_DOOR_OPEN = new XSound("DOOR_OPEN");
    public static final /* enum */ XSound BLOCK_WOODEN_PRESSURE_PLATE_CLICK_OFF = new XSound("BLOCK_WOOD_PRESSUREPLATE_CLICK_OFF");
    public static final /* enum */ XSound BLOCK_WOODEN_PRESSURE_PLATE_CLICK_ON = new XSound("BLOCK_WOOD_PRESSUREPLATE_CLICK_ON");
    public static final /* enum */ XSound BLOCK_WOODEN_TRAPDOOR_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WOODEN_TRAPDOOR_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WOOD_BREAK = new XSound("DIG_WOOD");
    public static final /* enum */ XSound BLOCK_WOOD_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WOOD_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WOOD_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WOOD_STEP = new XSound("STEP_WOOD");
    public static final /* enum */ XSound BLOCK_WOOL_BREAK = new XSound("DIG_WOOL", "BLOCK_CLOTH_BREAK");
    public static final /* enum */ XSound BLOCK_WOOL_FALL = new XSound(new String[0]);
    public static final /* enum */ XSound BLOCK_WOOL_HIT = new XSound("BLOCK_WOOL_FALL");
    public static final /* enum */ XSound BLOCK_WOOL_PLACE = new XSound("BLOCK_WOOL_FALL");
    public static final /* enum */ XSound BLOCK_WOOL_STEP = new XSound("STEP_WOOL", "BLOCK_CLOTH_STEP");
    public static final /* enum */ XSound ENCHANT_THORNS_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_AMBIENT_WITHOUT_ITEM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_AMBIENT_WITH_ITEM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_ITEM_GIVEN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_ITEM_TAKEN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ALLAY_ITEM_THROWN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ARMOR_STAND_BREAK = new XSound("ENTITY_ARMORSTAND_BREAK");
    public static final /* enum */ XSound ENTITY_ARMOR_STAND_FALL = new XSound("ENTITY_ARMORSTAND_FALL");
    public static final /* enum */ XSound ENTITY_ARMOR_STAND_HIT = new XSound("ENTITY_ARMORSTAND_HIT");
    public static final /* enum */ XSound ENTITY_ARMOR_STAND_PLACE = new XSound("ENTITY_ARMORSTAND_PLACE");
    public static final /* enum */ XSound ENTITY_ARROW_HIT = new XSound("ARROW_HIT");
    public static final /* enum */ XSound ENTITY_ARROW_HIT_PLAYER = new XSound("SUCCESSFUL_HIT");
    public static final /* enum */ XSound ENTITY_ARROW_SHOOT = new XSound("SHOOT_ARROW");
    public static final /* enum */ XSound ENTITY_AXOLOTL_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_AXOLOTL_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_AXOLOTL_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_AXOLOTL_IDLE_AIR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_AXOLOTL_IDLE_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_AXOLOTL_SPLASH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_AXOLOTL_SWIM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BAT_AMBIENT = new XSound("BAT_IDLE");
    public static final /* enum */ XSound ENTITY_BAT_DEATH = new XSound("BAT_DEATH");
    public static final /* enum */ XSound ENTITY_BAT_HURT = new XSound("BAT_HURT");
    public static final /* enum */ XSound ENTITY_BAT_LOOP = new XSound("BAT_LOOP");
    public static final /* enum */ XSound ENTITY_BAT_TAKEOFF = new XSound("BAT_TAKEOFF");
    public static final /* enum */ XSound ENTITY_BEE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BEE_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BEE_LOOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BEE_LOOP_AGGRESSIVE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BEE_POLLINATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BEE_STING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BLAZE_AMBIENT = new XSound("BLAZE_BREATH");
    public static final /* enum */ XSound ENTITY_BLAZE_BURN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BLAZE_DEATH = new XSound("BLAZE_DEATH");
    public static final /* enum */ XSound ENTITY_BLAZE_HURT = new XSound("BLAZE_HIT");
    public static final /* enum */ XSound ENTITY_BLAZE_SHOOT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BOAT_PADDLE_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_BOAT_PADDLE_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_DASH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_DASH_READY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_SADDLE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_SIT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_STAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAMEL_STEP_SAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAT_AMBIENT = new XSound("CAT_MEOW");
    public static final /* enum */ XSound ENTITY_CAT_BEG_FOR_FOOD = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAT_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAT_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CAT_HISS = new XSound("CAT_HISS");
    public static final /* enum */ XSound ENTITY_CAT_HURT = new XSound("CAT_HIT");
    public static final /* enum */ XSound ENTITY_CAT_PURR = new XSound("CAT_PURR");
    public static final /* enum */ XSound ENTITY_CAT_PURREOW = new XSound("CAT_PURREOW");
    public static final /* enum */ XSound ENTITY_CAT_STRAY_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CHICKEN_AMBIENT = new XSound("CHICKEN_IDLE");
    public static final /* enum */ XSound ENTITY_CHICKEN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CHICKEN_EGG = new XSound("CHICKEN_EGG_POP");
    public static final /* enum */ XSound ENTITY_CHICKEN_HURT = new XSound("CHICKEN_HURT");
    public static final /* enum */ XSound ENTITY_CHICKEN_STEP = new XSound("CHICKEN_WALK");
    public static final /* enum */ XSound ENTITY_COD_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_COD_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_COD_FLOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_COD_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_COW_AMBIENT = new XSound("COW_IDLE");
    public static final /* enum */ XSound ENTITY_COW_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_COW_HURT = new XSound("COW_HURT");
    public static final /* enum */ XSound ENTITY_COW_MILK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_COW_STEP = new XSound("COW_WALK");
    public static final /* enum */ XSound ENTITY_CREEPER_DEATH = new XSound("CREEPER_DEATH");
    public static final /* enum */ XSound ENTITY_CREEPER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_CREEPER_PRIMED = new XSound("CREEPER_HISS");
    public static final /* enum */ XSound ENTITY_DOLPHIN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_AMBIENT_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_JUMP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_PLAY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_SPLASH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DOLPHIN_SWIM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DONKEY_AMBIENT = new XSound("DONKEY_IDLE");
    public static final /* enum */ XSound ENTITY_DONKEY_ANGRY = new XSound("DONKEY_ANGRY");
    public static final /* enum */ XSound ENTITY_DONKEY_CHEST = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DONKEY_DEATH = new XSound("DONKEY_DEATH");
    public static final /* enum */ XSound ENTITY_DONKEY_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DONKEY_HURT = new XSound("DONKEY_HIT");
    public static final /* enum */ XSound ENTITY_DRAGON_FIREBALL_EXPLODE = new XSound("ENTITY_ENDERDRAGON_FIREBALL_EXPLODE");
    public static final /* enum */ XSound ENTITY_DROWNED_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_AMBIENT_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_DEATH_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_HURT_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_SHOOT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_DROWNED_SWIM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_EGG_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_AMBIENT_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_CURSE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_DEATH_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_FLOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ELDER_GUARDIAN_HURT_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ENDERMAN_AMBIENT = new XSound("ENDERMAN_IDLE", "ENTITY_ENDERMEN_AMBIENT");
    public static final /* enum */ XSound ENTITY_ENDERMAN_DEATH = new XSound("ENDERMAN_DEATH", "ENTITY_ENDERMEN_DEATH");
    public static final /* enum */ XSound ENTITY_ENDERMAN_HURT = new XSound("ENDERMAN_HIT", "ENTITY_ENDERMEN_HURT");
    public static final /* enum */ XSound ENTITY_ENDERMAN_SCREAM = new XSound("ENDERMAN_SCREAM", "ENTITY_ENDERMEN_SCREAM");
    public static final /* enum */ XSound ENTITY_ENDERMAN_STARE = new XSound("ENDERMAN_STARE", "ENTITY_ENDERMEN_STARE");
    public static final /* enum */ XSound ENTITY_ENDERMAN_TELEPORT = new XSound("ENDERMAN_TELEPORT", "ENTITY_ENDERMEN_TELEPORT");
    public static final /* enum */ XSound ENTITY_ENDERMITE_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ENDERMITE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ENDERMITE_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ENDERMITE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ENDER_DRAGON_AMBIENT = new XSound("ENDERDRAGON_WINGS", "ENTITY_ENDERDRAGON_AMBIENT");
    public static final /* enum */ XSound ENTITY_ENDER_DRAGON_DEATH = new XSound("ENDERDRAGON_DEATH", "ENTITY_ENDERDRAGON_DEATH");
    public static final /* enum */ XSound ENTITY_ENDER_DRAGON_FLAP = new XSound("ENDERDRAGON_WINGS", "ENTITY_ENDERDRAGON_FLAP");
    public static final /* enum */ XSound ENTITY_ENDER_DRAGON_GROWL = new XSound("ENDERDRAGON_GROWL", "ENTITY_ENDERDRAGON_GROWL");
    public static final /* enum */ XSound ENTITY_ENDER_DRAGON_HURT = new XSound("ENDERDRAGON_HIT", "ENTITY_ENDERDRAGON_HURT");
    public static final /* enum */ XSound ENTITY_ENDER_DRAGON_SHOOT = new XSound("ENTITY_ENDERDRAGON_SHOOT");
    public static final /* enum */ XSound ENTITY_ENDER_EYE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ENDER_EYE_LAUNCH = new XSound("ENTITY_ENDER_EYE_DEATH", "ENTITY_ENDEREYE_DEATH");
    public static final /* enum */ XSound ENTITY_ENDER_PEARL_THROW = new XSound("ENTITY_ENDERPEARL_THROW");
    public static final /* enum */ XSound ENTITY_EVOKER_AMBIENT = new XSound("ENTITY_EVOCATION_ILLAGER_AMBIENT");
    public static final /* enum */ XSound ENTITY_EVOKER_CAST_SPELL = new XSound("ENTITY_EVOCATION_ILLAGER_CAST_SPELL");
    public static final /* enum */ XSound ENTITY_EVOKER_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_EVOKER_DEATH = new XSound("ENTITY_EVOCATION_ILLAGER_DEATH");
    public static final /* enum */ XSound ENTITY_EVOKER_FANGS_ATTACK = new XSound("ENTITY_EVOCATION_FANGS_ATTACK");
    public static final /* enum */ XSound ENTITY_EVOKER_HURT = new XSound("ENTITY_EVOCATION_ILLAGER_HURT");
    public static final /* enum */ XSound ENTITY_EVOKER_PREPARE_ATTACK = new XSound("ENTITY_EVOCATION_ILLAGER_PREPARE_ATTACK");
    public static final /* enum */ XSound ENTITY_EVOKER_PREPARE_SUMMON = new XSound("ENTITY_EVOCATION_ILLAGER_PREPARE_SUMMON");
    public static final /* enum */ XSound ENTITY_EVOKER_PREPARE_WOLOLO = new XSound("ENTITY_EVOCATION_ILLAGER_PREPARE_WOLOLO");
    public static final /* enum */ XSound ENTITY_EXPERIENCE_BOTTLE_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_EXPERIENCE_ORB_PICKUP = new XSound("ORB_PICKUP");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_BLAST = new XSound("FIREWORK_BLAST", "ENTITY_FIREWORK_BLAST");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_BLAST_FAR = new XSound("FIREWORK_BLAST2", "ENTITY_FIREWORK_BLAST_FAR");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_LARGE_BLAST = new XSound("FIREWORK_LARGE_BLAST", "ENTITY_FIREWORK_LARGE_BLAST");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_LARGE_BLAST_FAR = new XSound("FIREWORK_LARGE_BLAST2", "ENTITY_FIREWORK_LARGE_BLAST_FAR");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_LAUNCH = new XSound("FIREWORK_LAUNCH", "ENTITY_FIREWORK_LAUNCH");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_SHOOT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_TWINKLE = new XSound("FIREWORK_TWINKLE", "ENTITY_FIREWORK_TWINKLE");
    public static final /* enum */ XSound ENTITY_FIREWORK_ROCKET_TWINKLE_FAR = new XSound("FIREWORK_TWINKLE2", "ENTITY_FIREWORK_TWINKLE_FAR");
    public static final /* enum */ XSound ENTITY_FISHING_BOBBER_RETRIEVE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FISHING_BOBBER_SPLASH = new XSound("SPLASH2", "ENTITY_BOBBER_SPLASH");
    public static final /* enum */ XSound ENTITY_FISHING_BOBBER_THROW = new XSound("ENTITY_BOBBER_THROW");
    public static final /* enum */ XSound ENTITY_FISH_SWIM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_AGGRO = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_BITE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_SCREECH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_SLEEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_SNIFF = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_SPIT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FOX_TELEPORT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_LAY_SPAWN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_LONG_JUMP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_FROG_TONGUE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GENERIC_BIG_FALL = new XSound("FALL_BIG");
    public static final /* enum */ XSound ENTITY_GENERIC_BURN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GENERIC_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GENERIC_DRINK = new XSound("DRINK");
    public static final /* enum */ XSound ENTITY_GENERIC_EAT = new XSound("EAT");
    public static final /* enum */ XSound ENTITY_GENERIC_EXPLODE = new XSound("EXPLODE");
    public static final /* enum */ XSound ENTITY_GENERIC_EXTINGUISH_FIRE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GENERIC_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GENERIC_SMALL_FALL = new XSound("FALL_SMALL");
    public static final /* enum */ XSound ENTITY_GENERIC_SPLASH = new XSound("SPLASH");
    public static final /* enum */ XSound ENTITY_GENERIC_SWIM = new XSound("SWIM");
    public static final /* enum */ XSound ENTITY_GHAST_AMBIENT = new XSound("GHAST_MOAN");
    public static final /* enum */ XSound ENTITY_GHAST_DEATH = new XSound("GHAST_DEATH");
    public static final /* enum */ XSound ENTITY_GHAST_HURT = new XSound("GHAST_SCREAM2");
    public static final /* enum */ XSound ENTITY_GHAST_SCREAM = new XSound("GHAST_SCREAM");
    public static final /* enum */ XSound ENTITY_GHAST_SHOOT = new XSound("GHAST_FIREBALL");
    public static final /* enum */ XSound ENTITY_GHAST_WARN = new XSound("GHAST_CHARGE");
    public static final /* enum */ XSound ENTITY_GLOW_ITEM_FRAME_ADD_ITEM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_ITEM_FRAME_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_ITEM_FRAME_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_ITEM_FRAME_REMOVE_ITEM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_ITEM_FRAME_ROTATE_ITEM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_SQUID_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_SQUID_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_SQUID_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GLOW_SQUID_SQUIRT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_HORN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_LONG_JUMP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_MILK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_PREPARE_RAM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_RAM_IMPACT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_HORN_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_LONG_JUMP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_MILK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_PREPARE_RAM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_SCREAMING_RAM_IMPACT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GOAT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_AMBIENT_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_DEATH_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_FLOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_GUARDIAN_HURT_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_CONVERTED_TO_ZOMBIFIED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_RETREAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOGLIN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HORSE_AMBIENT = new XSound("HORSE_IDLE");
    public static final /* enum */ XSound ENTITY_HORSE_ANGRY = new XSound("HORSE_ANGRY");
    public static final /* enum */ XSound ENTITY_HORSE_ARMOR = new XSound("HORSE_ARMOR");
    public static final /* enum */ XSound ENTITY_HORSE_BREATHE = new XSound("HORSE_BREATHE");
    public static final /* enum */ XSound ENTITY_HORSE_DEATH = new XSound("HORSE_DEATH");
    public static final /* enum */ XSound ENTITY_HORSE_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HORSE_GALLOP = new XSound("HORSE_GALLOP");
    public static final /* enum */ XSound ENTITY_HORSE_HURT = new XSound("HORSE_HIT");
    public static final /* enum */ XSound ENTITY_HORSE_JUMP = new XSound("HORSE_JUMP");
    public static final /* enum */ XSound ENTITY_HORSE_LAND = new XSound("HORSE_LAND");
    public static final /* enum */ XSound ENTITY_HORSE_SADDLE = new XSound("HORSE_SADDLE");
    public static final /* enum */ XSound ENTITY_HORSE_STEP = new XSound("HORSE_SOFT");
    public static final /* enum */ XSound ENTITY_HORSE_STEP_WOOD = new XSound("HORSE_WOOD");
    public static final /* enum */ XSound ENTITY_HOSTILE_BIG_FALL = new XSound("FALL_BIG");
    public static final /* enum */ XSound ENTITY_HOSTILE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOSTILE_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HOSTILE_SMALL_FALL = new XSound("FALL_SMALL");
    public static final /* enum */ XSound ENTITY_HOSTILE_SPLASH = new XSound("SPLASH");
    public static final /* enum */ XSound ENTITY_HOSTILE_SWIM = new XSound("SWIM");
    public static final /* enum */ XSound ENTITY_HUSK_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HUSK_CONVERTED_TO_ZOMBIE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HUSK_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HUSK_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_HUSK_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ILLUSIONER_AMBIENT = new XSound("ENTITY_ILLUSION_ILLAGER_AMBIENT");
    public static final /* enum */ XSound ENTITY_ILLUSIONER_CAST_SPELL = new XSound("ENTITY_ILLUSION_ILLAGER_CAST_SPELL");
    public static final /* enum */ XSound ENTITY_ILLUSIONER_DEATH = new XSound("ENTITY_ILLUSIONER_CAST_DEATH", "ENTITY_ILLUSION_ILLAGER_DEATH");
    public static final /* enum */ XSound ENTITY_ILLUSIONER_HURT = new XSound("ENTITY_ILLUSION_ILLAGER_HURT");
    public static final /* enum */ XSound ENTITY_ILLUSIONER_MIRROR_MOVE = new XSound("ENTITY_ILLUSION_ILLAGER_MIRROR_MOVE");
    public static final /* enum */ XSound ENTITY_ILLUSIONER_PREPARE_BLINDNESS = new XSound("ENTITY_ILLUSION_ILLAGER_PREPARE_BLINDNESS");
    public static final /* enum */ XSound ENTITY_ILLUSIONER_PREPARE_MIRROR = new XSound("ENTITY_ILLUSION_ILLAGER_PREPARE_MIRROR");
    public static final /* enum */ XSound ENTITY_IRON_GOLEM_ATTACK = new XSound("IRONGOLEM_THROW", "ENTITY_IRONGOLEM_ATTACK");
    public static final /* enum */ XSound ENTITY_IRON_GOLEM_DAMAGE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_IRON_GOLEM_DEATH = new XSound("IRONGOLEM_DEATH", "ENTITY_IRONGOLEM_DEATH");
    public static final /* enum */ XSound ENTITY_IRON_GOLEM_HURT = new XSound("IRONGOLEM_HIT", "ENTITY_IRONGOLEM_HURT");
    public static final /* enum */ XSound ENTITY_IRON_GOLEM_REPAIR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_IRON_GOLEM_STEP = new XSound("IRONGOLEM_WALK", "ENTITY_IRONGOLEM_STEP");
    public static final /* enum */ XSound ENTITY_ITEM_BREAK = new XSound("ITEM_BREAK");
    public static final /* enum */ XSound ENTITY_ITEM_FRAME_ADD_ITEM = new XSound("ENTITY_ITEMFRAME_ADD_ITEM");
    public static final /* enum */ XSound ENTITY_ITEM_FRAME_BREAK = new XSound("ENTITY_ITEMFRAME_BREAK");
    public static final /* enum */ XSound ENTITY_ITEM_FRAME_PLACE = new XSound("ENTITY_ITEMFRAME_PLACE");
    public static final /* enum */ XSound ENTITY_ITEM_FRAME_REMOVE_ITEM = new XSound("ENTITY_ITEMFRAME_REMOVE_ITEM");
    public static final /* enum */ XSound ENTITY_ITEM_FRAME_ROTATE_ITEM = new XSound("ENTITY_ITEMFRAME_ROTATE_ITEM");
    public static final /* enum */ XSound ENTITY_ITEM_PICKUP = new XSound("ITEM_PICKUP");
    public static final /* enum */ XSound ENTITY_LEASH_KNOT_BREAK = new XSound("ENTITY_LEASHKNOT_BREAK");
    public static final /* enum */ XSound ENTITY_LEASH_KNOT_PLACE = new XSound("ENTITY_LEASHKNOT_PLACE");
    public static final /* enum */ XSound ENTITY_LIGHTNING_BOLT_IMPACT = new XSound("AMBIENCE_THUNDER", "ENTITY_LIGHTNING_IMPACT");
    public static final /* enum */ XSound ENTITY_LIGHTNING_BOLT_THUNDER = new XSound("AMBIENCE_THUNDER", "ENTITY_LIGHTNING_THUNDER");
    public static final /* enum */ XSound ENTITY_LINGERING_POTION_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_CHEST = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_SPIT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_LLAMA_SWAG = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_DEATH = new XSound("ENTITY_MAGMACUBE_DEATH");
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_DEATH_SMALL = new XSound("ENTITY_SMALL_MAGMACUBE_DEATH");
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_HURT = new XSound("ENTITY_MAGMACUBE_HURT");
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_HURT_SMALL = new XSound("ENTITY_SMALL_MAGMACUBE_HURT");
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_JUMP = new XSound("MAGMACUBE_JUMP", "ENTITY_MAGMACUBE_JUMP");
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_SQUISH = new XSound("MAGMACUBE_WALK", "ENTITY_MAGMACUBE_SQUISH");
    public static final /* enum */ XSound ENTITY_MAGMA_CUBE_SQUISH_SMALL = new XSound("MAGMACUBE_WALK2", "ENTITY_SMALL_MAGMACUBE_SQUISH");
    public static final /* enum */ XSound ENTITY_MINECART_INSIDE = new XSound("MINECART_INSIDE");
    public static final /* enum */ XSound ENTITY_MINECART_INSIDE_UNDERWATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MINECART_RIDING = new XSound("MINECART_BASE");
    public static final /* enum */ XSound ENTITY_MOOSHROOM_CONVERT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MOOSHROOM_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MOOSHROOM_MILK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MOOSHROOM_SHEAR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MOOSHROOM_SUSPICIOUS_MILK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MULE_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MULE_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MULE_CHEST = new XSound("ENTITY_MULE_AMBIENT");
    public static final /* enum */ XSound ENTITY_MULE_DEATH = new XSound("ENTITY_MULE_AMBIENT");
    public static final /* enum */ XSound ENTITY_MULE_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_MULE_HURT = new XSound("ENTITY_MULE_AMBIENT");
    public static final /* enum */ XSound ENTITY_OCELOT_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_OCELOT_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_OCELOT_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PAINTING_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PAINTING_PLACE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_AGGRESSIVE_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_BITE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_CANT_BREED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_PRE_SNEEZE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_SNEEZE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PANDA_WORRIED_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_FLY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_BLAZE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_CREEPER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_DROWNED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ELDER_GUARDIAN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ENDERMAN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ENDERMITE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ENDER_DRAGON = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_EVOKER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_GHAST = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_GUARDIAN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_HOGLIN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_HUSK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ILLUSIONER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_MAGMA_CUBE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_PHANTOM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_PIGLIN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_PIGLIN_BRUTE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_PILLAGER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_POLAR_BEAR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_RAVAGER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_SHULKER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_SILVERFISH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_SKELETON = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_SLIME = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_SPIDER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_STRAY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_VEX = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_VINDICATOR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_WARDEN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_WITCH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_WITHER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_WITHER_SKELETON = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_WOLF = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ZOGLIN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ZOMBIE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_IMITATE_ZOMBIE_VILLAGER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PARROT_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PHANTOM_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PHANTOM_BITE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PHANTOM_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PHANTOM_FLAP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PHANTOM_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PHANTOM_SWOOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_ADMIRING_ITEM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_BRUTE_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_BRUTE_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_BRUTE_CONVERTED_TO_ZOMBIFIED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_BRUTE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_BRUTE_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_BRUTE_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_CONVERTED_TO_ZOMBIFIED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_JEALOUS = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_RETREAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIGLIN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIG_AMBIENT = new XSound("PIG_IDLE");
    public static final /* enum */ XSound ENTITY_PIG_DEATH = new XSound("PIG_DEATH");
    public static final /* enum */ XSound ENTITY_PIG_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PIG_SADDLE = new XSound("ENTITY_PIG_HURT");
    public static final /* enum */ XSound ENTITY_PIG_STEP = new XSound("PIG_WALK");
    public static final /* enum */ XSound ENTITY_PILLAGER_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PILLAGER_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PILLAGER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PILLAGER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_ATTACK_CRIT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_ATTACK_KNOCKBACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_ATTACK_NODAMAGE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_ATTACK_STRONG = new XSound("SUCCESSFUL_HIT");
    public static final /* enum */ XSound ENTITY_PLAYER_ATTACK_SWEEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_ATTACK_WEAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_BIG_FALL = new XSound("FALL_BIG");
    public static final /* enum */ XSound ENTITY_PLAYER_BREATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_BURP = new XSound("BURP");
    public static final /* enum */ XSound ENTITY_PLAYER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_HURT = new XSound("HURT_FLESH");
    public static final /* enum */ XSound ENTITY_PLAYER_HURT_DROWN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_HURT_FREEZE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_HURT_ON_FIRE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_HURT_SWEET_BERRY_BUSH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PLAYER_LEVELUP = new XSound("LEVEL_UP");
    public static final /* enum */ XSound ENTITY_PLAYER_SMALL_FALL = new XSound("FALL_SMALL");
    public static final /* enum */ XSound ENTITY_PLAYER_SPLASH = new XSound("SLASH");
    public static final /* enum */ XSound ENTITY_PLAYER_SPLASH_HIGH_SPEED = new XSound("SPLASH");
    public static final /* enum */ XSound ENTITY_PLAYER_SWIM = new XSound("SWIM");
    public static final /* enum */ XSound ENTITY_POLAR_BEAR_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_POLAR_BEAR_AMBIENT_BABY = new XSound("ENTITY_POLAR_BEAR_BABY_AMBIENT");
    public static final /* enum */ XSound ENTITY_POLAR_BEAR_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_POLAR_BEAR_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_POLAR_BEAR_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_POLAR_BEAR_WARNING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_BLOW_OUT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_BLOW_UP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_FLOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_PUFFER_FISH_STING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RABBIT_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RABBIT_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RABBIT_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RABBIT_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RABBIT_JUMP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_ROAR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_RAVAGER_STUNNED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SALMON_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SALMON_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SALMON_FLOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SALMON_HURT = new XSound("ENTITY_SALMON_FLOP");
    public static final /* enum */ XSound ENTITY_SHEEP_AMBIENT = new XSound("SHEEP_IDLE");
    public static final /* enum */ XSound ENTITY_SHEEP_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHEEP_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHEEP_SHEAR = new XSound("SHEEP_SHEAR");
    public static final /* enum */ XSound ENTITY_SHEEP_STEP = new XSound("SHEEP_WALK");
    public static final /* enum */ XSound ENTITY_SHULKER_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_BULLET_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_BULLET_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_HURT_CLOSED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_OPEN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_SHOOT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SHULKER_TELEPORT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SILVERFISH_AMBIENT = new XSound("SILVERFISH_IDLE");
    public static final /* enum */ XSound ENTITY_SILVERFISH_DEATH = new XSound("SILVERFISH_KILL");
    public static final /* enum */ XSound ENTITY_SILVERFISH_HURT = new XSound("SILVERFISH_HIT");
    public static final /* enum */ XSound ENTITY_SILVERFISH_STEP = new XSound("SILVERFISH_WALK");
    public static final /* enum */ XSound ENTITY_SKELETON_AMBIENT = new XSound("SKELETON_IDLE");
    public static final /* enum */ XSound ENTITY_SKELETON_CONVERTED_TO_STRAY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_DEATH = new XSound("SKELETON_DEATH");
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_AMBIENT = new XSound("HORSE_SKELETON_IDLE");
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_AMBIENT_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_DEATH = new XSound("HORSE_SKELETON_DEATH");
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_GALLOP_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_HURT = new XSound("HORSE_SKELETON_HIT");
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_JUMP_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_STEP_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_HORSE_SWIM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_HURT = new XSound("SKELETON_HURT");
    public static final /* enum */ XSound ENTITY_SKELETON_SHOOT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SKELETON_STEP = new XSound("SKELETON_WALK");
    public static final /* enum */ XSound ENTITY_SLIME_ATTACK = new XSound("SLIME_ATTACK");
    public static final /* enum */ XSound ENTITY_SLIME_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SLIME_DEATH_SMALL = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SLIME_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SLIME_HURT_SMALL = new XSound("ENTITY_SMALL_SLIME_HURT");
    public static final /* enum */ XSound ENTITY_SLIME_JUMP = new XSound("SLIME_WALK");
    public static final /* enum */ XSound ENTITY_SLIME_JUMP_SMALL = new XSound("SLIME_WALK2", "ENTITY_SMALL_SLIME_SQUISH");
    public static final /* enum */ XSound ENTITY_SLIME_SQUISH = new XSound("SLIME_WALK2");
    public static final /* enum */ XSound ENTITY_SLIME_SQUISH_SMALL = new XSound("ENTITY_SMALL_SLIME_SQUISH");
    public static final /* enum */ XSound ENTITY_SNIFFER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_DIGGING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_DIGGING_STOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_DROP_SEED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_HAPPY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_IDLE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_SCENTING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_SEARCHING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_SNIFFING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNIFFER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNOWBALL_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNOW_GOLEM_AMBIENT = new XSound("ENTITY_SNOWMAN_AMBIENT");
    public static final /* enum */ XSound ENTITY_SNOW_GOLEM_DEATH = new XSound("ENTITY_SNOWMAN_DEATH");
    public static final /* enum */ XSound ENTITY_SNOW_GOLEM_HURT = new XSound("ENTITY_SNOWMAN_HURT");
    public static final /* enum */ XSound ENTITY_SNOW_GOLEM_SHEAR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SNOW_GOLEM_SHOOT = new XSound("ENTITY_SNOWMAN_SHOOT");
    public static final /* enum */ XSound ENTITY_SPIDER_AMBIENT = new XSound("SPIDER_IDLE");
    public static final /* enum */ XSound ENTITY_SPIDER_DEATH = new XSound("SPIDER_DEATH");
    public static final /* enum */ XSound ENTITY_SPIDER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SPIDER_STEP = new XSound("SPIDER_WALK");
    public static final /* enum */ XSound ENTITY_SPLASH_POTION_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SPLASH_POTION_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SQUID_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SQUID_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SQUID_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_SQUID_SQUIRT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRAY_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRAY_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRAY_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRAY_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_EAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_HAPPY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_RETREAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_SADDLE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_STRIDER_STEP_LAVA = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TADPOLE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TADPOLE_FLOP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TADPOLE_GROW_UP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TADPOLE_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TNT_PRIMED = new XSound("FUSE");
    public static final /* enum */ XSound ENTITY_TROPICAL_FISH_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TROPICAL_FISH_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TROPICAL_FISH_FLOP = new XSound("ENTITY_TROPICAL_FISH_DEATH");
    public static final /* enum */ XSound ENTITY_TROPICAL_FISH_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_AMBIENT_LAND = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_DEATH_BABY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_EGG_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_EGG_CRACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_EGG_HATCH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_HURT_BABY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_LAY_EGG = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_SHAMBLE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_SHAMBLE_BABY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_TURTLE_SWIM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VEX_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VEX_CHARGE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VEX_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VEX_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_AMBIENT = new XSound("VILLAGER_IDLE");
    public static final /* enum */ XSound ENTITY_VILLAGER_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_DEATH = new XSound("VILLAGER_DEATH");
    public static final /* enum */ XSound ENTITY_VILLAGER_HURT = new XSound("VILLAGER_HIT");
    public static final /* enum */ XSound ENTITY_VILLAGER_NO = new XSound("VILLAGER_NO");
    public static final /* enum */ XSound ENTITY_VILLAGER_TRADE = new XSound("VILLAGER_HAGGLE", "ENTITY_VILLAGER_TRADING");
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_ARMORER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_BUTCHER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_CARTOGRAPHER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_CLERIC = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_FARMER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_FISHERMAN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_FLETCHER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_LEATHERWORKER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_LIBRARIAN = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_MASON = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_SHEPHERD = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_TOOLSMITH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_WORK_WEAPONSMITH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VILLAGER_YES = new XSound("VILLAGER_YES");
    public static final /* enum */ XSound ENTITY_VINDICATOR_AMBIENT = new XSound("ENTITY_VINDICATION_ILLAGER_AMBIENT");
    public static final /* enum */ XSound ENTITY_VINDICATOR_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_VINDICATOR_DEATH = new XSound("ENTITY_VINDICATION_ILLAGER_DEATH");
    public static final /* enum */ XSound ENTITY_VINDICATOR_HURT = new XSound("ENTITY_VINDICATION_ILLAGER_HURT");
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_DISAPPEARED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_DRINK_MILK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_DRINK_POTION = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_NO = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_REAPPEARED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_TRADE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WANDERING_TRADER_YES = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_AGITATED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_ATTACK_IMPACT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_DIG = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_EMERGE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_HEARTBEAT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_LISTENING = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_LISTENING_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_NEARBY_CLOSE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_NEARBY_CLOSER = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_NEARBY_CLOSEST = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_ROAR = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_SNIFF = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_SONIC_BOOM = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_SONIC_CHARGE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WARDEN_TENDRIL_CLICKS = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITCH_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITCH_CELEBRATE = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITCH_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITCH_DRINK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITCH_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITCH_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITHER_AMBIENT = new XSound("WITHER_IDLE");
    public static final /* enum */ XSound ENTITY_WITHER_BREAK_BLOCK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITHER_DEATH = new XSound("WITHER_DEATH");
    public static final /* enum */ XSound ENTITY_WITHER_HURT = new XSound("WITHER_HURT");
    public static final /* enum */ XSound ENTITY_WITHER_SHOOT = new XSound("WITHER_SHOOT");
    public static final /* enum */ XSound ENTITY_WITHER_SKELETON_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITHER_SKELETON_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITHER_SKELETON_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITHER_SKELETON_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_WITHER_SPAWN = new XSound("WITHER_SPAWN");
    public static final /* enum */ XSound ENTITY_WOLF_AMBIENT = new XSound("WOLF_BARK");
    public static final /* enum */ XSound ENTITY_WOLF_DEATH = new XSound("WOLF_DEATH");
    public static final /* enum */ XSound ENTITY_WOLF_GROWL = new XSound("WOLF_GROWL");
    public static final /* enum */ XSound ENTITY_WOLF_HOWL = new XSound("WOLF_HOWL");
    public static final /* enum */ XSound ENTITY_WOLF_HURT = new XSound("WOLF_HURT");
    public static final /* enum */ XSound ENTITY_WOLF_PANT = new XSound("WOLF_PANT");
    public static final /* enum */ XSound ENTITY_WOLF_SHAKE = new XSound("WOLF_SHAKE");
    public static final /* enum */ XSound ENTITY_WOLF_STEP = new XSound("WOLF_WALK");
    public static final /* enum */ XSound ENTITY_WOLF_WHINE = new XSound("WOLF_WHINE");
    public static final /* enum */ XSound ENTITY_ZOGLIN_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOGLIN_ANGRY = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOGLIN_ATTACK = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOGLIN_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOGLIN_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOGLIN_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIE_AMBIENT = new XSound("ZOMBIE_IDLE");
    public static final /* enum */ XSound ENTITY_ZOMBIE_ATTACK_IRON_DOOR = new XSound("ZOMBIE_METAL");
    public static final /* enum */ XSound ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR = new XSound("ZOMBIE_WOOD", "ENTITY_ZOMBIE_ATTACK_DOOR_WOOD");
    public static final /* enum */ XSound ENTITY_ZOMBIE_BREAK_WOODEN_DOOR = new XSound("ZOMBIE_WOODBREAK", "ENTITY_ZOMBIE_BREAK_DOOR_WOOD");
    public static final /* enum */ XSound ENTITY_ZOMBIE_CONVERTED_TO_DROWNED = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIE_DEATH = new XSound("ZOMBIE_DEATH");
    public static final /* enum */ XSound ENTITY_ZOMBIE_DESTROY_EGG = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIE_HORSE_AMBIENT = new XSound("HORSE_ZOMBIE_IDLE");
    public static final /* enum */ XSound ENTITY_ZOMBIE_HORSE_DEATH = new XSound("HORSE_ZOMBIE_DEATH");
    public static final /* enum */ XSound ENTITY_ZOMBIE_HORSE_HURT = new XSound("HORSE_ZOMBIE_HIT");
    public static final /* enum */ XSound ENTITY_ZOMBIE_HURT = new XSound("ZOMBIE_HURT");
    public static final /* enum */ XSound ENTITY_ZOMBIE_INFECT = new XSound("ZOMBIE_INFECT");
    public static final /* enum */ XSound ENTITY_ZOMBIE_STEP = new XSound("ZOMBIE_WALK");
    public static final /* enum */ XSound ENTITY_ZOMBIE_VILLAGER_AMBIENT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIE_VILLAGER_CONVERTED = new XSound("ZOMBIE_UNFECT");
    public static final /* enum */ XSound ENTITY_ZOMBIE_VILLAGER_CURE = new XSound("ZOMBIE_REMEDY");
    public static final /* enum */ XSound ENTITY_ZOMBIE_VILLAGER_DEATH = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIE_VILLAGER_HURT = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIE_VILLAGER_STEP = new XSound(new String[0]);
    public static final /* enum */ XSound ENTITY_ZOMBIFIED_PIGLIN_AMBIENT = new XSound("ZOMBIE_PIG_IDLE", "ENTITY_ZOMBIE_PIG_AMBIENT", "ENTITY_ZOMBIE_PIGMAN_AMBIENT");
    public static final /* enum */ XSound ENTITY_ZOMBIFIED_PIGLIN_ANGRY = new XSound("ZOMBIE_PIG_ANGRY", "ENTITY_ZOMBIE_PIG_ANGRY", "ENTITY_ZOMBIE_PIGMAN_ANGRY");
    public static final /* enum */ XSound ENTITY_ZOMBIFIED_PIGLIN_DEATH = new XSound("ZOMBIE_PIG_DEATH", "ENTITY_ZOMBIE_PIG_DEATH", "ENTITY_ZOMBIE_PIGMAN_DEATH");
    public static final /* enum */ XSound ENTITY_ZOMBIFIED_PIGLIN_HURT = new XSound("ZOMBIE_PIG_HURT", "ENTITY_ZOMBIE_PIG_HURT", "ENTITY_ZOMBIE_PIGMAN_HURT");
    public static final /* enum */ XSound EVENT_RAID_HORN = new XSound(new String[0]);
    public static final /* enum */ XSound INTENTIONALLY_EMPTY = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_CHAIN = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_DIAMOND = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_ELYTRA = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_GENERIC = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_GOLD = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_IRON = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_LEATHER = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_NETHERITE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ARMOR_EQUIP_TURTLE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_AXE_SCRAPE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_AXE_STRIP = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_AXE_WAX_OFF = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BONE_MEAL_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BOOK_PAGE_TURN = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BOOK_PUT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BOTTLE_EMPTY = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BOTTLE_FILL = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BOTTLE_FILL_DRAGONBREATH = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSHING = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSHING_GENERIC = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSHING_GRAVEL = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSHING_GRAVEL_COMPLETE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSHING_SAND = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSHING_SAND_COMPLETE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BRUSH_BRUSH_SAND_COMPLETED = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_EMPTY = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_EMPTY_AXOLOTL = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_EMPTY_FISH = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_EMPTY_LAVA = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_EMPTY_POWDER_SNOW = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_EMPTY_TADPOLE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_FILL = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_FILL_AXOLOTL = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_FILL_FISH = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_FILL_LAVA = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_FILL_POWDER_SNOW = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUCKET_FILL_TADPOLE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUNDLE_DROP_CONTENTS = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUNDLE_INSERT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_BUNDLE_REMOVE_ONE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CHORUS_FRUIT_TELEPORT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROP_PLANT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_LOADING_END = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_LOADING_MIDDLE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_LOADING_START = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_QUICK_CHARGE_1 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_QUICK_CHARGE_2 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_QUICK_CHARGE_3 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_CROSSBOW_SHOOT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_DYE_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_ELYTRA_FLYING = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_FIRECHARGE_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_FLINTANDSTEEL_USE = new XSound("FIRE_IGNITE");
    public static final /* enum */ XSound ITEM_GLOW_INK_SAC_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_PLAY = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_0 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_1 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_2 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_3 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_4 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_5 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_6 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_GOAT_HORN_SOUND_7 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_HOE_TILL = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_HONEYCOMB_WAX_ON = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_HONEY_BOTTLE_DRINK = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_INK_SAC_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_LODESTONE_COMPASS_LOCK = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_NETHER_WART_PLANT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_SHIELD_BLOCK = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_SHIELD_BREAK = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_SHOVEL_FLATTEN = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_SPYGLASS_STOP_USING = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_SPYGLASS_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TOTEM_USE = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TRIDENT_HIT = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TRIDENT_HIT_GROUND = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TRIDENT_RETURN = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TRIDENT_RIPTIDE_1 = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TRIDENT_RIPTIDE_2 = new XSound("ITEM_TRIDENT_RIPTIDE_1");
    public static final /* enum */ XSound ITEM_TRIDENT_RIPTIDE_3 = new XSound("ITEM_TRIDENT_RIPTIDE_1");
    public static final /* enum */ XSound ITEM_TRIDENT_THROW = new XSound(new String[0]);
    public static final /* enum */ XSound ITEM_TRIDENT_THUNDER = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_CREATIVE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_CREDITS = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_DISC_11 = new XSound("RECORD_11");
    public static final /* enum */ XSound MUSIC_DISC_13 = new XSound("RECORD_13");
    public static final /* enum */ XSound MUSIC_DISC_5 = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_DISC_BLOCKS = new XSound("RECORD_BLOCKS");
    public static final /* enum */ XSound MUSIC_DISC_CAT = new XSound("RECORD_CAT");
    public static final /* enum */ XSound MUSIC_DISC_CHIRP = new XSound("RECORD_CHIRP");
    public static final /* enum */ XSound MUSIC_DISC_FAR = new XSound("RECORD_FAR");
    public static final /* enum */ XSound MUSIC_DISC_MALL = new XSound("RECORD_MALL");
    public static final /* enum */ XSound MUSIC_DISC_MELLOHI = new XSound("RECORD_MELLOHI");
    public static final /* enum */ XSound MUSIC_DISC_OTHERSIDE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_DISC_PIGSTEP = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_DISC_RELIC = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_DISC_STAL = new XSound("RECORD_STAL");
    public static final /* enum */ XSound MUSIC_DISC_STRAD = new XSound("RECORD_STRAD");
    public static final /* enum */ XSound MUSIC_DISC_WAIT = new XSound("RECORD_WAIT");
    public static final /* enum */ XSound MUSIC_DISC_WARD = new XSound("RECORD_WARD");
    public static final /* enum */ XSound MUSIC_DRAGON = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_END = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_GAME = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_MENU = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_NETHER_BASALT_DELTAS = new XSound("MUSIC_NETHER");
    public static final /* enum */ XSound MUSIC_NETHER_CRIMSON_FOREST = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_NETHER_NETHER_WASTES = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_NETHER_SOUL_SAND_VALLEY = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_NETHER_WARPED_FOREST = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_BADLANDS = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_BAMBOO_JUNGLE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_CHERRY_GROVE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_DEEP_DARK = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_DESERT = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_DRIPSTONE_CAVES = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_FLOWER_FOREST = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_FOREST = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_FROZEN_PEAKS = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_GROVE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_JAGGED_PEAKS = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_JUNGLE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_JUNGLE_AND_FOREST = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_LUSH_CAVES = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_MEADOW = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_OLD_GROWTH_TAIGA = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_SNOWY_SLOPES = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_SPARSE_JUNGLE = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_STONY_PEAKS = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_OVERWORLD_SWAMP = new XSound(new String[0]);
    public static final /* enum */ XSound MUSIC_UNDER_WATER = new XSound(new String[0]);
    public static final /* enum */ XSound PARTICLE_SOUL_ESCAPE = new XSound(new String[0]);
    public static final /* enum */ XSound UI_BUTTON_CLICK = new XSound("CLICK");
    public static final /* enum */ XSound UI_CARTOGRAPHY_TABLE_TAKE_RESULT = new XSound(new String[0]);
    public static final /* enum */ XSound UI_LOOM_SELECT_PATTERN = new XSound(new String[0]);
    public static final /* enum */ XSound UI_LOOM_TAKE_RESULT = new XSound(new String[0]);
    public static final /* enum */ XSound UI_STONECUTTER_SELECT_RECIPE = new XSound(new String[0]);
    public static final /* enum */ XSound UI_STONECUTTER_TAKE_RESULT = new XSound(new String[0]);
    public static final /* enum */ XSound UI_TOAST_CHALLENGE_COMPLETE = new XSound(new String[0]);
    public static final /* enum */ XSound UI_TOAST_IN = new XSound(new String[0]);
    public static final /* enum */ XSound UI_TOAST_OUT = new XSound(new String[0]);
    public static final /* enum */ XSound WEATHER_RAIN = new XSound("AMBIENCE_RAIN");
    public static final /* enum */ XSound WEATHER_RAIN_ABOVE = new XSound(new String[0]);
    public static final XSound[] VALUES;
    public static final float DEFAULT_VOLUME = 1.0f;
    public static final float DEFAULT_PITCH = 1.0f;
    @Nullable
    private final Sound sound;
    private static final /* synthetic */ XSound[] $VALUES;

    public static XSound[] values() {
        return (XSound[])$VALUES.clone();
    }

    public static XSound valueOf(String string) {
        return Enum.valueOf(XSound.class, string);
    }

    private XSound(String ... arrstring) {
        Sound sound = Data.BUKKIT_NAMES.get(this.name());
        if (sound == null) {
            String string2;
            String[] arrstring2 = arrstring;
            int n2 = arrstring2.length;
            for (int i = 0; i < n2 && (sound = Data.BUKKIT_NAMES.get(string2 = arrstring2[i])) == null; ++i) {
            }
        }
        this.sound = sound;
        Data.NAMES.put(this.name(), this);
        for (String string2 : arrstring) {
            Data.NAMES.putIfAbsent(string2, this);
        }
    }

    @Nonnull
    private static String format(@Nonnull String string) {
        int n = string.length();
        char[] arrc = new char[n];
        int n2 = 0;
        boolean bl = false;
        for (int i = 0; i < n; ++i) {
            char c = string.charAt(i);
            if (!(bl || n2 == 0 || c != '-' && c != ' ' && c != '_' || arrc[n2] == '_')) {
                bl = true;
                continue;
            }
            boolean bl2 = false;
            if (!(c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z') && !(bl2 = c >= '0' && c <= '9')) continue;
            if (bl) {
                arrc[n2++] = 95;
                bl = false;
            }
            arrc[n2++] = bl2 ? c : (char)(c & 0x5F);
        }
        return new String(arrc, 0, n2);
    }

    @Nonnull
    public static Optional<XSound> matchXSound(@Nonnull String string) {
        if (string == null || string.isEmpty()) {
            throw new IllegalArgumentException("Cannot match XSound of a null or empty sound name");
        }
        return Optional.ofNullable(Data.NAMES.get(XSound.format(string)));
    }

    @Nonnull
    public static XSound matchXSound(@Nonnull Sound sound) {
        Objects.requireNonNull(sound, "Cannot match XSound of a null sound");
        return Objects.requireNonNull(Data.NAMES.get(sound.name()), () -> "Unsupported sound: " + sound.name());
    }

    private static List<String> split(@Nonnull String string, char c) {
        ArrayList<String> arrayList = new ArrayList<String>(5);
        boolean bl = false;
        boolean bl2 = false;
        int n = string.length();
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            if (string.charAt(i) == c) {
                if (bl) {
                    arrayList.add(string.substring(n2, i));
                    bl = false;
                    bl2 = true;
                }
                n2 = i + 1;
                continue;
            }
            bl2 = false;
            bl = true;
        }
        if (bl || bl2) {
            arrayList.add(string.substring(n2, n));
        }
        return arrayList;
    }

    @Nullable
    public static Record parse(@Nullable String string) {
        boolean bl;
        if (Strings.isNullOrEmpty((String)string) || string.equalsIgnoreCase("none")) {
            return null;
        }
        List<String> list = XSound.split(string.replace(" ", ""), ',');
        String string2 = list.get(0);
        if (string2.charAt(0) == '~') {
            string2 = string2.substring(1);
            bl = true;
        } else {
            bl = false;
        }
        if (string2.isEmpty()) {
            throw new IllegalArgumentException("No sound name specified: " + string);
        }
        Optional<XSound> optional = XSound.matchXSound(string2);
        if (!optional.isPresent()) {
            throw new IllegalArgumentException("Unknown sound: " + string2);
        }
        float f = 1.0f;
        float f2 = 1.0f;
        try {
            if (list.size() > 1) {
                f = Float.parseFloat(list.get(1));
            }
        }
        catch (NumberFormatException numberFormatException) {
            throw new NumberFormatException("Invalid number '" + list.get(1) + "' for sound volume '" + string + "'");
        }
        try {
            if (list.size() > 2) {
                f2 = Float.parseFloat(list.get(2));
            }
        }
        catch (NumberFormatException numberFormatException) {
            throw new NumberFormatException("Invalid number '" + list.get(2) + "' for sound pitch '" + string + "'");
        }
        return new Record(optional.get(), null, null, f, f2, bl);
    }

    public static void stopMusic(@Nonnull Player player) {
        XSound[] arrxSound;
        Objects.requireNonNull(player, "Cannot stop playing musics from null player");
        for (XSound xSound : arrxSound = new XSound[]{MUSIC_CREATIVE, MUSIC_CREDITS, MUSIC_DISC_11, MUSIC_DISC_13, MUSIC_DISC_BLOCKS, MUSIC_DISC_CAT, MUSIC_DISC_CHIRP, MUSIC_DISC_FAR, MUSIC_DISC_MALL, MUSIC_DISC_MELLOHI, MUSIC_DISC_STAL, MUSIC_DISC_STRAD, MUSIC_DISC_WAIT, MUSIC_DISC_WARD, MUSIC_DRAGON, MUSIC_END, MUSIC_GAME, MUSIC_MENU, MUSIC_NETHER_BASALT_DELTAS, MUSIC_UNDER_WATER, MUSIC_NETHER_CRIMSON_FOREST, MUSIC_NETHER_WARPED_FOREST}) {
            Sound sound = xSound.parseSound();
            if (sound == null) continue;
            player.stopSound(sound);
        }
    }

    @Nonnull
    public static BukkitTask playAscendingNote(@Nonnull Plugin plugin, final @Nonnull Player player, final @Nonnull Entity entity, final @Nonnull Instrument instrument, final int n, int n2) {
        Objects.requireNonNull(player, "Cannot play note from null player");
        Objects.requireNonNull(entity, "Cannot play note to null entity");
        if (n <= 0) {
            throw new IllegalArgumentException("Note ascend level cannot be lower than 1");
        }
        if (n > 7) {
            throw new IllegalArgumentException("Note ascend level cannot be greater than 7");
        }
        if (n2 <= 0) {
            throw new IllegalArgumentException("Delay ticks must be at least 1");
        }
        return new BukkitRunnable(){
            int repeating;
            {
                this.repeating = n;
            }

            public void run() {
                player.playNote(entity.getLocation(), instrument, Note.natural((int)1, (Note.Tone)Note.Tone.values()[n - this.repeating]));
                if (this.repeating-- == 0) {
                    this.cancel();
                }
            }
        }.runTaskTimerAsynchronously(plugin, 0L, (long)n2);
    }

    public String toString() {
        return Arrays.stream(this.name().split("_")).map(string -> string.charAt(0) + string.substring(1).toLowerCase()).collect(Collectors.joining(" "));
    }

    @Nullable
    public Sound parseSound() {
        return this.sound;
    }

    public boolean isSupported() {
        return this.parseSound() != null;
    }

    @Nonnull
    public BukkitTask playRepeatedly(@Nonnull Plugin plugin, @Nonnull Entity entity, float f, float f2, int n, int n2) {
        return this.playRepeatedly(plugin, Collections.singleton(entity), f, f2, n, n2);
    }

    @Nonnull
    public BukkitTask playRepeatedly(@Nonnull Plugin plugin, final @Nonnull Iterable<? extends Entity> iterable, final float f, final float f2, final int n, int n2) {
        Objects.requireNonNull(plugin, "Cannot play repeating sound from null plugin");
        Objects.requireNonNull(iterable, "Cannot play repeating sound at null locations");
        if (n <= 0) {
            throw new IllegalArgumentException("Cannot repeat playing sound " + n + " times");
        }
        if (n2 <= 0) {
            throw new IllegalArgumentException("Delay ticks must be at least 1");
        }
        return new BukkitRunnable(){
            int repeating;
            {
                this.repeating = n;
            }

            public void run() {
                for (Entity entity : iterable) {
                    XSound.this.play(entity.getLocation(), f, f2);
                }
                if (this.repeating-- == 0) {
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, (long)n2);
    }

    public void stopSound(@Nonnull Player player) {
        Objects.requireNonNull(player, "Cannot stop playing sound from null player");
        Sound sound = this.parseSound();
        if (sound != null) {
            player.stopSound(sound);
        }
    }

    @Nonnull
    @Deprecated
    public static CompletableFuture<Record> play(@Nonnull Player player, @Nullable String string) {
        Objects.requireNonNull(player, "Cannot play sound to null player");
        return CompletableFuture.supplyAsync(() -> {
            Record record;
            try {
                record = XSound.parse(string);
            }
            catch (Throwable throwable) {
                return null;
            }
            if (record == null) {
                return null;
            }
            record.forPlayer(player).play();
            return record;
        }).exceptionally(throwable -> {
            throwable.printStackTrace();
            return null;
        });
    }

    @Nullable
    public static Record play(@Nonnull Location location, @Nullable String string) {
        Objects.requireNonNull(location, "Cannot play sound to null location");
        Record record = XSound.parse(string);
        if (record == null) {
            return null;
        }
        record.atLocation(location).play();
        return record;
    }

    public void play(@Nonnull Entity entity) {
        this.play(entity, 1.0f, 1.0f);
    }

    public void play(@Nonnull Entity entity, float f, float f2) {
        Objects.requireNonNull(entity, "Cannot play sound to a null entity");
        if (entity instanceof Player) {
            Sound sound = this.parseSound();
            if (sound != null) {
                ((Player)entity).playSound(entity.getLocation(), sound, f, f2);
            }
        } else {
            this.play(entity.getLocation(), f, f2);
        }
    }

    public void play(@Nonnull Location location) {
        this.play(location, 1.0f, 1.0f);
    }

    public void play(@Nonnull Location location, float f, float f2) {
        Objects.requireNonNull(location, "Cannot play sound to null location");
        Sound sound = this.parseSound();
        if (sound != null) {
            location.getWorld().playSound(location, sound, f, f2);
        }
    }

    private static /* synthetic */ XSound[] $values() {
        return new XSound[]{AMBIENT_BASALT_DELTAS_ADDITIONS, AMBIENT_BASALT_DELTAS_LOOP, AMBIENT_BASALT_DELTAS_MOOD, AMBIENT_CAVE, AMBIENT_CRIMSON_FOREST_ADDITIONS, AMBIENT_CRIMSON_FOREST_LOOP, AMBIENT_CRIMSON_FOREST_MOOD, AMBIENT_NETHER_WASTES_ADDITIONS, AMBIENT_NETHER_WASTES_LOOP, AMBIENT_NETHER_WASTES_MOOD, AMBIENT_SOUL_SAND_VALLEY_ADDITIONS, AMBIENT_SOUL_SAND_VALLEY_LOOP, AMBIENT_SOUL_SAND_VALLEY_MOOD, AMBIENT_UNDERWATER_ENTER, AMBIENT_UNDERWATER_EXIT, AMBIENT_UNDERWATER_LOOP, AMBIENT_UNDERWATER_LOOP_ADDITIONS, AMBIENT_UNDERWATER_LOOP_ADDITIONS_RARE, AMBIENT_UNDERWATER_LOOP_ADDITIONS_ULTRA_RARE, AMBIENT_WARPED_FOREST_ADDITIONS, AMBIENT_WARPED_FOREST_LOOP, AMBIENT_WARPED_FOREST_MOOD, BLOCK_AMETHYST_BLOCK_BREAK, BLOCK_AMETHYST_BLOCK_CHIME, BLOCK_AMETHYST_BLOCK_FALL, BLOCK_AMETHYST_BLOCK_HIT, BLOCK_AMETHYST_BLOCK_PLACE, BLOCK_AMETHYST_BLOCK_RESONATE, BLOCK_AMETHYST_BLOCK_STEP, BLOCK_AMETHYST_CLUSTER_BREAK, BLOCK_AMETHYST_CLUSTER_FALL, BLOCK_AMETHYST_CLUSTER_HIT, BLOCK_AMETHYST_CLUSTER_PLACE, BLOCK_AMETHYST_CLUSTER_STEP, BLOCK_ANCIENT_DEBRIS_BREAK, BLOCK_ANCIENT_DEBRIS_FALL, BLOCK_ANCIENT_DEBRIS_HIT, BLOCK_ANCIENT_DEBRIS_PLACE, BLOCK_ANCIENT_DEBRIS_STEP, BLOCK_ANVIL_BREAK, BLOCK_ANVIL_DESTROY, BLOCK_ANVIL_FALL, BLOCK_ANVIL_HIT, BLOCK_ANVIL_LAND, BLOCK_ANVIL_PLACE, BLOCK_ANVIL_STEP, BLOCK_ANVIL_USE, BLOCK_AZALEA_BREAK, BLOCK_AZALEA_FALL, BLOCK_AZALEA_HIT, BLOCK_AZALEA_LEAVES_BREAK, BLOCK_AZALEA_LEAVES_FALL, BLOCK_AZALEA_LEAVES_HIT, BLOCK_AZALEA_LEAVES_PLACE, BLOCK_AZALEA_LEAVES_STEP, BLOCK_AZALEA_PLACE, BLOCK_AZALEA_STEP, BLOCK_BAMBOO_BREAK, BLOCK_BAMBOO_FALL, BLOCK_BAMBOO_HIT, BLOCK_BAMBOO_PLACE, BLOCK_BAMBOO_SAPLING_BREAK, BLOCK_BAMBOO_SAPLING_HIT, BLOCK_BAMBOO_SAPLING_PLACE, BLOCK_BAMBOO_STEP, BLOCK_BAMBOO_WOOD_BREAK, BLOCK_BAMBOO_WOOD_BUTTON_CLICK_OFF, BLOCK_BAMBOO_WOOD_BUTTON_CLICK_ON, BLOCK_BAMBOO_WOOD_DOOR_CLOSE, BLOCK_BAMBOO_WOOD_DOOR_OPEN, BLOCK_BAMBOO_WOOD_FALL, BLOCK_BAMBOO_WOOD_FENCE_GATE_CLOSE, BLOCK_BAMBOO_WOOD_FENCE_GATE_OPEN, BLOCK_BAMBOO_WOOD_HANGING_SIGN_BREAK, BLOCK_BAMBOO_WOOD_HANGING_SIGN_FALL, BLOCK_BAMBOO_WOOD_HANGING_SIGN_HIT, BLOCK_BAMBOO_WOOD_HANGING_SIGN_PLACE, BLOCK_BAMBOO_WOOD_HANGING_SIGN_STEP, BLOCK_BAMBOO_WOOD_HIT, BLOCK_BAMBOO_WOOD_PLACE, BLOCK_BAMBOO_WOOD_PRESSURE_PLATE_CLICK_OFF, BLOCK_BAMBOO_WOOD_PRESSURE_PLATE_CLICK_ON, BLOCK_BAMBOO_WOOD_STEP, BLOCK_BAMBOO_WOOD_TRAPDOOR_CLOSE, BLOCK_BAMBOO_WOOD_TRAPDOOR_OPEN, BLOCK_BARREL_CLOSE, BLOCK_BARREL_OPEN, BLOCK_BASALT_BREAK, BLOCK_BASALT_FALL, BLOCK_BASALT_HIT, BLOCK_BASALT_PLACE, BLOCK_BASALT_STEP, BLOCK_BEACON_ACTIVATE, BLOCK_BEACON_AMBIENT, BLOCK_BEACON_DEACTIVATE, BLOCK_BEACON_POWER_SELECT, BLOCK_BEEHIVE_DRIP, BLOCK_BEEHIVE_ENTER, BLOCK_BEEHIVE_EXIT, BLOCK_BEEHIVE_SHEAR, BLOCK_BEEHIVE_WORK, BLOCK_BELL_RESONATE, BLOCK_BELL_USE, BLOCK_BIG_DRIPLEAF_BREAK, BLOCK_BIG_DRIPLEAF_FALL, BLOCK_BIG_DRIPLEAF_HIT, BLOCK_BIG_DRIPLEAF_PLACE, BLOCK_BIG_DRIPLEAF_STEP, BLOCK_BIG_DRIPLEAF_TILT_DOWN, BLOCK_BIG_DRIPLEAF_TILT_UP, BLOCK_BLASTFURNACE_FIRE_CRACKLE, BLOCK_BONE_BLOCK_BREAK, BLOCK_BONE_BLOCK_FALL, BLOCK_BONE_BLOCK_HIT, BLOCK_BONE_BLOCK_PLACE, BLOCK_BONE_BLOCK_STEP, BLOCK_BREWING_STAND_BREW, BLOCK_BUBBLE_COLUMN_BUBBLE_POP, BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT, BLOCK_BUBBLE_COLUMN_UPWARDS_INSIDE, BLOCK_BUBBLE_COLUMN_WHIRLPOOL_AMBIENT, BLOCK_BUBBLE_COLUMN_WHIRLPOOL_INSIDE, BLOCK_CAKE_ADD_CANDLE, BLOCK_CALCITE_BREAK, BLOCK_CALCITE_FALL, BLOCK_CALCITE_HIT, BLOCK_CALCITE_PLACE, BLOCK_CALCITE_STEP, BLOCK_CAMPFIRE_CRACKLE, BLOCK_CANDLE_AMBIENT, BLOCK_CANDLE_BREAK, BLOCK_CANDLE_EXTINGUISH, BLOCK_CANDLE_FALL, BLOCK_CANDLE_HIT, BLOCK_CANDLE_PLACE, BLOCK_CANDLE_STEP, BLOCK_CAVE_VINES_BREAK, BLOCK_CAVE_VINES_FALL, BLOCK_CAVE_VINES_HIT, BLOCK_CAVE_VINES_PICK_BERRIES, BLOCK_CAVE_VINES_PLACE, BLOCK_CAVE_VINES_STEP, BLOCK_CHAIN_BREAK, BLOCK_CHAIN_FALL, BLOCK_CHAIN_HIT, BLOCK_CHAIN_PLACE, BLOCK_CHAIN_STEP, BLOCK_CHERRY_LEAVES_BREAK, BLOCK_CHERRY_LEAVES_FALL, BLOCK_CHERRY_LEAVES_HIT, BLOCK_CHERRY_LEAVES_PLACE, BLOCK_CHERRY_LEAVES_STEP, BLOCK_CHERRY_SAPLING_BREAK, BLOCK_CHERRY_SAPLING_FALL, BLOCK_CHERRY_SAPLING_HIT, BLOCK_CHERRY_SAPLING_PLACE, BLOCK_CHERRY_SAPLING_STEP, BLOCK_CHERRY_WOOD_BREAK, BLOCK_CHERRY_WOOD_BUTTON_CLICK_OFF, BLOCK_CHERRY_WOOD_BUTTON_CLICK_ON, BLOCK_CHERRY_WOOD_DOOR_CLOSE, BLOCK_CHERRY_WOOD_DOOR_OPEN, BLOCK_CHERRY_WOOD_FALL, BLOCK_CHERRY_WOOD_FENCE_GATE_CLOSE, BLOCK_CHERRY_WOOD_FENCE_GATE_OPEN, BLOCK_CHERRY_WOOD_HANGING_SIGN_BREAK, BLOCK_CHERRY_WOOD_HANGING_SIGN_FALL, BLOCK_CHERRY_WOOD_HANGING_SIGN_HIT, BLOCK_CHERRY_WOOD_HANGING_SIGN_PLACE, BLOCK_CHERRY_WOOD_HANGING_SIGN_STEP, BLOCK_CHERRY_WOOD_HIT, BLOCK_CHERRY_WOOD_PLACE, BLOCK_CHERRY_WOOD_PRESSURE_PLATE_CLICK_OFF, BLOCK_CHERRY_WOOD_PRESSURE_PLATE_CLICK_ON, BLOCK_CHERRY_WOOD_STEP, BLOCK_CHERRY_WOOD_TRAPDOOR_CLOSE, BLOCK_CHERRY_WOOD_TRAPDOOR_OPEN, BLOCK_CHEST_CLOSE, BLOCK_CHEST_LOCKED, BLOCK_CHEST_OPEN, BLOCK_CHISELED_BOOKSHELF_BREAK, BLOCK_CHISELED_BOOKSHELF_FALL, BLOCK_CHISELED_BOOKSHELF_HIT, BLOCK_CHISELED_BOOKSHELF_INSERT, BLOCK_CHISELED_BOOKSHELF_INSERT_ENCHANTED, BLOCK_CHISELED_BOOKSHELF_PICKUP, BLOCK_CHISELED_BOOKSHELF_PICKUP_ENCHANTED, BLOCK_CHISELED_BOOKSHELF_PLACE, BLOCK_CHISELED_BOOKSHELF_STEP, BLOCK_CHORUS_FLOWER_DEATH, BLOCK_CHORUS_FLOWER_GROW, BLOCK_COMPARATOR_CLICK, BLOCK_COMPOSTER_EMPTY, BLOCK_COMPOSTER_FILL, BLOCK_COMPOSTER_FILL_SUCCESS, BLOCK_COMPOSTER_READY, BLOCK_CONDUIT_ACTIVATE, BLOCK_CONDUIT_AMBIENT, BLOCK_CONDUIT_AMBIENT_SHORT, BLOCK_CONDUIT_ATTACK_TARGET, BLOCK_CONDUIT_DEACTIVATE, BLOCK_COPPER_BREAK, BLOCK_COPPER_FALL, BLOCK_COPPER_HIT, BLOCK_COPPER_PLACE, BLOCK_COPPER_STEP, BLOCK_CORAL_BLOCK_BREAK, BLOCK_CORAL_BLOCK_FALL, BLOCK_CORAL_BLOCK_HIT, BLOCK_CORAL_BLOCK_PLACE, BLOCK_CORAL_BLOCK_STEP, BLOCK_CROP_BREAK, BLOCK_DECORATED_POT_BREAK, BLOCK_DECORATED_POT_FALL, BLOCK_DECORATED_POT_HIT, BLOCK_DECORATED_POT_PLACE, BLOCK_DECORATED_POT_SHATTER, BLOCK_DECORATED_POT_STEP, BLOCK_DEEPSLATE_BREAK, BLOCK_DEEPSLATE_BRICKS_BREAK, BLOCK_DEEPSLATE_BRICKS_FALL, BLOCK_DEEPSLATE_BRICKS_HIT, BLOCK_DEEPSLATE_BRICKS_PLACE, BLOCK_DEEPSLATE_BRICKS_STEP, BLOCK_DEEPSLATE_FALL, BLOCK_DEEPSLATE_HIT, BLOCK_DEEPSLATE_PLACE, BLOCK_DEEPSLATE_STEP, BLOCK_DEEPSLATE_TILES_BREAK, BLOCK_DEEPSLATE_TILES_FALL, BLOCK_DEEPSLATE_TILES_HIT, BLOCK_DEEPSLATE_TILES_PLACE, BLOCK_DEEPSLATE_TILES_STEP, BLOCK_DISPENSER_DISPENSE, BLOCK_DISPENSER_FAIL, BLOCK_DISPENSER_LAUNCH, BLOCK_DRIPSTONE_BLOCK_BREAK, BLOCK_DRIPSTONE_BLOCK_FALL, BLOCK_DRIPSTONE_BLOCK_HIT, BLOCK_DRIPSTONE_BLOCK_PLACE, BLOCK_DRIPSTONE_BLOCK_STEP, BLOCK_ENCHANTMENT_TABLE_USE, BLOCK_ENDER_CHEST_CLOSE, BLOCK_ENDER_CHEST_OPEN, BLOCK_END_GATEWAY_SPAWN, BLOCK_END_PORTAL_FRAME_FILL, BLOCK_END_PORTAL_SPAWN, BLOCK_FENCE_GATE_CLOSE, BLOCK_FENCE_GATE_OPEN, BLOCK_FIRE_AMBIENT, BLOCK_FIRE_EXTINGUISH, BLOCK_FLOWERING_AZALEA_BREAK, BLOCK_FLOWERING_AZALEA_FALL, BLOCK_FLOWERING_AZALEA_HIT, BLOCK_FLOWERING_AZALEA_PLACE, BLOCK_FLOWERING_AZALEA_STEP, BLOCK_FROGLIGHT_BREAK, BLOCK_FROGLIGHT_FALL, BLOCK_FROGLIGHT_HIT, BLOCK_FROGLIGHT_PLACE, BLOCK_FROGLIGHT_STEP, BLOCK_FROGSPAWN_BREAK, BLOCK_FROGSPAWN_FALL, BLOCK_FROGSPAWN_HATCH, BLOCK_FROGSPAWN_HIT, BLOCK_FROGSPAWN_PLACE, BLOCK_FROGSPAWN_STEP, BLOCK_FUNGUS_BREAK, BLOCK_FUNGUS_FALL, BLOCK_FUNGUS_HIT, BLOCK_FUNGUS_PLACE, BLOCK_FUNGUS_STEP, BLOCK_FURNACE_FIRE_CRACKLE, BLOCK_GILDED_BLACKSTONE_BREAK, BLOCK_GILDED_BLACKSTONE_FALL, BLOCK_GILDED_BLACKSTONE_HIT, BLOCK_GILDED_BLACKSTONE_PLACE, BLOCK_GILDED_BLACKSTONE_STEP, BLOCK_GLASS_BREAK, BLOCK_GLASS_FALL, BLOCK_GLASS_HIT, BLOCK_GLASS_PLACE, BLOCK_GLASS_STEP, BLOCK_GRASS_BREAK, BLOCK_GRASS_FALL, BLOCK_GRASS_HIT, BLOCK_GRASS_PLACE, BLOCK_GRASS_STEP, BLOCK_GRAVEL_BREAK, BLOCK_GRAVEL_FALL, BLOCK_GRAVEL_HIT, BLOCK_GRAVEL_PLACE, BLOCK_GRAVEL_STEP, BLOCK_GRINDSTONE_USE, BLOCK_GROWING_PLANT_CROP, BLOCK_HANGING_ROOTS_BREAK, BLOCK_HANGING_ROOTS_FALL, BLOCK_HANGING_ROOTS_HIT, BLOCK_HANGING_ROOTS_PLACE, BLOCK_HANGING_ROOTS_STEP, BLOCK_HANGING_SIGN_BREAK, BLOCK_HANGING_SIGN_FALL, BLOCK_HANGING_SIGN_HIT, BLOCK_HANGING_SIGN_PLACE, BLOCK_HANGING_SIGN_STEP, BLOCK_HONEY_BLOCK_BREAK, BLOCK_HONEY_BLOCK_FALL, BLOCK_HONEY_BLOCK_HIT, BLOCK_HONEY_BLOCK_PLACE, BLOCK_HONEY_BLOCK_SLIDE, BLOCK_HONEY_BLOCK_STEP, BLOCK_IRON_DOOR_CLOSE, BLOCK_IRON_DOOR_OPEN, BLOCK_IRON_TRAPDOOR_CLOSE, BLOCK_IRON_TRAPDOOR_OPEN, BLOCK_LADDER_BREAK, BLOCK_LADDER_FALL, BLOCK_LADDER_HIT, BLOCK_LADDER_PLACE, BLOCK_LADDER_STEP, BLOCK_LANTERN_BREAK, BLOCK_LANTERN_FALL, BLOCK_LANTERN_HIT, BLOCK_LANTERN_PLACE, BLOCK_LANTERN_STEP, BLOCK_LARGE_AMETHYST_BUD_BREAK, BLOCK_LARGE_AMETHYST_BUD_PLACE, BLOCK_LAVA_AMBIENT, BLOCK_LAVA_EXTINGUISH, BLOCK_LAVA_POP, BLOCK_LEVER_CLICK, BLOCK_LILY_PAD_PLACE, BLOCK_LODESTONE_BREAK, BLOCK_LODESTONE_FALL, BLOCK_LODESTONE_HIT, BLOCK_LODESTONE_PLACE, BLOCK_LODESTONE_STEP, BLOCK_MANGROVE_ROOTS_BREAK, BLOCK_MANGROVE_ROOTS_FALL, BLOCK_MANGROVE_ROOTS_HIT, BLOCK_MANGROVE_ROOTS_PLACE, BLOCK_MANGROVE_ROOTS_STEP, BLOCK_MEDIUM_AMETHYST_BUD_BREAK, BLOCK_MEDIUM_AMETHYST_BUD_PLACE, BLOCK_METAL_BREAK, BLOCK_METAL_FALL, BLOCK_METAL_HIT, BLOCK_METAL_PLACE, BLOCK_METAL_PRESSURE_PLATE_CLICK_OFF, BLOCK_METAL_PRESSURE_PLATE_CLICK_ON, BLOCK_METAL_STEP, BLOCK_MOSS_BREAK, BLOCK_MOSS_CARPET_BREAK, BLOCK_MOSS_CARPET_FALL, BLOCK_MOSS_CARPET_HIT, BLOCK_MOSS_CARPET_PLACE, BLOCK_MOSS_CARPET_STEP, BLOCK_MOSS_FALL, BLOCK_MOSS_HIT, BLOCK_MOSS_PLACE, BLOCK_MOSS_STEP, BLOCK_MUDDY_MANGROVE_ROOTS_BREAK, BLOCK_MUDDY_MANGROVE_ROOTS_FALL, BLOCK_MUDDY_MANGROVE_ROOTS_HIT, BLOCK_MUDDY_MANGROVE_ROOTS_PLACE, BLOCK_MUDDY_MANGROVE_ROOTS_STEP, BLOCK_MUD_BREAK, BLOCK_MUD_BRICKS_BREAK, BLOCK_MUD_BRICKS_FALL, BLOCK_MUD_BRICKS_HIT, BLOCK_MUD_BRICKS_PLACE, BLOCK_MUD_BRICKS_STEP, BLOCK_MUD_FALL, BLOCK_MUD_HIT, BLOCK_MUD_PLACE, BLOCK_MUD_STEP, BLOCK_NETHERITE_BLOCK_BREAK, BLOCK_NETHERITE_BLOCK_FALL, BLOCK_NETHERITE_BLOCK_HIT, BLOCK_NETHERITE_BLOCK_PLACE, BLOCK_NETHERITE_BLOCK_STEP, BLOCK_NETHERRACK_BREAK, BLOCK_NETHERRACK_FALL, BLOCK_NETHERRACK_HIT, BLOCK_NETHERRACK_PLACE, BLOCK_NETHERRACK_STEP, BLOCK_NETHER_BRICKS_BREAK, BLOCK_NETHER_BRICKS_FALL, BLOCK_NETHER_BRICKS_HIT, BLOCK_NETHER_BRICKS_PLACE, BLOCK_NETHER_BRICKS_STEP, BLOCK_NETHER_GOLD_ORE_BREAK, BLOCK_NETHER_GOLD_ORE_FALL, BLOCK_NETHER_GOLD_ORE_HIT, BLOCK_NETHER_GOLD_ORE_PLACE, BLOCK_NETHER_GOLD_ORE_STEP, BLOCK_NETHER_ORE_BREAK, BLOCK_NETHER_ORE_FALL, BLOCK_NETHER_ORE_HIT, BLOCK_NETHER_ORE_PLACE, BLOCK_NETHER_ORE_STEP, BLOCK_NETHER_SPROUTS_BREAK, BLOCK_NETHER_SPROUTS_FALL, BLOCK_NETHER_SPROUTS_HIT, BLOCK_NETHER_SPROUTS_PLACE, BLOCK_NETHER_SPROUTS_STEP, BLOCK_NETHER_WART_BREAK, BLOCK_NETHER_WOOD_BREAK, BLOCK_NETHER_WOOD_BUTTON_CLICK_OFF, BLOCK_NETHER_WOOD_BUTTON_CLICK_ON, BLOCK_NETHER_WOOD_DOOR_CLOSE, BLOCK_NETHER_WOOD_DOOR_OPEN, BLOCK_NETHER_WOOD_FALL, BLOCK_NETHER_WOOD_FENCE_GATE_CLOSE, BLOCK_NETHER_WOOD_FENCE_GATE_OPEN, BLOCK_NETHER_WOOD_HANGING_SIGN_BREAK, BLOCK_NETHER_WOOD_HANGING_SIGN_FALL, BLOCK_NETHER_WOOD_HANGING_SIGN_HIT, BLOCK_NETHER_WOOD_HANGING_SIGN_PLACE, BLOCK_NETHER_WOOD_HANGING_SIGN_STEP, BLOCK_NETHER_WOOD_HIT, BLOCK_NETHER_WOOD_PLACE, BLOCK_NETHER_WOOD_PRESSURE_PLATE_CLICK_OFF, BLOCK_NETHER_WOOD_PRESSURE_PLATE_CLICK_ON, BLOCK_NETHER_WOOD_STEP, BLOCK_NETHER_WOOD_TRAPDOOR_CLOSE, BLOCK_NETHER_WOOD_TRAPDOOR_OPEN, BLOCK_NOTE_BLOCK_BANJO, BLOCK_NOTE_BLOCK_BASEDRUM, BLOCK_NOTE_BLOCK_BASS, BLOCK_NOTE_BLOCK_BELL, BLOCK_NOTE_BLOCK_BIT, BLOCK_NOTE_BLOCK_CHIME, BLOCK_NOTE_BLOCK_COW_BELL, BLOCK_NOTE_BLOCK_DIDGERIDOO, BLOCK_NOTE_BLOCK_FLUTE, BLOCK_NOTE_BLOCK_GUITAR, BLOCK_NOTE_BLOCK_HARP, BLOCK_NOTE_BLOCK_HAT, BLOCK_NOTE_BLOCK_IMITATE_CREEPER, BLOCK_NOTE_BLOCK_IMITATE_ENDER_DRAGON, BLOCK_NOTE_BLOCK_IMITATE_PIGLIN, BLOCK_NOTE_BLOCK_IMITATE_SKELETON, BLOCK_NOTE_BLOCK_IMITATE_WITHER_SKELETON, BLOCK_NOTE_BLOCK_IMITATE_ZOMBIE, BLOCK_NOTE_BLOCK_IRON_XYLOPHONE, BLOCK_NOTE_BLOCK_PLING, BLOCK_NOTE_BLOCK_SNARE, BLOCK_NOTE_BLOCK_XYLOPHONE, BLOCK_NYLIUM_BREAK, BLOCK_NYLIUM_FALL, BLOCK_NYLIUM_HIT, BLOCK_NYLIUM_PLACE, BLOCK_NYLIUM_STEP, BLOCK_PACKED_MUD_BREAK, BLOCK_PACKED_MUD_FALL, BLOCK_PACKED_MUD_HIT, BLOCK_PACKED_MUD_PLACE, BLOCK_PACKED_MUD_STEP, BLOCK_PINK_PETALS_BREAK, BLOCK_PINK_PETALS_FALL, BLOCK_PINK_PETALS_HIT, BLOCK_PINK_PETALS_PLACE, BLOCK_PINK_PETALS_STEP, BLOCK_PISTON_CONTRACT, BLOCK_PISTON_EXTEND, BLOCK_POINTED_DRIPSTONE_BREAK, BLOCK_POINTED_DRIPSTONE_DRIP_LAVA, BLOCK_POINTED_DRIPSTONE_DRIP_LAVA_INTO_CAULDRON, BLOCK_POINTED_DRIPSTONE_DRIP_WATER, BLOCK_POINTED_DRIPSTONE_DRIP_WATER_INTO_CAULDRON, BLOCK_POINTED_DRIPSTONE_FALL, BLOCK_POINTED_DRIPSTONE_HIT, BLOCK_POINTED_DRIPSTONE_LAND, BLOCK_POINTED_DRIPSTONE_PLACE, BLOCK_POINTED_DRIPSTONE_STEP, BLOCK_POLISHED_DEEPSLATE_BREAK, BLOCK_POLISHED_DEEPSLATE_FALL, BLOCK_POLISHED_DEEPSLATE_HIT, BLOCK_POLISHED_DEEPSLATE_PLACE, BLOCK_POLISHED_DEEPSLATE_STEP, BLOCK_PORTAL_AMBIENT, BLOCK_PORTAL_TRAVEL, BLOCK_PORTAL_TRIGGER, BLOCK_POWDER_SNOW_BREAK, BLOCK_POWDER_SNOW_FALL, BLOCK_POWDER_SNOW_HIT, BLOCK_POWDER_SNOW_PLACE, BLOCK_POWDER_SNOW_STEP, BLOCK_PUMPKIN_CARVE, BLOCK_REDSTONE_TORCH_BURNOUT, BLOCK_RESPAWN_ANCHOR_AMBIENT, BLOCK_RESPAWN_ANCHOR_CHARGE, BLOCK_RESPAWN_ANCHOR_DEPLETE, BLOCK_RESPAWN_ANCHOR_SET_SPAWN, BLOCK_ROOTED_DIRT_BREAK, BLOCK_ROOTED_DIRT_FALL, BLOCK_ROOTED_DIRT_HIT, BLOCK_ROOTED_DIRT_PLACE, BLOCK_ROOTED_DIRT_STEP, BLOCK_ROOTS_BREAK, BLOCK_ROOTS_FALL, BLOCK_ROOTS_HIT, BLOCK_ROOTS_PLACE, BLOCK_ROOTS_STEP, BLOCK_SAND_BREAK, BLOCK_SAND_FALL, BLOCK_SAND_HIT, BLOCK_SAND_PLACE, BLOCK_SAND_STEP, BLOCK_SCAFFOLDING_BREAK, BLOCK_SCAFFOLDING_FALL, BLOCK_SCAFFOLDING_HIT, BLOCK_SCAFFOLDING_PLACE, BLOCK_SCAFFOLDING_STEP, BLOCK_SCULK_BREAK, BLOCK_SCULK_CATALYST_BLOOM, BLOCK_SCULK_CATALYST_BREAK, BLOCK_SCULK_CATALYST_FALL, BLOCK_SCULK_CATALYST_HIT, BLOCK_SCULK_CATALYST_PLACE, BLOCK_SCULK_CATALYST_STEP, BLOCK_SCULK_CHARGE, BLOCK_SCULK_FALL, BLOCK_SCULK_HIT, BLOCK_SCULK_PLACE, BLOCK_SCULK_SENSOR_BREAK, BLOCK_SCULK_SENSOR_CLICKING, BLOCK_SCULK_SENSOR_CLICKING_STOP, BLOCK_SCULK_SENSOR_FALL, BLOCK_SCULK_SENSOR_HIT, BLOCK_SCULK_SENSOR_PLACE, BLOCK_SCULK_SENSOR_STEP, BLOCK_SCULK_SHRIEKER_BREAK, BLOCK_SCULK_SHRIEKER_FALL, BLOCK_SCULK_SHRIEKER_HIT, BLOCK_SCULK_SHRIEKER_PLACE, BLOCK_SCULK_SHRIEKER_SHRIEK, BLOCK_SCULK_SHRIEKER_STEP, BLOCK_SCULK_SPREAD, BLOCK_SCULK_STEP, BLOCK_SCULK_VEIN_BREAK, BLOCK_SCULK_VEIN_FALL, BLOCK_SCULK_VEIN_HIT, BLOCK_SCULK_VEIN_PLACE, BLOCK_SCULK_VEIN_STEP, BLOCK_SHROOMLIGHT_BREAK, BLOCK_SHROOMLIGHT_FALL, BLOCK_SHROOMLIGHT_HIT, BLOCK_SHROOMLIGHT_PLACE, BLOCK_SHROOMLIGHT_STEP, BLOCK_SHULKER_BOX_CLOSE, BLOCK_SHULKER_BOX_OPEN, BLOCK_SIGN_WAXED_INTERACT_FAIL, BLOCK_SLIME_BLOCK_BREAK, BLOCK_SLIME_BLOCK_FALL, BLOCK_SLIME_BLOCK_HIT, BLOCK_SLIME_BLOCK_PLACE, BLOCK_SLIME_BLOCK_STEP, BLOCK_SMALL_AMETHYST_BUD_BREAK, BLOCK_SMALL_AMETHYST_BUD_PLACE, BLOCK_SMALL_DRIPLEAF_BREAK, BLOCK_SMALL_DRIPLEAF_FALL, BLOCK_SMALL_DRIPLEAF_HIT, BLOCK_SMALL_DRIPLEAF_PLACE, BLOCK_SMALL_DRIPLEAF_STEP, BLOCK_SMITHING_TABLE_USE, BLOCK_SMOKER_SMOKE, BLOCK_SNIFFER_EGG_CRACK, BLOCK_SNIFFER_EGG_HATCH, BLOCK_SNIFFER_EGG_PLOP, BLOCK_SNOW_BREAK, BLOCK_SNOW_FALL, BLOCK_SNOW_HIT, BLOCK_SNOW_PLACE, BLOCK_SNOW_STEP, BLOCK_SOUL_SAND_BREAK, BLOCK_SOUL_SAND_FALL, BLOCK_SOUL_SAND_HIT, BLOCK_SOUL_SAND_PLACE, BLOCK_SOUL_SAND_STEP, BLOCK_SOUL_SOIL_BREAK, BLOCK_SOUL_SOIL_FALL, BLOCK_SOUL_SOIL_HIT, BLOCK_SOUL_SOIL_PLACE, BLOCK_SOUL_SOIL_STEP, BLOCK_SPORE_BLOSSOM_BREAK, BLOCK_SPORE_BLOSSOM_FALL, BLOCK_SPORE_BLOSSOM_HIT, BLOCK_SPORE_BLOSSOM_PLACE, BLOCK_SPORE_BLOSSOM_STEP, BLOCK_STEM_BREAK, BLOCK_STEM_FALL, BLOCK_STEM_HIT, BLOCK_STEM_PLACE, BLOCK_STEM_STEP, BLOCK_STONE_BREAK, BLOCK_STONE_BUTTON_CLICK_OFF, BLOCK_STONE_BUTTON_CLICK_ON, BLOCK_STONE_FALL, BLOCK_STONE_HIT, BLOCK_STONE_PLACE, BLOCK_STONE_PRESSURE_PLATE_CLICK_OFF, BLOCK_STONE_PRESSURE_PLATE_CLICK_ON, BLOCK_STONE_STEP, BLOCK_SUSPICIOUS_GRAVEL_BREAK, BLOCK_SUSPICIOUS_GRAVEL_FALL, BLOCK_SUSPICIOUS_GRAVEL_HIT, BLOCK_SUSPICIOUS_GRAVEL_PLACE, BLOCK_SUSPICIOUS_GRAVEL_STEP, BLOCK_SUSPICIOUS_SAND_BREAK, BLOCK_SUSPICIOUS_SAND_FALL, BLOCK_SUSPICIOUS_SAND_HIT, BLOCK_SUSPICIOUS_SAND_PLACE, BLOCK_SUSPICIOUS_SAND_STEP, BLOCK_SWEET_BERRY_BUSH_BREAK, BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES, BLOCK_SWEET_BERRY_BUSH_PLACE, BLOCK_TRIPWIRE_ATTACH, BLOCK_TRIPWIRE_CLICK_OFF, BLOCK_TRIPWIRE_CLICK_ON, BLOCK_TRIPWIRE_DETACH, BLOCK_TUFF_BREAK, BLOCK_TUFF_FALL, BLOCK_TUFF_HIT, BLOCK_TUFF_PLACE, BLOCK_TUFF_STEP, BLOCK_VINE_BREAK, BLOCK_VINE_FALL, BLOCK_VINE_HIT, BLOCK_VINE_PLACE, BLOCK_VINE_STEP, BLOCK_WART_BLOCK_BREAK, BLOCK_WART_BLOCK_FALL, BLOCK_WART_BLOCK_HIT, BLOCK_WART_BLOCK_PLACE, BLOCK_WART_BLOCK_STEP, BLOCK_WATER_AMBIENT, BLOCK_WEEPING_VINES_BREAK, BLOCK_WEEPING_VINES_FALL, BLOCK_WEEPING_VINES_HIT, BLOCK_WEEPING_VINES_PLACE, BLOCK_WEEPING_VINES_STEP, BLOCK_WET_GRASS_BREAK, BLOCK_WET_GRASS_FALL, BLOCK_WET_GRASS_HIT, BLOCK_WET_GRASS_PLACE, BLOCK_WET_GRASS_STEP, BLOCK_WOODEN_BUTTON_CLICK_OFF, BLOCK_WOODEN_BUTTON_CLICK_ON, BLOCK_WOODEN_DOOR_CLOSE, BLOCK_WOODEN_DOOR_OPEN, BLOCK_WOODEN_PRESSURE_PLATE_CLICK_OFF, BLOCK_WOODEN_PRESSURE_PLATE_CLICK_ON, BLOCK_WOODEN_TRAPDOOR_CLOSE, BLOCK_WOODEN_TRAPDOOR_OPEN, BLOCK_WOOD_BREAK, BLOCK_WOOD_FALL, BLOCK_WOOD_HIT, BLOCK_WOOD_PLACE, BLOCK_WOOD_STEP, BLOCK_WOOL_BREAK, BLOCK_WOOL_FALL, BLOCK_WOOL_HIT, BLOCK_WOOL_PLACE, BLOCK_WOOL_STEP, ENCHANT_THORNS_HIT, ENTITY_ALLAY_AMBIENT_WITHOUT_ITEM, ENTITY_ALLAY_AMBIENT_WITH_ITEM, ENTITY_ALLAY_DEATH, ENTITY_ALLAY_HURT, ENTITY_ALLAY_ITEM_GIVEN, ENTITY_ALLAY_ITEM_TAKEN, ENTITY_ALLAY_ITEM_THROWN, ENTITY_ARMOR_STAND_BREAK, ENTITY_ARMOR_STAND_FALL, ENTITY_ARMOR_STAND_HIT, ENTITY_ARMOR_STAND_PLACE, ENTITY_ARROW_HIT, ENTITY_ARROW_HIT_PLAYER, ENTITY_ARROW_SHOOT, ENTITY_AXOLOTL_ATTACK, ENTITY_AXOLOTL_DEATH, ENTITY_AXOLOTL_HURT, ENTITY_AXOLOTL_IDLE_AIR, ENTITY_AXOLOTL_IDLE_WATER, ENTITY_AXOLOTL_SPLASH, ENTITY_AXOLOTL_SWIM, ENTITY_BAT_AMBIENT, ENTITY_BAT_DEATH, ENTITY_BAT_HURT, ENTITY_BAT_LOOP, ENTITY_BAT_TAKEOFF, ENTITY_BEE_DEATH, ENTITY_BEE_HURT, ENTITY_BEE_LOOP, ENTITY_BEE_LOOP_AGGRESSIVE, ENTITY_BEE_POLLINATE, ENTITY_BEE_STING, ENTITY_BLAZE_AMBIENT, ENTITY_BLAZE_BURN, ENTITY_BLAZE_DEATH, ENTITY_BLAZE_HURT, ENTITY_BLAZE_SHOOT, ENTITY_BOAT_PADDLE_LAND, ENTITY_BOAT_PADDLE_WATER, ENTITY_CAMEL_AMBIENT, ENTITY_CAMEL_DASH, ENTITY_CAMEL_DASH_READY, ENTITY_CAMEL_DEATH, ENTITY_CAMEL_EAT, ENTITY_CAMEL_HURT, ENTITY_CAMEL_SADDLE, ENTITY_CAMEL_SIT, ENTITY_CAMEL_STAND, ENTITY_CAMEL_STEP, ENTITY_CAMEL_STEP_SAND, ENTITY_CAT_AMBIENT, ENTITY_CAT_BEG_FOR_FOOD, ENTITY_CAT_DEATH, ENTITY_CAT_EAT, ENTITY_CAT_HISS, ENTITY_CAT_HURT, ENTITY_CAT_PURR, ENTITY_CAT_PURREOW, ENTITY_CAT_STRAY_AMBIENT, ENTITY_CHICKEN_AMBIENT, ENTITY_CHICKEN_DEATH, ENTITY_CHICKEN_EGG, ENTITY_CHICKEN_HURT, ENTITY_CHICKEN_STEP, ENTITY_COD_AMBIENT, ENTITY_COD_DEATH, ENTITY_COD_FLOP, ENTITY_COD_HURT, ENTITY_COW_AMBIENT, ENTITY_COW_DEATH, ENTITY_COW_HURT, ENTITY_COW_MILK, ENTITY_COW_STEP, ENTITY_CREEPER_DEATH, ENTITY_CREEPER_HURT, ENTITY_CREEPER_PRIMED, ENTITY_DOLPHIN_AMBIENT, ENTITY_DOLPHIN_AMBIENT_WATER, ENTITY_DOLPHIN_ATTACK, ENTITY_DOLPHIN_DEATH, ENTITY_DOLPHIN_EAT, ENTITY_DOLPHIN_HURT, ENTITY_DOLPHIN_JUMP, ENTITY_DOLPHIN_PLAY, ENTITY_DOLPHIN_SPLASH, ENTITY_DOLPHIN_SWIM, ENTITY_DONKEY_AMBIENT, ENTITY_DONKEY_ANGRY, ENTITY_DONKEY_CHEST, ENTITY_DONKEY_DEATH, ENTITY_DONKEY_EAT, ENTITY_DONKEY_HURT, ENTITY_DRAGON_FIREBALL_EXPLODE, ENTITY_DROWNED_AMBIENT, ENTITY_DROWNED_AMBIENT_WATER, ENTITY_DROWNED_DEATH, ENTITY_DROWNED_DEATH_WATER, ENTITY_DROWNED_HURT, ENTITY_DROWNED_HURT_WATER, ENTITY_DROWNED_SHOOT, ENTITY_DROWNED_STEP, ENTITY_DROWNED_SWIM, ENTITY_EGG_THROW, ENTITY_ELDER_GUARDIAN_AMBIENT, ENTITY_ELDER_GUARDIAN_AMBIENT_LAND, ENTITY_ELDER_GUARDIAN_CURSE, ENTITY_ELDER_GUARDIAN_DEATH, ENTITY_ELDER_GUARDIAN_DEATH_LAND, ENTITY_ELDER_GUARDIAN_FLOP, ENTITY_ELDER_GUARDIAN_HURT, ENTITY_ELDER_GUARDIAN_HURT_LAND, ENTITY_ENDERMAN_AMBIENT, ENTITY_ENDERMAN_DEATH, ENTITY_ENDERMAN_HURT, ENTITY_ENDERMAN_SCREAM, ENTITY_ENDERMAN_STARE, ENTITY_ENDERMAN_TELEPORT, ENTITY_ENDERMITE_AMBIENT, ENTITY_ENDERMITE_DEATH, ENTITY_ENDERMITE_HURT, ENTITY_ENDERMITE_STEP, ENTITY_ENDER_DRAGON_AMBIENT, ENTITY_ENDER_DRAGON_DEATH, ENTITY_ENDER_DRAGON_FLAP, ENTITY_ENDER_DRAGON_GROWL, ENTITY_ENDER_DRAGON_HURT, ENTITY_ENDER_DRAGON_SHOOT, ENTITY_ENDER_EYE_DEATH, ENTITY_ENDER_EYE_LAUNCH, ENTITY_ENDER_PEARL_THROW, ENTITY_EVOKER_AMBIENT, ENTITY_EVOKER_CAST_SPELL, ENTITY_EVOKER_CELEBRATE, ENTITY_EVOKER_DEATH, ENTITY_EVOKER_FANGS_ATTACK, ENTITY_EVOKER_HURT, ENTITY_EVOKER_PREPARE_ATTACK, ENTITY_EVOKER_PREPARE_SUMMON, ENTITY_EVOKER_PREPARE_WOLOLO, ENTITY_EXPERIENCE_BOTTLE_THROW, ENTITY_EXPERIENCE_ORB_PICKUP, ENTITY_FIREWORK_ROCKET_BLAST, ENTITY_FIREWORK_ROCKET_BLAST_FAR, ENTITY_FIREWORK_ROCKET_LARGE_BLAST, ENTITY_FIREWORK_ROCKET_LARGE_BLAST_FAR, ENTITY_FIREWORK_ROCKET_LAUNCH, ENTITY_FIREWORK_ROCKET_SHOOT, ENTITY_FIREWORK_ROCKET_TWINKLE, ENTITY_FIREWORK_ROCKET_TWINKLE_FAR, ENTITY_FISHING_BOBBER_RETRIEVE, ENTITY_FISHING_BOBBER_SPLASH, ENTITY_FISHING_BOBBER_THROW, ENTITY_FISH_SWIM, ENTITY_FOX_AGGRO, ENTITY_FOX_AMBIENT, ENTITY_FOX_BITE, ENTITY_FOX_DEATH, ENTITY_FOX_EAT, ENTITY_FOX_HURT, ENTITY_FOX_SCREECH, ENTITY_FOX_SLEEP, ENTITY_FOX_SNIFF, ENTITY_FOX_SPIT, ENTITY_FOX_TELEPORT, ENTITY_FROG_AMBIENT, ENTITY_FROG_DEATH, ENTITY_FROG_EAT, ENTITY_FROG_HURT, ENTITY_FROG_LAY_SPAWN, ENTITY_FROG_LONG_JUMP, ENTITY_FROG_STEP, ENTITY_FROG_TONGUE, ENTITY_GENERIC_BIG_FALL, ENTITY_GENERIC_BURN, ENTITY_GENERIC_DEATH, ENTITY_GENERIC_DRINK, ENTITY_GENERIC_EAT, ENTITY_GENERIC_EXPLODE, ENTITY_GENERIC_EXTINGUISH_FIRE, ENTITY_GENERIC_HURT, ENTITY_GENERIC_SMALL_FALL, ENTITY_GENERIC_SPLASH, ENTITY_GENERIC_SWIM, ENTITY_GHAST_AMBIENT, ENTITY_GHAST_DEATH, ENTITY_GHAST_HURT, ENTITY_GHAST_SCREAM, ENTITY_GHAST_SHOOT, ENTITY_GHAST_WARN, ENTITY_GLOW_ITEM_FRAME_ADD_ITEM, ENTITY_GLOW_ITEM_FRAME_BREAK, ENTITY_GLOW_ITEM_FRAME_PLACE, ENTITY_GLOW_ITEM_FRAME_REMOVE_ITEM, ENTITY_GLOW_ITEM_FRAME_ROTATE_ITEM, ENTITY_GLOW_SQUID_AMBIENT, ENTITY_GLOW_SQUID_DEATH, ENTITY_GLOW_SQUID_HURT, ENTITY_GLOW_SQUID_SQUIRT, ENTITY_GOAT_AMBIENT, ENTITY_GOAT_DEATH, ENTITY_GOAT_EAT, ENTITY_GOAT_HORN_BREAK, ENTITY_GOAT_HURT, ENTITY_GOAT_LONG_JUMP, ENTITY_GOAT_MILK, ENTITY_GOAT_PREPARE_RAM, ENTITY_GOAT_RAM_IMPACT, ENTITY_GOAT_SCREAMING_AMBIENT, ENTITY_GOAT_SCREAMING_DEATH, ENTITY_GOAT_SCREAMING_EAT, ENTITY_GOAT_SCREAMING_HORN_BREAK, ENTITY_GOAT_SCREAMING_HURT, ENTITY_GOAT_SCREAMING_LONG_JUMP, ENTITY_GOAT_SCREAMING_MILK, ENTITY_GOAT_SCREAMING_PREPARE_RAM, ENTITY_GOAT_SCREAMING_RAM_IMPACT, ENTITY_GOAT_STEP, ENTITY_GUARDIAN_AMBIENT, ENTITY_GUARDIAN_AMBIENT_LAND, ENTITY_GUARDIAN_ATTACK, ENTITY_GUARDIAN_DEATH, ENTITY_GUARDIAN_DEATH_LAND, ENTITY_GUARDIAN_FLOP, ENTITY_GUARDIAN_HURT, ENTITY_GUARDIAN_HURT_LAND, ENTITY_HOGLIN_AMBIENT, ENTITY_HOGLIN_ANGRY, ENTITY_HOGLIN_ATTACK, ENTITY_HOGLIN_CONVERTED_TO_ZOMBIFIED, ENTITY_HOGLIN_DEATH, ENTITY_HOGLIN_HURT, ENTITY_HOGLIN_RETREAT, ENTITY_HOGLIN_STEP, ENTITY_HORSE_AMBIENT, ENTITY_HORSE_ANGRY, ENTITY_HORSE_ARMOR, ENTITY_HORSE_BREATHE, ENTITY_HORSE_DEATH, ENTITY_HORSE_EAT, ENTITY_HORSE_GALLOP, ENTITY_HORSE_HURT, ENTITY_HORSE_JUMP, ENTITY_HORSE_LAND, ENTITY_HORSE_SADDLE, ENTITY_HORSE_STEP, ENTITY_HORSE_STEP_WOOD, ENTITY_HOSTILE_BIG_FALL, ENTITY_HOSTILE_DEATH, ENTITY_HOSTILE_HURT, ENTITY_HOSTILE_SMALL_FALL, ENTITY_HOSTILE_SPLASH, ENTITY_HOSTILE_SWIM, ENTITY_HUSK_AMBIENT, ENTITY_HUSK_CONVERTED_TO_ZOMBIE, ENTITY_HUSK_DEATH, ENTITY_HUSK_HURT, ENTITY_HUSK_STEP, ENTITY_ILLUSIONER_AMBIENT, ENTITY_ILLUSIONER_CAST_SPELL, ENTITY_ILLUSIONER_DEATH, ENTITY_ILLUSIONER_HURT, ENTITY_ILLUSIONER_MIRROR_MOVE, ENTITY_ILLUSIONER_PREPARE_BLINDNESS, ENTITY_ILLUSIONER_PREPARE_MIRROR, ENTITY_IRON_GOLEM_ATTACK, ENTITY_IRON_GOLEM_DAMAGE, ENTITY_IRON_GOLEM_DEATH, ENTITY_IRON_GOLEM_HURT, ENTITY_IRON_GOLEM_REPAIR, ENTITY_IRON_GOLEM_STEP, ENTITY_ITEM_BREAK, ENTITY_ITEM_FRAME_ADD_ITEM, ENTITY_ITEM_FRAME_BREAK, ENTITY_ITEM_FRAME_PLACE, ENTITY_ITEM_FRAME_REMOVE_ITEM, ENTITY_ITEM_FRAME_ROTATE_ITEM, ENTITY_ITEM_PICKUP, ENTITY_LEASH_KNOT_BREAK, ENTITY_LEASH_KNOT_PLACE, ENTITY_LIGHTNING_BOLT_IMPACT, ENTITY_LIGHTNING_BOLT_THUNDER, ENTITY_LINGERING_POTION_THROW, ENTITY_LLAMA_AMBIENT, ENTITY_LLAMA_ANGRY, ENTITY_LLAMA_CHEST, ENTITY_LLAMA_DEATH, ENTITY_LLAMA_EAT, ENTITY_LLAMA_HURT, ENTITY_LLAMA_SPIT, ENTITY_LLAMA_STEP, ENTITY_LLAMA_SWAG, ENTITY_MAGMA_CUBE_DEATH, ENTITY_MAGMA_CUBE_DEATH_SMALL, ENTITY_MAGMA_CUBE_HURT, ENTITY_MAGMA_CUBE_HURT_SMALL, ENTITY_MAGMA_CUBE_JUMP, ENTITY_MAGMA_CUBE_SQUISH, ENTITY_MAGMA_CUBE_SQUISH_SMALL, ENTITY_MINECART_INSIDE, ENTITY_MINECART_INSIDE_UNDERWATER, ENTITY_MINECART_RIDING, ENTITY_MOOSHROOM_CONVERT, ENTITY_MOOSHROOM_EAT, ENTITY_MOOSHROOM_MILK, ENTITY_MOOSHROOM_SHEAR, ENTITY_MOOSHROOM_SUSPICIOUS_MILK, ENTITY_MULE_AMBIENT, ENTITY_MULE_ANGRY, ENTITY_MULE_CHEST, ENTITY_MULE_DEATH, ENTITY_MULE_EAT, ENTITY_MULE_HURT, ENTITY_OCELOT_AMBIENT, ENTITY_OCELOT_DEATH, ENTITY_OCELOT_HURT, ENTITY_PAINTING_BREAK, ENTITY_PAINTING_PLACE, ENTITY_PANDA_AGGRESSIVE_AMBIENT, ENTITY_PANDA_AMBIENT, ENTITY_PANDA_BITE, ENTITY_PANDA_CANT_BREED, ENTITY_PANDA_DEATH, ENTITY_PANDA_EAT, ENTITY_PANDA_HURT, ENTITY_PANDA_PRE_SNEEZE, ENTITY_PANDA_SNEEZE, ENTITY_PANDA_STEP, ENTITY_PANDA_WORRIED_AMBIENT, ENTITY_PARROT_AMBIENT, ENTITY_PARROT_DEATH, ENTITY_PARROT_EAT, ENTITY_PARROT_FLY, ENTITY_PARROT_HURT, ENTITY_PARROT_IMITATE_BLAZE, ENTITY_PARROT_IMITATE_CREEPER, ENTITY_PARROT_IMITATE_DROWNED, ENTITY_PARROT_IMITATE_ELDER_GUARDIAN, ENTITY_PARROT_IMITATE_ENDERMAN, ENTITY_PARROT_IMITATE_ENDERMITE, ENTITY_PARROT_IMITATE_ENDER_DRAGON, ENTITY_PARROT_IMITATE_EVOKER, ENTITY_PARROT_IMITATE_GHAST, ENTITY_PARROT_IMITATE_GUARDIAN, ENTITY_PARROT_IMITATE_HOGLIN, ENTITY_PARROT_IMITATE_HUSK, ENTITY_PARROT_IMITATE_ILLUSIONER, ENTITY_PARROT_IMITATE_MAGMA_CUBE, ENTITY_PARROT_IMITATE_PHANTOM, ENTITY_PARROT_IMITATE_PIGLIN, ENTITY_PARROT_IMITATE_PIGLIN_BRUTE, ENTITY_PARROT_IMITATE_PILLAGER, ENTITY_PARROT_IMITATE_POLAR_BEAR, ENTITY_PARROT_IMITATE_RAVAGER, ENTITY_PARROT_IMITATE_SHULKER, ENTITY_PARROT_IMITATE_SILVERFISH, ENTITY_PARROT_IMITATE_SKELETON, ENTITY_PARROT_IMITATE_SLIME, ENTITY_PARROT_IMITATE_SPIDER, ENTITY_PARROT_IMITATE_STRAY, ENTITY_PARROT_IMITATE_VEX, ENTITY_PARROT_IMITATE_VINDICATOR, ENTITY_PARROT_IMITATE_WARDEN, ENTITY_PARROT_IMITATE_WITCH, ENTITY_PARROT_IMITATE_WITHER, ENTITY_PARROT_IMITATE_WITHER_SKELETON, ENTITY_PARROT_IMITATE_WOLF, ENTITY_PARROT_IMITATE_ZOGLIN, ENTITY_PARROT_IMITATE_ZOMBIE, ENTITY_PARROT_IMITATE_ZOMBIE_VILLAGER, ENTITY_PARROT_STEP, ENTITY_PHANTOM_AMBIENT, ENTITY_PHANTOM_BITE, ENTITY_PHANTOM_DEATH, ENTITY_PHANTOM_FLAP, ENTITY_PHANTOM_HURT, ENTITY_PHANTOM_SWOOP, ENTITY_PIGLIN_ADMIRING_ITEM, ENTITY_PIGLIN_AMBIENT, ENTITY_PIGLIN_ANGRY, ENTITY_PIGLIN_BRUTE_AMBIENT, ENTITY_PIGLIN_BRUTE_ANGRY, ENTITY_PIGLIN_BRUTE_CONVERTED_TO_ZOMBIFIED, ENTITY_PIGLIN_BRUTE_DEATH, ENTITY_PIGLIN_BRUTE_HURT, ENTITY_PIGLIN_BRUTE_STEP, ENTITY_PIGLIN_CELEBRATE, ENTITY_PIGLIN_CONVERTED_TO_ZOMBIFIED, ENTITY_PIGLIN_DEATH, ENTITY_PIGLIN_HURT, ENTITY_PIGLIN_JEALOUS, ENTITY_PIGLIN_RETREAT, ENTITY_PIGLIN_STEP, ENTITY_PIG_AMBIENT, ENTITY_PIG_DEATH, ENTITY_PIG_HURT, ENTITY_PIG_SADDLE, ENTITY_PIG_STEP, ENTITY_PILLAGER_AMBIENT, ENTITY_PILLAGER_CELEBRATE, ENTITY_PILLAGER_DEATH, ENTITY_PILLAGER_HURT, ENTITY_PLAYER_ATTACK_CRIT, ENTITY_PLAYER_ATTACK_KNOCKBACK, ENTITY_PLAYER_ATTACK_NODAMAGE, ENTITY_PLAYER_ATTACK_STRONG, ENTITY_PLAYER_ATTACK_SWEEP, ENTITY_PLAYER_ATTACK_WEAK, ENTITY_PLAYER_BIG_FALL, ENTITY_PLAYER_BREATH, ENTITY_PLAYER_BURP, ENTITY_PLAYER_DEATH, ENTITY_PLAYER_HURT, ENTITY_PLAYER_HURT_DROWN, ENTITY_PLAYER_HURT_FREEZE, ENTITY_PLAYER_HURT_ON_FIRE, ENTITY_PLAYER_HURT_SWEET_BERRY_BUSH, ENTITY_PLAYER_LEVELUP, ENTITY_PLAYER_SMALL_FALL, ENTITY_PLAYER_SPLASH, ENTITY_PLAYER_SPLASH_HIGH_SPEED, ENTITY_PLAYER_SWIM, ENTITY_POLAR_BEAR_AMBIENT, ENTITY_POLAR_BEAR_AMBIENT_BABY, ENTITY_POLAR_BEAR_DEATH, ENTITY_POLAR_BEAR_HURT, ENTITY_POLAR_BEAR_STEP, ENTITY_POLAR_BEAR_WARNING, ENTITY_PUFFER_FISH_AMBIENT, ENTITY_PUFFER_FISH_BLOW_OUT, ENTITY_PUFFER_FISH_BLOW_UP, ENTITY_PUFFER_FISH_DEATH, ENTITY_PUFFER_FISH_FLOP, ENTITY_PUFFER_FISH_HURT, ENTITY_PUFFER_FISH_STING, ENTITY_RABBIT_AMBIENT, ENTITY_RABBIT_ATTACK, ENTITY_RABBIT_DEATH, ENTITY_RABBIT_HURT, ENTITY_RABBIT_JUMP, ENTITY_RAVAGER_AMBIENT, ENTITY_RAVAGER_ATTACK, ENTITY_RAVAGER_CELEBRATE, ENTITY_RAVAGER_DEATH, ENTITY_RAVAGER_HURT, ENTITY_RAVAGER_ROAR, ENTITY_RAVAGER_STEP, ENTITY_RAVAGER_STUNNED, ENTITY_SALMON_AMBIENT, ENTITY_SALMON_DEATH, ENTITY_SALMON_FLOP, ENTITY_SALMON_HURT, ENTITY_SHEEP_AMBIENT, ENTITY_SHEEP_DEATH, ENTITY_SHEEP_HURT, ENTITY_SHEEP_SHEAR, ENTITY_SHEEP_STEP, ENTITY_SHULKER_AMBIENT, ENTITY_SHULKER_BULLET_HIT, ENTITY_SHULKER_BULLET_HURT, ENTITY_SHULKER_CLOSE, ENTITY_SHULKER_DEATH, ENTITY_SHULKER_HURT, ENTITY_SHULKER_HURT_CLOSED, ENTITY_SHULKER_OPEN, ENTITY_SHULKER_SHOOT, ENTITY_SHULKER_TELEPORT, ENTITY_SILVERFISH_AMBIENT, ENTITY_SILVERFISH_DEATH, ENTITY_SILVERFISH_HURT, ENTITY_SILVERFISH_STEP, ENTITY_SKELETON_AMBIENT, ENTITY_SKELETON_CONVERTED_TO_STRAY, ENTITY_SKELETON_DEATH, ENTITY_SKELETON_HORSE_AMBIENT, ENTITY_SKELETON_HORSE_AMBIENT_WATER, ENTITY_SKELETON_HORSE_DEATH, ENTITY_SKELETON_HORSE_GALLOP_WATER, ENTITY_SKELETON_HORSE_HURT, ENTITY_SKELETON_HORSE_JUMP_WATER, ENTITY_SKELETON_HORSE_STEP_WATER, ENTITY_SKELETON_HORSE_SWIM, ENTITY_SKELETON_HURT, ENTITY_SKELETON_SHOOT, ENTITY_SKELETON_STEP, ENTITY_SLIME_ATTACK, ENTITY_SLIME_DEATH, ENTITY_SLIME_DEATH_SMALL, ENTITY_SLIME_HURT, ENTITY_SLIME_HURT_SMALL, ENTITY_SLIME_JUMP, ENTITY_SLIME_JUMP_SMALL, ENTITY_SLIME_SQUISH, ENTITY_SLIME_SQUISH_SMALL, ENTITY_SNIFFER_DEATH, ENTITY_SNIFFER_DIGGING, ENTITY_SNIFFER_DIGGING_STOP, ENTITY_SNIFFER_DROP_SEED, ENTITY_SNIFFER_EAT, ENTITY_SNIFFER_HAPPY, ENTITY_SNIFFER_HURT, ENTITY_SNIFFER_IDLE, ENTITY_SNIFFER_SCENTING, ENTITY_SNIFFER_SEARCHING, ENTITY_SNIFFER_SNIFFING, ENTITY_SNIFFER_STEP, ENTITY_SNOWBALL_THROW, ENTITY_SNOW_GOLEM_AMBIENT, ENTITY_SNOW_GOLEM_DEATH, ENTITY_SNOW_GOLEM_HURT, ENTITY_SNOW_GOLEM_SHEAR, ENTITY_SNOW_GOLEM_SHOOT, ENTITY_SPIDER_AMBIENT, ENTITY_SPIDER_DEATH, ENTITY_SPIDER_HURT, ENTITY_SPIDER_STEP, ENTITY_SPLASH_POTION_BREAK, ENTITY_SPLASH_POTION_THROW, ENTITY_SQUID_AMBIENT, ENTITY_SQUID_DEATH, ENTITY_SQUID_HURT, ENTITY_SQUID_SQUIRT, ENTITY_STRAY_AMBIENT, ENTITY_STRAY_DEATH, ENTITY_STRAY_HURT, ENTITY_STRAY_STEP, ENTITY_STRIDER_AMBIENT, ENTITY_STRIDER_DEATH, ENTITY_STRIDER_EAT, ENTITY_STRIDER_HAPPY, ENTITY_STRIDER_HURT, ENTITY_STRIDER_RETREAT, ENTITY_STRIDER_SADDLE, ENTITY_STRIDER_STEP, ENTITY_STRIDER_STEP_LAVA, ENTITY_TADPOLE_DEATH, ENTITY_TADPOLE_FLOP, ENTITY_TADPOLE_GROW_UP, ENTITY_TADPOLE_HURT, ENTITY_TNT_PRIMED, ENTITY_TROPICAL_FISH_AMBIENT, ENTITY_TROPICAL_FISH_DEATH, ENTITY_TROPICAL_FISH_FLOP, ENTITY_TROPICAL_FISH_HURT, ENTITY_TURTLE_AMBIENT_LAND, ENTITY_TURTLE_DEATH, ENTITY_TURTLE_DEATH_BABY, ENTITY_TURTLE_EGG_BREAK, ENTITY_TURTLE_EGG_CRACK, ENTITY_TURTLE_EGG_HATCH, ENTITY_TURTLE_HURT, ENTITY_TURTLE_HURT_BABY, ENTITY_TURTLE_LAY_EGG, ENTITY_TURTLE_SHAMBLE, ENTITY_TURTLE_SHAMBLE_BABY, ENTITY_TURTLE_SWIM, ENTITY_VEX_AMBIENT, ENTITY_VEX_CHARGE, ENTITY_VEX_DEATH, ENTITY_VEX_HURT, ENTITY_VILLAGER_AMBIENT, ENTITY_VILLAGER_CELEBRATE, ENTITY_VILLAGER_DEATH, ENTITY_VILLAGER_HURT, ENTITY_VILLAGER_NO, ENTITY_VILLAGER_TRADE, ENTITY_VILLAGER_WORK_ARMORER, ENTITY_VILLAGER_WORK_BUTCHER, ENTITY_VILLAGER_WORK_CARTOGRAPHER, ENTITY_VILLAGER_WORK_CLERIC, ENTITY_VILLAGER_WORK_FARMER, ENTITY_VILLAGER_WORK_FISHERMAN, ENTITY_VILLAGER_WORK_FLETCHER, ENTITY_VILLAGER_WORK_LEATHERWORKER, ENTITY_VILLAGER_WORK_LIBRARIAN, ENTITY_VILLAGER_WORK_MASON, ENTITY_VILLAGER_WORK_SHEPHERD, ENTITY_VILLAGER_WORK_TOOLSMITH, ENTITY_VILLAGER_WORK_WEAPONSMITH, ENTITY_VILLAGER_YES, ENTITY_VINDICATOR_AMBIENT, ENTITY_VINDICATOR_CELEBRATE, ENTITY_VINDICATOR_DEATH, ENTITY_VINDICATOR_HURT, ENTITY_WANDERING_TRADER_AMBIENT, ENTITY_WANDERING_TRADER_DEATH, ENTITY_WANDERING_TRADER_DISAPPEARED, ENTITY_WANDERING_TRADER_DRINK_MILK, ENTITY_WANDERING_TRADER_DRINK_POTION, ENTITY_WANDERING_TRADER_HURT, ENTITY_WANDERING_TRADER_NO, ENTITY_WANDERING_TRADER_REAPPEARED, ENTITY_WANDERING_TRADER_TRADE, ENTITY_WANDERING_TRADER_YES, ENTITY_WARDEN_AGITATED, ENTITY_WARDEN_AMBIENT, ENTITY_WARDEN_ANGRY, ENTITY_WARDEN_ATTACK_IMPACT, ENTITY_WARDEN_DEATH, ENTITY_WARDEN_DIG, ENTITY_WARDEN_EMERGE, ENTITY_WARDEN_HEARTBEAT, ENTITY_WARDEN_HURT, ENTITY_WARDEN_LISTENING, ENTITY_WARDEN_LISTENING_ANGRY, ENTITY_WARDEN_NEARBY_CLOSE, ENTITY_WARDEN_NEARBY_CLOSER, ENTITY_WARDEN_NEARBY_CLOSEST, ENTITY_WARDEN_ROAR, ENTITY_WARDEN_SNIFF, ENTITY_WARDEN_SONIC_BOOM, ENTITY_WARDEN_SONIC_CHARGE, ENTITY_WARDEN_STEP, ENTITY_WARDEN_TENDRIL_CLICKS, ENTITY_WITCH_AMBIENT, ENTITY_WITCH_CELEBRATE, ENTITY_WITCH_DEATH, ENTITY_WITCH_DRINK, ENTITY_WITCH_HURT, ENTITY_WITCH_THROW, ENTITY_WITHER_AMBIENT, ENTITY_WITHER_BREAK_BLOCK, ENTITY_WITHER_DEATH, ENTITY_WITHER_HURT, ENTITY_WITHER_SHOOT, ENTITY_WITHER_SKELETON_AMBIENT, ENTITY_WITHER_SKELETON_DEATH, ENTITY_WITHER_SKELETON_HURT, ENTITY_WITHER_SKELETON_STEP, ENTITY_WITHER_SPAWN, ENTITY_WOLF_AMBIENT, ENTITY_WOLF_DEATH, ENTITY_WOLF_GROWL, ENTITY_WOLF_HOWL, ENTITY_WOLF_HURT, ENTITY_WOLF_PANT, ENTITY_WOLF_SHAKE, ENTITY_WOLF_STEP, ENTITY_WOLF_WHINE, ENTITY_ZOGLIN_AMBIENT, ENTITY_ZOGLIN_ANGRY, ENTITY_ZOGLIN_ATTACK, ENTITY_ZOGLIN_DEATH, ENTITY_ZOGLIN_HURT, ENTITY_ZOGLIN_STEP, ENTITY_ZOMBIE_AMBIENT, ENTITY_ZOMBIE_ATTACK_IRON_DOOR, ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, ENTITY_ZOMBIE_CONVERTED_TO_DROWNED, ENTITY_ZOMBIE_DEATH, ENTITY_ZOMBIE_DESTROY_EGG, ENTITY_ZOMBIE_HORSE_AMBIENT, ENTITY_ZOMBIE_HORSE_DEATH, ENTITY_ZOMBIE_HORSE_HURT, ENTITY_ZOMBIE_HURT, ENTITY_ZOMBIE_INFECT, ENTITY_ZOMBIE_STEP, ENTITY_ZOMBIE_VILLAGER_AMBIENT, ENTITY_ZOMBIE_VILLAGER_CONVERTED, ENTITY_ZOMBIE_VILLAGER_CURE, ENTITY_ZOMBIE_VILLAGER_DEATH, ENTITY_ZOMBIE_VILLAGER_HURT, ENTITY_ZOMBIE_VILLAGER_STEP, ENTITY_ZOMBIFIED_PIGLIN_AMBIENT, ENTITY_ZOMBIFIED_PIGLIN_ANGRY, ENTITY_ZOMBIFIED_PIGLIN_DEATH, ENTITY_ZOMBIFIED_PIGLIN_HURT, EVENT_RAID_HORN, INTENTIONALLY_EMPTY, ITEM_ARMOR_EQUIP_CHAIN, ITEM_ARMOR_EQUIP_DIAMOND, ITEM_ARMOR_EQUIP_ELYTRA, ITEM_ARMOR_EQUIP_GENERIC, ITEM_ARMOR_EQUIP_GOLD, ITEM_ARMOR_EQUIP_IRON, ITEM_ARMOR_EQUIP_LEATHER, ITEM_ARMOR_EQUIP_NETHERITE, ITEM_ARMOR_EQUIP_TURTLE, ITEM_AXE_SCRAPE, ITEM_AXE_STRIP, ITEM_AXE_WAX_OFF, ITEM_BONE_MEAL_USE, ITEM_BOOK_PAGE_TURN, ITEM_BOOK_PUT, ITEM_BOTTLE_EMPTY, ITEM_BOTTLE_FILL, ITEM_BOTTLE_FILL_DRAGONBREATH, ITEM_BRUSH_BRUSHING, ITEM_BRUSH_BRUSHING_GENERIC, ITEM_BRUSH_BRUSHING_GRAVEL, ITEM_BRUSH_BRUSHING_GRAVEL_COMPLETE, ITEM_BRUSH_BRUSHING_SAND, ITEM_BRUSH_BRUSHING_SAND_COMPLETE, ITEM_BRUSH_BRUSH_SAND_COMPLETED, ITEM_BUCKET_EMPTY, ITEM_BUCKET_EMPTY_AXOLOTL, ITEM_BUCKET_EMPTY_FISH, ITEM_BUCKET_EMPTY_LAVA, ITEM_BUCKET_EMPTY_POWDER_SNOW, ITEM_BUCKET_EMPTY_TADPOLE, ITEM_BUCKET_FILL, ITEM_BUCKET_FILL_AXOLOTL, ITEM_BUCKET_FILL_FISH, ITEM_BUCKET_FILL_LAVA, ITEM_BUCKET_FILL_POWDER_SNOW, ITEM_BUCKET_FILL_TADPOLE, ITEM_BUNDLE_DROP_CONTENTS, ITEM_BUNDLE_INSERT, ITEM_BUNDLE_REMOVE_ONE, ITEM_CHORUS_FRUIT_TELEPORT, ITEM_CROP_PLANT, ITEM_CROSSBOW_HIT, ITEM_CROSSBOW_LOADING_END, ITEM_CROSSBOW_LOADING_MIDDLE, ITEM_CROSSBOW_LOADING_START, ITEM_CROSSBOW_QUICK_CHARGE_1, ITEM_CROSSBOW_QUICK_CHARGE_2, ITEM_CROSSBOW_QUICK_CHARGE_3, ITEM_CROSSBOW_SHOOT, ITEM_DYE_USE, ITEM_ELYTRA_FLYING, ITEM_FIRECHARGE_USE, ITEM_FLINTANDSTEEL_USE, ITEM_GLOW_INK_SAC_USE, ITEM_GOAT_HORN_PLAY, ITEM_GOAT_HORN_SOUND_0, ITEM_GOAT_HORN_SOUND_1, ITEM_GOAT_HORN_SOUND_2, ITEM_GOAT_HORN_SOUND_3, ITEM_GOAT_HORN_SOUND_4, ITEM_GOAT_HORN_SOUND_5, ITEM_GOAT_HORN_SOUND_6, ITEM_GOAT_HORN_SOUND_7, ITEM_HOE_TILL, ITEM_HONEYCOMB_WAX_ON, ITEM_HONEY_BOTTLE_DRINK, ITEM_INK_SAC_USE, ITEM_LODESTONE_COMPASS_LOCK, ITEM_NETHER_WART_PLANT, ITEM_SHIELD_BLOCK, ITEM_SHIELD_BREAK, ITEM_SHOVEL_FLATTEN, ITEM_SPYGLASS_STOP_USING, ITEM_SPYGLASS_USE, ITEM_TOTEM_USE, ITEM_TRIDENT_HIT, ITEM_TRIDENT_HIT_GROUND, ITEM_TRIDENT_RETURN, ITEM_TRIDENT_RIPTIDE_1, ITEM_TRIDENT_RIPTIDE_2, ITEM_TRIDENT_RIPTIDE_3, ITEM_TRIDENT_THROW, ITEM_TRIDENT_THUNDER, MUSIC_CREATIVE, MUSIC_CREDITS, MUSIC_DISC_11, MUSIC_DISC_13, MUSIC_DISC_5, MUSIC_DISC_BLOCKS, MUSIC_DISC_CAT, MUSIC_DISC_CHIRP, MUSIC_DISC_FAR, MUSIC_DISC_MALL, MUSIC_DISC_MELLOHI, MUSIC_DISC_OTHERSIDE, MUSIC_DISC_PIGSTEP, MUSIC_DISC_RELIC, MUSIC_DISC_STAL, MUSIC_DISC_STRAD, MUSIC_DISC_WAIT, MUSIC_DISC_WARD, MUSIC_DRAGON, MUSIC_END, MUSIC_GAME, MUSIC_MENU, MUSIC_NETHER_BASALT_DELTAS, MUSIC_NETHER_CRIMSON_FOREST, MUSIC_NETHER_NETHER_WASTES, MUSIC_NETHER_SOUL_SAND_VALLEY, MUSIC_NETHER_WARPED_FOREST, MUSIC_OVERWORLD_BADLANDS, MUSIC_OVERWORLD_BAMBOO_JUNGLE, MUSIC_OVERWORLD_CHERRY_GROVE, MUSIC_OVERWORLD_DEEP_DARK, MUSIC_OVERWORLD_DESERT, MUSIC_OVERWORLD_DRIPSTONE_CAVES, MUSIC_OVERWORLD_FLOWER_FOREST, MUSIC_OVERWORLD_FOREST, MUSIC_OVERWORLD_FROZEN_PEAKS, MUSIC_OVERWORLD_GROVE, MUSIC_OVERWORLD_JAGGED_PEAKS, MUSIC_OVERWORLD_JUNGLE, MUSIC_OVERWORLD_JUNGLE_AND_FOREST, MUSIC_OVERWORLD_LUSH_CAVES, MUSIC_OVERWORLD_MEADOW, MUSIC_OVERWORLD_OLD_GROWTH_TAIGA, MUSIC_OVERWORLD_SNOWY_SLOPES, MUSIC_OVERWORLD_SPARSE_JUNGLE, MUSIC_OVERWORLD_STONY_PEAKS, MUSIC_OVERWORLD_SWAMP, MUSIC_UNDER_WATER, PARTICLE_SOUL_ESCAPE, UI_BUTTON_CLICK, UI_CARTOGRAPHY_TABLE_TAKE_RESULT, UI_LOOM_SELECT_PATTERN, UI_LOOM_TAKE_RESULT, UI_STONECUTTER_SELECT_RECIPE, UI_STONECUTTER_TAKE_RESULT, UI_TOAST_CHALLENGE_COMPLETE, UI_TOAST_IN, UI_TOAST_OUT, WEATHER_RAIN, WEATHER_RAIN_ABOVE};
    }

    static {
        $VALUES = XSound.$values();
        VALUES = XSound.values();
    }

    private static final class Data {
        private static final WeakHashMap<String, Sound> BUKKIT_NAMES = new WeakHashMap();
        private static final Map<String, XSound> NAMES = new HashMap<String, XSound>();

        private Data() {
        }

        static {
            for (Sound sound : Sound.values()) {
                BUKKIT_NAMES.put(sound.name(), sound);
            }
        }
    }

    public static class Record
    implements Cloneable {
        @Nonnull
        public final XSound sound;
        public final float volume;
        public final float pitch;
        public boolean playAtLocation;
        @Nullable
        public Player player;
        @Nullable
        public Location location;

        public Record(@Nonnull XSound xSound) {
            this(xSound, 1.0f, 1.0f);
        }

        public Record(@Nonnull XSound xSound, float f, float f2) {
            this(xSound, null, null, f, f2, false);
        }

        public Record(@Nonnull XSound xSound, @Nullable Player player, @Nullable Location location, float f, float f2, boolean bl) {
            this.sound = Objects.requireNonNull(xSound, "Sound cannot be null");
            this.player = player;
            this.location = location;
            this.volume = f;
            this.pitch = f2;
            this.playAtLocation = bl;
        }

        public Record forPlayer(@Nullable Player player) {
            this.player = player;
            return this;
        }

        public Record atLocation(@Nullable Location location) {
            this.location = location;
            return this;
        }

        public Record forPlayerAtLocation(@Nullable Player player, @Nullable Location location) {
            this.player = player;
            this.location = location;
            return this;
        }

        public void play() {
            if (this.player == null && this.location == null) {
                throw new IllegalStateException("Cannot play sound when there is no location available");
            }
            this.play(this.player == null ? this.location : this.player.getLocation());
        }

        public void play(@Nonnull Location location) {
            Objects.requireNonNull(location, "Cannot play sound at null location");
            if (this.playAtLocation || this.player == null) {
                this.location.getWorld().playSound(location, this.sound.parseSound(), this.volume, this.pitch);
            } else {
                this.player.playSound(location, this.sound.parseSound(), this.volume, this.pitch);
            }
        }

        public void stopSound() {
            if (this.playAtLocation) {
                for (Entity entity : this.location.getWorld().getNearbyEntities(this.location, (double)this.volume, (double)this.volume, (double)this.volume)) {
                    if (!(entity instanceof Player)) continue;
                    ((Player)entity).stopSound(this.sound.parseSound());
                }
            }
            if (this.player != null) {
                this.player.stopSound(this.sound.parseSound());
            }
        }

        public String rebuild() {
            return (this.playAtLocation ? "~" : "") + this.sound.sound + ", " + this.volume + ", " + this.pitch;
        }

        public Record clone() {
            return new Record(this.sound, this.player, this.location, this.volume, this.pitch, this.playAtLocation);
        }
    }
}

