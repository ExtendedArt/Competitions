/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.CropState
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.data.Ageable
 *  org.bukkit.material.Crops
 *  org.bukkit.material.MaterialData
 */
package fun.lewisdev.tournaments.utility.universal;

import fun.lewisdev.tournaments.utility.universal.XMaterial;
import org.bukkit.CropState;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.Ageable;
import org.bukkit.material.Crops;
import org.bukkit.material.MaterialData;

public final class XBlock {
    public static boolean isCrop(Block block) {
        if (XMaterial.supports(13)) {
            return block.getBlockData() instanceof Ageable;
        }
        BlockState blockState = block.getState();
        MaterialData materialData = blockState.getData();
        return materialData instanceof Crops;
    }

    public static boolean isFullyGrown(Block block) {
        if (XMaterial.supports(13)) {
            Ageable ageable = (Ageable)block.getBlockData();
            return ageable.getAge() == ageable.getMaximumAge();
        }
        BlockState blockState = block.getState();
        MaterialData materialData = blockState.getData();
        return ((Crops)materialData).getState() == CropState.RIPE;
    }
}

