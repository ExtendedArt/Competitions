/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.utility;

public final class Timeline
extends Enum<Timeline> {
    public static final /* enum */ Timeline SPECIFIC = new Timeline();
    public static final /* enum */ Timeline DAILY = new Timeline();
    public static final /* enum */ Timeline WEEKLY = new Timeline();
    public static final /* enum */ Timeline MONTHLY = new Timeline();
    private static final /* synthetic */ Timeline[] $VALUES;

    public static Timeline[] values() {
        return (Timeline[])$VALUES.clone();
    }

    public static Timeline valueOf(String string) {
        return Enum.valueOf(Timeline.class, string);
    }

    private static /* synthetic */ Timeline[] $values() {
        return new Timeline[]{SPECIFIC, DAILY, WEEKLY, MONTHLY};
    }

    static {
        $VALUES = Timeline.$values();
    }
}

