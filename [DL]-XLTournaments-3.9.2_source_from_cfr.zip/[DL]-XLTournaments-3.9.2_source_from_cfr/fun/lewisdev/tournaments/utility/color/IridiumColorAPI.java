/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  net.md_5.bungee.api.ChatColor
 */
package fun.lewisdev.tournaments.utility.color;

import com.google.common.collect.ImmutableMap;
import fun.lewisdev.tournaments.utility.color.patterns.GradientPattern;
import fun.lewisdev.tournaments.utility.color.patterns.Pattern;
import fun.lewisdev.tournaments.utility.color.patterns.RainbowPattern;
import fun.lewisdev.tournaments.utility.color.patterns.SolidPattern;
import fun.lewisdev.tournaments.utility.universal.XMaterial;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.md_5.bungee.api.ChatColor;

public class IridiumColorAPI {
    private static final boolean SUPPORTS_RGB = XMaterial.getVersion() >= 16;
    private static final List<String> SPECIAL_COLORS = Arrays.asList("&l", "&n", "&o", "&k", "&m");
    private static final Map<Color, ChatColor> COLORS = ImmutableMap.builder().put((Object)new Color(0), (Object)ChatColor.getByChar((char)'0')).put((Object)new Color(170), (Object)ChatColor.getByChar((char)'1')).put((Object)new Color(43520), (Object)ChatColor.getByChar((char)'2')).put((Object)new Color(43690), (Object)ChatColor.getByChar((char)'3')).put((Object)new Color(0xAA0000), (Object)ChatColor.getByChar((char)'4')).put((Object)new Color(0xAA00AA), (Object)ChatColor.getByChar((char)'5')).put((Object)new Color(0xFFAA00), (Object)ChatColor.getByChar((char)'6')).put((Object)new Color(0xAAAAAA), (Object)ChatColor.getByChar((char)'7')).put((Object)new Color(0x555555), (Object)ChatColor.getByChar((char)'8')).put((Object)new Color(0x5555FF), (Object)ChatColor.getByChar((char)'9')).put((Object)new Color(0x55FF55), (Object)ChatColor.getByChar((char)'a')).put((Object)new Color(0x55FFFF), (Object)ChatColor.getByChar((char)'b')).put((Object)new Color(0xFF5555), (Object)ChatColor.getByChar((char)'c')).put((Object)new Color(0xFF55FF), (Object)ChatColor.getByChar((char)'d')).put((Object)new Color(0xFFFF55), (Object)ChatColor.getByChar((char)'e')).put((Object)new Color(0xFFFFFF), (Object)ChatColor.getByChar((char)'f')).build();
    private static final List<Pattern> PATTERNS = Arrays.asList(new GradientPattern(), new SolidPattern(), new RainbowPattern());

    public static String process(String string) {
        for (Pattern pattern : PATTERNS) {
            string = pattern.process(string);
        }
        return ChatColor.translateAlternateColorCodes((char)'&', (String)string);
    }

    public static List<String> process(List<String> list) {
        return list.stream().map(IridiumColorAPI::process).collect(Collectors.toList());
    }

    public static String color(String string, Color color) {
        return (SUPPORTS_RGB ? ChatColor.of((Color)color) : IridiumColorAPI.getClosestColor(color)) + string;
    }

    public static String color(String string, Color color, Color color2) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String arrchatColor2 : SPECIAL_COLORS) {
            if (!string.contains(arrchatColor2)) continue;
            stringBuilder.append(arrchatColor2);
            string = string.replace(arrchatColor2, "");
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        ChatColor[] arrchatColor = IridiumColorAPI.createGradient(color, color2, string.length());
        String[] arrstring = string.split("");
        for (int i = 0; i < string.length(); ++i) {
            stringBuilder2.append((Object)arrchatColor[i]).append((CharSequence)stringBuilder).append(arrstring[i]);
        }
        return stringBuilder2.toString();
    }

    public static String rainbow(String string, float f) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String arrchatColor2 : SPECIAL_COLORS) {
            if (!string.contains(arrchatColor2)) continue;
            stringBuilder.append(arrchatColor2);
            string = string.replace(arrchatColor2, "");
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        ChatColor[] arrchatColor = IridiumColorAPI.createRainbow(string.length(), f);
        String[] arrstring = string.split("");
        for (int i = 0; i < string.length(); ++i) {
            stringBuilder2.append((Object)arrchatColor[i]).append((CharSequence)stringBuilder).append(arrstring[i]);
        }
        return stringBuilder2.toString();
    }

    public static ChatColor getColor(String string) {
        return SUPPORTS_RGB ? ChatColor.of((Color)new Color(Integer.parseInt(string, 16))) : IridiumColorAPI.getClosestColor(new Color(Integer.parseInt(string, 16)));
    }

    public static String stripColorFormatting(String string) {
        return string.replaceAll("<#[0-9A-F]{6}>|[&\u00c2\u00a7][a-f0-9lnokm]|<[/]?[A-Z]{5,8}(:[0-9A-F]{6})?[0-9]*>", "");
    }

    private static ChatColor[] createRainbow(int n, float f) {
        ChatColor[] arrchatColor = new ChatColor[n];
        double d = 1.0 / (double)n;
        for (int i = 0; i < n; ++i) {
            Color color = Color.getHSBColor((float)(d * (double)i), f, f);
            arrchatColor[i] = SUPPORTS_RGB ? ChatColor.of((Color)color) : IridiumColorAPI.getClosestColor(color);
        }
        return arrchatColor;
    }

    private static ChatColor[] createGradient(Color color, Color color2, int n) {
        ChatColor[] arrchatColor = new ChatColor[n];
        int n2 = Math.abs(color.getRed() - color2.getRed()) / (n - 1);
        int n3 = Math.abs(color.getGreen() - color2.getGreen()) / (n - 1);
        int n4 = Math.abs(color.getBlue() - color2.getBlue()) / (n - 1);
        int[] arrn = new int[]{color.getRed() < color2.getRed() ? 1 : -1, color.getGreen() < color2.getGreen() ? 1 : -1, color.getBlue() < color2.getBlue() ? 1 : -1};
        for (int i = 0; i < n; ++i) {
            Color color3 = new Color(color.getRed() + n2 * i * arrn[0], color.getGreen() + n3 * i * arrn[1], color.getBlue() + n4 * i * arrn[2]);
            arrchatColor[i] = SUPPORTS_RGB ? ChatColor.of((Color)color3) : IridiumColorAPI.getClosestColor(color3);
        }
        return arrchatColor;
    }

    private static ChatColor getClosestColor(Color color) {
        Color color2 = null;
        double d = 2.147483647E9;
        for (Color color3 : COLORS.keySet()) {
            double d2 = Math.pow(color.getRed() - color3.getRed(), 2.0) + Math.pow(color.getGreen() - color3.getGreen(), 2.0) + Math.pow(color.getBlue() - color3.getBlue(), 2.0);
            if (!(d > d2)) continue;
            color2 = color3;
            d = d2;
        }
        return COLORS.get(color2);
    }
}

