/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.utility.color.patterns;

import fun.lewisdev.tournaments.utility.color.IridiumColorAPI;
import fun.lewisdev.tournaments.utility.color.patterns.Pattern;
import java.awt.Color;
import java.util.regex.Matcher;

public class GradientPattern
implements Pattern {
    java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\\{#([A-Fa-f0-9]{6})[>}](.*?)[<{]/#([A-Fa-f0-9]{6})}");

    @Override
    public String process(String string) {
        Matcher matcher = this.pattern.matcher(string);
        while (matcher.find()) {
            String string2 = matcher.group(1);
            String string3 = matcher.group(3);
            String string4 = matcher.group(2);
            string = string.replace(matcher.group(), IridiumColorAPI.color(string4, new Color(Integer.parseInt(string2, 16)), new Color(Integer.parseInt(string3, 16))));
        }
        return string;
    }
}

