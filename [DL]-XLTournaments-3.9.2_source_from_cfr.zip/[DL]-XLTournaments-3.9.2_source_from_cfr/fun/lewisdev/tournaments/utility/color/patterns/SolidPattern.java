/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.utility.color.patterns;

import fun.lewisdev.tournaments.utility.color.IridiumColorAPI;
import fun.lewisdev.tournaments.utility.color.patterns.Pattern;
import java.util.regex.Matcher;

public class SolidPattern
implements Pattern {
    public static final java.util.regex.Pattern PATTERN = java.util.regex.Pattern.compile("\\{#([A-Fa-f0-9]{6})}|[&]?#([A-Fa-f0-9]{6})");

    @Override
    public String process(String string) {
        Matcher matcher = PATTERN.matcher(string);
        while (matcher.find()) {
            String string2 = matcher.group(1);
            if (string2 == null) {
                string2 = matcher.group(2);
            }
            string = string.replace(matcher.group(), "" + IridiumColorAPI.getColor(string2));
        }
        return string;
    }
}

