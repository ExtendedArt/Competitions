/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.utility.color.patterns;

public interface Pattern {
    public String process(String var1);
}

