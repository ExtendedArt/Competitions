/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  org.apache.commons.lang.StringUtils
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 */
package fun.lewisdev.tournaments.utility;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import fun.lewisdev.tournaments.utility.universal.XMaterial;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.lang.StringUtils;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class Base64Util {
    private static final Map<String, ItemStack> cache = new HashMap<String, ItemStack>();

    public static ItemStack getBaseHead(String string) {
        if (cache.containsKey(string)) {
            return cache.get(string);
        }
        ItemStack itemStack = XMaterial.PLAYER_HEAD.parseItem();
        SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
        GameProfile gameProfile = new GameProfile(UUID.randomUUID(), "");
        gameProfile.getProperties().put((Object)"textures", (Object)new Property("textures", string));
        try {
            Field field = skullMeta.getClass().getDeclaredField("profile");
            field.setAccessible(true);
            field.set((Object)skullMeta, (Object)gameProfile);
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException | SecurityException exception) {
            exception.printStackTrace();
        }
        itemStack.setItemMeta((ItemMeta)skullMeta);
        cache.put(string, itemStack);
        return itemStack;
    }

    private static String getUrl(String string) {
        String string2 = StringUtils.replace((String)string, (String)"-", (String)"");
        URL uRL = null;
        try {
            uRL = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + string2 + "?unsigned=false");
        }
        catch (MalformedURLException malformedURLException) {
            malformedURLException.printStackTrace();
        }
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(uRL.openStream());
            JsonObject jsonObject = new JsonParser().parse(inputStreamReader).getAsJsonObject().get("properties").getAsJsonArray().get(0).getAsJsonObject();
            return jsonObject.get("value").getAsString();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return null;
        }
    }

    public static GameProfile getGameProfile(String string) {
        GameProfile gameProfile = new GameProfile(UUID.randomUUID(), null);
        gameProfile.getProperties().put((Object)"textures", (Object)new Property("textures", string));
        return gameProfile;
    }

    public static ItemStack getSkull(UUID uUID) {
        if (cache.containsKey(uUID.toString())) {
            return cache.get(uUID.toString());
        }
        String string = Base64Util.getUrl(uUID.toString());
        ItemStack itemStack = XMaterial.PLAYER_HEAD.parseItem();
        if (string.isEmpty()) {
            return itemStack;
        }
        SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
        GameProfile gameProfile = Base64Util.getGameProfile(string);
        try {
            Field field = skullMeta.getClass().getDeclaredField("profile");
            field.setAccessible(true);
            field.set((Object)skullMeta, (Object)gameProfile);
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException exception) {
            exception.printStackTrace();
        }
        itemStack.setItemMeta((ItemMeta)skullMeta);
        cache.put(uUID.toString(), itemStack);
        return itemStack;
    }
}

