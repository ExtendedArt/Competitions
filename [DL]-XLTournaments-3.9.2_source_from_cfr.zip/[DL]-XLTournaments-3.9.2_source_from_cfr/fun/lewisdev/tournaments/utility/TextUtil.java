/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.OfflinePlayer
 */
package fun.lewisdev.tournaments.utility;

import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.utility.TimeUtil;
import fun.lewisdev.tournaments.utility.color.IridiumColorAPI;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.OfflinePlayer;

public class TextUtil {
    private static final String N0NCE_ID = "1870218064";
    private static final String US3R_ID = "94252";
    private static final String US3R_ID2 = "94252321";
    private static final Pattern HEX_PATTERN = Pattern.compile("#<([A-Fa-f0-9]){6}>");
    private static final NumberFormat NUMBER_FORMAT = NumberFormat.getNumberInstance(Locale.US);

    public static boolean isMCMarket() {
        String string = "%__FILEHASH__%";
        return !(string.charAt(0) + string + string.charAt(0)).equals("%%__FILEHASH__%%");
    }

    public static boolean isValidDownload() {
        String string = "%__USER__%";
        return !(string.charAt(0) + string + string.charAt(0)).equals(US3R_ID);
    }

    public static String getNumberFormatted(int n) {
        return NUMBER_FORMAT.format(n);
    }

    public static String color(String string) {
        return IridiumColorAPI.process(string);
    }

    public static String fromList(List<?> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < list.size(); ++i) {
            if (i != 0 && list.get(i).toString().equals("")) {
                stringBuilder.append("&r\n ");
            } else {
                stringBuilder.append(list.get(i).toString());
            }
            stringBuilder.append(i + 1 != list.size() ? "\n" : "");
        }
        return stringBuilder.toString();
    }

    public static List<String> setPlaceholders(List<String> list, UUID uUID, Tournament tournament) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string : list) {
            arrayList.add(TextUtil.setPlaceholders(string, uUID, tournament));
        }
        return arrayList;
    }

    public static String setPlaceholders(String string, UUID uUID, Tournament tournament) {
        Matcher matcher;
        Pattern pattern;
        String string2;
        string = string.replace("{START_DAY}", tournament.getStartDay()).replace("{END_DAY}", tournament.getEndDay()).replace("{START_MONTH}", tournament.getStartMonth()).replace("{START_MONTH_NUMBER}", tournament.getStartMonthNumber()).replace("{END_MONTH_NUMBER}", tournament.getEndMonthNumber()).replace("{END_MONTH}", tournament.getEndMonth()).replace("{PLAYER_POSITION}", String.valueOf(tournament.getPosition(uUID))).replace("{PLAYER_POSITION_FORMATTED}", TextUtil.getNumberFormatted(tournament.getPosition(uUID))).replace("{PLAYER_SCORE}", String.valueOf(tournament.getScore(uUID))).replace("{PLAYER_SCORE_FORMATTED}", TextUtil.getNumberFormatted(tournament.getScore(uUID))).replace("{PLAYER_SCORE_TIME_FORMATTED}", TimeUtil.formatTime(tournament.getScore(uUID))).replace("{TIME_REMAINING}", tournament.getTimeRemaining());
        try {
            string2 = "\\{LEADER_NAME_(\\w+)}";
            pattern = Pattern.compile("\\{LEADER_NAME_(\\w+)}");
            matcher = pattern.matcher(string);
            while (matcher.find()) {
                OfflinePlayer offlinePlayer = tournament.getPlayerFromPosition(Integer.parseInt(matcher.group(1)));
                string = matcher.replaceAll(offlinePlayer != null ? offlinePlayer.getName() : "N/A");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            string2 = "\\{LEADER_SCORE_(\\w+)}";
            pattern = Pattern.compile("\\{LEADER_SCORE_(\\w+)}");
            matcher = pattern.matcher(string);
            while (matcher.find()) {
                string = matcher.replaceAll(String.valueOf(tournament.getScoreFromPosition(Integer.parseInt(matcher.group(1)))));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            string2 = "\\{LEADER_SCORE_FORMATTED_(\\w+)}";
            pattern = Pattern.compile("\\{LEADER_SCORE_FORMATTED_(\\w+)}");
            matcher = pattern.matcher(string);
            while (matcher.find()) {
                string = matcher.replaceAll(TextUtil.getNumberFormatted(tournament.getScoreFromPosition(Integer.parseInt(matcher.group(1)))));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            string2 = "\\{LEADER_SCORE_TIME_FORMATTED_(\\w+)}";
            pattern = Pattern.compile("\\{LEADER_SCORE_TIME_FORMATTED_(\\w+)}");
            matcher = pattern.matcher(string);
            while (matcher.find()) {
                string = matcher.replaceAll(TimeUtil.formatTime(tournament.getScoreFromPosition(Integer.parseInt(matcher.group(1)))));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return string;
    }
}

