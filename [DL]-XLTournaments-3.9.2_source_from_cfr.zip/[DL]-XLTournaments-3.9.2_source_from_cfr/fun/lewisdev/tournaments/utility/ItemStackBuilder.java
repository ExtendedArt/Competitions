/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.LeatherArmorMeta
 *  org.bukkit.inventory.meta.SkullMeta
 */
package fun.lewisdev.tournaments.utility;

import fun.lewisdev.tournaments.utility.Base64Util;
import fun.lewisdev.tournaments.utility.TextUtil;
import fun.lewisdev.tournaments.utility.universal.XMaterial;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class ItemStackBuilder {
    private final ItemStack ITEM_STACK;

    public ItemStackBuilder(Material material) {
        this.ITEM_STACK = new ItemStack(material);
    }

    public ItemStackBuilder(ItemStack itemStack) {
        this.ITEM_STACK = itemStack;
    }

    public static ItemStackBuilder getItemStack(ConfigurationSection configurationSection) {
        ItemStack itemStack = XMaterial.matchXMaterial(configurationSection.getString("material")).get().parseItem();
        if (itemStack.getType() == XMaterial.PLAYER_HEAD.parseMaterial() && configurationSection.contains("base64")) {
            itemStack = Base64Util.getBaseHead(configurationSection.getString("base64")).clone();
        }
        ItemStackBuilder itemStackBuilder = new ItemStackBuilder(itemStack);
        if (configurationSection.contains("amount")) {
            itemStackBuilder.withAmount(configurationSection.getInt("amount"));
        }
        if (configurationSection.contains("username")) {
            itemStackBuilder.setSkullOwner(configurationSection.getString("username"));
        }
        if (configurationSection.contains("display_name")) {
            itemStackBuilder.withName(configurationSection.getString("display_name"));
        }
        if (configurationSection.contains("lore")) {
            itemStackBuilder.withLore(configurationSection.getStringList("lore"));
        }
        if (configurationSection.contains("custom_model_data")) {
            itemStackBuilder.withCustomModelData(configurationSection.getInt("custom_model_data"));
        }
        if (configurationSection.contains("glow") && configurationSection.getBoolean("glow")) {
            itemStackBuilder.withGlow();
        }
        if (configurationSection.contains("item_flags")) {
            ArrayList arrayList = new ArrayList();
            configurationSection.getStringList("item_flags").forEach(string -> {
                try {
                    ItemFlag itemFlag = ItemFlag.valueOf((String)string);
                    arrayList.add(itemFlag);
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    // empty catch block
                }
            });
            itemStackBuilder.withFlags(arrayList.toArray((T[])new ItemFlag[0]));
        }
        return itemStackBuilder;
    }

    public ItemStackBuilder withAmount(int n) {
        this.ITEM_STACK.setAmount(n);
        return this;
    }

    public ItemStackBuilder withName(String string) {
        ItemMeta itemMeta = this.ITEM_STACK.getItemMeta();
        itemMeta.setDisplayName(TextUtil.color(string));
        this.ITEM_STACK.setItemMeta(itemMeta);
        return this;
    }

    public ItemStackBuilder setSkullOwner(String string) {
        try {
            SkullMeta skullMeta = (SkullMeta)this.ITEM_STACK.getItemMeta();
            skullMeta.setOwner(string);
            this.ITEM_STACK.setItemMeta((ItemMeta)skullMeta);
        }
        catch (ClassCastException classCastException) {
            // empty catch block
        }
        return this;
    }

    public ItemStackBuilder withLore(List<String> list) {
        ItemMeta itemMeta = this.ITEM_STACK.getItemMeta();
        ArrayList arrayList = new ArrayList();
        list.forEach(string -> arrayList.add(TextUtil.color(string)));
        itemMeta.setLore(arrayList);
        this.ITEM_STACK.setItemMeta(itemMeta);
        return this;
    }

    public ItemStackBuilder withFlags(ItemFlag ... arritemFlag) {
        ItemMeta itemMeta = this.ITEM_STACK.getItemMeta();
        itemMeta.addItemFlags(arritemFlag);
        this.ITEM_STACK.setItemMeta(itemMeta);
        return this;
    }

    public ItemStackBuilder withCustomModelData(int n) {
        ItemMeta itemMeta = this.ITEM_STACK.getItemMeta();
        itemMeta.setCustomModelData(Integer.valueOf(n));
        this.ITEM_STACK.setItemMeta(itemMeta);
        return this;
    }

    public ItemStackBuilder withEnchantment(Enchantment enchantment, int n) {
        this.ITEM_STACK.addUnsafeEnchantment(enchantment, n);
        return this;
    }

    public ItemStackBuilder withEnchantment(Enchantment enchantment) {
        return this.withEnchantment(enchantment, 1);
    }

    public ItemStackBuilder withGlow() {
        ItemMeta itemMeta = this.ITEM_STACK.getItemMeta();
        itemMeta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
        this.ITEM_STACK.setItemMeta(itemMeta);
        this.ITEM_STACK.addUnsafeEnchantment(Enchantment.ARROW_INFINITE, 1);
        return this;
    }

    public ItemStackBuilder withType(Material material) {
        this.ITEM_STACK.setType(material);
        return this;
    }

    public ItemStackBuilder clearLore() {
        ItemMeta itemMeta = this.ITEM_STACK.getItemMeta();
        itemMeta.setLore(new ArrayList());
        this.ITEM_STACK.setItemMeta(itemMeta);
        return this;
    }

    public ItemStackBuilder clearEnchantments() {
        for (Enchantment enchantment : this.ITEM_STACK.getEnchantments().keySet()) {
            this.ITEM_STACK.removeEnchantment(enchantment);
        }
        return this;
    }

    public ItemStackBuilder withColor(Color color) {
        Material material = this.ITEM_STACK.getType();
        if (material == Material.LEATHER_BOOTS || material == Material.LEATHER_CHESTPLATE || material == Material.LEATHER_HELMET || material == Material.LEATHER_LEGGINGS) {
            LeatherArmorMeta leatherArmorMeta = (LeatherArmorMeta)this.ITEM_STACK.getItemMeta();
            leatherArmorMeta.setColor(color);
            this.ITEM_STACK.setItemMeta((ItemMeta)leatherArmorMeta);
            return this;
        }
        throw new IllegalArgumentException("withColor is only applicable for leather armor!");
    }

    public ItemStack build() {
        return this.ITEM_STACK;
    }
}

