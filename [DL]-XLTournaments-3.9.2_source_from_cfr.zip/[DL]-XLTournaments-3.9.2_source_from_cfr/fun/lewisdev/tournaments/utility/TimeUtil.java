/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.utility;

import fun.lewisdev.tournaments.utility.Timeline;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.Locale;

public class TimeUtil {
    public static boolean isWaiting(ZonedDateTime zonedDateTime) {
        return ZonedDateTime.now(zonedDateTime.getZone()).isBefore(zonedDateTime);
    }

    public static boolean isEnded(ZonedDateTime zonedDateTime) {
        return ZonedDateTime.now(zonedDateTime.getZone()).isAfter(zonedDateTime);
    }

    public static Date getDateFromString(String string) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        try {
            Date date = simpleDateFormat.parse(string);
            return date;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

    public static String formatTime(long l) {
        long l2 = l % 60L;
        long l3 = l % 3600L / 60L;
        long l4 = l % 86400L / 3600L;
        long l5 = l / 86400L;
        if (l5 > 0L) {
            return String.format("%02dd %02dh %02dm %02ds", l5, l4, l3, l2);
        }
        if (l4 > 0L) {
            return String.format("%02dh %02dm %02ds", l4, l3, l2);
        }
        if (l3 > 0L) {
            return String.format("%02dm %02ds", l3, l2);
        }
        return String.format("%02ds", l2);
    }

    public static String getStringBetweenDates(ZonedDateTime zonedDateTime) {
        Object object = null;
        long l = ZonedDateTime.now(zonedDateTime.getZone()).toInstant().toEpochMilli();
        long l2 = zonedDateTime.toInstant().toEpochMilli();
        long l3 = Math.abs(l2 - l);
        if (l3 > 0L) {
            int[] arrn = TimeUtil.splitSeconds(new BigDecimal(l3 / 1000L));
            if (arrn[0] > 0) {
                object = arrn[0] + "d";
            }
            if (arrn[1] > 0) {
                object = object == null ? arrn[1] + "h" : (String)object + " " + arrn[1] + "h";
            }
            if (arrn[2] > 0) {
                object = object == null ? arrn[2] + "m" : (String)object + " " + arrn[2] + "m";
            }
            if (arrn[3] > 0) {
                object = object == null ? arrn[3] + "s" : (String)object + " " + arrn[3] + "s";
            }
        }
        if (object == null) {
            object = "None";
        }
        return object;
    }

    public static int[] splitSeconds(BigDecimal bigDecimal) {
        long l = bigDecimal.longValue();
        int n = (int)l / 86400;
        int n2 = (int)l - n * 86400;
        int n3 = n2 / 3600;
        int n4 = (n2 -= n3 * 3600) / 60;
        int n5 = n2 -= n4 * 60;
        int[] arrn = new int[]{n, n3, n4, n5};
        return arrn;
    }

    public static ZonedDateTime getStartTime(Timeline timeline, ZoneId zoneId) {
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        switch (timeline) {
            case WEEKLY: {
                zonedDateTime = ZonedDateTime.of(LocalDateTime.of(zonedDateTime.with(DayOfWeek.MONDAY).toLocalDate(), zonedDateTime.toLocalDate().atStartOfDay().toLocalTime()), zoneId);
                break;
            }
            case MONTHLY: {
                zonedDateTime = ZonedDateTime.of(LocalDateTime.of(zonedDateTime.with(TemporalAdjusters.firstDayOfMonth()).toLocalDate(), zonedDateTime.toLocalDate().atStartOfDay().toLocalTime()), zoneId);
                break;
            }
            case DAILY: {
                zonedDateTime = ZonedDateTime.of(LocalDateTime.of(zonedDateTime.toLocalDate(), zonedDateTime.toLocalDate().atStartOfDay().toLocalTime()), zoneId);
            }
        }
        return zonedDateTime;
    }

    public static ZonedDateTime getEndTime(Timeline timeline, ZoneId zoneId) {
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        switch (timeline) {
            case WEEKLY: {
                zonedDateTime = ZonedDateTime.of(LocalDateTime.of(zonedDateTime.with(DayOfWeek.SUNDAY).toLocalDate(), LocalTime.of(23, 59, 59)), zoneId);
                break;
            }
            case MONTHLY: {
                zonedDateTime = ZonedDateTime.of(LocalDateTime.of(zonedDateTime.with(TemporalAdjusters.lastDayOfMonth()).toLocalDate(), LocalTime.of(23, 59, 59)), zoneId);
                break;
            }
            case DAILY: {
                zonedDateTime = ZonedDateTime.of(LocalDateTime.of(zonedDateTime.toLocalDate(), LocalTime.of(23, 59, 59)), zoneId);
            }
        }
        return zonedDateTime;
    }

    public static String getMonthName(ZonedDateTime zonedDateTime) {
        return zonedDateTime.getMonth().getDisplayName(TextStyle.FULL, Locale.US);
    }

    public static String getMonthNumber(ZonedDateTime zonedDateTime) {
        return String.valueOf(zonedDateTime.getMonth().getValue());
    }

    public static String getDay(ZonedDateTime zonedDateTime) {
        return String.valueOf(zonedDateTime.getDayOfMonth());
    }
}

