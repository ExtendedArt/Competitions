/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.permissions.Permission
 */
package fun.lewisdev.tournaments.command;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.libs.command.annotations.Command;
import fun.lewisdev.tournaments.libs.command.annotations.Completion;
import fun.lewisdev.tournaments.libs.command.annotations.Default;
import fun.lewisdev.tournaments.libs.command.annotations.SubCommand;
import fun.lewisdev.tournaments.libs.command.annotations.WrongUsage;
import fun.lewisdev.tournaments.libs.command.base.CommandBase;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentStatus;
import fun.lewisdev.tournaments.utility.Messages;
import fun.lewisdev.tournaments.utility.TextUtil;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;

@Command(value="tournament")
public class TournamentsCommand
extends CommandBase {
    private final XLTournamentsPlugin plugin;

    public TournamentsCommand(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
        List list = xLTournamentsPlugin.getConfig().getStringList("command_aliases");
        if (!list.isEmpty()) {
            this.setAliases(xLTournamentsPlugin.getConfig().getStringList("command_aliases"));
        }
    }

    @Default
    public void defaultCommand(Player player) {
        this.plugin.getMenuManager().getTournamentGui().openInventory(player);
    }

    @SubCommand(value="help")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament help")
    public void helpSubCommand(CommandSender commandSender) {
        for (String string : this.plugin.getMessagesFile().getConfig().getStringList("general.help")) {
            commandSender.sendMessage(TextUtil.color(string).replace("{VERSION}", this.plugin.getDescription().getVersion()));
        }
    }

    @SubCommand(value="reload")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament reload")
    public void reloadSubCommand(CommandSender commandSender) {
        this.plugin.reload();
        Messages.RELOAD.send(commandSender, new Object[0]);
    }

    @SubCommand(value="about")
    @WrongUsage(value="&c/tournament about")
    public void aboutSubCommand(CommandSender commandSender) {
        commandSender.sendMessage("");
        commandSender.sendMessage(TextUtil.color("&b&lXLTournaments"));
        commandSender.sendMessage(TextUtil.color("&bVersion: &fv" + this.plugin.getDescription().getVersion()));
        commandSender.sendMessage(TextUtil.color("&bAuthor: &fItsLewizzz"));
        if (!TextUtil.isValidDownload()) {
            commandSender.sendMessage(TextUtil.color("&4Registered to: &cFailed to find licensed owner to this plugin. Contact developer to report possible leak (itslewizzz)."));
        } else if (TextUtil.isMCMarket()) {
            commandSender.sendMessage(TextUtil.color("&4Registered to: &chttps://builtbybit.com/members/94252/"));
        } else {
            commandSender.sendMessage(TextUtil.color("&4Registered to: &chttps://www.spigotmc.org/members/94252/"));
        }
        commandSender.sendMessage("");
    }

    @SubCommand(value="update")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament update")
    public void updateSubCommand(CommandSender commandSender) {
        for (Tournament tournament : this.plugin.getTournamentManager().getTournaments()) {
            if (tournament.getStatus() != TournamentStatus.ACTIVE) continue;
            tournament.update();
        }
        Messages.FORCE_UPDATED_TOURNAMENTS.send(commandSender, new Object[0]);
    }

    @SubCommand(value="info")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament info <tournament>")
    @Completion(value={"#tournaments"})
    public void infoSubCommand(CommandSender commandSender, String string) {
        Optional<Tournament> optional = this.plugin.getTournamentManager().getTournament(string);
        if (!optional.isPresent()) {
            commandSender.sendMessage(TextUtil.color("&cCould not find tournament with that ID"));
            return;
        }
        Tournament tournament = optional.get();
        commandSender.sendMessage("");
        commandSender.sendMessage(TextUtil.color("&b&lTournament Information"));
        commandSender.sendMessage("");
        commandSender.sendMessage(TextUtil.color("&bIdentifier: &f" + tournament.getIdentifier()));
        commandSender.sendMessage(TextUtil.color("&bStatus: &f" + tournament.getStatus().toString()));
        commandSender.sendMessage(TextUtil.color("&bParticipants Amount: &f" + tournament.getParticipants().size()));
        commandSender.sendMessage(TextUtil.color("&bObjective: &f" + tournament.getObjective().getIdentifier()));
        commandSender.sendMessage(TextUtil.color("&bTimeline: &f" + tournament.getTimeline()));
        commandSender.sendMessage(TextUtil.color("&bTimezone: &f" + tournament.getZoneId().getId()));
        commandSender.sendMessage(TextUtil.color("&bStart Date: &f" + DateTimeFormatter.ofPattern("yyyy/MM/dd - hh:mm:ss").format(tournament.getStartDate())));
        commandSender.sendMessage(TextUtil.color("&bEnd Date: &f" + DateTimeFormatter.ofPattern("yyyy/MM/dd - hh:mm:ss").format(tournament.getEndDate())));
        commandSender.sendMessage(TextUtil.color("&bDisabled Worlds: &f" + tournament.getDisabledWorlds()));
        commandSender.sendMessage(TextUtil.color("&bDisabled Gamemodes: &f" + tournament.getDisabledGamemodes()));
        commandSender.sendMessage(TextUtil.color("&bAutomatic Participation: &f" + tournament.isAutomaticParticipation()));
        commandSender.sendMessage(TextUtil.color("&bParticipation Cost: &f" + tournament.getParticipationCost()));
        Permission permission = tournament.getParticipationPermission();
        commandSender.sendMessage(TextUtil.color("&bParticipation Permission: &f" + (permission == null ? "N/A" : permission.getName())));
        commandSender.sendMessage(TextUtil.color("&bLeaderboard Refresh: &f" + tournament.getLeaderboardRefresh()));
        Set<String> set = tournament.getMeta().keySet();
        commandSender.sendMessage(TextUtil.color("&bMetadata: &f" + (set.isEmpty() ? "N/A" : set)));
        commandSender.sendMessage("");
    }

    @SubCommand(value="clear")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament clear <tournament>")
    @Completion(value={"#tournaments"})
    public void clearSubCommand(CommandSender commandSender, String string) {
        Optional<Tournament> optional = this.plugin.getTournamentManager().getTournament(string);
        if (!optional.isPresent()) {
            commandSender.sendMessage(TextUtil.color("&cCould not find tournament with that ID"));
            return;
        }
        Tournament tournament = optional.get();
        tournament.clearParticipants();
        Messages.TOURNAMENT_CLEARED.send(commandSender, "{TOURNAMENT}", tournament.getIdentifier());
    }

    @SubCommand(value="clearplayer")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament clearplayer <player> <tournament>")
    @Completion(value={"#players", "#tournaments"})
    public void clearPlayerSubCommand(CommandSender commandSender, Player player, String string) {
        if (player == null) {
            commandSender.sendMessage(TextUtil.color("&cPlayer is invalid or offline."));
            return;
        }
        Optional<Tournament> optional = this.plugin.getTournamentManager().getTournament(string);
        if (!optional.isPresent()) {
            commandSender.sendMessage(TextUtil.color("&cCould not find tournament with that ID"));
            return;
        }
        Tournament tournament = optional.get();
        tournament.clearParticipant(player.getUniqueId());
        Messages.TOURNAMENT_CLEARED_PLAYER.send(commandSender, "{TOURNAMENT}", tournament.getIdentifier(), "{PLAYER}", player.getName());
    }

    @SubCommand(value="list")
    @fun.lewisdev.tournaments.libs.command.annotations.Permission(value={"tournaments.admin"})
    @WrongUsage(value="&c/tournament list")
    public void listSubCommand(CommandSender commandSender) {
        Messages.LIST_TOURNAMENTS.send(commandSender, "{LIST}", String.join((CharSequence)", ", this.plugin.getTournamentManager().getTournaments().stream().map(Tournament::getIdentifier).collect(Collectors.toList())));
    }
}

