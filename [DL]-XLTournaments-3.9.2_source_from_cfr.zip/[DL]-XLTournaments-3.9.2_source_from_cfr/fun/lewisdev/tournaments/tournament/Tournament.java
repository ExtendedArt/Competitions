/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.permissions.Permission
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package fun.lewisdev.tournaments.tournament;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.action.ActionManager;
import fun.lewisdev.tournaments.events.CompletedChallengeEvent;
import fun.lewisdev.tournaments.events.TournamentEndEvent;
import fun.lewisdev.tournaments.events.TournamentStartEvent;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.storage.StorageHandler;
import fun.lewisdev.tournaments.tournament.TournamentStatus;
import fun.lewisdev.tournaments.utility.TimeUtil;
import fun.lewisdev.tournaments.utility.Timeline;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class Tournament {
    private final XLTournamentsPlugin plugin;
    private final ActionManager actionManager;
    private final StorageHandler storageHandler;
    private final String identifier;
    private BukkitTask updateTask;
    private TournamentStatus status;
    private ZonedDateTime startDate;
    private ZonedDateTime endDate;
    private long startTimeMillis;
    private long endTimeMillis;
    private ZoneId zoneId;
    private boolean updating;
    private XLObjective objective;
    private Timeline timeline;
    private int leaderboardRefresh;
    private List<String> disabledWorlds;
    private List<GameMode> disabledGamemodes;
    private Map<Integer, List<String>> rewards;
    private boolean challenge;
    private int challengeGoal;
    private List<String> startActions;
    private List<String> endActions;
    private boolean automaticParticipation;
    private Permission participationPermission;
    private double participationCost;
    private List<String> participationActions;
    private final Map<UUID, Integer> participants;
    private Map<UUID, Integer> sortedParticipants;
    private final Map<String, Object> meta;

    Tournament(XLTournamentsPlugin xLTournamentsPlugin, String string) {
        this.plugin = xLTournamentsPlugin;
        this.identifier = string;
        this.actionManager = xLTournamentsPlugin.getActionManager();
        this.storageHandler = xLTournamentsPlugin.getStorageManager().getStorageHandler();
        this.participants = new ConcurrentHashMap<UUID, Integer>();
        this.sortedParticipants = new LinkedHashMap<UUID, Integer>();
        this.challenge = false;
        this.challengeGoal = -1;
        this.leaderboardRefresh = 60;
        this.automaticParticipation = false;
        this.updating = false;
        this.participationCost = 0.0;
        this.participationActions = new ArrayList<String>();
        this.disabledWorlds = new ArrayList<String>();
        this.disabledGamemodes = new ArrayList<GameMode>();
        this.rewards = new HashMap<Integer, List<String>>();
        this.startActions = new ArrayList<String>();
        this.endActions = new ArrayList<String>();
        this.meta = new HashMap<String, Object>();
    }

    public void updateStatus() {
        if (this.timeline != Timeline.SPECIFIC) {
            this.startDate = TimeUtil.getStartTime(this.timeline, this.zoneId);
            this.endDate = TimeUtil.getEndTime(this.timeline, this.zoneId);
        }
        this.startTimeMillis = this.startDate.toInstant().toEpochMilli();
        this.endTimeMillis = this.endDate.toInstant().toEpochMilli();
        if (TimeUtil.isWaiting(this.startDate)) {
            this.status = TournamentStatus.WAITING;
        } else if (!TimeUtil.isWaiting(this.startDate) && !TimeUtil.isEnded(this.endDate)) {
            this.status = TournamentStatus.ACTIVE;
        } else if (TimeUtil.isEnded(this.endDate)) {
            this.status = TournamentStatus.ENDED;
        }
    }

    public void start(boolean bl) {
        if (bl) {
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, this::clearParticipants);
            if (!this.startActions.isEmpty()) {
                Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> Bukkit.getOnlinePlayers().forEach(player -> this.actionManager.executeActions((Player)player, this.startActions, this)));
            }
        }
        this.status = TournamentStatus.ACTIVE;
        this.updateTask = Bukkit.getScheduler().runTaskTimerAsynchronously((Plugin)this.plugin, () -> {
            if (!this.isUpdating()) {
                this.update();
            }
        }, 0L, (long)this.leaderboardRefresh * 20L);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> Bukkit.getPluginManager().callEvent((Event)new TournamentStartEvent(this)));
    }

    public void stop() {
        if (this.status != TournamentStatus.ACTIVE) {
            return;
        }
        if (this.updateTask != null) {
            this.updateTask.cancel();
        }
        this.update();
        if (!this.challenge) {
            for (int n : this.rewards.keySet()) {
                OfflinePlayer offlinePlayer = this.getPlayerFromPosition(n);
                if (offlinePlayer == null) continue;
                if (!offlinePlayer.isOnline()) {
                    Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
                        for (String string : this.rewards.get(n)) {
                            this.storageHandler.addActionToQueue(offlinePlayer.getUniqueId().toString(), string);
                        }
                    });
                    continue;
                }
                Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.actionManager.executeActions(offlinePlayer.getPlayer(), this.rewards.get(n), this));
            }
        }
        if (!this.endActions.isEmpty()) {
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.actionManager.executeActions(null, this.endActions, this));
            return;
        }
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> Bukkit.getPluginManager().callEvent((Event)new TournamentEndEvent(this)));
    }

    public void update() {
        this.updating = true;
        this.sortedParticipants.clear();
        for (Map.Entry<UUID, Integer> entry : this.participants.entrySet()) {
            this.storageHandler.updateParticipant(this.getIdentifier(), entry.getKey(), entry.getValue());
        }
        this.sortedParticipants = this.storageHandler.getTopPlayers(this.identifier);
        this.updating = false;
    }

    public void clearParticipants() {
        this.participants.clear();
        this.sortedParticipants.clear();
        this.storageHandler.clearParticipants(this.identifier);
    }

    public void clearParticipant(UUID uUID) {
        this.participants.remove(uUID);
        this.sortedParticipants.remove(uUID);
        this.storageHandler.clearParticipant(this.identifier, uUID);
    }

    void setObjective(XLObjective xLObjective) {
        this.objective = xLObjective;
    }

    void setChallenge(boolean bl) {
        this.challenge = bl;
    }

    void setChallengeGoal(int n) {
        this.challengeGoal = n;
    }

    void setTimeline(Timeline timeline) {
        this.timeline = timeline;
    }

    void setStartDate(ZonedDateTime zonedDateTime) {
        this.startDate = zonedDateTime;
    }

    void setEndDate(ZonedDateTime zonedDateTime) {
        this.endDate = zonedDateTime;
    }

    void setUpdateTime(int n) {
        if (n < 10) {
            n = 10;
        }
        this.leaderboardRefresh = n;
    }

    void setAutomaticParticipation(boolean bl) {
        this.automaticParticipation = bl;
    }

    void setParticipationCost(double d) {
        this.participationCost = d;
    }

    void setParticipationPermission(Permission permission) {
        this.participationPermission = permission;
    }

    void setParticipationActions(List<String> list) {
        this.participationActions = list;
    }

    void setDisabledWorlds(List<String> list) {
        this.disabledWorlds = list;
    }

    void setDisabledGamemodes(List<GameMode> list) {
        this.disabledGamemodes = list;
    }

    void setRewards(Map<Integer, List<String>> map) {
        this.rewards = map;
    }

    void setStartActions(List<String> list) {
        this.startActions = list;
    }

    void setEndActions(List<String> list) {
        this.endActions = list;
    }

    void setZoneId(ZoneId zoneId) {
        this.zoneId = zoneId;
    }

    public String getTimeRemaining() {
        if (this.status == TournamentStatus.ACTIVE) {
            return TimeUtil.getStringBetweenDates(this.endDate);
        }
        if (this.status == TournamentStatus.WAITING) {
            return TimeUtil.getStringBetweenDates(this.startDate);
        }
        return "N/A";
    }

    public int getPosition(UUID uUID) {
        if (this.sortedParticipants.containsKey(uUID)) {
            return new ArrayList<UUID>(this.sortedParticipants.keySet()).indexOf(uUID) + 1;
        }
        return 0;
    }

    public int getScore(UUID uUID) {
        return this.participants.getOrDefault(uUID, 0);
    }

    public OfflinePlayer getPlayerFromPosition(int n) {
        if (this.sortedParticipants.size() < n || n > this.sortedParticipants.size()) {
            return null;
        }
        int n2 = 1;
        for (UUID uUID : this.sortedParticipants.keySet()) {
            if (n2 == n && this.sortedParticipants.get(uUID) > 0) {
                return Bukkit.getOfflinePlayer((UUID)uUID);
            }
            ++n2;
        }
        return null;
    }

    public int getScoreFromPosition(int n) {
        if (this.sortedParticipants.size() < n || n > this.sortedParticipants.size()) {
            return 0;
        }
        int n2 = 1;
        for (UUID uUID : this.sortedParticipants.keySet()) {
            if (n2 == n && this.sortedParticipants.get(uUID) > 0) {
                return this.sortedParticipants.get(uUID);
            }
            ++n2;
        }
        return 0;
    }

    public void addParticipant(UUID uUID, int n, boolean bl) {
        this.participants.put(uUID, n);
        if (bl) {
            this.storageHandler.addParticipant(this.getIdentifier(), uUID);
        }
    }

    public void addScore(UUID uUID, int n) {
        this.addScore(uUID, n, false);
    }

    public void addScore(UUID uUID, int n, boolean bl) {
        if (this.participants.containsKey(uUID)) {
            this.participants.put(uUID, bl ? n : this.participants.get(uUID) + n);
        } else {
            this.participants.put(uUID, n);
        }
        if (this.hasFinishedChallenge(uUID)) {
            this.storageHandler.updateParticipant(this.getIdentifier(), uUID, this.participants.get(uUID));
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
                int n = this.getPlayersCompletedChallenge();
                Player player = Bukkit.getPlayer((UUID)uUID);
                Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
                    if (this.rewards.containsKey(n)) {
                        this.actionManager.executeActions(player, this.rewards.get(n));
                    }
                    Bukkit.getPluginManager().callEvent((Event)new CompletedChallengeEvent(player, n, this));
                });
            });
        }
    }

    public int getPlayersCompletedChallenge() {
        return this.storageHandler.getTopPlayersByScore(this.identifier, this.challengeGoal).size();
    }

    public String getStartDay() {
        return TimeUtil.getDay(this.startDate);
    }

    public String getEndDay() {
        return TimeUtil.getDay(this.endDate);
    }

    public String getStartMonth() {
        return TimeUtil.getMonthName(this.startDate);
    }

    public String getStartMonthNumber() {
        return TimeUtil.getMonthNumber(this.startDate);
    }

    public String getEndMonthNumber() {
        return TimeUtil.getMonthNumber(this.endDate);
    }

    public String getEndMonth() {
        return TimeUtil.getMonthName(this.endDate);
    }

    public boolean isParticipant(UUID uUID) {
        return this.participants.containsKey(uUID);
    }

    public Map<UUID, Integer> getParticipants() {
        return this.participants;
    }

    public boolean hasFinishedChallenge(UUID uUID) {
        return this.challenge && this.participants.get(uUID) >= this.challengeGoal;
    }

    public void removeParticipant(UUID uUID) {
        this.participants.remove(uUID);
    }

    public Map<UUID, Integer> getSortedParticipants() {
        return this.sortedParticipants;
    }

    public double getParticipationCost() {
        return this.participationCost;
    }

    public Permission getParticipationPermission() {
        return this.participationPermission;
    }

    public boolean isAutomaticParticipation() {
        return this.automaticParticipation;
    }

    public List<String> getParticipationActions() {
        return this.participationActions;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public boolean isChallenge() {
        return this.challenge;
    }

    public int getChallengeGoal() {
        return this.challengeGoal;
    }

    public XLObjective getObjective() {
        return this.objective;
    }

    public Timeline getTimeline() {
        return this.timeline;
    }

    public int getLeaderboardRefresh() {
        return this.leaderboardRefresh;
    }

    public TournamentStatus getStatus() {
        return this.status;
    }

    public List<String> getDisabledWorlds() {
        return this.disabledWorlds;
    }

    public List<GameMode> getDisabledGamemodes() {
        return this.disabledGamemodes;
    }

    public Object getMeta(String string) {
        return this.meta.get(string);
    }

    public void setMeta(String string, Object object) {
        this.meta.put(string, object);
    }

    public Map<String, Object> getMeta() {
        return this.meta;
    }

    public boolean hasMeta(String string) {
        return this.meta.containsKey(string);
    }

    public boolean isUpdating() {
        return this.updating;
    }

    public ZoneId getZoneId() {
        return this.zoneId;
    }

    public ZonedDateTime getStartDate() {
        return this.startDate;
    }

    public ZonedDateTime getEndDate() {
        return this.endDate;
    }

    public BukkitTask getUpdateTask() {
        return this.updateTask;
    }

    public long getEndTimeMillis() {
        return this.endTimeMillis;
    }

    public long getStartTimeMillis() {
        return this.startTimeMillis;
    }

    public void setStatus(TournamentStatus tournamentStatus) {
        this.status = tournamentStatus;
    }
}

