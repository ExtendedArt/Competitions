/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.permissions.Permission
 */
package fun.lewisdev.tournaments.tournament;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.exception.ObjectiveNotFoundException;
import fun.lewisdev.tournaments.exception.TournamentLoadException;
import fun.lewisdev.tournaments.objective.ObjectiveManager;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.utility.Timeline;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.permissions.Permission;

public class TournamentBuilder {
    private final Tournament tournament;

    public TournamentBuilder(XLTournamentsPlugin xLTournamentsPlugin, String string) {
        this.tournament = new Tournament(xLTournamentsPlugin, string);
    }

    public TournamentBuilder loadFromFile(ObjectiveManager objectiveManager, FileConfiguration fileConfiguration) {
        Object object;
        Object object22;
        ArrayList<GameMode> arrayList;
        if (fileConfiguration.getBoolean("challenge.enabled")) {
            this.withChallengeGoal(fileConfiguration.getInt("challenge.goal"));
        }
        this.withDisabledWorlds(fileConfiguration.getStringList("disabled_worlds"));
        if (fileConfiguration.contains("disabled_gamemodes")) {
            arrayList = new ArrayList();
            for (Object object22 : fileConfiguration.getStringList("disabled_gamemodes")) {
                try {
                    arrayList.add(GameMode.valueOf((String)object22));
                }
                catch (Exception exception) {}
            }
            this.withDisabledGamemodes(arrayList);
        }
        try {
            arrayList = Timeline.valueOf(fileConfiguration.getString("timeline"));
        }
        catch (Exception exception) {
            throw new TournamentLoadException("The timeline (" + fileConfiguration.getString("timeline") + ") set in file " + this.tournament.getIdentifier() + ".yml does not exist. Skipping..");
        }
        this.withTimeline((Timeline)((Object)arrayList));
        ZoneId zoneId = fileConfiguration.contains("timezone_options") && !fileConfiguration.getBoolean("timezone_options.automatically_detect") ? ZoneId.of(fileConfiguration.getString("timezone_options.force_timezone")) : ZoneId.systemDefault();
        this.withZoneId(zoneId);
        if (arrayList == Timeline.SPECIFIC) {
            object22 = ZonedDateTime.of(LocalDateTime.parse(fileConfiguration.getString("start_date"), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")), zoneId);
            this.withStartDate((ZonedDateTime)object22);
            object = ZonedDateTime.of(LocalDateTime.parse(fileConfiguration.getString("end_date"), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")), zoneId);
            this.withEndDate((ZonedDateTime)object);
        }
        if (((String)(object22 = fileConfiguration.getString("objective"))).contains(";")) {
            object22 = ((String)object22).split(";")[0];
        }
        if ((object = objectiveManager.getObjective((String)object22)) == null) {
            throw new ObjectiveNotFoundException("The objective (" + (String)object22 + ") set in file " + this.tournament.getIdentifier() + ".yml does not exist. Skipping..");
        }
        this.withObjective((XLObjective)object);
        this.withUpdateTime(fileConfiguration.getInt("leaderboard_refresh", 60));
        if (fileConfiguration.getBoolean("participation.automatic")) {
            this.withAutomaticParticipation();
        } else {
            this.withParticipationCost(fileConfiguration.getDouble("participation.cost"));
        }
        if (fileConfiguration.contains("participation.permission")) {
            this.withParticipationPermission(fileConfiguration.getString("participation.permission"));
        }
        this.withParticipationActions(fileConfiguration.getStringList("participation.join_actions"));
        HashMap<Integer, List<String>> hashMap = new HashMap<Integer, List<String>>();
        for (String string : fileConfiguration.getConfigurationSection("rewards").getKeys(false)) {
            hashMap.put(Integer.parseInt(string), fileConfiguration.getStringList("rewards." + string));
        }
        this.withRewards(hashMap);
        this.withStartActions(fileConfiguration.getStringList("start_actions"));
        this.withEndActions(fileConfiguration.getStringList("end_actions"));
        return this;
    }

    public Tournament build() {
        return this.tournament;
    }

    public TournamentBuilder withObjective(XLObjective xLObjective) {
        this.tournament.setObjective(xLObjective);
        return this;
    }

    public TournamentBuilder withChallengeGoal(int n) {
        this.tournament.setChallenge(true);
        this.tournament.setChallengeGoal(n);
        return this;
    }

    public TournamentBuilder withTimeline(Timeline timeline) {
        this.tournament.setTimeline(timeline);
        return this;
    }

    public TournamentBuilder withStartDate(ZonedDateTime zonedDateTime) {
        this.tournament.setStartDate(zonedDateTime);
        return this;
    }

    public TournamentBuilder withEndDate(ZonedDateTime zonedDateTime) {
        this.tournament.setEndDate(zonedDateTime);
        return this;
    }

    public TournamentBuilder withUpdateTime(int n) {
        this.tournament.setUpdateTime(n);
        return this;
    }

    public TournamentBuilder withAutomaticParticipation() {
        this.tournament.setAutomaticParticipation(true);
        return this;
    }

    public TournamentBuilder withParticipationCost(double d) {
        this.tournament.setParticipationCost(d);
        return this;
    }

    public TournamentBuilder withParticipationPermission(String string) {
        this.tournament.setParticipationPermission(new Permission(string));
        return this;
    }

    public TournamentBuilder withParticipationActions(List<String> list) {
        this.tournament.setParticipationActions(list);
        return this;
    }

    public TournamentBuilder withDisabledWorlds(List<String> list) {
        this.tournament.setDisabledWorlds(list);
        return this;
    }

    public TournamentBuilder withDisabledGamemodes(List<GameMode> list) {
        this.tournament.setDisabledGamemodes(list);
        return this;
    }

    public TournamentBuilder withRewards(Map<Integer, List<String>> map) {
        this.tournament.setRewards(map);
        return this;
    }

    public TournamentBuilder withStartActions(List<String> list) {
        this.tournament.setStartActions(list);
        return this;
    }

    public TournamentBuilder withEndActions(List<String> list) {
        this.tournament.setEndActions(list);
        return this;
    }

    public TournamentBuilder withZoneId(ZoneId zoneId) {
        this.tournament.setZoneId(zoneId);
        return this;
    }
}

