/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.tournament;

public final class TournamentStatus
extends Enum<TournamentStatus> {
    public static final /* enum */ TournamentStatus WAITING = new TournamentStatus();
    public static final /* enum */ TournamentStatus ACTIVE = new TournamentStatus();
    public static final /* enum */ TournamentStatus ENDED = new TournamentStatus();
    private static final /* synthetic */ TournamentStatus[] $VALUES;

    public static TournamentStatus[] values() {
        return (TournamentStatus[])$VALUES.clone();
    }

    public static TournamentStatus valueOf(String string) {
        return Enum.valueOf(TournamentStatus.class, string);
    }

    private static /* synthetic */ TournamentStatus[] $values() {
        return new TournamentStatus[]{WAITING, ACTIVE, ENDED};
    }

    static {
        $VALUES = TournamentStatus.$values();
    }
}

