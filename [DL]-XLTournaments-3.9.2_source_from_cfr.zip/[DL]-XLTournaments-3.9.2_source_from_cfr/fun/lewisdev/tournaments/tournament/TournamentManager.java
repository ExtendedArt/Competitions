/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.permissions.Permission
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package fun.lewisdev.tournaments.tournament;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.config.ConfigHandler;
import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.storage.StorageHandler;
import fun.lewisdev.tournaments.task.TimerTask;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentBuilder;
import fun.lewisdev.tournaments.tournament.TournamentStatus;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class TournamentManager {
    private final XLTournamentsPlugin plugin;
    private Map<String, Tournament> tournaments;
    private boolean listenersRegistered;
    private BukkitTask timerTask;

    public TournamentManager(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
        this.tournaments = new HashMap<String, Tournament>();
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    public void onEnable() {
        File[] arrfile;
        this.tournaments = new HashMap<String, Tournament>();
        Object object = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017G'{\u001d\u0010F\u001dB\u0015W?{\u0005\u001aD\u0006_\u0010_,;\u0005\u0006\u001f,}%]<'\u001f\u0014\\\u0011_\u0005A\u00199\u0004\u0012X\u001a", (Object)"\u0016W=\u0011\u0010\u0001P2^\u001dV,'", "Y\u001b\u0005?\u0010\u0003P[X\u001e\u001d\u000f<\u001d\u0010\n", -115, -0.18089682f, "pxda1JBKuhMvvyStmH2vQHu5d8cTKvbUYv60F2RF1y", this.plugin);
        File file2 = new File((String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0003?4_!$Z\r\u0018\u000e,", (Object)"\u0016\u0007=\u0014\u0013;$\u0018>\u0005\u0007\u00194\u0005 ", "YK\u0005?\u0010>*['\u0010\f.z\"<9\u001d%\u0016Y", -113, -1.0760498187573473, "qqe9KMAkHEkOaQZM5qbKTNru40AHUxcgisaLqCw5qMKySI7DVmTx", object) + File.separator + "tournaments");
        if (DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0010?4_0VZ\u007f\u0018\u001d,", (Object)"\u0014\t &\u0005*", "YX\u0013", -115, -15.9233067777165, "ksAc9BsNYxmH6nyUsgqm1MxaGRDAIPBRhgHxavd7grXejEjZ1XW", file2) == false) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0011?4_\u0011#Z\n\u0018\u001c,", (Object)"\u001c\u001b-<\u0003", "YY\u0013", -115, 106503411, "A1qqLPwex0bqZK7RD8pP0VtTlssmQY8LxBAnCeKdtyJ3u", file2);
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u0011'{\u001dU2\u001d6\u0015\u0001?{\u0005_0\u0006+\u0010\t,;\u0005Ck\u0017*\u001f\u0002 2_s*\u001a#\u0018\u0003\u00014\u001fT)\u00117", (Object)"\u0002\u0005?05U#\u00150\u001d\u0010\n:\u001fV,\u0013", "YM\u001f", -113, -401634991, "6ctfElgs0d7abAjrUodGgfMPUpku6elwR8L9hHY7zFtUp1ANRBXI", new ConfigHandler(this.plugin, new File((String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b%?4_>[Zr\u0018(,", (Object)"\u0016!=\u0014\u0013$[\u0018A\u0005!\u00194\u0005?", "Ym\u0005?\u0010!U[X\u0010*.z\"#F\u001dZ\u0016\u007f", -115, -0.18402916f, "pAID4jj0WiIAIGVmrqDCxX92FMMsLyoLFTtTovUQYm44afm6", file2)), (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "5\u0000;0\u0012+x\u0011T\u001a\u001a*8(>D\u0004d\u001e?+\u0011\u0017=FF", (Object)"C3\u0003%H\u0007t\u0004o\u0014\n\u0011dE<L\u001aW6.", "Y%#4\u0007\u0010\u001a\u0018T\u001f\u000ef\u0006\u0005\u0003\\\u001aRJ%#4\u0007\u0010\u001a\u0018T\u001f\u000ef\u0006\u0005\u0003\\\u001aRJ@\u0005?\u0010\u0007T[Y\u0010\u0007.z\"\u0005G\u001d[\u0016R", -114, -3762575464128484499L, "HVyp5JOpqzYOdQN0qdicr44EJu9Q52t84hysi3uikMbZ7hy0xPD14vL", "\u001d\u0003\u0010\f\u00140\u001d\u001d\u001a\u000e\u00140\u000b\u0000\n\u001d\u0011\u000e\u0012\n\u0011\u001b", "PogCLh8DaCFGey2fT16z38Fykiu0t2Y5NxSxRhrKDBa")));
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017?'{\u001d$\u000e\u001d\n\u0015/?{\u0005.\f\u0006\u0017\u0010',;\u00052W\u0017\u0016\u001f, 2_\u0002\u0016\u001a\u001f\u0018-\u00014\u001f%\u0015\u0011\u000b", (Object)"\u0002+?05$\u001f\u0015\f\u001d>\n:\u001f'\u0010\u0013", "Yc\u001f", -113, 16.706634143207435, "v0ypyoZeABH4nqIMoBJR5rPuUclt1qBihFHmfjGUyZ3W", new ConfigHandler(this.plugin, new File((String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001bQ?4_Q\rZ$\u0018\\,", (Object)"\u0016U=\u0014\u0013K\r\u0018\u0017\u0005U\u00194\u0005P", "Y\u0019\u0005?\u0010N\u0003[\u000e\u0010^.z\"L\u0010\u001d\f\u0016\u000b", -115, -411639939, "cYWebi2P8j1jhZ4aut0F8WMTuQ3AIHT06QHIk1Y59riZJA2", file2)), (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "5\r;0\u00129|\u0011P\u001a\u0017*8(,@\u0004`\u001e2+\u0011\u0017/BF", (Object)"C>\u0003%H\u0015p\u0004k\u0014\u0007\u0011dE.H\u001aS6#", "Y(#4\u0007\u0002\u001e\u0018P\u001f\u0003f\u0006\u0005\u0011X\u001aVJ(#4\u0007\u0002\u001e\u0018P\u001f\u0003f\u0006\u0005\u0011X\u001aVJM\u0005?\u0010\u0015P[]\u0010\n.z\"\u0017C\u001d_\u0016_", -114, -0.27197874f, "pSsc1lCWcDFIa6dy1gdxXVENSmBDckwCbYjtTjzFHtRdIDms6d", "\u00129\u001e $.\t,\u001d9$.\u0013,\u0017!\u001e#\u001c($9\u00148\t#\u001a \u001e#\u000f", "ljEHLCB8q9IpPa7q7nHTVhLCIe4mGywWJ6I6zP0WtlkrLE9kaJd")));
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u000f'{\u001d\u0016.\u001d*\u0015\u001f?{\u0005\u001c,\u00067\u0010\u0017,;\u0005\u0000w\u00176\u001f\u001c 2_06\u001a?\u0018\u001d\u00014\u001f\u00175\u0011+", (Object)"\u0002\u001b?05\u0016?\u0015,\u001d\u000e\n:\u001f\u00150\u0013", "YS\u001f", -115, 1341012566, "TkrlYKVIsKbqRXycVTziTtjfJp0vkKB5Ev9pU2LY7Ay1lDXWezhA", new ConfigHandler(this.plugin, new File((String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b/?4_<\rZ$\u0018\",", (Object)"\u0016+=\u0014\u0013&\r\u0018\u0017\u0005+\u00194\u0005=", "Yg\u0005?\u0010#\u0003[\u000e\u0010 .z\"!\u0010\u001d\f\u0016u", -113, 2.6873559117423773, "z0RzbVQ0U4PyL6TljXNLXLqcQ835GorVBzoL5FaJPrNdNhC7R", file2)), (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "5=;0\u0012-\u000e\u0011\"\u001a'*8(82\u0004\u0012\u001e\u0002+\u0011\u0017;0F", (Object)"C\u000e\u0003%H\u0001\u0002\u0004\u0019\u00147\u0011dE::\u001a!6\u0013", "Y\u0018#4\u0007\u0016l\u0018\"\u001f3f\u0006\u0005\u0005*\u001a$J\u0018#4\u0007\u0016l\u0018\"\u001f3f\u0006\u0005\u0005*\u001a$J}\u0005?\u0010\u0001\"[/\u0010:.z\"\u00031\u001d-\u0016o", -114, 7451518327754835875L, "2XCTCItzwGIOT3xnmZTpKS64yCcrTjFJoeL1e1vNqzzeK", "\u000f!\u001e4\u001a? &\u0016!\u0013> 9\u00108\r#\u001e \u001a#\u000b", "XgRnJvR8eZE6PRcqLfNK9S9oEJSkrnBczU7ApKLr")));
        }
        if ((arrfile = (File[])DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0012?4_\u001b\nZ#\u0018\u001f,", (Object)"\u001d\u001a:!7\u001b\t\u0011\u0016", "Y?#4\u0007\u0013J\u001d\n^5 9\u0014\u001c\u0004\u0019\u00007\u001a%!\u0014\u0000^]>=\u0019(#\u0010]\f\u001bJ7\u001a%0J", -113, 5.310063354281384, "VPNXeweIrdRr1RVh3gsttdWi8C7hC0NNTxe9nDKL1", new File((String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001bT?4_:?Z\u0016\u0018Y,", (Object)"\u0016P=\u0014\u0013 ?\u0018%\u0005P\u00194\u0005;", "Y\u001c\u0005?\u0010%1[<\u0010[.z\"'\"\u001d>\u0016\u000e", -115, 11.788920304030576, "0vm2PJYtSEnXAbHTNb5XNbHdFHfyxW33InlVNUgi4q", file2)), (file, string) -> string.toLowerCase().endsWith(".yml"))) == null) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b7?4_\u0018\u0000\u001d\u0018_:&2\u0016\u0004\u001a\u0013Z=9.2\u0014\u001f", (Object)"\u00067;;\u0018\u0003\u0013", "Y\u001a#4\u0007\f[\u0018\u0015\u001f1f\u0006\u0005\u001f\u001d\u001a\u0013J\u007f\u001f", -115, -5130489954761507536L, "2jo5tfArmglwzXXLlrVn0WCvbRCXsWRzSnJWVWfcovsiirdIWmA", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u001c'{\u001d\t.\u001d*\u0015\f?{\u0005\u0003,\u00067\u0010\u0004,;\u0005\u001fw,\u0015%\u0006<'\u001f\r4\u00117\u0005\u001a\u00199\u0004\u000b0\u001a", (Object)"\u0016\f=\u0019\u001e\u000b>\u0011+", "Y@\u0005?\u0010\u001a8[,\u0005\u0000%z\u001d\u0003>\u00130\u001f\u000ef\u0019\u001e\u000b>\u0011+J", -115, -12.23944677357463, "NMsNYOkolji6n3BasGiRNPu8LLn3BBbZKhz1SYjOwZImWdLXjOCu", this.plugin), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "5:;0\u0012i&\u0011\n\u001a *8(|\u001a\u0004:\u001e\u0005+\u0011\u0017\u007f\u0018F", (Object)"C\t\u0003%HE*\u00041\u00140\u0011dE~\u0012\u001a\t6\u0014", "Y\u001f#4\u0007RD\u0018\n\u001f4f\u0006\u0005A\u0002\u001a\fJ\u001f#4\u0007RD\u0018\n\u001f4f\u0006\u0005A\u0002\u001a\fJz\u0005?\u0010E\n[\u0007\u0010=.z\"G\u0019\u001d\u0005\u0016h", -114, -0.64150643f, "Jatxk51R3f9jApaUCOSZlx22xHERRLlbOifudlFBAiP6FQdd", ":\u0002\f\u0001\u001dM\u0017\u0002\rM\u001f\u0004\u0017\tY\f\u0017\u0014Y\u0019\u0016\u0018\u000b\u0003\u0018\u0000\u001c\u0003\r\u001eY\u0004\u0017M\r\u0005\u001cM\r\u0002\f\u001f\u0017\f\u0014\b\u0017\u0019\nM\u001f\u0002\u0015\t\u001c\u001fW", "IhOeR41arce6P1K0BS4UnvlYmnGqfbs0Z0u"));
            return;
        }
        for (File file3 : arrfile) {
            Object object2;
            try {
                object2 = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001e\u0017.{\u00139=\u001f?\u0005K*:\u001f*?\u0013#\u0003\u0004=<\u001e\"x\u0012?\u001d\u0000g\f\u0010!:79\u001f\u0003 2\u0004>7\u0000?\u001e\u000b", (Object)"\u001d\n(12#8\u0012?\u0016\u0010;4\u0005%9\u001a", "Y)#4\u0007-y\u001d9^# 9\u0014w\u007f89\u0003\u0002f7\u0004'=\u001d\"^\u0006&;\u0017%1\u0001$\u0010\u0011 :\u001fc0\u001d:\u0014J\u00104\u001c \u0015\u001b8\u0017\f. \u0003-\"\u001d9\u001f^", -114, -0.83021706f, "5I84V8nnLo35Aa9fs6eWUJ3ln33HaUnXmvwXjC5a07UCkDsHDB51qDw", file3);
            }
            catch (Exception exception) {
                DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0016?4_\u00143\u001a5_216\u0014\b&\u001d=\u001f", (Object)"\u0001\u0005 ;\u0005+&\u00151\u001a#;4\u0012\u001d", "Y^\u001f", -113, -10.716327773737222, "K6WpRccxx1Mo5zC1M1w9Cg7l0n5EJXcrnpVn65Lyb", exception);
                DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0007?4_6-\u001d5_\n&2\u0016*7\u0013w=\t.2\u00141", (Object)"\u0002\u0003?0\u0003&", "Y*#4\u0007\"v\u00188\u001f\u0001f\u0006\u000510\u001a>JO\u001f", -113, -483851693715086619L, "2qdZYC4kCTMrCrGFV4fN84gM2jRQP5EFBJuH", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u0014'{\u001d!#\u001d'\u0015\u0004?{\u0005+!\u0006:\u0010\f,;\u00057z,\u0018%\u000e<'\u001f%9\u0011:\u0005\u0012\u00199\u0004#=\u001a", (Object)"\u0016\u0004=\u0019\u001e#3\u0011&", "YH\u0005?\u001025[!\u0005\b%z\u001d+3\u0013=\u001f\u0006f\u0019\u001e#3\u0011&J", -113, 699373244, "nHfZT6SuDhaOOmDnqYadQy95zmdMrKbBR0SrzG5hn0lO9GgsJHzJTm", this.plugin), "There was a YAML error while trying to load " + (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0015?4_\u001e6Z\u001f\u0018\u0018,", (Object)"\u0016\u0011=\u001b\u0010\u001a<", "Y]\u0005?\u0010\u00018[5\u0010\u001a.z\"\u0003+\u001d7\u0016O", -115, 1.6279255431001776, "YKjRYhFmwArltTiefXtQK7joCAczUhoSbOHEcLwFqq8JOixkSy3SHF", file3) + ". Skipping..");
                continue;
            }
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017G'{\u001d<\u0007\u001d\u0003\u0015W?{\u00056\u0005\u0006\u001e\u0010_,;\u0005*^\u0000\u001f\u0004@'4\u001c<\u001e\u0000^%]<'\u001f8\u001d\u0011\u001e\u0005\u007f(;\u0010>\u0015\u0006", (Object)"\u0003W.<\u0002-\u0015\u0006$\u001eG;;\u00104\u0015\u001a\u0004", "Y~#4\u00078_\u0018\u0011\u001fUf\u0006\u0005+\u0019\u001a\u0017J~&'\u0016v\u0012\u0001\u001b\u001a[=z\u00126\u001e\u0012\u0019\u0016G;4\u00050\u001f\u001a_\u0017[%0^\u001f\u0019\u0018\u00152]'3\u0018>\u0005\u0006\u0011\u0005[&;Jp&", -115, -0.6326856f, "mXgSpCdUYGlDmO8QnH2VpbuomOKN2Vasdu1u0O6StS4TvZIp1kRsXhK", this, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001bR?4_XY\u001a__`='\u0018Z_", (Object)"\u0003V99\u0010W]", "Y\u007f#4\u0007U\u0017\u0018Y\u001fTf\u0016\u0019UJ']\u0000F,;\u0012Q\u00038R\u0010E(z\u001dUV\u0013\u00172[('\"QI\u0001]\u001fP,nXxR\u0015N\u0010\u001c%4\u001fS\u0017'L\u0003Z'2J", -113, 671570136, "4tTV8QjV4Dn0GdJvtX3fzmNqTZR1cksmOmt4mO", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b$?4_Z7Z\u001e\u0018),", (Object)"\u0016 =\u001b\u0010^=", "Yl\u0005?\u0010E9[4\u0010+.z\"G*\u001d6\u0016~", -115, -0.6289678285207099, "lPfRXWlz3gAbhOpfvFExHLFMCJhkGV8RLebsIB", file3), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "5:;0\u0012*8\u0011\u0014\u001a *8(?\u0004\u0004$\u001e\u0005+\u0011\u0017<\u0006F", (Object)"C\t\u0003%H\u00064\u0004/\u00140\u0011dE=\f\u001a\u00176\u0014", "Y\u001f#4\u0007\u0011Z\u0018\u0014\u001f4f\u0006\u0005\u0002\u001c\u001a\u0012J\u001f#4\u0007\u0011Z\u0018\u0014\u001f4f\u0006\u0005\u0002\u001c\u001a\u0012Jz\u0005?\u0010\u0006\u0014[\u0019\u0010=.z\"\u0004\u0007\u001d\u001b\u0016h", -114, 0.09659362f, "qNreuJQJp6o1qdjvpySEbhi1Dr6K7Km4CHuxIJZ3btgL", "U$\u00161", "WjCrElfY4n95YrAPKhMtBTNTQBzy9drIBe8dv345OnPhxaP7el"), (Object)""), (Object)object2);
        }
        if (!this.listenersRegistered) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u000f?4_\u0017E\u001d]_\u001d='\u0014\u0003\\Zb\u0005\u001c,4\u001c", (Object)"\u001e\b", "Y5\u0005?\u0010\u0014P[]\u0010\u0000.z>\u0000[\u0011R\u0005U`\u0019\u001b\u0003G\u0015\u001e\u0004\u001a 9^\u0011E\u0006T\u0010\u0003f\u0006\u0005\u0010T\u0015\\J", -114, -0.108475804f, "Tj9P1Qv3bbUP3G6TyanP2gOJ4s5yev2FACLHX9XtdD96vTF7X", (Object[])new Listener[]{new Listener(){

                @EventHandler(priority=EventPriority.MONITOR)
                public void onPlayerJoin(PlayerJoinEvent playerJoinEvent) {
                    TournamentManager.this.loadPlayerCache(playerJoinEvent.getPlayer());
                }
            }, new Listener(){

                @EventHandler(priority=EventPriority.MONITOR)
                public void onPlayerQuit(PlayerQuitEvent playerQuitEvent) {
                    TournamentManager.this.savePlayerCache(playerQuitEvent.getPlayer().getUniqueId());
                }
            }}).forEach(listener -> this.plugin.getServer().getPluginManager().registerEvents(listener, (Plugin)this.plugin));
            this.listenersRegistered = true;
        }
        Iterator iterator = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001e4.{\u0013\u0002Z\u001fX\u0005h\u000b \u001a\u001cX\u0000", (Object)"\u0016#=\u001a\u001f\u001bX\u001aT!*(,\u0014\u0005B", "Yo\u0005?\u0010\u0001P[D\u0005/%z2\u0018]\u0018T\u00122 :\u001fL", -114, 108533118466860804L, "vbpm1HnDw2BxvcTdkrFtUU4asOtcqgpcMb3WMukBwaZ").iterator();
        while (iterator.hasNext()) {
            Player player = (Player)iterator.next();
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u00179'{\u001d?A\u001dE\u0015)?{\u00055C\u0006X\u0010!,;\u0005)\u0018\u0000Y\u0004>'4\u001c?X\u0000\u0018%#<'\u001f;[\u0011X\u0005\u0001(;\u0010=S\u0006", (Object)"\u001d#(1!6W\rS\u0003\u000f(6\u0019?", "Y\u0000&'\u0016uT\u0001]\u001a%=z\u00144B\u001dB\bc\u00199\u0010#S\u0006\rX\u001a", -115, 7300714942056346396L, "jXqt6ytkZLEgspkoGCLIAF4R4Tab8ZEV7elbDf90CDpFpn", this, (Object)player);
        }
        this.timerTask = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001e\u0015.{\u0013'\u001f\u001f\u001d\u0005I\u000b \u001a9\u001d\u0000", (Object)"\u0016\u0002=\u0006\u0012:\u0011\u0010\u0001\u001d\u0002;", "YN\u0005:\u00035[\u0016\u0001\u001a\f !^!\u0017\u001c\u0011\u0015\u0012%0\u0003}6\u0001\u001f\u001a\u000e=\u0006\u0012:\u0011\u0010\u0001\u001d\u0002;n", -114, 60291836, "RMIvtmPwR13IikZWzAgrR1GzQR4c5nqNmkJ3Il503").runTaskTimerAsynchronously((Plugin)this.plugin, (Runnable)new TimerTask(this), 100L, 20L);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001e\u001a.{\u0013>'\u001f%\u0005F\u000b \u001a %\u0000", (Object)"\u0016\r=\u0006\u0012#)\u00109\u001d\r;", "YA\u0005:\u0003,c\u00169\u001a\u0003 !^8/\u001c)\u0015\u001d%0\u0003d\u000e\u0001'\u001a\u0001=\u0006\u0012#)\u00109\u001d\r;n", -114, -0.7664848f, "FtPYLi1XKsGjlaiff7hDRkt2U0IlCO1x8u4Vw").runTaskAsynchronously((Plugin)this.plugin, () -> this.tournaments.values().forEach(Tournament::update));
    }

    public void onDisable(boolean bl) {
        this.timerTask.cancel();
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001e3.{\u00134R\u001fP\u0005o\u000b \u001a*P\u0000", (Object)"\u0016$=\u0006\u0012)\\\u0010L\u001d$;", "Yh\u0005:\u0003&\u0016\u0016L\u001a* !^2Z\u001c\\\u00154%0\u0003n{\u0001R\u001a(=\u0006\u0012)\\\u0010L\u001d$;n", -114, -736715588, "YuIE9DgLAaWcF0l6DBAl052pAnGoTXoL7ZzoMry6OQ1Id2QM9k").cancelTasks((Plugin)this.plugin);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b\u0016?4_;\u0012\u001d\n_\u001b&2\u0016'\b\u0013H=\u0018.2\u0014<", (Object)"\u0018\u0019/:", "Y;#4\u0007/I\u0018\u0007\u001f\u0010f\u0006\u0005<\u000f\u001a\u0001J^\u001f", -115, 1621968869083579071L, "Q191fXFmNKUx4JQ1D1wKoHczQPaRqKhcX5kW7yUE5BPIu5d6OvVLW", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u001f'{\u001dVG\u001dC\u0015\u000f?{\u0005\\E\u0006^\u0010\u0007,;\u0005@\u001e,|%\u0005<'\u001fR]\u0011^\u0005\u0019\u00199\u0004TY\u001a", (Object)"\u0016\u000f=\u0019\u001eTW\u0011B", "YC\u0005?\u0010EQ[E\u0005\u0003%z\u001d\\W\u0013Y\u001f\rf\u0019\u001eTW\u0011BJ", -113, 0.63295007f, "esdC0sZx3et3dHSn0cjEL5PVzMGutkj1AwD", this.plugin), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "5\b;0\u0012.\u000e\u0011\"\u001a\u0012*8(;2\u0004\u0012\u001e7+\u0011\u001780F", (Object)"C;\u0003%H\u0002\u0002\u0004\u0019\u0014\u0002\u0011dE9:\u001a!6&", "Y-#4\u0007\u0015l\u0018\"\u001f\u0006f\u0006\u0005\u0006*\u001a$J-#4\u0007\u0015l\u0018\"\u001f\u0006f\u0006\u0005\u0006*\u001a$JH\u0005?\u0010\u0002\"[/\u0010\u000f.z\"\u00001\u001d-\u0016Z", -114, -2.3447319227784296, "W7nCCFYztn6VNdWHyNaP9yxp0HM06PwMqVzphAGNsYt1Eb8IeDty", "*\u001f\u000f\u0017\u0017\u0019Y\u000e\u0015\u001f\u0000\u001b\u000b^\u001d\u001f\r\u001fY\n\u0016^\u001d\u001f\r\u001f\u001b\u001f\n\u001bWP", "9hmUM1ghzTUIRnMRRiORpq1Gv2bUdw71tf64ak7xdsQeyAsg"));
        this.tournaments.values().forEach(tournament -> {
            BukkitTask bukkitTask = tournament.getUpdateTask();
            if (bukkitTask != null) {
                bukkitTask.cancel();
            }
        });
        Object object = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u0011'{\u001d\u0007\"\u001d&\u0015\u0001?{\u0005\r \u0006;\u0010\t,;\u0005\u0011{\u0007!\u001e\u0016(2\u0014L\u0006\u0000:\u0003\u0005.0<\u0003;\u00152\u0014\u0016", (Object)"\u0016\u0001=\u0006\u0005\r'\u00152\u0014,(;\u0015\u000e0\u0006", "YM\u00053\u0004\fz\u00180\u0006\r:1\u0014\u0014z\u0000:\u0004\u0016'4\u001c\u0007;\u0000&^\u0017=:\u0003\u00032\u0011z\"\u0010&'\u0010\u00050<4\u001f\u0000%0\u0003Y", -115, 0.24850261567985235, "An9TUbK2b1rUj3Xu7Pd4voE0STB4f9YQKG4PIHY3Nh451BF", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u0012'{\u001dW\u0006\u001d\u0002\u0015\u0002?{\u0005]\u0004\u0006\u001f\u0010\n,;\u0005A_,=%\b<'\u001fS\u001c\u0011\u001f\u0005\u0014\u00199\u0004U\u0018\u001a", (Object)"\u0016\u0002=\u0006\u0005]\u0003\u0015\u0016\u0014*(;\u0010U\u0014\u0006", "YN\u00053\u0004\\^\u0018\u0014\u0006\u000e:1\u0014D^\u0000\u001e\u0004\u0015'4\u001cW\u001f\u0000\u0002^\u0014=:\u0003S\u0016\u0011^\"\u0013&'\u0010U\u00149\u0010\u001f\u0006.0\u0003\t", -115, 5384481033778986938L, "un6oq9SC2QCmtW9rUNg8dAgfXRm633F7cQuooED2SFG", this.plugin));
        Iterator iterator = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001e\u001f.{\u0013\"2\u001f0\u0005C\u000b \u001a<0\u0000", (Object)"\u0016\b=\u001a\u001f;0\u001a<!\u0001(,\u0014%*", "YD\u0005?\u0010!8[,\u0005\u0004%z285\u0018<\u0012\u0019 :\u001fl", -114, -0.700594876912477, "XuG3YaN7WoC7U0sxpPmuM1kZ1GCr6U8j80BSZR0dMKEWjoVQbhehKxE").iterator();
        while (iterator.hasNext()) {
            Player player = (Player)iterator.next();
            UUID uUID = player.getUniqueId();
            Iterator iterator2 = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017L'{\u001d#\u001d\u001d\u0019\u0015\\?{\u0005)\u001f\u0006\u0004\u0010T,;\u00055D\u0000\u0005\u0004K'4\u001c#\u0004\u0000D%V<'\u001f'\u0007\u0011\u0004\u0005t(;\u0010!\u000f\u0006", (Object)"\u0016\\=\u0001\u001e3\u0018\u001a\u000b\u001c\\'!\u0002", "Yu#4\u0007'E\u0001\u001e\u0018Uf\u0000$\u000f.OC=S(#\u0010i\u001f\u0000\u0003\u001d\u0016\u001a0\u0005}", -115, -6937854706249796450L, "07t2j35YFQa3KOf59V9GvvZfKjPNYSqGGucwO1cmIp3jS", this, uUID).iterator();
            while (iterator2.hasNext()) {
                Tournament tournament2 = (Tournament)iterator2.next();
                object.setPlayerScore((String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017M'{\u001d5@\u001dD\u0015]?{\u0005?B\u0006Y\u0010U,;\u0005#\u0019\u0000X\u0004J'4\u001c5Y\u0000\u0019%W<'\u001f1Z\u0011Y\u0005", (Object)"\u0016]=\u001c\u00155Y\u0000^\u0017Q,'", "Y\u0011\u0005?\u0010&V[[\u0010V.z\"$E\u001dY\u0016\u0003", -113, 0.8636883207491745, "p4767Gb0PhKwimRuTN8TgTRJVb59ErJJqRypIs", tournament2), (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u001b%?4_\u0016;\u001d#_\u0011\u001c\u001c5", (Object)"\u0005+\u001a!\u0003\n!\u0013", "Ym\u0005?\u0010\u0015.[#\u0010*.z\"\u0017=\u001d!\u0016\u007f", -115, 0.025286825279864176, "kV3jOLrzce2Tsn0iZhDjWPKcbXoayYpZXoRfr", uUID), (int)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u0004'{\u001d\u0016!\u001d%\u0015\u0014?{\u0005\u001c#\u00068\u0010\u001c,;\u0005\u0000x\u00009\u0004\u0003'4\u001c\u00168\u0000x%\u001e<'\u001f\u0012;\u00118\u0005", (Object)"\u0016\u0014=\u0006\u0012\u001c$\u0011", "Y=#4\u0007\u0012y\u0001\"\u0018\u001df\u0000$:\u0012O\u007f8", -115, -784155709, "0z6xVtcwsJGyhCn5YAqrouCxkZVTiTQCrOopdc", tournament2, uUID));
                DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017!'{\u001dU;\u001d?\u00151?{\u0005_9\u0006\"\u00109,;\u0005Cb\u0000#\u0004&'4\u001cU\"\u0000b%;<'\u001fQ!\u0011\"\u0005", (Object)"\u00031$:\u0007U\u001c\u0015>\u0005=*<\u0001Q\"\u0000", "Y\u0018#4\u0007Qc\u00018\u00188f\u0000$y\bOe'", -113, -2.3601132720724505, "5bcgL6ZP0CG39K1D17TsW0rGdsU6wEXkwP2kDb7LNOsVqFWV1", tournament2, uUID);
            }
        }
        if (!bl) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017\u0017'{\u001d+O\u001dK\u0015\u0007?{\u0005!M\u0006V\u0010\u000f,;\u0005=\u0016\u0007L\u001e\u0010(2\u0014`k\u0000W\u0003\u0003.0</V\u0015_\u0014\u0010", (Object)"\u0016\u0007=\u0006\u0005!J\u0015_\u0014*(;\u0015\"]\u0006", "YK\u00053\u0004 \u0017\u0018]\u0006\u000b:1\u00148\u0017\u0000W\u0004\u0010'4\u001c+V\u0000K^\u0011=:\u0003/_\u0011\u0017\"\u0016&'\u0010)]<Y\u001f\u0006%0\u0003u", -113, 8243225927041041928L, "IfPK8VlVNhpNaczLuObzjZATYY7vblYtsb0K28LI8gs5BAudArbT48W", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("diRHctleqKs", "\u0017%'{\u001dW\u0000\u001d\u0004\u00155?{\u0005]\u0002\u0006\u0019\u0010=,;\u0005AY,;%?<'\u001fS\u001a\u0011\u0019\u0005#\u00199\u0004U\u001e\u001a", (Object)"\u00165=\u0006\u0005]\u0005\u0015\u0010\u0014\u001d(;\u0010U\u0012\u0006", "Yy\u00053\u0004\\X\u0018\u0012\u00069:1\u0014DX\u0000\u0018\u0004\"'4\u001cW\u0019\u0000\u0004^#=:\u0003S\u0010\u0011X\"$&'\u0010U\u00129\u0016\u001f1.0\u0003\t", -115, -4696946247847697169L, "WYdbwwYt2FV33CnObwP0y1UuLrXzNMQc0iCRhZUpWynG", this.plugin)).onDisable();
        }
    }

    public Set<Tournament> getTournaments(UUID uUID) {
        return this.tournaments.values().stream().filter(tournament -> tournament.isParticipant(uUID)).collect(Collectors.toSet());
    }

    public void loadPlayerCache(Player player) {
        UUID uUID = player.getUniqueId();
        StorageHandler storageHandler = this.plugin.getStorageManager().getStorageHandler();
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
            ArrayList<String> arrayList = new ArrayList<String>(storageHandler.getPlayerQueueActions(uUID.toString()));
            if (!arrayList.isEmpty()) {
                this.plugin.getStorageManager().getStorageHandler().removeQueueActions(uUID.toString());
                Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.plugin.getActionManager().executeActions(player, arrayList));
            }
            for (Tournament tournament : this.getTournaments()) {
                int n = storageHandler.getPlayerScore(tournament.getIdentifier(), uUID.toString());
                if (n > -1) {
                    tournament.addParticipant(uUID, n, false);
                    continue;
                }
                if (!tournament.isAutomaticParticipation()) continue;
                Permission permission = tournament.getParticipationPermission();
                if (permission != null) {
                    if (player.hasPermission(permission)) {
                        tournament.addParticipant(uUID, 0, true);
                    }
                } else {
                    tournament.addParticipant(uUID, 0, true);
                }
                Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.plugin.getActionManager().executeActions(player, tournament.getParticipationActions()));
            }
        });
    }

    public void savePlayerCache(UUID uUID) {
        StorageHandler storageHandler = this.plugin.getStorageManager().getStorageHandler();
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
            for (Tournament tournament : this.getTournaments(uUID)) {
                storageHandler.setPlayerScore(tournament.getIdentifier(), uUID.toString(), tournament.getScore(uUID));
                tournament.removeParticipant(uUID);
            }
        });
    }

    public void registerTournament(String string, FileConfiguration fileConfiguration) {
        if (!fileConfiguration.getBoolean("enabled")) {
            return;
        }
        TournamentBuilder tournamentBuilder = new TournamentBuilder(this.plugin, string);
        try {
            tournamentBuilder.loadFromFile(this.plugin.getObjectiveManager(), fileConfiguration);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        Tournament tournament = tournamentBuilder.build();
        XLObjective xLObjective = tournament.getObjective();
        Logger logger = this.plugin.getLogger();
        if (!xLObjective.loadTournament(tournament, fileConfiguration)) {
            logger.severe("The objective (\" + obj + \") in file \" + identifier + \" did not load correctly. Skipping..");
            return;
        }
        xLObjective.addTournament(tournament);
        tournament.updateStatus();
        if (tournament.getStatus() == TournamentStatus.ACTIVE) {
            tournament.start(false);
        }
        this.plugin.getStorageManager().getStorageHandler().createTournamentTable(string);
        this.tournaments.put(string, tournament);
        logger.info("Loaded '" + string + "' tournament.");
    }

    public Optional<Tournament> getTournament(String string) {
        return this.tournaments.values().stream().filter(tournament -> tournament.getIdentifier().equalsIgnoreCase(string)).findFirst();
    }

    public List<Tournament> getTournaments() {
        return new ArrayList<Tournament>(this.tournaments.values());
    }
}

