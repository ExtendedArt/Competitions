/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.InvalidConfigurationException
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package fun.lewisdev.tournaments.config;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class ConfigHandler {
    private final JavaPlugin plugin;
    private final String name;
    private final File file;
    private FileConfiguration configuration;

    public ConfigHandler(JavaPlugin javaPlugin, File file, String string) {
        this.plugin = javaPlugin;
        this.name = string.endsWith(".yml") ? string : string + ".yml";
        this.file = new File(file, this.name);
        this.configuration = new YamlConfiguration();
    }

    public ConfigHandler(JavaPlugin javaPlugin, String string) {
        this(javaPlugin, javaPlugin.getDataFolder(), string);
    }

    public void saveDefaultConfig() {
        if (!this.file.exists()) {
            int n = this.file.toPath().getNameCount();
            this.plugin.saveResource(this.file.getParentFile().getName().equals(this.plugin.getName()) ? this.name : this.file.toPath().subpath(n - 2, n).toFile().getPath(), false);
        }
        try {
            this.configuration.load(this.file);
        }
        catch (IOException | InvalidConfigurationException throwable) {
            throwable.printStackTrace();
            this.plugin.getLogger().severe("============= CONFIGURATION ERROR =============");
            this.plugin.getLogger().severe("There was an error loading " + this.name);
            this.plugin.getLogger().severe("Please check for any obvious configuration mistakes");
            this.plugin.getLogger().severe("such as using tabs for spaces or forgetting to end quotes");
            this.plugin.getLogger().severe("before reporting to the developer. The plugin will now disable..");
            this.plugin.getLogger().severe("============= CONFIGURATION ERROR =============");
            this.plugin.getServer().getPluginManager().disablePlugin((Plugin)this.plugin);
        }
    }

    public void save() {
        if (this.configuration == null || this.file == null) {
            return;
        }
        try {
            this.getConfig().save(this.file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public void reload() {
        this.configuration = YamlConfiguration.loadConfiguration((File)this.file);
    }

    public FileConfiguration getConfig() {
        return this.configuration;
    }

    public File getFile() {
        return this.file;
    }
}

