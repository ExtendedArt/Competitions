/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 */
package fun.lewisdev.tournaments.storage;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.storage.StorageHandler;
import fun.lewisdev.tournaments.storage.impl.MySQLHandler;
import fun.lewisdev.tournaments.storage.impl.SQLiteHandler;
import org.bukkit.plugin.Plugin;

public class StorageManager {
    private final XLTournamentsPlugin plugin;
    private StorageHandler storageHandler;

    public StorageManager(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    public void onEnable() {
        Object object = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u001e;.{\u0013A(\u001f*\u0005g*:\u001fR*\u00136\u0003(=<\u001eZm\u0012*\u001d,g\u0013\u0018X&7,\u001f/ 2\u0004F\"\u0000*\u001e'", (Object)"\u0016,=\u0006\u0005F*\u001a$", "Y\u0005#4\u0007Ul\u0018\"\u001f.f\u0006\u0005F*\u001a$J`\u0005?\u0010B\"[/\u0010'.z\"@1\u001d-\u0016r", -115, -695173538, "I0WNCS5C4ii9hSZsqEIZxMOFsfadAkmJZZ7yNuk", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u0017\u0011'{\u001d6#\u001d'\u0015\u0001?{\u0005<!\u0006:\u0010\t,;\u0005 z,\u0018%\u000b<'\u001f29\u0011:\u0005\u0017\u00199\u00044=\u001a", (Object)"\u0016\u0001=\u0016\u001e=2\u001d3", "YM\u0005:\u00034{\u0016!\u001a\u000f !^0;\u001a2\u0018\u0003<'\u0010'=\u001b:^\u0002 9\u0014|\u0012\u001d8\u0014'&;\u0017:3\u0001&\u0010\u0010 :\u001fh", -115, 1762427699, "xVsRTIgvSMydUTOWfEdPiuQon3kTAb7xZEkr2UV5Q3", this.plugin), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "5\";0\u0012\u0015\u000e\u0011\"\u001a8*8(\u00002\u0004\u0012\u001e\u001d+\u0011\u0017\u00030F", (Object)"C\u0011\u0003%H9\u0002\u0004\u0019\u0014(\u0011dE\u0002:\u001a!6\f", "Y\u0007#4\u0007.l\u0018\"\u001f,f\u0006\u0005=*\u001a$J\u0007#4\u0007.l\u0018\"\u001f,f\u0006\u0005=*\u001a$Jb\u0005?\u00109\"[/\u0010%.z\";1\u001d-\u0016p", -114, 968680775, "yVMoCLikOJQoChgL8gKhjN6YJUWQIV6FnPXuFSYrIY110UUz4", "\u000e:\u0012<\u001c)\u0018`\t7\r+", "cl6Zmgi2psFViAoRqrdBR4DfNRyxZbMswDW"));
        Object object2 = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u001b\u0004?4_\u0006\u0002\u001a\u0004_6='\u0018\u0004\u0004", (Object)"\u0005\n\u001c%\u0001\u000f\u00117\u0002\u0002\u0000", "YL\u0005?\u0010\u001c\u0002[\u000f\u0010\u000b.z\"\u001e\u0011\u001d\r\u0016^", -113, 0.27845988456617116, "6paucgcvjzbztCpAOxeDn1zLQ15A3QdZKpyYmFeeSB7m", object);
        int n = -1;
        switch (DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u001b2?4_\b\u0019\u001a\u001f_\u0000='\u0018\n\u001f", (Object)"\u00192:=2\u000b\u001c\u0011", "Yz\u0000", -115, -0.21363038f, "wcUsxcNKdVNzV3aqUGSt3NEAuoFbAESltOqDfJBzQXIsM", object2)) {
            case -1841605620: {
                if (DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u001b\r?4_>Q\u001aW_?='\u0018<W", (Object)"\u0014\u001d<4\u001d!", "Y #4\u00073\u001f\u0018Q\u001f\u000bf\u001a\u00138U\u0017DJE\u0013", -113, 5268308507381574398L, "yS3b0fjKRYEJnTzRzQlGc6c0fu7e7ifNHGl836ZpQv0a", object2, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "5.;0\u00128\u0002\u0011.\u001a4*8(->\u0004\u001e\u001e\u0011+\u0011\u0017.<F", (Object)"C\u001d\u0003%H\u0014\u000e\u0004\u0015\u0014$\u0011dE/6\u001a-6\u0000", "Y\u000b#4\u0007\u0003`\u0018.\u001f f\u0006\u0005\u0010&\u001a(J\u000b#4\u0007\u0003`\u0018.\u001f f\u0006\u0005\u0010&\u001a(Jn\u0005?\u0010\u0014.[#\u0010).z\"\u0016=\u001d!\u0016|", -114, -1.3777952752476037, "bykhOGe1bunsYmbsuGGqnznburSG1XbcYG7", "\n\f\u0015\u0014\r\u0018", "HXtGTBKA9PgQWCifPLDKpyfOYfn5hppIH5fZDwuaZId")) == false) break;
                n = 0;
                break;
            }
            case 73844866: {
                if (DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u001b(?4_:S\u001aU_\u001a='\u00188U", (Object)"\u00148<4\u001d%", "Y\u0005#4\u00077\u001d\u0018S\u001f.f\u001a\u0013<W\u0017FJ`\u0013", -115, 0.9817009817284333, "rCBC267aVtrDaCpbR4IrwH9o1FY54MPbior5w6vn6BVe0lb1K7lxNR", object2, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "5<;0\u0012\u001e*\u0011\u0006\u001a&*8(\u000b\u0016\u00046\u001e\u0003+\u0011\u0017\b\u0014F", (Object)"C\u000f\u0003%H2&\u0004=\u00146\u0011dE\t\u001e\u001a\u00056\u0012", "Y\u0019#4\u0007%H\u0018\u0006\u001f2f\u0006\u00056\u000e\u001a\u0000J\u0019#4\u0007%H\u0018\u0006\u001f2f\u0006\u00056\u000e\u001a\u0000J|\u0005?\u00102\u0006[\u000b\u0010;.z\"0\u0015\u001d\t\u0016n", -114, 1980113345, "3m96giH4DaO56ax8GKUChaQV6ycmlw8d7O4WPgqAB1wUs1PdBZNPnj", "4$*,5", "pxip0uw0sQfSUqALgY75XTcByuZ8dbIHp5Lbaa80Hzn87ru")) == false) break;
                n = 1;
            }
        }
        switch (n) {
            case 0: {
                this.storageHandler = new SQLiteHandler();
                break;
            }
            case 1: {
                this.storageHandler = new MySQLHandler();
                break;
            }
            default: {
                DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u0017\u001d'{\u001d\"/\u001d+\u0015\r?{\u0005(-\u00066\u0010\u0005,;\u00054v,\u0014%\u0007<'\u001f&5\u00116\u0005\u001b\u00199\u0004 1\u001a", (Object)"\u0016\r=\u0006\u00145.\u0011*", "YA\u0005:\u0003 w\u0016-\u001a\u0003 !^\u0014=\u0006.\u0014\u001ar", -113, -1205401150266785049L, "y5M7Xa9pGx1asumr5whJ7UsHVfAXnoBJhKjDBw", this.plugin).getPluginManager().disablePlugin((Plugin)this.plugin);
            }
        }
        if (!this.storageHandler.onEnable(this.plugin)) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIReJtLeaKE", "\u0017\u0002'{\u001d\t\u0002\u001d\u0006\u0015\u0012?{\u0005\u0003\u0000\u0006\u001b\u0010\u001a,;\u0005\u001f[,9%\u0018<'\u001f\r\u0018\u0011\u001b\u0005\u0004\u00199\u0004\u000b\u001c\u001a", (Object)"\u0016\u0012=\u0006\u0014\u001e\u0003\u0011\u0007", "Y^\u0005:\u0003\u000bZ\u0016\u0000\u001a\u001c !^?\u0010\u0006\u0003\u0014\u0005r", -113, -15.019165219210631, "Q7fmuiMQlKSpuQndOXwkNvdi7qGjTJYVwxkrXLTlR", this.plugin).getPluginManager().disablePlugin((Plugin)this.plugin);
        }
    }

    public void onDisable() {
        this.storageHandler.onDisable();
    }

    public StorageHandler getStorageHandler() {
        return this.storageHandler;
    }
}

