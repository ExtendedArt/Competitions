/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.storage.impl;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.libs.hikari.HikariConfig;
import fun.lewisdev.tournaments.libs.hikari.HikariDataSource;
import fun.lewisdev.tournaments.storage.StorageHandler;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MySQLHandler
implements StorageHandler {
    private HikariDataSource hikari;

    public MySQLHandler() {
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    @Override
    public boolean onEnable(XLTournamentsPlugin xLTournamentsPlugin) {
        Object object = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017\u0003'{\u001d,B\u001dF\u0015\u0013?{\u0005&@\u0006[\u0010\u001b,;\u0005:\u001b,y%\u0019<'\u001f(X\u0011[\u0005\u0005\u00199\u0004.\\\u001a", (Object)"\u0016\u0013=\u0016\u001e'S\u001dR", "Y_\u0005:\u0003.\u001a\u0016@\u001a\u001d !^*Z\u001aS\u0018\u0011<'\u0010=\\\u001b[^\u0010 9\u0014fs\u001dY\u00145&;\u0017 R\u0001G\u0010\u0002 :\u001fr", -113, 968652296, "5H9N5oInIWgSv8gue0vuXvTY69CmWvjQzuq8PXY1CjvA0", xLTournamentsPlugin);
        HikariConfig hikariConfig = new HikariConfig();
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017 '{\u001d)1\u001d5\u00150?{\u0005#3\u0006(\u00108,;\u0005?h\u0018/\u0013&g=\u0018''\u0006/_\u001d >\u0010>/7)\u001f3 2", (Object)"\u00020=\u001f\u0015.%!4\u001d", "Y\u0019#4\u0007-i\u0018'\u001f2f\u0006\u0005>/\u001a!J|\u001f", -113, -2.1356264608708786, "3YWvFobCL0VvSLwGXXUTB4avOPXWvXaCtoD", hikariConfig, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001b3?4_:\u0000\u001a\u0006_\u0001='\u00188\u0006", (Object)"\u0003799\u00105\u0004", "Y\u001e#4\u00077N\u0018\u0000\u001f5f\u0016\u00197\u0013'\u0004\u0000',;\u00123Z8\u000b\u0010$(z\u001d7\u000f\u0013N2:('\"3\u0010\u0001\u0004\u001f1,nX\u001a\u000b\u0015\u0017\u0010}%4\u001f1N'\u0015\u0003;'2J", -115, 0.46401536f, "ImNMaSWsVHBM7M9QJER154dQ2k30unbooWWwqEXJL1T9pc3xuwhO5", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001bQ?4_\u0007'\u001a!_c='\u0018\u0005!", (Object)"\u0003U99\u0010\b#", "Y|#4\u0007\ni\u0018'\u001fWf\u0016\u0019\n4'#\u0000E,;\u0012\u000e}8,\u0010F(z\u001d\n(\u0013i2X('\"\u000e7\u0001#\u001fS,nX',\u00150\u0010\u001f%4\u001f\fi'2\u0003Y'2J", -113, 4.321955401401603, "KGICFfKXkFP0ekUDrP0hr7KitrPHtNu6mDF8a3T1w", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001b\u0011?4_\u00149\u001a?_#='\u0018\u0016?", (Object)"\u0003\u001599\u0010\u001b=", "Y<#4\u0007\u0019w\u00189\u001f\u0017f\u0016\u0019\u0019*'=\u0000\u0005,;\u0012\u001dc82\u0010\u0006(z\u001d\u00196\u0013w2\u0018('\"\u001d)\u0001=\u001f\u0013,nX42\u0015.\u0010_%4\u001f\u001fw',\u0003\u0019'2J", -115, -16.710930788285534, "HrVRXNgqx7dkSC1EUnpBQjkPQ4iH2VV9g1tJmbMeBBpgrAJWgLEExxo", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001bS?4_\u000e\u0002\u001a\u0004_a='\u0018\f\u0004", (Object)"\u0003W99\u0010\u0001\u0006", "Y~#4\u0007\u0003L\u0018\u0002\u001fUf\u0016\u0019\u0003\u0011'\u0006\u0000G,;\u0012\u0007X8\t\u0010D(z\u001d\u0003\r\u0013L2Z('\"\u0007\u0012\u0001\u0006\u001fQ,nX.\t\u0015\u0015\u0010\u001d%4\u001f\u0005L'\u0017\u0003['2J", -115, -0.32385153f, "qmfZc9imbtbQynFili2wBteBxyeDAcUtescFZWrMaQ7mHcGxtQd", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u0011;0\u0012\n<\u0011\u0010\u001a\u000b*8(\u001f\u0000\u0004 \u001e.+\u0011\u0017\u001c\u0002F", (Object)"C\"\u0003%H&0\u0004+\u0014\u001b\u0011dE\u001d\b\u001a\u00136?", "Y4#4\u00071^\u0018\u0010\u001f\u001ff\u0006\u0005\"\u0018\u001a\u0016J4#4\u00071^\u0018\u0010\u001f\u001ff\u0006\u0005\"\u0018\u001a\u0016JQ\u0005?\u0010&\u0010[\u001d\u0010\u0016.z\"$\u0003\u001d\u001f\u0016C", -114, -0.27297157f, "XGfuqYDhPzOVHifdvtx1pv2b4R7R8egKffLxm", "\u0013\b\u001b\u000fC\u0001\u0000\u001f\b\u0000CCVI\u0011\u0003\n\u0018\\V\\\u001c\u0016\u001e\rIVI\u001d\r\r\r\u001b\r\n\t\\S\f\u001f\u001c?* DI\n\u001f\u0015I", "FhERZNwTQ1eauE2LOskClDofhaDdCknzdfrOnTFTpTuV24M"), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5P;0\u0012;\u001c\u00110\u001aJ*8(. \u0004\u0000\u001eo+\u0011\u0017-\"F", (Object)"Cc\u0003%H\u0017\u0010\u0004\u000b\u0014Z\u0011dE,(\u001a36~", "Yu#4\u0007\u0000~\u00180\u001f^f\u0006\u0005\u00138\u001a6Ju#4\u0007\u0000~\u00180\u001f^f\u0006\u0005\u00138\u001a6J\u0010\u0005?\u0010\u00170[=\u0010W.z\"\u0015#\u001d?\u0016\u0002", -114, -0.94286853f, "as1lQi9Ja3YBr62etK9buwfCVUqWYhqOair4sQwRRaLY0pk30gt", "X4\u0012/\ty", "EmQk1KrpvHwdaAz1oIcGsCgVXPxZ2ZikLI"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001e%.{\u0013\u0007\u0012\u001f\u0010\u0005y*:\u001f\u0014\u0010\u0013\f\u00036=<\u001e\u001cW\u0012\u0010\u001d2g\u0013\u0018\u001e\u001c7\u0016\u001f1 2\u0004\u0000\u0018\u0000\u0010\u001e9", (Object)"\u00162=\u0006\u0005\u0000\u0010\u001a\u001e", "Y\u001b#4\u0007\u0013V\u0018\u0018\u001f0f\u0006\u0005\u0000\u0010\u001a\u001eJ~\u0005?\u0010\u0004\u0018[\u0015\u00109.z\"\u0006\u000b\u001d\u0017\u0016l", -115, -0.5989683f, "JjqHyYPCrDomfSaoNZWbhMjduCxrZQcSJkBqKRUOWg6PKitzY6KIWk", object, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u000e;0\u0012\t;\u0011\u0017\u001a\u0014*8(\u001c\u0007\u0004'\u001e1+\u0011\u0017\u001f\u0005F", (Object)"C=\u0003%H%7\u0004,\u0014\u0004\u0011dE\u001e\u000f\u001a\u00146 ", "Y+#4\u00072Y\u0018\u0017\u001f\u0000f\u0006\u0005!\u001f\u001a\u0011J+#4\u00072Y\u0018\u0017\u001f\u0000f\u0006\u0005!\u001f\u001a\u0011JN\u0005?\u0010%\u0017[\u001a\u0010\t.z\"'\u0004\u001d\u0018\u0016\\", -114, 0.7868503f, "MJejvSBESbH4mGzXXjgIdTnTAjre3btpR0X9iLe87UUxHpYlDI8F8", "\u000e\u0018\u0012\u001e\u001c\u000b\u0018B\u0010\u0015\u000e\u001d\u0011B\u0015\u0003\u000e\u0018", "wetF3PIJ8DJq4BLycMJ76ruzdpzfXG52myaNm8bWMVNUzvA8ZD"))), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5;;0\u0012\u00139\u0011\u0015\u001a!*8(\u0006\u0005\u0004%\u001e\u0004+\u0011\u0017\u0005\u0007F", (Object)"C\b\u0003%H?5\u0004.\u00141\u0011dE\u0004\r\u001a\u00166\u0015", "Y\u001e#4\u0007([\u0018\u0015\u001f5f\u0006\u0005;\u001d\u001a\u0013J\u001e#4\u0007([\u0018\u0015\u001f5f\u0006\u0005;\u001d\u001a\u0013J{\u0005?\u0010?\u0015[\u0018\u0010<.z\"=\u0006\u001d\u001a\u0016i", -114, 0.117629826f, "XOdJthx6IBYxtZkb6SRxcWD31JC6m7unWlpVWNyMA4TCSNBndctKB", "~?4=/j", "DZtF3NiSSSyoQKC8PG7FR96eOvSNRruHs1lAFDD1UeuSz"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001b\f?4_Y\u0000\u001a\u0006_>='\u0018[\u0006", (Object)"\u0007\f% \u0014z\u0007", "Y$`\u0019\u001bT\u0017\u0015N\u001d\f'2^f\u0015\u0006\b\u001f\nr", -114, -1873872178694495003L, "meK8aagq5py09jNqSHmQZZF5SiaWAGMyIVxeJEWbHzfJMzs", (int)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001e\u0001.{\u0013\r\u0003\u001f\u0001\u0005]*:\u001f\u001e\u0001\u0013\u001d\u0003\u0012=<\u001e\u0016F\u0012\u0001\u001d\u0016g\u0013\u0018\u0014\r7\u0007\u001f\u0015 2\u0004\n\t\u0000\u0001\u001e\u001d", (Object)"\u0016\u0016=\u001c\u001f\f", "Y?#4\u0007\u0019G\u0018\t\u001f\u0014f\u0006\u0005\n\u0001\u001a\u000fJZ\u0000", -115, 0.6376474258444723, "l2fJhWZexsOkmNi7JXsL9gi5iDlaX1Q3bQx", object, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\r;0\u0012;/\u0011\u0003\u001a\u0017*8(.\u0013\u00043\u001e2+\u0011\u0017-\u0011F", (Object)"C>\u0003%H\u0017#\u00048\u0014\u0007\u0011dE,\u001b\u001a\u00006#", "Y(#4\u0007\u0000M\u0018\u0003\u001f\u0003f\u0006\u0005\u0013\u000b\u001a\u0005J(#4\u0007\u0000M\u0018\u0003\u001f\u0003f\u0006\u0005\u0013\u000b\u001a\u0005JM\u0005?\u0010\u0017\u0003[\u000e\u0010\n.z\"\u0015\u0010\u001d\f\u0016_", -114, 1.9843959732960603, "utMsbehMauIpuBmEKPdsQLLn8TABxYnhwtE6Wm", "\f\u001b\u0010\u001d\u001e\b\u001aA\u0012\u0016\f\u001e\u0013A\u000f\u0000\r\u001b", "ffrW6WdXbD38Q0ZyNCkOrHQ3gD472De06D74dmC3VHo")))), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u001a;0\u0012\u0000t\u0011X\u001a\u0000*8(\u0015H\u0004h\u001e%+\u0011\u0017\u0016JF", (Object)"C)\u0003%H,x\u0004c\u0014\u0010\u0011dE\u0017@\u001a[64", "Y?#4\u0007;\u0016\u0018X\u001f\u0014f\u0006\u0005(P\u001a^J?#4\u0007;\u0016\u0018X\u001f\u0014f\u0006\u0005(P\u001a^JZ\u0005?\u0010,X[U\u0010\u001d.z\".K\u001dW\u0016H", -114, 13.330620116009875, "I8dk9JqhZUJiTIYHGOsxn85B92UuoTCREPj01h0VqG", "Z\u001a\u001e\n\u001e\u001c\u001e\r\u001a[", "TozVmYQa1GGnjYsEQM8gA5sO6fAktwnqBrxXeQEVBFZg4WkWlPi"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001e3.{\u00136/\u001f-\u0005o*:\u001f%-\u00131\u0003 =<\u001e-j\u0012-\u001d$g\u0013\u0018/!7+\u001f' 2\u00041%\u0000-\u001e/", (Object)"\u0016$=\u0006\u00051-\u001a#", "Y\r#4\u0007\"k\u0018%\u001f&f\u0006\u00051-\u001a#Jh\u0005?\u00105%[(\u0010/.z\"76\u001d*\u0016z", -113, -1.6795458571050248, "zYVkDisuCiYy6HUmh4AC9nWnLNQMZMg2aIZEEM1dO8AmZIm3X", object, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5*;0\u0012\u000f&\u0011\n\u001a0*8(\u001a\u001a\u0004:\u001e\u0015+\u0011\u0017\u0019\u0018F", (Object)"C\u0019\u0003%H#*\u00041\u0014 \u0011dE\u0018\u0012\u001a\t6\u0004", "Y\u000f#4\u00074D\u0018\n\u001f$f\u0006\u0005'\u0002\u001a\fJ\u000f#4\u00074D\u0018\n\u001f$f\u0006\u0005'\u0002\u001a\fJj\u0005?\u0010#\n[\u0007\u0010-.z\"!\u0019\u001d\u0005\u0016x", -114, -0.91601247f, "7NHzkD4vUZ5XSWDE2iCsid3RAQGfFhfAGKkXbOATskZVC0ZzCeLYNR", "\n\u0018\u0016\u001e\u0018\u000b\u001cB\u0014\u0015\n\u001d\u0015B\u001d\r\r\r\u001b\r\n\t", "n0KXjwTwdCVOdI3DtMGxEL1whd8RXPOZZATUo"))), DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "59;0\u0012j\u001b\u00117\u001a#*8(\u007f'\u0004\u0007\u001e\u0006+\u0011\u0017|%F", (Object)"C\n\u0003%HF\u0017\u0004\f\u00143\u0011dE}/\u001a46\u0017", "Y\u001c#4\u0007Qy\u00187\u001f7f\u0006\u0005B?\u001a1J\u001c#4\u0007Qy\u00187\u001f7f\u0006\u0005B?\u001a1Jy\u0005?\u0010F7[:\u0010>.z\"D$\u001d8\u0016k", -114, -16.432422170957025, "WOfXV1Ht0Rtsp9IPadPQT4Qqg3GprN5D7hA3Mhxm8xbK", "|\u001f*\u0000|", "2Hf7kECbeY17a7TUUTMezkYOd9xoaytVuiPIlGWvBqhYyv2zd"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001b&?4_>2\u001a4_\u0014='\u0018<4", (Object)"\u0007&% \u0014\u001d5", "Y\u001d`\u0019\u001b3%\u0015|\u001d&'2^\u0001'\u0006:\u001f r", -114, 0.6056071160502104, "M6r4SsRSRtI9XaLODdGe9JFnWxHNsnBsvcN9C3rgEbzkffc0Fj8F", (boolean)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001e$.{\u0013FY\u001f[\u0005x*:\u001fU[\u0013G\u00037=<\u001e]\u001c\u0012[\u001d3g\u0013\u0018_W7]\u001f0 2\u0004AS\u0000[\u001e8", (Object)"\u00163=\u0017\u001e\\^\u0011S\u001f", "Y\u001a#4\u0007R\u001d\u0018S\u001f1f\u0006\u0005A[\u001aUJ\u007f\u0013", -113, -0.5593743056425459, "xbNs2xsw3ln1qPNWFlVFwiNXfAEWb7X0s2uTL9", object, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u001f;0\u0012\u0017\u001c\u00110\u001a\u0005*8(\u0002 \u0004\u0000\u001e +\u0011\u0017\u0001\"F", (Object)"C,\u0003%H;\u0010\u0004\u000b\u0014\u0015\u0011dE\u0000(\u001a361", "Y:#4\u0007,~\u00180\u001f\u0011f\u0006\u0005?8\u001a6J:#4\u0007,~\u00180\u001f\u0011f\u0006\u0005?8\u001a6J_\u0005?\u0010;0[=\u0010\u0018.z\"9#\u001d?\u0016M", -114, 392494049746033959L, "Ks5FQhOVM64MgUBKcxvPZZh3UzXpvJuSJ9xpljhm5tMjZfA", "(\u001a4\u001c:\t>@6\u0017(\u001f7@.\u001d>1(\u001d7", "oSfepbjHe3lmxVSQW0M1hluhbtuHyRGLv79QC9V")))));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017M'{\u001d\fD\u001d@\u0015]?{\u0005\u0006F\u0006]\u0010U,;\u0005\u001a\u001d\u0018Z\u0013Kg=\u0018\u0002R\u0006Z_p >\u0010\u001bZ7\\\u001f^ 2", (Object)"\u0002]=\u0000\u0002\fA\u001aR\u001c]", "Yt#4\u0007\b\u001c\u0018R\u001f_f\u0006\u0005\u001bZ\u001aTJ\u0011\u001f", -115, 1103648599, "2I4L3QjYiuIs9L6Adh8mGEeeJqvhNlin3SG9nOUrU7aAfMcFbhbx", hikariConfig, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001eF.{\u0013&:\u001f8\u0005\u001a*:\u001f58\u0013$\u0003U=<\u001e=\u007f\u00128\u001dQg\u0013\u0018?47>\u001fR 2\u0004!0\u00008\u001eZ", (Object)"\u0016Q=\u0006\u0005!8\u001a6", "Yx#4\u00072~\u00180\u001fSf\u0006\u0005!8\u001a6J\u001d\u0005?\u0010%0[=\u0010Z.z\"'#\u001d?\u0016\u000f", -115, -0.8452929f, "okptQw9NS7bvr7fie44zi0EIrjH2ZpGkbBHaG1lnwOCjPpNmEqoK", object, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u0013;0\u0012?4\u0011\u0018\u001a\t*8(*\b\u0004(\u001e,+\u0011\u0017)\nF", (Object)"C \u0003%H\u00138\u0004#\u0014\u0019\u0011dE(\u0000\u001a\u001b6=", "Y6#4\u0007\u0004V\u0018\u0018\u001f\u001df\u0006\u0005\u0017\u0010\u001a\u001eJ6#4\u0007\u0004V\u0018\u0018\u001f\u001df\u0006\u0005\u0017\u0010\u001a\u001eJS\u0005?\u0010\u0013\u0018[\u0015\u0010\u0014.z\"\u0011\u000b\u001d\u0017\u0016A", -114, 1213281408, "70DDype4eLTnAl1dN5zJinmiHm5wyM3VOlZrRNfZsEK44esa", "\b:\u0014<\u001a)\u001e`\u00167\b?\u0017`\u000e=\u001e<\u0015/\u0016+", "UzK0qFnis1ErhOayEIZVn8pOBHOFDxAU9cNQjsGIDz086gCc")));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u00170'{\u001d'\u0014\u001d\u0010\u0015 ?{\u0005-\u0016\u0006\r\u0010(,;\u00051M\u0018\n\u00136g=\u0018)\u0002\u0006\n_\r >\u00100\n7\f\u001f# 2", (Object)"\u0002 =\u0005\u00101\u0010\u0003\f\u0003!", "Y\t#4\u0007#L\u0018\u0002\u001f\"f\u0006\u00050\n\u001a\u0004Jl\u001f", -113, -0.29551470945569036, "vThRcLTaB5MzPBrY7FE5RoPFL8v0ZXsx5Ux9JdmHmmpc1kjyqU", hikariConfig, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u001e1.{\u0013/\u0013\u001f\u0011\u0005m*:\u001f<\u0011\u0013\r\u0003\"=<\u001e4V\u0012\u0011\u001d&g\u0013\u00186\u001d7\u0017\u001f% 2\u0004(\u0019\u0000\u0011\u001e-", (Object)"\u0016&=\u0006\u0005(\u0011\u001a\u001f", "Y\u000f#4\u0007;W\u0018\u0019\u001f$f\u0006\u0005(\u0011\u001a\u001fJj\u0005?\u0010,\u0019[\u0014\u0010-.z\".\n\u001d\u0016\u0016x", -113, -1.333960424681977, "td9dxcfFZQWpB7PQMsCNczpBxSPUWhHK9vepX9lnTC1qZl", object, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u000f;0\u0012\t\u000b\u0011'\u001a\u0015*8(\u001c7\u0004\u0017\u001e0+\u0011\u0017\u001f5F", (Object)"C<\u0003%H%\u0007\u0004\u001c\u0014\u0005\u0011dE\u001e?\u001a$6!", "Y*#4\u00072i\u0018'\u001f\u0001f\u0006\u0005!/\u001a!J*#4\u00072i\u0018'\u001f\u0001f\u0006\u0005!/\u001a!JO\u0005?\u0010%'[*\u0010\b.z\"'4\u001d(\u0016]", -114, 0.9456404767615353, "I9aFFa5zS5ILyoV6wbfPzQTkKViuEugf9cG0t5DUIJFMXLK", "\u000e\n\u0012\f\u001c\u0019\u0018P\u0010\u0007\u000e\u000f\u0011P\r\u001f\u000e\r\n\u0011\u000f\u001a", "pdMvV1DsLouffItzdOV1vG8xrfm9qQbVt")));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017,'{\u001dV\u001d\u001d\u0019\u0015<?{\u0005\\\u001f\u0006\u0004\u00104,;\u0005@D\u0018\u0003\u0013*g=\u0018X\u000b\u0006\u0003_\u0011 >\u0010A\u00037\u0005\u001f? 2", (Object)"\u0010=-\u0011\u0010G\u000b'\u0005\u0004+*0!A\u0005\u0004\u000f\u0003-0", "Y\u0015#4\u0007RE\u0018\u000b\u001f>f\u0006\u0005A\u0003\u001a\rJ\u0015#4\u0007RE\u0018\u000b\u001f>f\u001a\u0013Y\u000f\u0017\u001eJp\u001f", -115, 3317966632536262385L, "UskFjRK83wAKwLhCuOYqmodjLR2lJ8LB54drDrmUbscSegZ1vy", hikariConfig, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\n;0\u0012\b:\u0011\u0016\u001a\u0010*8(\u001d\u0006\u0004&\u001e5+\u0011\u0017\u001e\u0004F", (Object)"C9\u0003%H$6\u0004-\u0014\u0000\u0011dE\u001f\u000e\u001a\u00156$", "Y/#4\u00073X\u0018\u0016\u001f\u0004f\u0006\u0005 \u001e\u001a\u0010J/#4\u00073X\u0018\u0016\u001f\u0004f\u0006\u0005 \u001e\u001a\u0010JJ\u0005?\u0010$\u0016[\u001b\u0010\r.z\"&\u0005\u001d\u0019\u0016X", -114, 0.7364244939298874, "6EcRwxVjRUYtrnA9wfcI1PVy2TgzmUy2W3Z1fusuToD78aGeYz75TxO", "\u0018\u001e\u0018\u0017\u001e/\t\u001a\u000b,\u000f\u0012\u000f\f", "Y27RFbU18zGQ4x1hjYvaii4nwjKk1So05jMohB"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5*;0\u0012\u001c\t\u0011%\u001a0*8(\t5\u0004\u0015\u001e\u0015+\u0011\u0017\n7F", (Object)"C\u0019\u0003%H0\u0005\u0004\u001e\u0014 \u0011dE\u000b=\u001a&6\u0004", "Y\u000f#4\u0007'k\u0018%\u001f$f\u0006\u00054-\u001a#J\u000f#4\u0007'k\u0018%\u001f$f\u0006\u00054-\u001a#Jj\u0005?\u00100%[(\u0010-.z\"26\u001d*\u0016x", -114, 1.45113187605968, "nUXmDcJdFpgsyb4eHcCf2muRrnFBKZnpaLopw", "/\u000f.\u0018", "pJNNqDYfVvoDgB3IpBvRPQrI1PlQcXbdFefkXIklrIwiQd"));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017>'{\u001d\u0006\u001c\u001d\u0018\u0015.?{\u0005\f\u001e\u0006\u0005\u0010&,;\u0005\u0010E\u0018\u0002\u00138g=\u0018\b\n\u0006\u0002_\u0003 >\u0010\u0011\u00027\u0004\u001f- 2", (Object)"\u0010/-\u0011\u0010\u0017\n'\u0004\u00049*0!\u0011\u0004\u0004\u000e\u0003?0", "Y\u0007#4\u0007\u0002D\u0018\n\u001f,f\u0006\u0005\u0011\u0002\u001a\fJ\u0007#4\u0007\u0002D\u0018\n\u001f,f\u001a\u0013\t\u000e\u0017\u001fJb\u001f", -113, 0.5591798f, "Qv1Tk5yVctDWvL1pSBKcZRBuSrlFhC2VfLVdPJkxUc4nisfKB", hikariConfig, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5,;0\u0012>/\u0011\u0003\u001a6*8(+\u0013\u00043\u001e\u0013+\u0011\u0017(\u0011F", (Object)"C\u001f\u0003%H\u0012#\u00048\u0014&\u0011dE)\u001b\u001a\u00006\u0002", "Y\t#4\u0007\u0005M\u0018\u0003\u001f\"f\u0006\u0005\u0016\u000b\u001a\u0005J\t#4\u0007\u0005M\u0018\u0003\u001f\"f\u0006\u0005\u0016\u000b\u001a\u0005Jl\u0005?\u0010\u0012\u0003[\u000e\u0010+.z\"\u0010\u0010\u001d\f\u0016~", -114, 1972608337, "jGgAbp01dY7dAKAcoHEYJFLpBQEKZhoANOY0TsmdNLzf4m", "\t?\u001c=*9\u00149:,\u001a%\u001c\u001e\u00107\u001c", "n8QMZoZzSTxziZ1sVdTKdlFBEUsv9uvoK"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5Y;0\u0012\f\"\u0011\u000e\u001aC*8(\u0019\u001e\u0004>\u001ef+\u0011\u0017\u001a\u001cF", (Object)"Cj\u0003%H .\u00045\u0014S\u0011dE\u001b\u0016\u001a\r6w", "Y|#4\u00077@\u0018\u000e\u001fWf\u0006\u0005$\u0006\u001a\bJ|#4\u00077@\u0018\u000e\u001fWf\u0006\u0005$\u0006\u001a\bJ\u0019\u0005?\u0010 \u000e[\u0003\u0010^.z\"\"\u001d\u001d\u0001\u0016\u000b", -114, 0.61076134f, "if3XoPATVuD4vQKTKO0XCAPBwmdQLmmihJw2c", "OHM", "3mPROeVnI6EQNDhR7f3Yzr051oCog7Pe"));
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017\u0007'{\u001d \u0000\u001d\u0004\u0015\u0017?{\u0005*\u0002\u0006\u0019\u0010\u001f,;\u00056Y\u0018\u001e\u0013\u0001g=\u0018.\u0016\u0006\u001e_: >\u00107\u001e7\u0018\u001f\u0014 2", (Object)"\u0010\u0016-\u0011\u00101\u0016'\u0018\u0004\u0000*0!7\u0018\u0004\u0012\u0003\u00060", "Y>#4\u0007$X\u0018\u0016\u001f\u0015f\u0006\u00057\u001e\u001a\u0010J>#4\u0007$X\u0018\u0016\u001f\u0015f\u001a\u0013/\u0012\u0017\u0003J[\u001f", -113, 0.7462341f, "7zmswpGXEGD3dVrBj2rOLPG3oqrGWBZOMRGOwy", hikariConfig, DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "51;0\u0012\u0010 \u0011\f\u001a+*8(\u0005\u001c\u0004<\u001e\u000e+\u0011\u0017\u0006\u001eF", (Object)"C\u0002\u0003%H<,\u00047\u0014;\u0011dE\u0007\u0014\u001a\u000f6\u001f", "Y\u0014#4\u0007+B\u0018\f\u001f?f\u0006\u00058\u0004\u001a\nJ\u0014#4\u0007+B\u0018\f\u001f?f\u0006\u00058\u0004\u001a\nJq\u0005?\u0010<\f[\u0001\u00106.z\">\u001f\u001d\u0003\u0016c", -114, 102237932, "JihBm5ywJnoLfg1ByiXx2FVcyn2to3itQrdOAkjXFeffvdEYS", "\u000b<\u001e>(:\u0016:8/\u0018&\u001e\u001d\n\"7'\u0016'\u000f", "63gjk1vsV9D9BWRXCDhZZZoKBMkCD5WhYCRtfm043dg"), (Object)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "5\u0010;0\u0012\u000fu\u0011Y\u001a\n*8(\u001aI\u0004i\u001e/+\u0011\u0017\u0019KF", (Object)"C#\u0003%H#y\u0004b\u0014\u001a\u0011dE\u0018A\u001aZ6>", "Y5#4\u00074\u0017\u0018Y\u001f\u001ef\u0006\u0005'Q\u001a_J5#4\u00074\u0017\u0018Y\u001f\u001ef\u0006\u0005'Q\u001a_JP\u0005?\u0010#Y[T\u0010\u0017.z\"!J\u001dV\u0016B", -114, -12.638812745861955, "jeN98nZ5UfMj5M5z6JycrSFGiF8IwFWpxhi4KY4ZhEgu2d9AsOv", "ilod", "vZ8i1w0VnBiqkxWikXDpTwfLXw73nFbTdcHch"));
        this.hikari = new HikariDataSource(hikariConfig);
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017\u001a'{\u001dR\u0007\u001d\u0003\u0015\n?{\u0005X\u0005\u0006\u001e\u0010\u0002,;\u0005D^\u0007\u0004\u001e\u001d(2\u0014\u0019\u0019\u0019\u0000\u001dA\u0004,\"f<<\u0011\u001f\u000b%0\u0003", (Object)"\u0012\u001d,4\u0005R!\u0001\u0015\u0004\n\u001d4\u0013[\u0015", "YF\u001f", -113, -1.1318464286626226, "lCFUpbyl76nNh5TbAto2JeGxqDLOIPt3eF8bMDOW3qZQ", this);
        return true;
    }

    @Override
    public void onDisable() {
        if (this.hikari != null) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("dIrWCTLetkS", "\u0017\u001f'{\u001d2\"\u001d&\u0015\u000f?{\u00058 \u0006;\u0010\u0007,;\u0005${\u0018<\u0013\u0019g=\u0018<4\u0006<_\" >\u0010%<04\u0005\u000b\u001a:\u0004%6\u0011", (Object)"\u0012\u0006&&\u0014", "YC\u001f", -113, 10.542358031472325, "No3mUCU0W1iU8H2eNRjMpVy13KQgt2qau7qHN", this.hikari);
        }
    }

    @Override
    public void createQueueTable() {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("CREATE TABLE IF NOT EXISTS `action_queue` (uuid varchar(255) NOT NULL, action varchar(255));");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void createTournamentTable(String string) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("CREATE TABLE IF NOT EXISTS `" + string + "` (uuid varchar(255) NOT NULL PRIMARY KEY, score decimal NOT NULL);");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void addParticipant(String string, UUID uUID) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("REPLACE INTO `" + string + "` (uuid, score) VALUES ('" + uUID + "',0);");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void updateParticipant(String string, UUID uUID, int n) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("UPDATE `" + string + "` SET score = " + n + " WHERE uuid='" + uUID.toString() + "';");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void clearParticipants(String string) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("DELETE FROM `" + string + "`;");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void clearParticipant(String string, UUID uUID) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("DELETE FROM `" + string + "` WHERE uuid='" + uUID.toString() + "';");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<String> getPlayerQueueActions(String string) {
        try (Connection connection = this.hikari.getConnection();){
            ArrayList<String> arrayList;
            block15: {
                Statement statement = connection.createStatement();
                try {
                    ArrayList<String> arrayList2 = new ArrayList<String>();
                    ResultSet resultSet = statement.executeQuery("SELECT action FROM action_queue WHERE uuid='" + string + "';");
                    while (resultSet.next()) {
                        arrayList2.add(resultSet.getString("action"));
                    }
                    arrayList = arrayList2;
                    if (statement == null) break block15;
                }
                catch (Throwable throwable) {
                    if (statement != null) {
                        try {
                            statement.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                statement.close();
            }
            return arrayList;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
            return Collections.emptyList();
        }
    }

    @Override
    public void addActionToQueue(String string, String string2) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("INSERT INTO action_queue (uuid, action) VALUES('" + string + "','" + string2 + "');");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void removeQueueActions(String string) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("DELETE FROM action_queue WHERE uuid='" + string + "';");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    @Override
    public Map<UUID, Integer> getTopPlayers(String string) {
        try (Connection connection = this.hikari.getConnection();){
            LinkedHashMap<UUID, Integer> linkedHashMap;
            block15: {
                Statement statement = connection.createStatement();
                try {
                    LinkedHashMap<LinkedHashMap<UUID, Integer>, Integer> linkedHashMap2 = new LinkedHashMap<LinkedHashMap<UUID, Integer>, Integer>();
                    ResultSet resultSet = statement.executeQuery("SELECT * FROM `" + string + "` ORDER BY score DESC");
                    while (resultSet.next()) {
                        linkedHashMap = UUID.fromString(resultSet.getString("uuid"));
                        int n = resultSet.getInt("score");
                        linkedHashMap2.put(linkedHashMap, n);
                    }
                    linkedHashMap = linkedHashMap2;
                    if (statement == null) break block15;
                }
                catch (Throwable throwable) {
                    if (statement != null) {
                        try {
                            statement.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                statement.close();
            }
            return linkedHashMap;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
            return null;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    @Override
    public Map<UUID, Integer> getTopPlayersByScore(String string, int n) {
        try (Connection connection = this.hikari.getConnection();){
            LinkedHashMap<UUID, Integer> linkedHashMap;
            block15: {
                Statement statement = connection.createStatement();
                try {
                    LinkedHashMap<LinkedHashMap<UUID, Integer>, Integer> linkedHashMap2 = new LinkedHashMap<LinkedHashMap<UUID, Integer>, Integer>();
                    ResultSet resultSet = statement.executeQuery("SELECT uuid,score FROM `" + string + "` WHERE score>=" + n + ";");
                    while (resultSet.next()) {
                        linkedHashMap = UUID.fromString(resultSet.getString("uuid"));
                        int n2 = resultSet.getInt("score");
                        linkedHashMap2.put(linkedHashMap, n2);
                    }
                    linkedHashMap = linkedHashMap2;
                    if (statement == null) break block15;
                }
                catch (Throwable throwable) {
                    if (statement != null) {
                        try {
                            statement.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                statement.close();
            }
            return linkedHashMap;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getPlayerScore(String string, String string2) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            ResultSet resultSet = statement.executeQuery("SELECT score FROM `" + string + "` WHERE uuid='" + string2 + "';");
            if (!resultSet.next()) return -1;
            int n = resultSet.getInt("score");
            return n;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
        return -1;
    }

    @Override
    public void setPlayerScore(String string, String string2, int n) {
        try (Connection connection = this.hikari.getConnection();
             Statement statement = connection.createStatement();){
            statement.execute("REPLACE INTO `" + string + "` (uuid, score) VALUES ('" + string2 + "'," + n + ");");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }
}

