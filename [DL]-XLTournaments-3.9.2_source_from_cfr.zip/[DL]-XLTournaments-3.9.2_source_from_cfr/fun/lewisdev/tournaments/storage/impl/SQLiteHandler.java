/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.storage.impl;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.storage.StorageHandler;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SQLiteHandler
implements StorageHandler {
    private File file;
    private Connection connection;

    public SQLiteHandler() {
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    @Override
    public boolean onEnable(XLTournamentsPlugin xLTournamentsPlugin) {
        this.file = new File((File)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u0017\"'{\u001d(N\u001dJ\u00152?{\u0005\"L\u0006W\u0010:,;\u0005>\u0017,u%8<'\u001f,T\u0011W\u0005$\u00199\u0004*P\u001a", (Object)"\u00162=\u0011\u00109X2V\u001d3,'", "Y~\u0005?\u0010;X[P\u001ex\u000f<\u001d(\u0002", -113, -2053157784, "Uu9H9I21MtqTMgEeZuWwfSWYcdyUUx7drFVU0MbRrdm09YDJy6", xLTournamentsPlugin), (String)DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "59;0\u0012;\u0000\u0011,\u001a#*8(.<\u0004\u001c\u001e\u0006+\u0011\u0017->F", (Object)"C\n\u0003%H\u0017\f\u0004\u0017\u00143\u0011dE,4\u001a/6\u0017", "Y\u001c#4\u0007\u0000b\u0018,\u001f7f\u0006\u0005\u0013$\u001a*J\u001c#4\u0007\u0000b\u0018,\u001f7f\u0006\u0005\u0013$\u001a*Jy\u0005?\u0010\u0017,[!\u0010>.z\"\u0015?\u001d#\u0016k", -114, 0.36111462f, "GoldM0CCaIVKrdz3M2PWku828L6wcM84Ay9m4V3iyP2Kdng4R8", "9>)>?>.:s;?", "mEnHIbG9yNFvLcqa1hzPU4xSSjlERUuhtEUU9"));
        if (DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b-?4_\u0000,Z\u0005\u0018 ,", (Object)"\u00144 &\u0005\u001a", "Ye\u0013", -113, 0.41755933f, "PfxgCmhCirmYzSC0wzL7ZqPykwjZmNK1fFNuD", this.file) == false) {
            try {
                DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b\u0015?4_Q9Z\u0010\u0018\u0018,", (Object)"\u0012\u0006,4\u0005]\u0018\u0011!7\u001d%0", "Y]\u0013", -115, 9.652173823923372, "CB97VzSq8ddEoWbklztbzkM2Qbjf2OYnlbXyj1K", this.file);
            }
            catch (IOException iOException) {
                DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b\u000f?4_\n%Z\u0003>+16\u0014\u0013>\u001d%\u001f", (Object)"\u0001\u001c ;\u00050>\u0015)\u001a:;4\u0012\u0006", "YG\u001f", -113, -0.46194184f, "rztvJ2HncwIwqDjBsJnnz9AUJ5v4pvNkKFavazk6MzgHSsKD1YTSlvT", iOException);
                return false;
            }
        }
        try {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b\u000e?4_\u00030\u001a6_,%4\u0002\u001c", (Object)"\u0017\u0000;\u001b\u0010\u00024", "Y##4\u0007\u000e~\u00180\u001f\bf\u0006\u0005\u001d8\u001a6JF\u0005?\u0010\u00190[=\u0010\u0001.z2\u00030\u0007\"J", -114, -905347537, "AnONQIUEosGhY7Rjd3orKO5hskTsRsP2QOxdZP6GPv7wi4HpV", DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "5[;0\u00120!\u0011\r\u001aA*8(%\u001d\u0004=\u001ed+\u0011\u0017&\u001fF", (Object)"Ch\u0003%H\u001c-\u00046\u0014Q\u0011dE'\u0015\u001a\u000e6u", "Y~#4\u0007\u000bC\u0018\r\u001fUf\u0006\u0005\u0018\u0005\u001a\u000bJ~#4\u0007\u000bC\u0018\r\u001fUf\u0006\u0005\u0018\u0005\u001a\u000bJ\u001b\u0005?\u0010\u001c\r[\u0000\u0010\\.z\"\u001e\u001e\u001d\u0002\u0016\t", -114, -0.22883117f, "3QJOl3azjkDZgFu6y62iVDnjVg9mdKa5pBWe2AvdjDMalzWcftD", "\u0016\u001d\u001eA\n\u001e\u0015\u0006\r\nW%=-:", "RaVsQahwmv3qnYfqNQjPUQbWoZrCR0WTPx2vHcL4lfgymfOR"));
            if (this.connection != null) {
                this.connection.close();
            }
            this.connection = DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b\u0007?4_!\u001b\u0018D5\u0014 #\u0014 '\u0015\u0004\u0010\u0001,'", (Object)"\u0016\u0003=\u0016\u001e<\u0004\u0011\t\u0005\u000f&;", "Y*#4\u00073E\u0018\u000b\u001f\u0001f\u0006\u0005 \u0003\u001a\rJO\u0005?\u0010$\u000b[\u0019\u0000\nf\u0016\u001e<\u0004\u0011\t\u0005\u000f&;J", -114, -1.4836338362757528, "9YFtjMGgRpqvvVk3mRf84vN5kH3RgwsBTEQaw1SWBlT391", "jdbc:sqlite:" + this.file);
        }
        catch (ClassNotFoundException | SQLException exception) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b\u0007?4_\u0015\f\u001a\n_#16\u0014\t\u0019\u001d\u0002\u001f", (Object)"\u0001\u0014 ;\u0005*\u0019\u0015\u000e\u001a2;4\u0012\u001c", "YO\u001f", -115, 568480808, "tyNkm0SAycMvhTOcY8fBTZLzi7BauJvbsW07oDMYXY", exception);
        }
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u00176'{\u001d+-\u001d)\u0015&?{\u0005!/\u00064\u0010.,;\u0005=t\u0007.\u001e1(2\u0014`3\u0019*\u001dm\u001a\u0004='.\u0011\u0012\u0010--9\u0014<", (Object)"\u00121,4\u0005+\u000b\u0001?\u0004&\u001d4\u0013\"?", "Yj\u001f", -113, 899633956, "k6ymZfoLNBn30eZMvhCWGH9DsvTgqs4dmZgSVKplv8grqp", this);
        return true;
    }

    @Override
    public void onDisable() {
        try {
            this.connection.close();
        }
        catch (SQLException sQLException) {
            DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DieecTZeaKs", "\u001b\u0005?4_E!\u0018~\"5\u0005\u0010\tU5\u0004$\u0018\u000b'", (Object)"\u0001\u0016 ;\u0005e$\u00153\u001a0;4\u0012S", "YM\u001f", -115, 2008092403, "qRk5PMZ96pnDqkhiJLds9WTIPGn392KEMDfGGJLeg", sQLException);
        }
    }

    public Connection getConnection() {
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                return this.connection;
            }
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection("jdbc:sqlite:" + this.file);
            return this.connection;
        }
        catch (ClassNotFoundException | SQLException exception) {
            exception.printStackTrace();
            return this.connection;
        }
    }

    @Override
    public void createQueueTable() {
        try {
            Connection connection = this.getConnection();
            String string = "CREATE TABLE IF NOT EXISTS action_queue (uuid varchar(255) NOT NULL, action varchar(255));";
            Statement statement = connection.createStatement();
            statement.execute(string);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void createTournamentTable(String string) {
        try {
            Connection connection = this.getConnection();
            String string2 = "CREATE TABLE IF NOT EXISTS '" + string + "' (uuid varchar(255) NOT NULL PRIMARY KEY, score decimal NOT NULL);";
            Statement statement = connection.createStatement();
            statement.execute(string2);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void addParticipant(String string, UUID uUID) {
        try {
            Connection connection = this.getConnection();
            String string2 = "INSERT OR IGNORE INTO '" + string + "' (uuid, score) VALUES ('" + uUID + "',0);";
            Statement statement = connection.createStatement();
            statement.execute(string2);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void updateParticipant(String string, UUID uUID, int n) {
        try {
            Connection connection = this.getConnection();
            String string2 = "UPDATE '" + string + "' SET score = " + n + " WHERE uuid='" + uUID.toString() + "';";
            Statement statement = connection.createStatement();
            statement.execute(string2);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void clearParticipants(String string) {
        try {
            Connection connection = this.getConnection();
            String string2 = "DELETE FROM '" + string + "';";
            Statement statement = connection.createStatement();
            statement.execute(string2);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void clearParticipant(String string, UUID uUID) {
        try {
            Connection connection = this.getConnection();
            String string2 = "DELETE FROM '" + string + "' WHERE uuid='" + uUID.toString() + "';";
            Statement statement = connection.createStatement();
            statement.execute(string2);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public List<String> getPlayerQueueActions(String string) {
        try {
            Connection connection = this.getConnection();
            ArrayList<String> arrayList = new ArrayList<String>();
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT action FROM 'action_queue' WHERE uuid='" + string + "';");
            while (resultSet.next()) {
                arrayList.add(resultSet.getString("action"));
            }
            return arrayList;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
            return Collections.emptyList();
        }
    }

    @Override
    public void addActionToQueue(String string, String string2) {
        try {
            Connection connection = this.getConnection();
            String string3 = "INSERT INTO action_queue (uuid, action) VALUES('" + string + "','" + string2 + "');";
            Statement statement = connection.createStatement();
            statement.execute(string3);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public void removeQueueActions(String string) {
        try {
            Connection connection = this.getConnection();
            String string2 = "DELETE FROM 'action_queue' WHERE uuid='" + string + "';";
            Statement statement = connection.createStatement();
            statement.execute(string2);
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }

    @Override
    public Map<UUID, Integer> getTopPlayers(String string) {
        try {
            Connection connection = this.getConnection();
            LinkedHashMap<UUID, Integer> linkedHashMap = new LinkedHashMap<UUID, Integer>();
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT * FROM '" + string + "' ORDER BY score DESC");
            while (resultSet.next()) {
                UUID uUID = UUID.fromString(resultSet.getString("uuid"));
                int n = resultSet.getInt("score");
                linkedHashMap.put(uUID, n);
            }
            return linkedHashMap;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
            return null;
        }
    }

    @Override
    public Map<UUID, Integer> getTopPlayersByScore(String string, int n) {
        try {
            Connection connection = this.getConnection();
            LinkedHashMap<UUID, Integer> linkedHashMap = new LinkedHashMap<UUID, Integer>();
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT uuid,score FROM '" + string + "' WHERE score>=" + n + ";");
            while (resultSet.next()) {
                UUID uUID = UUID.fromString(resultSet.getString("uuid"));
                int n2 = resultSet.getInt("score");
                linkedHashMap.put(uUID, n2);
            }
            return linkedHashMap;
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
            return null;
        }
    }

    @Override
    public int getPlayerScore(String string, String string2) {
        try {
            Connection connection = this.getConnection();
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT score FROM '" + string + "' WHERE uuid='" + string2 + "';");
            if (resultSet.next()) {
                return resultSet.getInt("score");
            }
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
        return -1;
    }

    @Override
    public void setPlayerScore(String string, String string2, int n) {
        try {
            Connection connection = this.getConnection();
            connection.createStatement().execute("REPLACE INTO '" + string + "' (uuid, score) VALUES ('" + string2 + "'," + n + ");");
        }
        catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
    }
}

