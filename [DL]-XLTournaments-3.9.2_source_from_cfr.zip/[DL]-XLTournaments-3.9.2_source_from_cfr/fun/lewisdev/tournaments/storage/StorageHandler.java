/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments.storage;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface StorageHandler {
    public boolean onEnable(XLTournamentsPlugin var1);

    public void onDisable();

    public void createQueueTable();

    public void createTournamentTable(String var1);

    public void addParticipant(String var1, UUID var2);

    public void updateParticipant(String var1, UUID var2, int var3);

    public void clearParticipants(String var1);

    public void clearParticipant(String var1, UUID var2);

    public List<String> getPlayerQueueActions(String var1);

    public void addActionToQueue(String var1, String var2);

    public void removeQueueActions(String var1);

    public Map<UUID, Integer> getTopPlayers(String var1);

    public Map<UUID, Integer> getTopPlayersByScore(String var1, int var2);

    public int getPlayerScore(String var1, String var2);

    public void setPlayerScore(String var1, String var2, int var3);
}

