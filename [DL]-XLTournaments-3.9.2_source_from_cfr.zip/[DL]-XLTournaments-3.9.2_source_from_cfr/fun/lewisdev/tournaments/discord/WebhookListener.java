/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 */
package fun.lewisdev.tournaments.discord;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class WebhookListener
implements Listener {
    private final XLTournamentsPlugin plugin;

    public WebhookListener(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)xLTournamentsPlugin);
    }
}

