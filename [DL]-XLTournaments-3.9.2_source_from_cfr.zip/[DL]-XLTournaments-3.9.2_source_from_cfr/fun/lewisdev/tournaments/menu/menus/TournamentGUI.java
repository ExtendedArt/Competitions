/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.permissions.Permission
 */
package fun.lewisdev.tournaments.menu.menus;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.hook.HookManager;
import fun.lewisdev.tournaments.hook.hooks.VaultHook;
import fun.lewisdev.tournaments.libs.gui.guis.Gui;
import fun.lewisdev.tournaments.libs.gui.guis.GuiItem;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.tournament.TournamentManager;
import fun.lewisdev.tournaments.tournament.TournamentStatus;
import fun.lewisdev.tournaments.utility.ItemStackBuilder;
import fun.lewisdev.tournaments.utility.Messages;
import fun.lewisdev.tournaments.utility.TextUtil;
import java.util.Optional;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.permissions.Permission;

public class TournamentGUI {
    private final XLTournamentsPlugin plugin;

    public TournamentGUI(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
    }

    public void openInventory(Player player) {
        Optional<Tournament> optional;
        FileConfiguration fileConfiguration = this.plugin.getMenuFile().getConfig();
        Gui gui = new Gui(fileConfiguration.getInt("rows"), TextUtil.color(fileConfiguration.getString("title")));
        gui.setDefaultClickAction(inventoryClickEvent -> inventoryClickEvent.setCancelled(true));
        Object object = fileConfiguration.getConfigurationSection("filler_items");
        if (object != null) {
            for (Object object2 : object.getKeys(false)) {
                Object object3 = ItemStackBuilder.getItemStack(fileConfiguration.getConfigurationSection(object.getCurrentPath() + "." + (String)object2));
                ((ItemStackBuilder)object3).withName(fileConfiguration.getString(object.getCurrentPath() + "." + (String)object2 + ".display_name").replace("{PLAYER}", player.getName()));
                ((ItemStackBuilder)object3).withLore(fileConfiguration.getStringList(object.getCurrentPath() + "." + (String)object2 + ".lore").stream().map(string -> string.replace("{PLAYER}", player.getName())).collect(Collectors.toList()));
                optional = new GuiItem(((ItemStackBuilder)object3).build());
                if (fileConfiguration.contains(object.getCurrentPath() + "." + (String)object2 + ".commands")) {
                    ((GuiItem)((Object)optional)).setAction(arg_0 -> TournamentGUI.lambda$openInventory$2(player, fileConfiguration, (ConfigurationSection)object, (String)object2, arg_0));
                }
                if (fileConfiguration.contains(object.getCurrentPath() + "." + (String)object2 + ".slots")) {
                    for (Object object4 : fileConfiguration.getStringList(object.getCurrentPath() + "." + (String)object2 + ".slots")) {
                        gui.setItem(Integer.parseInt((String)object4), (GuiItem)((Object)optional));
                    }
                    continue;
                }
                if (!fileConfiguration.contains(object.getCurrentPath() + "." + (String)object2 + ".slot")) continue;
                int n = fileConfiguration.getInt(object.getCurrentPath() + "." + (String)object2 + ".slot");
                if (n == -1) {
                    gui.getFiller().fill((GuiItem)((Object)optional));
                    continue;
                }
                gui.setItem(n, (GuiItem)((Object)optional));
            }
        }
        object = this.plugin.getTournamentManager();
        ConfigurationSection configurationSection = fileConfiguration.getConfigurationSection("tournament_items");
        if (configurationSection != null) {
            for (Object object3 : configurationSection.getKeys(false)) {
                Object object4;
                optional = ((TournamentManager)object).getTournament((String)object3);
                if (!optional.isPresent()) continue;
                Tournament tournament = optional.get();
                object4 = null;
                TournamentStatus tournamentStatus = tournament.getStatus();
                if (tournamentStatus == TournamentStatus.ACTIVE) {
                    object4 = ItemStackBuilder.getItemStack(fileConfiguration.getConfigurationSection(configurationSection.getCurrentPath() + "." + (String)object3 + ".active"));
                    ((ItemStackBuilder)object4).withLore(TextUtil.setPlaceholders(fileConfiguration.getStringList(configurationSection.getCurrentPath() + "." + (String)object3 + ".active.lore"), player.getUniqueId(), tournament));
                } else if (tournamentStatus == TournamentStatus.WAITING) {
                    object4 = ItemStackBuilder.getItemStack(fileConfiguration.getConfigurationSection(configurationSection.getCurrentPath() + "." + (String)object3 + ".waiting"));
                    ((ItemStackBuilder)object4).withLore(TextUtil.setPlaceholders(fileConfiguration.getStringList(configurationSection.getCurrentPath() + "." + (String)object3 + ".waiting.lore"), player.getUniqueId(), tournament));
                } else if (tournamentStatus == TournamentStatus.ENDED) {
                    object4 = ItemStackBuilder.getItemStack(fileConfiguration.getConfigurationSection(configurationSection.getCurrentPath() + "." + (String)object3 + ".ended"));
                    ((ItemStackBuilder)object4).withLore(TextUtil.setPlaceholders(fileConfiguration.getStringList(configurationSection.getCurrentPath() + "." + (String)object3 + ".ended.lore"), player.getUniqueId(), tournament));
                }
                GuiItem guiItem = new GuiItem(((ItemStackBuilder)object4).build());
                guiItem.setAction(inventoryClickEvent -> {
                    switch (tournamentStatus) {
                        case ACTIVE: {
                            if (tournament.isParticipant(player.getUniqueId())) {
                                Messages.ALREADY_PARTICIPATING.send((CommandSender)player, new Object[0]);
                                gui.close((HumanEntity)player);
                                return;
                            }
                            Permission permission = tournament.getParticipationPermission();
                            if (permission != null && !player.hasPermission(permission)) {
                                Messages.TOURNAMENT_NO_PERMISSION.send((CommandSender)player, new Object[0]);
                                gui.close((HumanEntity)player);
                                return;
                            }
                            HookManager hookManager = this.plugin.getHookManager();
                            double d = tournament.getParticipationCost();
                            if (hookManager.isHookEnabled("Vault") && d > 0.0) {
                                VaultHook vaultHook = (VaultHook)hookManager.getPluginHook("Vault");
                                if (vaultHook.getBalance(player) >= d) {
                                    vaultHook.withdraw(player, d);
                                    tournament.addParticipant(player.getUniqueId(), 0, true);
                                    this.plugin.getActionManager().executeActions(player, tournament.getParticipationActions());
                                    gui.close((HumanEntity)player);
                                    break;
                                }
                                Messages.NOT_ENOUGH_FUNDS.send((CommandSender)player, "{AMOUNT}", String.valueOf(d));
                                gui.close((HumanEntity)player);
                                break;
                            }
                            tournament.addParticipant(player.getUniqueId(), 0, true);
                            this.plugin.getActionManager().executeActions(player, tournament.getParticipationActions());
                            gui.close((HumanEntity)player);
                            break;
                        }
                        case WAITING: {
                            Messages.TOURNAMENT_WAITING.send((CommandSender)player, new Object[0]);
                            gui.close((HumanEntity)player);
                            break;
                        }
                        case ENDED: {
                            Messages.TOURNAMENT_ENDED.send((CommandSender)player, new Object[0]);
                            gui.close((HumanEntity)player);
                        }
                    }
                });
                if (fileConfiguration.contains(configurationSection.getCurrentPath() + "." + (String)object3 + ".slots")) {
                    for (String string2 : fileConfiguration.getStringList(configurationSection.getCurrentPath() + "." + (String)object3 + ".slots")) {
                        gui.setItem(Integer.parseInt(string2), guiItem);
                    }
                    continue;
                }
                if (!fileConfiguration.contains(configurationSection.getCurrentPath() + "." + (String)object3 + ".slot")) continue;
                int n = fileConfiguration.getInt(configurationSection.getCurrentPath() + "." + (String)object3 + ".slot");
                if (n == -1) {
                    gui.getFiller().fill(guiItem);
                    continue;
                }
                gui.setItem(n, guiItem);
            }
        }
        gui.open((HumanEntity)player);
    }

    private static /* synthetic */ void lambda$openInventory$2(Player player, FileConfiguration fileConfiguration, ConfigurationSection configurationSection, String string, InventoryClickEvent inventoryClickEvent) {
        player.closeInventory();
        for (String string2 : fileConfiguration.getStringList(configurationSection.getCurrentPath() + "." + string + ".commands")) {
            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)string2.replace("{PLAYER}", player.getName()));
        }
    }
}

