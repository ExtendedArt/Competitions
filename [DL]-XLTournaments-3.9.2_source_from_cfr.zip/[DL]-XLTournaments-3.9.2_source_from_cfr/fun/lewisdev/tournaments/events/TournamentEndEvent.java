/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package fun.lewisdev.tournaments.events;

import fun.lewisdev.tournaments.tournament.Tournament;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TournamentEndEvent
extends Event {
    private static final HandlerList HANDLERS_LIST = new HandlerList();
    private boolean cancelled = false;
    private Tournament tournament;

    public TournamentEndEvent(Tournament tournament) {
        this.tournament = tournament;
    }

    public Tournament getTournament() {
        return this.tournament;
    }

    public HandlerList getHandlers() {
        return HANDLERS_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS_LIST;
    }
}

