/*
 * Decompiled with CFR 0.150.
 */
package fun.lewisdev.tournaments;

import fun.lewisdev.tournaments.objective.XLObjective;
import fun.lewisdev.tournaments.tournament.Tournament;
import java.util.Optional;

public interface XLTournamentsAPI {
    public void registerObjective(XLObjective var1);

    public void registerObjective(XLObjective var1, String var2);

    public Optional<Tournament> getTournament(String var1);
}

