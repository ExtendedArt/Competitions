/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.action.actions;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.action.Action;
import org.bukkit.entity.Player;

public class CommandAction
implements Action {
    @Override
    public String getIdentifier() {
        return "COMMAND";
    }

    @Override
    public void execute(XLTournamentsPlugin xLTournamentsPlugin, Player player, String string) {
        player.chat((String)(string.contains("/") ? string : "/" + string));
    }
}

