/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.action.actions;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.action.Action;
import fun.lewisdev.tournaments.utility.TextUtil;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class BroadcastMessageAction
implements Action {
    @Override
    public String getIdentifier() {
        return "BROADCAST";
    }

    @Override
    public void execute(XLTournamentsPlugin xLTournamentsPlugin, Player player, String string) {
        block0: {
            Iterator iterator = Bukkit.getOnlinePlayers().iterator();
            if (!iterator.hasNext()) break block0;
            Player player2 = (Player)iterator.next();
            player2.sendMessage(TextUtil.color(string));
        }
    }
}

