/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.action.actions;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.action.Action;
import fun.lewisdev.tournaments.utility.universal.XSound;
import org.bukkit.entity.Player;

public class SoundAction
implements Action {
    @Override
    public String getIdentifier() {
        return "SOUND";
    }

    @Override
    public void execute(XLTournamentsPlugin xLTournamentsPlugin, Player player, String string) {
        try {
            player.playSound(player.getLocation(), XSound.matchXSound(string).get().parseSound(), 1.0f, 1.0f);
        }
        catch (Exception exception) {
            xLTournamentsPlugin.getLogger().warning("Invalid sound name in action: " + string.toUpperCase());
        }
    }
}

