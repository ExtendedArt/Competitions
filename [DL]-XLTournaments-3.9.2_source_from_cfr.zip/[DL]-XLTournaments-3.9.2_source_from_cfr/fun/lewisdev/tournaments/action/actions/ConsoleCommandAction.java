/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.action.actions;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.action.Action;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ConsoleCommandAction
implements Action {
    @Override
    public String getIdentifier() {
        return "CONSOLE";
    }

    @Override
    public void execute(XLTournamentsPlugin xLTournamentsPlugin, Player player, String string) {
        Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)string);
    }
}

