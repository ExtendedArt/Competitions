/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.action;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import org.bukkit.entity.Player;

public interface Action {
    public String getIdentifier();

    public void execute(XLTournamentsPlugin var1, Player var2, String var3);
}

