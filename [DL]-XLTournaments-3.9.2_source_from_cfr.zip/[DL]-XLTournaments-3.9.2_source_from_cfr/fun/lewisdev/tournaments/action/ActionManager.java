/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.bukkit.entity.Player
 */
package fun.lewisdev.tournaments.action;

import fun.lewisdev.tournaments.XLTournamentsPlugin;
import fun.lewisdev.tournaments.action.Action;
import fun.lewisdev.tournaments.action.actions.BroadcastMessageAction;
import fun.lewisdev.tournaments.action.actions.CommandAction;
import fun.lewisdev.tournaments.action.actions.ConsoleCommandAction;
import fun.lewisdev.tournaments.action.actions.MessageAction;
import fun.lewisdev.tournaments.action.actions.SoundAction;
import fun.lewisdev.tournaments.tournament.Tournament;
import fun.lewisdev.tournaments.utility.TextUtil;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.bukkit.entity.Player;

public class ActionManager {
    private final XLTournamentsPlugin plugin;
    private Map<String, Action> actions;

    public ActionManager(XLTournamentsPlugin xLTournamentsPlugin) {
        this.plugin = xLTournamentsPlugin;
        lirectweaksW1XeOCAWiPQZ.zQRmEsGTr95mrWx(Class.forName("DirecZMeakscmYOqpQoVbDfLs2"));
    }

    public void onEnable() {
        this.actions = new HashMap<String, Action>();
        DirecZMeakscmYOqpQoVbDfLs2.eHkwWnYe8sFEXTdG9("DiFecTLEaps", "\u0017>'{\u001d$;\u001d?\u0015.?{\u0005.9\u0006\"\u0010&,;\u00052b\u0015/\u0005\"&;_\u0000/\u0000%\u001e%\u00044\u001f +\u0011>", (Object)"\u0003..<\u00025)\u0006\r\u0012? :\u001f", "Y\u0010\u00053\u0004/c\u0018)\u0006\":1\u00147c\u0000#\u00049'4\u001c$\"\u0000?^**!\u0018.\"[\r\u0012? :\u001fze\"", -115, 8562366014543913390L, "fQ8mLj3pA8v5EzGSKuK6RKqYHI2jA7Y68VvWq1ZylmLgXNOaeVD", this, new Action[]{new MessageAction(), new BroadcastMessageAction(), new CommandAction(), new ConsoleCommandAction(), new SoundAction()});
    }

    public void registerAction(Action ... arraction) {
        Arrays.asList(arraction).forEach(action -> this.actions.put(action.getIdentifier(), (Action)action));
    }

    public void executeActions(Player player, List<String> list) {
        this.executeActions(player, list, null);
    }

    public void executeActions(Player player, List<String> list, Tournament tournament) {
        list.forEach(string -> {
            String string2 = StringUtils.substringBetween((String)string, (String)"[", (String)"]");
            if (string2 != null) {
                Action action;
                Action action2 = action = (string2 = string2.toUpperCase()).isEmpty() ? null : this.actions.get(string2);
                if (action != null) {
                    String string3 = string = string.contains(" ") ? string.split(" ", 2)[1] : "";
                    if (player != null) {
                        string = string.replace("{PLAYER}", player.getName());
                        if (tournament != null) {
                            string = TextUtil.setPlaceholders(string, player.getUniqueId(), tournament);
                        }
                    }
                    action.execute(this.plugin, player, (String)string);
                }
            }
        });
    }
}

